﻿namespace cad
{
    partial class Setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_ok = new Button();
            button_cancel = new Button();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            label_epsg = new Label();
            textBox_epsg = new TextBox();
            comboBox_Unit = new ComboBox();
            label_unit = new Label();
            comboBox_Epsg = new ComboBox();
            label_projection = new Label();
            tabPage2 = new TabPage();
            panel1 = new Panel();
            tabPage3 = new TabPage();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // button_ok
            // 
            button_ok.Dock = DockStyle.Right;
            button_ok.Location = new Point(630, 0);
            button_ok.Name = "button_ok";
            button_ok.Size = new Size(85, 30);
            button_ok.TabIndex = 0;
            button_ok.Text = "확인";
            button_ok.UseVisualStyleBackColor = true;
            button_ok.Click += button_ok_Click;
            // 
            // button_cancel
            // 
            button_cancel.Dock = DockStyle.Right;
            button_cancel.Location = new Point(715, 0);
            button_cancel.Name = "button_cancel";
            button_cancel.Size = new Size(85, 30);
            button_cancel.TabIndex = 0;
            button_cancel.Text = "취소";
            button_cancel.UseVisualStyleBackColor = true;
            button_cancel.Click += button_cancel_Click;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(800, 450);
            tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(label_epsg);
            tabPage1.Controls.Add(textBox_epsg);
            tabPage1.Controls.Add(comboBox_Unit);
            tabPage1.Controls.Add(label_unit);
            tabPage1.Controls.Add(comboBox_Epsg);
            tabPage1.Controls.Add(label_projection);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(792, 422);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "좌표계";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // label_epsg
            // 
            label_epsg.AutoSize = true;
            label_epsg.Location = new Point(334, 33);
            label_epsg.Name = "label_epsg";
            label_epsg.Size = new Size(38, 15);
            label_epsg.TabIndex = 6;
            label_epsg.Text = "EPSG:";
            // 
            // textBox_epsg
            // 
            textBox_epsg.Font = new Font("맑은 고딕", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox_epsg.Location = new Point(379, 29);
            textBox_epsg.Name = "textBox_epsg";
            textBox_epsg.Size = new Size(172, 25);
            textBox_epsg.TabIndex = 5;
            // 
            // comboBox_Unit
            // 
            comboBox_Unit.FormattingEnabled = true;
            comboBox_Unit.Location = new Point(85, 75);
            comboBox_Unit.Name = "comboBox_Unit";
            comboBox_Unit.Size = new Size(202, 23);
            comboBox_Unit.TabIndex = 4;
            // 
            // label_unit
            // 
            label_unit.AutoSize = true;
            label_unit.Location = new Point(23, 75);
            label_unit.Name = "label_unit";
            label_unit.Size = new Size(38, 15);
            label_unit.TabIndex = 3;
            label_unit.Text = "단위: ";
            // 
            // comboBox_Epsg
            // 
            comboBox_Epsg.FormattingEnabled = true;
            comboBox_Epsg.Location = new Point(85, 29);
            comboBox_Epsg.Name = "comboBox_Epsg";
            comboBox_Epsg.Size = new Size(202, 23);
            comboBox_Epsg.TabIndex = 2;
            comboBox_Epsg.SelectedIndexChanged += comboBox_Epsg_SelectedIndexChanged;
            // 
            // label_projection
            // 
            label_projection.AutoSize = true;
            label_projection.Location = new Point(23, 32);
            label_projection.Name = "label_projection";
            label_projection.Size = new Size(46, 15);
            label_projection.TabIndex = 1;
            label_projection.Text = "좌표계:";
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(792, 422);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "일반";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.Controls.Add(button_ok);
            panel1.Controls.Add(button_cancel);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 420);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 30);
            panel1.TabIndex = 2;
            // 
            // tabPage3
            // 
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(792, 422);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "레이어";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // Setting
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Controls.Add(tabControl1);
            Name = "Setting";
            Text = "Setting";
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button button_ok;
        private Button button_cancel;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Panel panel1;
        private ComboBox comboBox_Epsg;
        private Label label_projection;
        private Label label_unit;
        private ComboBox comboBox_Unit;
        private Label label_epsg;
        private TextBox textBox_epsg;
        private TabPage tabPage3;
    }
}