using WeifenLuo.WinFormsUI.Docking;

namespace cad;

// DockPanel 안에서 하나의 .cad 도면 탭을 표현합니다.
// 저장 전에는 파일을 디스크에 만들지 않고 제목 끝의 *로 미저장 상태만 표시합니다.
internal sealed class CadDocument : DockContent, IViewportDocument
{
    private readonly CadCanvas canvas;

    internal string? FilePath { get; private set; }
    internal bool IsDirty { get; private set; }

    internal CadDocument(IList<DxfEditPoint> points, DxfEditStyle style, string title = "새 도면 1.cad")
    {
        Text = title + "*";
        TabText = Text;
        DockAreas = DockAreas.Document | DockAreas.Float;

        canvas = new CadCanvas(points, style)
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(43, 61, 88)
        };
        canvas.DrawingChanged += (_, _) => MarkChanged();
        Controls.Add(canvas);
    }

    public void ZoomIn() => canvas.ZoomIn();
    public void ZoomOut() => canvas.ZoomOut();

    internal void SetPointLineMode(bool enabled, DxfEditStyle style) => canvas.SetPointLineMode(enabled, style);
    internal void UpdatePointLineStyle(DxfEditStyle style) => canvas.UpdateStyle(style);
    internal void RefreshCanvas() => canvas.Invalidate();

    // 이후 저장 기능에서 호출하면 탭 제목을 실제 저장 파일명으로 바꿉니다.
    internal void SetSavedFile(string path)
    {
        FilePath = Path.GetFullPath(path);
        IsDirty = false;
        Text = Path.GetFileName(FilePath);
        TabText = Text;
    }

    // 이후 점·선이 추가될 때 호출할 미저장 상태 표시 함수입니다.
    internal void MarkChanged()
    {
        IsDirty = true;
        if (!Text.EndsWith('*'))
        {
            Text += "*";
            TabText = Text;
        }
    }
}
