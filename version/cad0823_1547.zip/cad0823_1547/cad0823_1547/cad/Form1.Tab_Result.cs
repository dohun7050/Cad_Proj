﻿namespace cad;

public partial class Form1
{
    // 결과 출력 탭의 노선 비교·보고서·도면 생성·검토 버튼에 아이콘을 적용합니다.
    private void ConfigureResultTab()
    {
        ConfigureRibbonButton(menuOutput, "route_compare.png");
        ConfigureRibbonButton(menuReport, "report.png");
        ConfigureRibbonButton(menuDrawing, "drawing.png");
        ConfigureRibbonButton(menuReview, "review.png");
    }
}
