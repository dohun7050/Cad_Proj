﻿using System.Diagnostics;
using System.Runtime.InteropServices;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

public partial class Form1
{
    // 최대화하기 전의 창 위치와 크기를 저장합니다.
    private Rectangle normalWindowBounds;

    // 현재 창이 작업표시줄을 제외한 작업영역 크기로 최대화되었는지 나타냅니다.
    private bool isWorkingAreaMaximized;

    // 사용자 정의 최소화 버튼을 누르면 메인 창을 작업표시줄로 최소화합니다.
    private void MinimizeButton_Click(object? sender, EventArgs e) => WindowState = FormWindowState.Minimized;

    // 테두리 없는 창을 작업표시줄을 제외한 Windows 작업영역 안에서 최대화하거나 원래 크기로 복원합니다.
    private void MaximizeButton_Click(object? sender, EventArgs e)
    {
        if (isWorkingAreaMaximized)
        {
            Bounds = normalWindowBounds;
            isWorkingAreaMaximized = false;
            maximizeButton.Text = "□";
            return;
        }

        normalWindowBounds = Bounds;
        WindowState = FormWindowState.Normal;
        Bounds = Screen.FromControl(this).WorkingArea;
        isWorkingAreaMaximized = true;
        maximizeButton.Text = "❐";
    }
    // 사용자 정의 닫기 버튼을 누르면 메인 창을 종료합니다.
    private void CloseButton_Click(object? sender, EventArgs e) => Close();

    // 제목 표시줄을 두 번 클릭하면 최대화와 원래 크기 복원을 전환합니다.
    private void HeaderPanel_DoubleClick(object? sender, EventArgs e) => MaximizeButton_Click(sender, e);

    // 제목 표시줄을 마우스로 누르고 움직일 때 테두리 없는 창을 드래그할 수 있게 합니다.
    private void HeaderPanel_MouseDown(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;

        // 최대화 상태에서 바로 드래그하면 먼저 원래 크기로 복원합니다.
        if (isWorkingAreaMaximized) MaximizeButton_Click(sender, e);
        ReleaseCapture();
        SendMessage(Handle, 0xA1, 0x2, 0);
    }

    // Windows에 잡힌 현재 마우스 캡처를 해제합니다.
    [DllImport("user32.dll")]
    private static extern bool ReleaseCapture();

    // Windows 창에 시스템 메시지를 전달하여 창 이동 동작을 실행합니다.
    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr handle, int message, int wParam, int lParam);
}
