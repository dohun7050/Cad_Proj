﻿using WeifenLuo.WinFormsUI.Docking;

namespace cad;

internal sealed class GeoVectorDocument : DockContent, IViewportDocument
{
    private readonly GeoCanvas canvas;
    internal string DocumentPath { get; }

    internal GeoVectorDocument(GeoLayerData data, string filePath)
    {
        DocumentPath = Path.GetFullPath(filePath);
        Text = Path.GetFileName(filePath);
        TabText = Text;
        DockAreas = DockAreas.Document | DockAreas.Float;
        canvas = new GeoCanvas(data) { Dock = DockStyle.Fill };
        Controls.Add(canvas);
    }

    internal void FitAll() => canvas.FitAll();
    public void ZoomIn() => canvas.ZoomIn();
    public void ZoomOut() => canvas.ZoomOut();

    
}

internal sealed class GeoCanvas : Canvas
{
    private const float MarginSize = 35f;
    private readonly GeoLayerData data;
    private readonly GeoBounds bounds;
    private float zoom = 1f;
    private PointF pan;

    internal GeoCanvas(GeoLayerData layerData)
    {
        data = layerData;
        if (!GeoBounds.TryCreate(data.Features, out bounds))
            throw new InvalidDataException("표시할 좌표가 없습니다.");
        BackColor = Color.FromArgb(246, 248, 250);
    }

    internal void FitAll()
    {
        zoom = 1f;
        pan = PointF.Empty;
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        using var linePen = new Pen(data.DisplayColor, 2f);
        using var fillBrush = new SolidBrush(Color.FromArgb(55, data.DisplayColor));
        using var pointBrush = new SolidBrush(data.DisplayColor);

        foreach (GeoFeature feature in data.Features)
        foreach (IReadOnlyList<GeoPoint> part in feature.Parts)
        {
            PointF[] points = part.Select(Project).ToArray();
            if (points.Length == 0) continue;
            if (feature.Kind == GeoGeometryKind.Point)
            {
                foreach (PointF point in points)
                    e.Graphics.FillEllipse(pointBrush, point.X - 4, point.Y - 4, 8, 8);
            }
            else if (feature.Kind == GeoGeometryKind.Polygon && points.Length >= 3)
            {
                e.Graphics.FillPolygon(fillBrush, points);
                e.Graphics.DrawPolygon(linePen, points);
            }
            else if (points.Length >= 2)
            {
                e.Graphics.DrawLines(linePen, points);
            }
        }
    }

    private PointF Project(GeoPoint point)
    {
        double worldWidth = Math.Max(bounds.Width, 1e-12);
        double worldHeight = Math.Max(bounds.Height, 1e-12);
        double availableWidth = Math.Max(Width - MarginSize * 2, 1);
        double availableHeight = Math.Max(Height - MarginSize * 2, 1);
        double scale = Math.Min(availableWidth / worldWidth, availableHeight / worldHeight) * zoom;
        double drawnWidth = bounds.Width * scale;
        double drawnHeight = bounds.Height * scale;
        float x = (float)((point.X - bounds.MinX) * scale + (Width - drawnWidth) / 2 + pan.X);
        float y = (float)((bounds.MaxY - point.Y) * scale + (Height - drawnHeight) / 2 + pan.Y);
        return new PointF(x, y);
    }
    protected override void ApplyPan(int deltaX, int deltaY)
    {
        pan.X += deltaX;
        pan.Y += deltaY;
    }

    protected override void ApplyZoom(Point screenPoint, double factor)
    {
        float previousZoom = zoom;
        zoom = Math.Clamp(zoom * (float)factor, 0.1f, 100f);
        float applied = zoom / previousZoom;
        pan.X = screenPoint.X - (screenPoint.X - pan.X) * applied;
        pan.Y = screenPoint.Y - (screenPoint.Y - pan.Y) * applied;
    }
}
