﻿namespace cad;

public partial class Form1
{
    // 리본 도구 버튼이 눌린 상태임을 마우스 효과 함수에 알리는 태그 값입니다.
    private const string PressedRibbonButtonTag = "PressedRibbonButton";

    // 사용자가 상단 탭을 변경하면 선택한 탭 번호에 맞는 리본 메뉴를 표시합니다.
    private void TabChanged(object? sender, EventArgs e) => ShowMenu(tabControl1.SelectedIndex);

    // 지정한 탭의 리본 패널만 표시하고 하단 작업 상태를 함께 갱신합니다.
    private void ShowMenu(int index)
    {
        fileMenu.Visible = index == 0; editMenu.Visible = index == 1; routeMenu.Visible = index == 2;
        designMenu.Visible = index == 3; outputMenu.Visible = index == 4;
        if (index == 0) fileMenu.BringToFront();
        else if (index == 1) editMenu.BringToFront();
        else if (index == 2) routeMenu.BringToFront(); else if (index == 3) designMenu.BringToFront(); else outputMenu.BringToFront();
        UpdateBottomStatus(index);
    }

    // 모든 탭의 버튼에 지정된 아이콘과 공통 리본 스타일을 적용합니다.
    private void ApplyRibbonStyle()
    {
        ConfigureFileTab(); ConfigureEditTab(); ConfigurePathTab(); ConfigureDesignTab(); ConfigureResultTab();
    }

    // 버튼에 Icons 폴더의 이미지를 적용하고 정렬·여백·마우스 효과를 설정합니다.
    private static void ConfigureRibbonButton(Button button, string fileName)
    {
        string path = Path.Combine(AppContext.BaseDirectory, "Icons", fileName);
        if (File.Exists(path)) { using Image image = Image.FromFile(path); 
            button.Image = new Bitmap(image, new Size(28, 28)); }
        button.ImageAlign = ContentAlignment.TopCenter; 
        button.TextAlign = ContentAlignment.BottomCenter;
        button.TextImageRelation = TextImageRelation.Overlay; 
        button.Padding = new Padding(4, 2, 4, 20);
        button.Margin = new Padding(4, 2, 4, 2); 
        button.FlatAppearance.BorderSize = 0; 
        button.Cursor = Cursors.Hand;
        button.MouseEnter += RibbonButton_MouseEnter; 
        button.MouseLeave += RibbonButton_MouseLeave;
    }
    // 마우스가 리본 버튼 위에 올라오면 강조 배경색으로 변경합니다.
    private static void RibbonButton_MouseEnter(object? sender, EventArgs e)
    {
        if (sender is Button b && !Equals(b.Tag, PressedRibbonButtonTag))
            b.BackColor = Color.FromArgb(228, 239, 252);
    }

    // 마우스가 리본 버튼에서 벗어나면 기본 배경색으로 복원합니다.
    private static void RibbonButton_MouseLeave(object? sender, EventArgs e)
    {
        if (sender is Button b && !Equals(b.Tag, PressedRibbonButtonTag))
            b.BackColor = Color.FromArgb(247, 250, 253);
    }
}
