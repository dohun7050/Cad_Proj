namespace cad;

// 우리 프로그램의 .cad 작업 파일에서 사용자 점·선·도형을 표시할 전용 캔버스입니다.
internal sealed class CadCanvas : Canvas
{
    private readonly IList<DxfEditPoint> points;
    private double zoom = 1.0;
    private PointF pan;
    private DxfEditStyle style;
    private bool isPointLineMode;

    internal event EventHandler? DrawingChanged;

    internal CadCanvas(IList<DxfEditPoint> points, DxfEditStyle style)
    {
        this.points = points;
        this.style = style;
    }

    // 점/선 도구가 켜진 동안에는 왼쪽 클릭이 화면 이동이 아니라 새 점 입력입니다.
    protected override bool UsesAutomaticPanning => !isPointLineMode;

    internal void SetPointLineMode(bool enabled, DxfEditStyle newStyle)
    {
        isPointLineMode = enabled;
        style = newStyle;
        Cursor = enabled ? Cursors.Cross : Cursors.Default;
        Invalidate();
    }

    internal void UpdateStyle(DxfEditStyle newStyle)
    {
        style = newStyle;
        Invalidate();
    }

    protected override void ApplyZoom(Point screenPoint, double factor)
    {
        double previousZoom = zoom;
        zoom = Math.Clamp(zoom * factor, 0.1, 100.0);
        double appliedFactor = zoom / previousZoom;
        pan.X = (float)(screenPoint.X - (screenPoint.X - pan.X) * appliedFactor);
        pan.Y = (float)(screenPoint.Y - (screenPoint.Y - pan.Y) * appliedFactor);
    }

    protected override void ApplyPan(int deltaX, int deltaY)
    {
        pan.X += deltaX;
        pan.Y += deltaY;
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (isPointLineMode && e.Button == MouseButtons.Left)
        {
            points.Add(ToWorldPoint(e.Location));
            DrawingChanged?.Invoke(this, EventArgs.Empty);
            Invalidate();
            return;
        }

        base.OnMouseDown(e);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        if (isPointLineMode && e.Button == MouseButtons.Left)
        {
            Cursor = Cursors.Cross;
            return;
        }

        base.OnMouseUp(e);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        using var linePen = new Pen(style.LineColor, style.LineWidth);
        using var pointBrush = new SolidBrush(style.PointColor);

        for (int index = 1; index < points.Count; index++)
            e.Graphics.DrawLine(linePen, ToScreenPoint(points[index - 1]), ToScreenPoint(points[index]));

        foreach (DxfEditPoint point in points)
        {
            PointF screen = ToScreenPoint(point);
            float radius = Math.Max(1F, style.PointSize / 2F);
            e.Graphics.FillEllipse(pointBrush, screen.X - radius, screen.Y - radius, radius * 2F, radius * 2F);
        }
    }

    private PointF ToScreenPoint(DxfEditPoint point) => new(
        (float)(point.X * zoom + pan.X),
        (float)(Height - point.Y * zoom + pan.Y));

    private DxfEditPoint ToWorldPoint(Point screenPoint) => new(
        (screenPoint.X - pan.X) / zoom,
        (Height + pan.Y - screenPoint.Y) / zoom);
}
