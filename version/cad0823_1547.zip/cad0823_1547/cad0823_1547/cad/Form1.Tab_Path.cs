﻿namespace cad;

public partial class Form1
{
    // 전처리/노선 탭의 지형·수권·환경·제약조건·노선 탐색 버튼에 아이콘을 적용합니다.
    private void ConfigurePathTab()
    {
        ConfigureRibbonButton(menuTerrain, "terrain.png");
        ConfigureRibbonButton(menuHydrology, "hydrology.png");
        ConfigureRibbonButton(menuEnvironment, "environment.png");
        ConfigureRibbonButton(menuConstraint, "constraint.png");
        ConfigureRibbonButton(menuRouteSearch, "route.png");
        ConfigureRibbonButton(menuAlignment, "alignment.png");
    }
}
