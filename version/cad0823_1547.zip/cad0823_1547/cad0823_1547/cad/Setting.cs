﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace cad
{
    public partial class Setting : Form
    {
        private Form1 f1;
        public Setting()
        {
            InitializeComponent();
            Combobox_Epsg_Setting();
            Combobox_Unit_Setting();
        }
        public Setting(Form1 form1)
        {
            InitializeComponent();
            Combobox_Epsg_Setting();
            Combobox_Unit_Setting();
            f1 = form1;
            int index;
            switch (f1.epsg)
            {
                case null:
                    index = 0;
                    break;
                case 5179:
                    index = 1;
                    break;
                case 5186:
                    index = 2;
                    break;
                case 4326:
                    index = 3;
                    break;
                default:
                    index = 4;
                    textBox_epsg.Text = f1.epsg.Value.ToString();
                    break;
            }
            comboBox_Epsg.SelectedIndex = index;
            

        }
        private void button_ok_Click(object sender, EventArgs e)
        {
            int index = comboBox_Epsg.SelectedIndex;
            switch (index)
            {
                case 0:
                    f1.SetEpsg(null);
                    break;
                case 1:
                    f1.SetEpsg(5179);
                    break;
                case 2:
                    f1.SetEpsg(5186);
                    break;
                case 3:
                    f1.SetEpsg(4326);
                    break;
                case 4:
                    if(!int.TryParse(textBox_epsg.Text,out int i))
                    {
                        MessageBox.Show("EPSG 번호를 숫자로 입력하세요.");
                        return;
                    }
                    f1.SetEpsg(i);
                    break;
            }
            this.Close();
        }
        private void button_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Combobox_Epsg_Setting()
        {
            comboBox_Epsg.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_Epsg.Items.Add("좌표계 미지정");
            comboBox_Epsg.Items.Add("EPSG : 5179");
            comboBox_Epsg.Items.Add("EPSG : 5186");
            comboBox_Epsg.Items.Add("EPSG:4326 - WGS84 위경도");
            comboBox_Epsg.Items.Add("직접 EPSG 입력");

            comboBox_Epsg.SelectedIndex = 0;

            
        }

        private void Combobox_Unit_Setting()
        {
            comboBox_Unit.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_Unit.Items.Add("meter (m)");

            comboBox_Unit.SelectedIndex = 0;
        }

        private void comboBox_Epsg_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_Epsg.SelectedIndex == 4)
            {
                label_epsg.Visible = true;
                textBox_epsg.Visible = true;
            }
            else
            {
                label_epsg.Visible = false;
                textBox_epsg.Visible = false;
            }
        }

        
    }
}
