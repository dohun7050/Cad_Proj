﻿using IxMilia.Dxf;
using IxMilia.Dxf.Entities;
using cad.Importers;
using cad.Models;
using WeifenLuo.WinFormsUI.Docking;
using System.Text;
using System.Drawing.Imaging;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using System.Net.Http;

namespace cad;
public partial class Form1 {

    private readonly List<ProjectLayer> l = new();

    // 중앙 패널의 각 지도 문서가 마지막으로 저장된 PNG/JPG 경로를 기억하기 위해 추가했습니다.
    // 최초 저장은 경로를 선택하고 이후 Ctrl+S 또는 저장 버튼은 같은 경로에 덮어씁니다.
    private readonly Dictionary<Control, string> mapImageSavePaths = new();

    private void ConfigureFileTab() { 
        ConfigureRibbonButton(menuFile,"new_project.png"); 
        ConfigureRibbonButton(menuOpen,"open.png"); 
        ConfigureRibbonButton(menuAerialPhoto,"globe.png");
        ConfigureRibbonButton(menuNgiiPortal,"globe.png");
        ConfigureRibbonButton(menuSave,"save.png"); 
        ConfigureRibbonButton(menuSaveAs,"save.png");
        ConfigureRibbonButton(menuExport,"export.png");
        ConfigureRibbonButton(menuSetting, "settings.png");

        // 디자이너에 배치한 새 버튼과 저장 단축키를 Tab_File 기능에 연결합니다.
        menuAerialPhoto.Click += menuAerialPhoto_Click;
        menuNgiiPortal.Click += menuNgiiPortal_Click;
        menuSave.Click += menuSave_Click;
        menuSaveAs.Click += menuSaveAs_Click;
        menuExport.Click += menuExport_Click;
        KeyPreview = true;
        KeyDown += FormFileShortcut_KeyDown;
    }
    private void menuOpen_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog
        {
            Title = "파일 열기",
            Filter = "지원 파일 (*.cad;*.dxf;*.shp;*.kmz;*.txt;*.las;*.laz;*.dem;*.tif;*.tiff;*.asc)|*.cad;*.dxf;*.shp;*.kmz;*.txt;*.las;*.laz;*.dem;*.tif;*.tiff;*.asc|임도 CAD 작업 파일 (*.cad)|*.cad|DXF 파일 (*.dxf)|*.dxf|Shapefile (*.shp)|*.shp|KMZ 파일 (*.kmz)|*.kmz|LAS 파일 (*.las;*.laz)|*.las;*.laz|DEM 파일 (*.dem;*.tif;*.tiff;*.asc)|*.dem;*.tif;*.tiff;*.asc|텍스트 파일 (*.txt)|*.txt|모든 파일 (*.*)|*.*",
            InitialDirectory = projectRoot,
            Multiselect = false
        };

        if(dialog.ShowDialog() != DialogResult.OK)
        {
            return;
        }

        // .cad는 별도 문서 탭이 아니라 프로그램 전체의 공용 CAD 작업 모델로 불러옵니다.
        if (IsCadDocument(dialog.FileName))
        {
            OpenCadWorkspace(dialog.FileName);
            return;
        }

        // TXT 파일은 DXF 전용 DxfImporter로 전달하면 불러오기 오류가 발생하므로 먼저 확장자를 구분합니다.
        // 기존 프로젝트 탐색기와 동일한 OpenTextDocument 함수를 호출하여 중앙 DockPanel 문서 탭으로 엽니다.
        if (IsTextDocument(dialog.FileName))
        {
            OpenTextDocument(dialog.FileName);
            return;
        }

        // LAS·DEM은 DXF 전용 Importer가 처리할 수 없으므로 Tab_Edit에 추가한 지형 작업 문서로 전달합니다.
        if (IsLasOrDemDocument(dialog.FileName))
        {
            OpenLasOrDemDocument(dialog.FileName);
            return;
        }

        // SHP와 KMZ는 기존 화면 구성을 변경하지 않고 중앙 DockPanel의 단일 지도 문서로 엽니다.
        if (IsGeoVectorDocument(dialog.FileName))
        {
            OpenGeoVectorDocument(dialog.FileName);
            return;
        }

        // 같은 DXF가 여러 탭으로 중복 생성되는 것을 막기 위해 가져오기 전에 열린 문서의 전체 경로를 검사합니다.
        // 이미 열려 있다면 기존 문서 탭만 활성화하고 아래의 기존 DXF 불러오기 코드는 실행하지 않습니다.
        if (TryActivateOpenedDxfDocument(dialog.FileName))
        {
            return;
        }

        var importer = new DxfImporter();
        ImportResult result = importer.Import(dialog.FileName);
        if (!result.IsSuccess)
        {
            MessageBox.Show( result.Message, "DXF 불러오기 오류", MessageBoxButtons.OK, MessageBoxIcon.Error );
            return;
        }
        if (result.Layer is not null)
        {
            l.Add(result.Layer);
        }
        // 레이어 원본 데이터가 DxfFile이면 중앙 DockPanel 탭 열기
        if (result.Layer?.SourceData is DxfFile dxfFile)
        {
            int line = dxfFile.Entities.OfType<DxfLine>().Count();
            int pline = dxfFile.Entities.OfType<DxfPolyline>().Count();
            int lw_pline = dxfFile.Entities.OfType<DxfLwPolyline>().Count();

            double minX = double.MaxValue;
            double minY = double.MaxValue;
            double maxX = double.MinValue;
            double maxY = double.MinValue;

            void Total_Area(double x, double y)
            {
                if (x < minX) minX = x;
                if (y < minY) minY = y;
                if (x > maxX) maxX = x;
                if (y > maxY) maxY = y;
            }
            // 하단 상태 패널 오른쪽에 현재 DXF의 객체 개수를 표시합니다.
            label1.Text = $"객체: {dxfFile.Entities.Count}  |  선: {line}  |  폴리선: {pline + lw_pline}  |  영역: 0";
            //int text = dxfFile.Entities.OfType<DxfText>().Count(entity => entity is DxfText || entity is DxfMText); 
            MessageBox.Show($"전체 객체 : {dxfFile.Entities.Count}");
            var str = new StringBuilder();
            int count = 0;
            foreach(var en in dxfFile.Entities)
            {
               
                string layer_name = en.Layer;
                if (en is DxfLine l)
                {
                    // Line의 시작점(P1) 좌표
                    double sX = l.P1.X;
                    double sY = l.P1.Y;

                    // Line의 끝점은 P1이 아니라 P2
                    double eX = l.P2.X;
                    double eY = l.P2.Y;

                    // 시작점과 끝점을 전체 도면 범위에 포함
                    Total_Area(sX, sY);
                    Total_Area(eX, eY);
                    //MessageBox.Show($"레이어 : {layer_name}\t 시작점 {sX},{sY}");
                }
                else if(en is DxfLwPolyline lwp)
                {
                    // LwPolyline을 구성하는 모든 꼭짓점을 확인
                    foreach( var v in lwp.Vertices)
                    {
                        double x = v.X;
                        double y = v.Y;

                        // 현재 꼭짓점을 전체 도면 범위에 포함
                        Total_Area(x, y);
                    }
                    //MessageBox.Show($"레이어 : {layer_name}");
                }
                else if (en is DxfPolyline pl)
                {
                    // 일반 Polyline의 좌표는 Vertex 안의 Location에 
                    foreach (var v in pl.Vertices)
                    {
                        double x = v.Location.X;
                        double y = v.Location.Y;

                        // 현재 꼭짓점을 전체 도면 범위에 포함합니다.
                        Total_Area(x, y);
                    }
                }
                count++;
            }

            double totalWidth = maxX - minX;
            double totalHeight = maxY - minY;

            // 전체 Line과 Polyline을 검사한 좌표 범위를 확인
            //MessageBox.Show(
            //    $"X 범위: {minX:N2} ~ {maxX:N2}\n" +
            //    $"Y 범위: {minY:N2} ~ {maxY:N2}\n" +
            //    $"도면 폭: {totalWidth:N2}\n" +
            //    $"도면 높이: {totalHeight:N2}",
            //    "전체 좌표 범위"
            //);
            // 파일 메뉴로 연 DXF도 중앙 CAD와 동일한 실제 X·Y 좌표계를 사용하도록 맞춥니다.
            SynchronizeCadWorkspaceWithDxfBounds(minX, minY, maxX, maxY);

            var dxfDocument = new Docment_Dxf(
                dxfFile,
                result.Layer.Name,
                minX,
                minY,
                maxX,
                maxY
            );

            // 다음 파일 열기에서 동일 DXF인지 비교할 수 있도록 새 문서에 정규화된 전체 경로를 기록합니다.
            dxfDocument.SetDocumentPath(Path.GetFullPath(dialog.FileName));
            dxfDocument.Show(dockPanel1, DockState.Document);
            dxfDocument.Activate();
            ApplyCadWorkspaceToActiveDxf();
        }
        
    }

    // [추가 기능] 이미 열린 DXF 문서를 전체 경로로 찾아 활성화합니다.
    // 파일 이름만 비교하면 서로 다른 폴더의 동명 파일을 같은 문서로 오인할 수 있어 전체 경로 비교 방식으로 추가했습니다.
    private bool TryActivateOpenedDxfDocument(string path)
    {
        string fullPath = Path.GetFullPath(path);
        Docment_Dxf? openedDocument = dockPanel1.Documents
            .OfType<Docment_Dxf>()
            .FirstOrDefault(document => string.Equals(
                document.GetDocumentPath(),
                fullPath,
                StringComparison.OrdinalIgnoreCase));

        if (openedDocument is null)
        {
            return false;
        }

        openedDocument.Activate();
        return true;
    }

    // [추가 기능] 저장 버튼은 현재 문서의 기존 저장 경로가 있으면 바로 덮어쓰고 없으면 경로 선택창을 엽니다.
    private void menuSave_Click(object? sender, EventArgs e)
    {
        SaveActiveMapDocument(forceSaveAs: false);
    }

    // [추가 기능] 다른 이름으로 저장 버튼은 기존 경로와 관계없이 항상 새 PNG/JPG 경로를 선택합니다.
    private void menuSaveAs_Click(object? sender, EventArgs e)
    {
        SaveActiveMapDocument(forceSaveAs: true);
    }

    // [추가 기능] 메인 폼에서 Ctrl+S를 감지해 저장 버튼과 동일한 덮어쓰기 흐름을 실행합니다.
    private void FormFileShortcut_KeyDown(object? sender, KeyEventArgs e)
    {
        if (!e.Control || e.KeyCode != Keys.S) return;
        SaveActiveMapDocument(forceSaveAs: false);
        e.SuppressKeyPress = true;
    }

    // [추가 기능] 중앙 패널의 DXF·LAS·DEM·항공사진 문서를 PNG/JPG 이미지로 저장합니다.
    // 최초 저장 또는 다른 이름으로 저장에서는 경로를 선택하고, 일반 저장에서는 문서별 최근 경로를 재사용합니다.
    private void SaveActiveMapDocument(bool forceSaveAs)
    {
        if (dockPanel1.ActiveDocument is not Control activeDocument || !IsMapImageSaveTarget(activeDocument))
        {
            MessageBox.Show("먼저 중앙 패널에서 DXF, LAS 또는 DEM 문서를 선택해 주세요.", "이미지 저장", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        string? savePath = null;
        if (!forceSaveAs) mapImageSavePaths.TryGetValue(activeDocument, out savePath);
        if (string.IsNullOrWhiteSpace(savePath))
        {
            savePath = SelectMapImageSavePath(activeDocument);
            if (savePath is null) return;
        }

        try
        {
            SaveControlAsImage(activeDocument, savePath);
            mapImageSavePaths[activeDocument] = savePath;
            statusLabel.Text = $"이미지 저장 완료: {savePath}";
        }
        catch (Exception exception)
        {
            MessageBox.Show(exception.Message, "이미지 저장 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    // 중앙 패널의 TXT 편집기는 제외하고 지도 화면을 제공하는 문서 형식만 이미지 저장 대상으로 판단합니다.
    private static bool IsMapImageSaveTarget(Control document)
    {
        return document is Docment_Dxf
            || document is TerrainEditDocument
            || document is GeoVectorDocument;
    }

    // 최초 저장과 다른 이름으로 저장에 사용할 PNG/JPG 파일 경로를 사용자에게 선택받습니다.
    private string? SelectMapImageSavePath(Control document)
    {
        string documentName = Path.GetFileNameWithoutExtension(document.Text.TrimEnd(' ', '*'));
        using var dialog = new SaveFileDialog
        {
            Title = "중앙 작업 화면 이미지 저장",
            Filter = "PNG 이미지 (*.png)|*.png|JPEG 이미지 (*.jpg;*.jpeg)|*.jpg;*.jpeg",
            FilterIndex = 1,
            DefaultExt = "png",
            AddExtension = true,
            OverwritePrompt = true,
            InitialDirectory = projectRoot,
            FileName = string.IsNullOrWhiteSpace(documentName) ? "작업화면" : documentName
        };

        return dialog.ShowDialog() == DialogResult.OK ? dialog.FileName : null;
    }

    // 활성 문서의 클라이언트 영역을 비트맵으로 캡처하고 선택한 확장자에 맞춰 PNG 또는 JPG로 기록합니다.
    private static void SaveControlAsImage(Control document, string path)
    {
        if (document.ClientSize.Width <= 0 || document.ClientSize.Height <= 0)
            throw new InvalidOperationException("현재 문서 화면의 크기가 올바르지 않아 저장할 수 없습니다.");

        using var captured = new Bitmap(document.ClientSize.Width, document.ClientSize.Height, PixelFormat.Format32bppArgb);
        document.DrawToBitmap(captured, new Rectangle(Point.Empty, document.ClientSize));

        string extension = Path.GetExtension(path);
        ImageFormat format = extension.Equals(".jpg", StringComparison.OrdinalIgnoreCase)
            || extension.Equals(".jpeg", StringComparison.OrdinalIgnoreCase)
            ? ImageFormat.Jpeg
            : ImageFormat.Png;

        using var output = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None);
        if (format.Guid == ImageFormat.Jpeg.Guid)
        {
            using var flattened = new Bitmap(captured.Width, captured.Height, PixelFormat.Format24bppRgb);
            using Graphics graphics = Graphics.FromImage(flattened);
            graphics.Clear(Color.White);
            graphics.DrawImageUnscaled(captured, 0, 0);
            flattened.Save(output, format);
        }
        else
        {
            captured.Save(output, format);
        }
    }

}

// 국토지리정보원 WMTS JavaScript API를 WebView2로 표시하기 위해 추가한 중앙 도킹 문서입니다.
internal sealed partial class NgiiAerialMapDocument : DockContent
{
    private const string ApiKey = "B593A48585BCD8A134BA9DDF00329A894517EB0A1B";
    private readonly WebView2 webView;

    // 코드에 포함된 API 키로 항공사진 지도를 표시할 WebView2 컨트롤을 중앙 문서에 배치합니다.
    internal NgiiAerialMapDocument()
    {
        Text = "국토지리정보원 항공사진";
        TabText = "항공사진 지도";
        DockAreas = DockAreas.Document | DockAreas.Float;
        webView = new WebView2
        {
            Dock = DockStyle.Fill,
            DefaultBackgroundColor = Color.White
        };
        Controls.Add(webView);
        Shown += NgiiAerialMapDocument_Shown;
    }

    // 문서가 처음 표시될 때 WebView2 런타임을 초기화합니다.
    // WebView2가 HTTP 외부 스크립트를 차단하므로 C#에서 NGII 스크립트를 먼저 받은 다음 HTML 내부에 삽입합니다.
    private async void NgiiAerialMapDocument_Shown(object? sender, EventArgs e)
    {
        Shown -= NgiiAerialMapDocument_Shown;
        try
        {
            await webView.EnsureCoreWebView2Async();
            webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
            webView.CoreWebView2.Settings.AreDevToolsEnabled = true;
            ConfigureAreaImageExport();
            string ngiiScript = await DownloadNgiiMapScriptAsync(ApiKey);
            webView.NavigateToString(CreateNgiiMapHtml(ngiiScript));
        }
        catch (WebView2RuntimeNotFoundException)
        {
            ShowMapError("Microsoft Edge WebView2 Runtime이 설치되어 있지 않습니다. WebView2 Runtime을 설치한 뒤 다시 실행해 주세요.");
        }
        catch (Exception exception)
        {
            ShowMapError("항공사진 지도를 초기화하지 못했습니다.\r\n" + exception.Message);
        }
    }

    // NGII의 HTTPS 스크립트 주소에서 발생하는 인증서 문제와 WebView2의 HTTP 차단을 피하기 위해
    // 공식 HTTP 주소의 지도 스크립트를 C# HttpClient로 내려받아 반환합니다.
    private static async Task<string> DownloadNgiiMapScriptAsync(string key)
    {
        string encodedKey = Uri.EscapeDataString(key);
        string scriptUrl = $"http://map.ngii.go.kr/openapi/wmts_ngiiMap_v6.4.3.js?apikey={encodedKey}";
        using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
        return await client.GetStringAsync(scriptUrl);
    }

    // 빌드 결과의 WebAssets 폴더에서 지도 라이브러리를 읽고 HTML에 삽입할 수 있는 문자열로 반환합니다.
    // 파일이 없으면 예외를 발생시켜 누락된 배포 파일 이름이 오류 메시지에 나타나게 합니다.
    private static string LoadMapWebAsset(string fileName)
    {
        string assetPath = Path.Combine(AppContext.BaseDirectory, "WebAssets", fileName);
        return File.ReadAllText(assetPath, Encoding.UTF8);
    }

    // 공식 NGII WMTS 스크립트와 OpenLayers 6.4.3을 이용하는 항공사진 지도 페이지를 생성합니다.
    // OpenLayers·jQuery·Proj4는 프로젝트의 WebAssets에서 읽어 CDN 접속 실패 없이 실행되게 합니다.
    // C#에서 내려받은 NGII 스크립트도 HTML 안에 직접 삽입하여 외부 HTTP 스크립트 차단을 방지합니다.
    // 항공사진에 해당하는 mapMode 9를 사용하며 API 버전 변경 시 이 값만 조정할 수 있습니다.
    private static string CreateNgiiMapHtml(string ngiiScript)
    {
        string jqueryScript = LoadMapWebAsset("jquery-3.7.1.min.js").Replace("</script", "<\\/script", StringComparison.OrdinalIgnoreCase);
        string openLayersScript = LoadMapWebAsset("ol-6.4.3.js").Replace("</script", "<\\/script", StringComparison.OrdinalIgnoreCase);
        string proj4Script = LoadMapWebAsset("proj4-2.6.2.js").Replace("</script", "<\\/script", StringComparison.OrdinalIgnoreCase);
        string openLayersCss = LoadMapWebAsset("ol-6.4.3.css").Replace("</style", "<\\/style", StringComparison.OrdinalIgnoreCase);
        string safeNgiiScript = ngiiScript.Replace("</script", "<\\/script", StringComparison.OrdinalIgnoreCase);
        return $$"""
            <!DOCTYPE html>
            <html lang="ko">
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>국토지리정보원 항공사진</title>
              <style>{{openLayersCss}}</style>
              <script>{{jqueryScript}}</script>
              <script>{{openLayersScript}}</script>
              <script>{{proj4Script}}</script>
              <script>
                window.ngiiLoadError = '';
                try {
                  {{safeNgiiScript}}
                } catch (error) {
                  window.ngiiLoadError = error && error.message ? error.message : String(error);
                }
              </script>
              <style>
                html, body, #map { width:100%; height:100%; margin:0; overflow:hidden; background:#eef2f5; }
                #message { position:absolute; left:16px; top:16px; z-index:10000; padding:10px 14px;
                  background:rgba(8,38,66,.9); color:white; border-radius:5px; font:13px 'Malgun Gothic'; }
              </style>
            </head>
            <body>
              <div id="map"></div>
              <div id="message">국토지리정보원 항공사진 지도를 불러오는 중입니다.</div>
              <script>
                window.addEventListener('load', function () {
                  try {
                    if (typeof ngii_wmts === 'undefined') {
                      throw new Error('NGII 스크립트 실행 실패: ' + (window.ngiiLoadError || '알 수 없는 오류'));
                    }
                    window.ngiiMap = new ngii_wmts.map('map', { mapMode: 9 });
                    document.getElementById('message').style.display = 'none';
                  } catch (error) {
                    document.getElementById('message').textContent =
                      '지도 로드 실패: ' + error.message + ' (API 키와 이용 도메인 등록을 확인하세요.)';
                  }
                });
              </script>
            </body>
            </html>
            """;
    }

    // WebView2 초기화 오류를 문서 안과 메시지 상자에 함께 표시해 원인을 확인할 수 있게 합니다.
    private void ShowMapError(string message)
    {
        Controls.Clear();
        Controls.Add(new Label
        {
            Dock = DockStyle.Fill,
            Text = message,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("맑은 고딕", 10F),
            ForeColor = Color.FromArgb(150, 35, 35),
            Padding = new Padding(30)
        });
        MessageBox.Show(message, "항공사진 지도 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
