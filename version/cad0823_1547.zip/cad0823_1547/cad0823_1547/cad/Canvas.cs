namespace cad;

// 모든 CAD 화면이 공통으로 사용하는 확대·축소와 화면 이동 입력을 담당합니다.
// 자식 캔버스는 각 파일 형식의 객체를 어떻게 그릴지만 구현합니다.
public abstract class Canvas : Panel
{
    private Point? panStart;

    protected Canvas()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        TabStop = true;
        MouseEnter += (_, _) => Focus();
    }

    public void ZoomIn() => ZoomAt(new Point(Width / 2, Height / 2), 1.2);
    public void ZoomOut() => ZoomAt(new Point(Width / 2, Height / 2), 1.0 / 1.2);

    protected void ZoomAt(Point screenPoint, double factor)
    {
        ApplyZoom(screenPoint, factor);
        Invalidate();
    }

    protected abstract void ApplyZoom(Point screenPoint, double factor);
    protected abstract void ApplyPan(int deltaX, int deltaY);

    // DXF처럼 왼쪽 클릭에 객체 입력 기능이 있는 자식은 false로 바꾸고,
    // 필요한 순간에만 BeginPan을 직접 호출합니다.
    protected virtual bool UsesAutomaticPanning => true;

    protected void BeginPan(Point screenPoint)
    {
        panStart = screenPoint;
        Capture = true;
        Cursor = Cursors.SizeAll;
    }

    protected void ContinuePan(Point screenPoint)
    {
        if (panStart is not Point previous) return;
        ApplyPan(screenPoint.X - previous.X, screenPoint.Y - previous.Y);
        panStart = screenPoint;
        Invalidate();
    }

    protected void EndPan()
    {
        panStart = null;
        Capture = false;
        Cursor = Cursors.Default;
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
        base.OnMouseWheel(e);
        ZoomAt(e.Location, e.Delta > 0 ? 1.2 : 1.0 / 1.2);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (UsesAutomaticPanning && e.Button == MouseButtons.Left) BeginPan(e.Location);
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        ContinuePan(e.Location);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (e.Button == MouseButtons.Left) EndPan();
    }
}

// 파일 형식과 무관하게 확대·축소 가능한 문서를 표현합니다.
internal interface IViewportDocument
{
    void ZoomIn();
    void ZoomOut();
}
