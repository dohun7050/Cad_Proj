namespace cad;

internal readonly record struct GeoPoint(double X, double Y, double? Z = null);

internal enum GeoGeometryKind { Point, Polyline, Polygon }

internal sealed record GeoFeature(
    GeoGeometryKind Kind,
    IReadOnlyList<IReadOnlyList<GeoPoint>> Parts);

internal sealed class GeoLayerData
{
    internal required IReadOnlyList<GeoFeature> Features { get; init; }
    internal required Color DisplayColor { get; init; }

    internal int PointCount => Features
        .Where(feature => feature.Kind == GeoGeometryKind.Point)
        .Sum(feature => feature.Parts.Sum(part => part.Count));
    internal int LineCount => Features.Count(feature => feature.Kind == GeoGeometryKind.Polyline);
    internal int PolygonCount => Features.Count(feature => feature.Kind == GeoGeometryKind.Polygon);
}

internal readonly record struct GeoBounds(double MinX, double MinY, double MaxX, double MaxY)
{
    internal double Width => MaxX - MinX;
    internal double Height => MaxY - MinY;

    internal static bool TryCreate(IEnumerable<GeoFeature> features, out GeoBounds bounds)
    {
        List<GeoPoint> points = features.SelectMany(feature => feature.Parts).SelectMany(part => part).ToList();
        if (points.Count == 0)
        {
            bounds = default;
            return false;
        }

        bounds = new GeoBounds(points.Min(p => p.X), points.Min(p => p.Y),
            points.Max(p => p.X), points.Max(p => p.Y));
        return true;
    }
}
