﻿using IxMilia.Dxf;
using IxMilia.Dxf.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace cad
{
    // 점/선 편집 기능을 별도 DxfDocument.Editing.cs에 추가하기 위해 partial만 확장했습니다.
    // 기존 DXF 문서 생성 방식과 생성자 내부 코드는 변경하지 않습니다.
    public partial class Docment_Dxf : DockContent, IViewportDocument
    {
        // 불러온 DXF 도면 전체 데이터
        private readonly DxfFile dxf;
        private readonly double minX;
        private readonly double minY;
        private readonly double maxX;
        private readonly double maxY;
        private readonly List<DxfCanvas> drawingPanels = new();
        
        public Docment_Dxf(DxfFile dxf, string title, double minX, double minY, double maxX, double maxY)
        {
            this.dxf = dxf;
            this.minX = minX;
            this.minY = minY;
            this.maxX = maxX;
            this.maxY = maxY;
            Text = title;
            var panel = CreateDrawingPanel();
            drawingPanels.Add(panel);
            Controls.Add(panel);
        }

        private DxfCanvas CreateDrawingPanel() => new(dxf, minX, minY, maxX, maxY);

        public void ZoomIn() => drawingPanels.ForEach(panel => panel.ZoomIn());
        public void ZoomOut() => drawingPanels.ForEach(panel => panel.ZoomOut());

        // 동일한 파싱 결과를 3D 문서에서도 재사용합니다.
        internal DxfFile GetDxfFile() => dxf;


        // DXF 파일에 저장된 전체 최상위 엔티티 수를 반환한다. Dxf계산 메서드 추가 1
        internal int GetFeatureCount()
        {
            return dxf.Entities.Count;
        }

        // DXF의 POINT, LINE 끝점, POLYLINE 정점을 합산한다. Dxf 계산 메서드 추가 2
        // 같은 좌표가 여러 객체에 사용되면 각각 계산한다. 
        internal int GetPointCount()
        {
            int pointCount = 0;

            foreach (DxfEntity entity in dxf.Entities)
            {
                pointCount += entity switch
                {
                    // 독립적인 POINT 객체
                    DxfModelPoint => 1,

                    //LINE의 시작점과 끝점
                    DxfLine => 2,


                    //구형 POLYLINE의 정점 
                    DxfPolyline polyline => polyline.Vertices.Count, 

                    // 경량 LWPOLYLINE의 정점 
                    DxfLwPolyline polyline => polyline.Vertices.Count,

                    // 원, 호, 문자 등은 포인트 계산에서 제외한다.
                    _ => 0

                };

            }
            return pointCount;
        }


    }
    // 기존 확대·이동·렌더링 형식을 유지하면서 별도 파일에 편집 기능을 추가하기 위해 partial로 확장했습니다.
    public partial class DxfCanvas : Canvas
    {
        private readonly DxfFile dxf;
        private readonly double minX;
        private readonly double minY;
        private readonly double maxX;
        private readonly double maxY;
        private const float DrawingMargin = 30;
        private bool isFirstDraw = true;
        private double scale = 1.0;

        //현재 도면의 화면 위치 offset
        private double offsetX;
        private double offsetY;

        // DXF는 왼쪽 클릭으로 점·선 입력과 객체 선택도 하므로 이동 시작 시점을 직접 판단합니다.
        protected override bool UsesAutomaticPanning => false;

        public DxfCanvas(DxfFile dxf, double minx, double miny, double maxx, double maxy)
        {
            this.dxf = dxf;
            this.minX = minx;
            this.minY = miny;
            this.maxX = maxx;
            this.maxY = maxy;

            Dock = DockStyle.Fill;
            BackColor = Color.White;
            InitializeLayerSettings();
            //화면 깜빡임을 줄이기
        }

        //dxf좌표를 화면 winform 좌표로 변경
        private PointF ToScreenPoint(double dxfx, double dxfy, double scale, double offsetx, double offsety)
        {
            // 도면의 가장 왼쪽(minX)을 0 기준으로 옮긴 뒤,
            // 화면 배율을 곱하고 여백·가운데 정렬 위치(offsetX)를 더함
            float screenx = (float)((dxfx - minX) * scale + offsetx);
            // DXF는 Y가 위로 증가하지만,
            // WinForms 화면은 Y가 아래로 증가
            // 그래서 패널 높이에서 값을 빼서 Y축 방향을 반대로 만들기
            float screeny = (float)(ClientSize.Height - ((dxfy - minY) * scale + offsety));

            // WinForms가 사용하는 화면상의 한 점(X, Y)을 반환
            return new PointF(screenx, screeny);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            double w = maxX - minX;
            double h = maxY - minY;

            if(w<=0|| h <= 0)
            {
                return;
            }
            
            double screenW = ClientSize.Width - DrawingMargin * 2;
            double screenH = ClientSize.Height - DrawingMargin * 2;

            if (isFirstDraw)
            {
                double scaleX = screenW / w;
                double scaleY = screenH / h;

                //둘 중 작은 값을 사용->도묜이 가로 / 세로 모두 화면 밖으로 나가지 않음
                scale = Math.Min(scaleX, scaleY);

                // 화면에 남는 가로 공간의 절반만큼 옮겨 가로 중앙 정렬
                offsetX = DrawingMargin + (screenW - w * scale) / 2;
                // 화면에 남는 가로 공간의 절반만큼 옮겨 가로 중앙 정렬
                offsetY = DrawingMargin + (screenH - h * scale) / 2;
                isFirstDraw = false;
            }
            // 대각선·곡선 부드럽게 처리
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // 같은 색상은 하나의 Pen을 재사용해 대형 DXF의 GDI 객체 생성을 줄입니다.
            var pens = new Dictionary<Color, Pen>();
            try
            {
                foreach( var en in dxf.Entities)
                {
                    // 레이어 창에서 숨긴 레이어의 엔티티는 그리지 않습니다.
                    if (!IsLayerVisible(en.Layer))
                    {
                        continue;
                    }

                    Color color = GetLayerColor(en.Layer);
                    if (!pens.TryGetValue(color, out Pen? pen))
                    {
                        pen = new Pen(color, 1);
                        pens.Add(color, pen);
                    }

                    if(en is DxfLine line)
                    {
                        PointF startP = ToScreenPoint(line.P1.X, line.P1.Y, scale, offsetX, offsetY);
                        PointF endP = ToScreenPoint(line.P2.X, line.P2.Y, scale, offsetX, offsetY);
                        e.Graphics.DrawLine(pen, startP, endP);
                    }
                    else if(en is DxfLwPolyline lwp)
                    {
                        if (lwp.Vertices.Count < 2)
                        {
                            continue;
                        }
                        for(int i=1; i<lwp.Vertices.Count; i++)
                        {
                            var prev = lwp.Vertices[i - 1];
                            var curr = lwp.Vertices[i];

                            PointF startP = ToScreenPoint(prev.X, prev.Y, scale, offsetX, offsetY);
                            PointF endP = ToScreenPoint(curr.X, curr.Y, scale, offsetX, offsetY);
                            e.Graphics.DrawLine(pen, startP, endP);
                        }
                    }
                }
            }
            finally
            {
                foreach (Pen pen in pens.Values) pen.Dispose();
            }

            // 기존 DXF 도면을 모두 그린 뒤 사용자가 추가한 점과 선을 위쪽 레이어에 표시하기 위해 추가했습니다.
            DrawEditingOverlay(e.Graphics);
            DrawSelectedEntity(e.Graphics);
           
        }
        // Canvas가 받은 확대 요청을 DXF 도면의 배율 값에 적용합니다.
        protected override void ApplyZoom(Point screenPoint, double factor)
        {
            scale = Math.Clamp(scale * factor, 0.000001, 1000000);
        }

        // Canvas가 계산한 화면 이동량을 DXF의 오프셋에 적용합니다.
        protected override void ApplyPan(int deltaX, int deltaY)
        {
            offsetX += deltaX;
            offsetY -= deltaY;
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if(e.Button == MouseButtons.Left)
            {
                Focus();

                // 점/선 추가 모드에서는 기존 화면 이동을 시작하지 않고 클릭 좌표를 편집 기능으로 전달합니다.
                if (TryAddEditingPoint(e.Location))
                {
                    return;
                }

                if (TrySelectDxfEntity(e.Location))
                {
                    return;
                }

                BeginPan(e.Location);
            }
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            ContinuePan(e.Location);
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);

            if(e.Button == MouseButtons.Left)
            {
                // 점/선 추가 중에는 십자 커서를 유지하고 기존 화면 이동 종료 코드는 실행하지 않습니다.
                if (IsEditingPointLine)
                {
                    Cursor = Cursors.Cross;
                    return;
                }

                EndPan();
            }
        }
    }
}
