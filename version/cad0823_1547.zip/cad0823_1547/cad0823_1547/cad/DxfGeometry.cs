﻿using IxMilia.Dxf;
using IxMilia.Dxf.Entities;

namespace cad;

// DXF 엔티티의 화면 표시와 전체 좌표 범위 계산을 한곳에서 처리합니다.
internal static class DxfGeometry
{
    // LINE, 원, 호와 두 종류의 폴리선을 실제로 그릴 수 있는 기본 엔티티로 펼칩니다.
    private static IEnumerable<DxfEntity> GetDrawableEntities(DxfEntity entity)
    {
        if (entity is DxfLwPolyline lightweightPolyline)
        {
            foreach (DxfEntity child in lightweightPolyline.AsSimpleEntities()) yield return child;
            yield break;
        }

        if (entity is DxfPolyline polyline)
        {
            foreach (DxfEntity child in polyline.AsSimpleEntities()) yield return child;
            yield break;
        }

        if (entity is DxfLine or DxfCircle or DxfArc) yield return entity;
    }

    // 지원하는 모든 DXF 엔티티를 검사하여 화면 맞춤에 사용할 최소·최대 좌표를 계산합니다.
    public static bool TryGetBounds(DxfFile dxf, out double minX, out double minY, out double maxX, out double maxY)
    {
        double localMinX = double.MaxValue;
        double localMinY = double.MaxValue;
        double localMaxX = double.MinValue;
        double localMaxY = double.MinValue;
        bool hasPoint = false;

        void Include(double x, double y)
        {
            if (!double.IsFinite(x) || !double.IsFinite(y)) return;
            localMinX = Math.Min(localMinX, x);
            localMinY = Math.Min(localMinY, y);
            localMaxX = Math.Max(localMaxX, x);
            localMaxY = Math.Max(localMaxY, y);
            hasPoint = true;
        }

        foreach (DxfEntity source in dxf.Entities)
        {
            foreach (DxfEntity entity in GetDrawableEntities(source))
            {
                switch (entity)
                {
                    case DxfLine line:
                        Include(line.P1.X, line.P1.Y);
                        Include(line.P2.X, line.P2.Y);
                        break;
                    case DxfArc arc:
                        // 호 전체를 포함하는 원의 범위를 사용하면 일부가 화면 밖으로 잘리지 않습니다.
                        Include(arc.Center.X - arc.Radius, arc.Center.Y - arc.Radius);
                        Include(arc.Center.X + arc.Radius, arc.Center.Y + arc.Radius);
                        break;
                    case DxfCircle circle:
                        Include(circle.Center.X - circle.Radius, circle.Center.Y - circle.Radius);
                        Include(circle.Center.X + circle.Radius, circle.Center.Y + circle.Radius);
                        break;
                }
            }

            // INSERT는 아직 블록 형상을 변환해 그리지 않지만 삽입점은 화면 범위에 포함합니다.
            if (source is DxfInsert insert) Include(insert.Location.X, insert.Location.Y);
        }

        minX = localMinX;
        minY = localMinY;
        maxX = localMaxX;
        maxY = localMaxY;
        return hasPoint && maxX > minX && maxY > minY;
    }

    // 지원하는 DXF 엔티티를 WinForms Graphics에 그립니다.
    public static void Draw(Graphics graphics, DxfFile dxf, Func<double, double, PointF> toScreen, double scale, Pen pen)
    {
        foreach (DxfEntity source in dxf.Entities)
        {
            foreach (DxfEntity entity in GetDrawableEntities(source))
            {
                switch (entity)
                {
                    case DxfLine line:
                        graphics.DrawLine(pen, toScreen(line.P1.X, line.P1.Y), toScreen(line.P2.X, line.P2.Y));
                        break;
                    case DxfArc arc:
                        DrawArc(graphics, arc, toScreen, scale, pen);
                        break;
                    case DxfCircle circle:
                        DrawCircle(graphics, circle.Center.X, circle.Center.Y, circle.Radius, toScreen, scale, pen);
                        break;
                }
            }
        }
    }

    // 중심점과 반지름을 화면 좌표의 사각형으로 바꾸어 원을 그립니다.
    private static void DrawCircle(Graphics graphics, double centerX, double centerY, double radius, Func<double, double, PointF> toScreen, double scale, Pen pen)
    {
        PointF center = toScreen(centerX, centerY);
        float screenRadius = (float)Math.Abs(radius * scale);
        graphics.DrawEllipse(pen, center.X - screenRadius, center.Y - screenRadius, screenRadius * 2, screenRadius * 2);
    }

    // DXF의 반시계방향 각도를 Y축이 반대인 WinForms 화면 각도로 변환하여 호를 그립니다.
    private static void DrawArc(Graphics graphics, DxfArc arc, Func<double, double, PointF> toScreen, double scale, Pen pen)
    {
        PointF center = toScreen(arc.Center.X, arc.Center.Y);
        float screenRadius = (float)Math.Abs(arc.Radius * scale);
        double dxfSweep = arc.EndAngle - arc.StartAngle;
        while (dxfSweep < 0) dxfSweep += 360;
        if (dxfSweep == 0) dxfSweep = 360;

        graphics.DrawArc(
            pen,
            center.X - screenRadius,
            center.Y - screenRadius,
            screenRadius * 2,
            screenRadius * 2,
            (float)-arc.StartAngle,
            (float)-dxfSweep);
    }
}
