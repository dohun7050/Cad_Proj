﻿using WeifenLuo.WinFormsUI.Docking;

namespace cad;

// 중앙 작업영역 왼쪽 아래에 작은 빠른 작업 도구줄과 문서 분할 기능을 추가합니다.
public partial class Form1
{
    private FlowLayoutPanel? bottomToolbar;
    private Label? measurementStatusLabel;// 피처수와 포인터수 를 하단 왼쪽에 표시한다. 
    private readonly List<DockContent> emptySplitDocuments = new();
    private readonly List<DockContent> floatingDocuments = new();

    private void ConfigureBottomToolbar()
    {
        measurementStatusLabel = new Label
        {
            Dock = DockStyle.Left,
            Width = 430,
            ForeColor = Color.White,
            BackColor = Color.Transparent,
            Font = new Font("맑은 고딕", 9F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(12,0,0,0),
            AutoEllipsis = true,
            Text = "DXF 측정 결과: -"
        };
        statusPanel.Controls.Add(measurementStatusLabel);
        measurementStatusLabel.BringToFront();

        // 활성 문서가 바뀌거나 닫히면 DXF 측정 결과를 초기화
        dockPanel1.ActiveDocumentChanged += DockPanel1_ActiveDocumentChanged;


        bottomToolbar = new FlowLayoutPanel
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Anchor = AnchorStyles.Left | AnchorStyles.Bottom,
            BackColor = Color.FromArgb(15, 48, 79),
            Padding = new Padding(6, 3, 6, 3),
            WrapContents = false,
            FlowDirection = FlowDirection.LeftToRight,
            Margin = Padding.Empty
        };
        FlowLayoutPanel toolBar = bottomToolbar;

        AddBottomButton(toolBar, "피처 수", "select.png", ShowActiveDxfFeatureCount);
        AddBottomButton(toolBar, "포인트 수", "point_line_add.png", ShowActiveDxfPointCount);
        AddBottomButton(toolBar, "좌표계", "terrain.png");
        AddBottomButton(toolBar, "축척", "profile.png");
        AddBottomButton(toolBar, "연산 상태", "review.png");
        AddBottomButton(toolBar, "제약 조건 위반", "constraint.png");
        AddBottomSeparator(toolBar);
        AddBottomButton(toolBar, "확대", null, () => ZoomActiveDocument(true));
        AddBottomButton(toolBar, "축소", null, () => ZoomActiveDocument(false));
        AddBottomButton(toolBar, "창 분리", "export.png", FloatActiveDocument);
        AddBottomButton(toolBar, "도킹 복귀", "alignment.png", DockFloatingDocument);
        AddBottomSeparator(toolBar);
        AddSplitButton(toolBar, "2분할", 2, () => SetWorkspaceSplit(2));
        AddSplitButton(toolBar, "3분할", 3, () => SetWorkspaceSplit(3));
        AddSplitButton(toolBar, "4분할", 4, () => SetWorkspaceSplit(4));
        AddSplitButton(toolBar, "분할 해제", 1, () => SetWorkspaceSplit(1));
        AddBottomSeparator(toolBar);
        AddBottomButton(toolBar, "횡단면도", "cross_section.png", ShowCrossSectionDrawing);
        AddBottomButton(toolBar, "종단면도", "profile.png", ShowLongitudinalDrawing);
        AddBottomButton(toolBar, "3D", "terrain.png", ShowActiveDxf3D);
        AddBottomButton(toolBar, "2D", "drawing.png", ShowDxf2D);
        AddBottomButton(toolBar, "보고서", "report.png");
        AddBottomButton(toolBar, "1차 보고서", "review.png");
        AddBottomButton(toolBar, "로그 창", "route_compare.png");

        // 빈 오른쪽 영역을 덮지 않고 실제 버튼 폭만큼만 중앙 작업영역에 표시합니다.
        contentPanel.Controls.Add(toolBar);
        contentPanel.Layout += (_, _) => PositionBottomToolbar();
        PositionBottomToolbar();
    }

    private void PositionBottomToolbar()
    {
        if (bottomToolbar is null || bottomToolbar.IsDisposed) return;

        bottomToolbar.Location = new Point(
            contentPanel.Padding.Left,
            Math.Max(contentPanel.Padding.Top,
                contentPanel.ClientSize.Height - contentPanel.Padding.Bottom - bottomToolbar.Height));
        bottomToolbar.Visible = true;
        bottomToolbar.BringToFront();
    }

    private void AddBottomButton(FlowLayoutPanel parent, string toolTip, string? iconFile, Action? action = null)
    {
        var button = new Button
        {
            Width = 30, Height = 30, FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(25, 65, 101), ForeColor = Color.White,
            Margin = new Padding(2, 0, 2, 0), Cursor = Cursors.Hand,
            Text = iconFile is null ? (toolTip == "확대" ? "+" : "−") : ""
        };
        button.FlatAppearance.BorderColor = Color.FromArgb(59, 98, 131);
        button.FlatAppearance.BorderSize = 1;
        if (iconFile is not null)
        {
            string path = Path.Combine(AppContext.BaseDirectory, "Icons", iconFile);
            if (File.Exists(path))
            {
                using Image image = Image.FromFile(path);
                button.Image = CreateWhiteIcon(image, 22, 22);
            }
        }
        button.Click += (_, _) => action?.Invoke();
        new ToolTip().SetToolTip(button, toolTip);
        parent.Controls.Add(button);
    }

    private static void AddBottomSeparator(FlowLayoutPanel parent) => parent.Controls.Add(new Panel
    {
        Width = 1, Height = 24, BackColor = Color.FromArgb(88, 120, 148), Margin = new Padding(5, 3, 5, 3)
    });

    private void AddSplitButton(FlowLayoutPanel parent, string toolTip, int layout, Action action)
    {
        var button = new Button
        {
            Width = 30, Height = 30, FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(25, 65, 101), ForeColor = Color.White,
            Margin = new Padding(2, 0, 2, 0), Cursor = Cursors.Hand,
            Image = CreateSplitLayoutIcon(layout), ImageAlign = ContentAlignment.MiddleCenter
        };
        button.FlatAppearance.BorderColor = Color.FromArgb(59, 98, 131);
        button.FlatAppearance.BorderSize = 1;
        button.Click += (_, _) => action();
        new ToolTip().SetToolTip(button, toolTip);
        parent.Controls.Add(button);
    }

    private static Bitmap CreateSplitLayoutIcon(int layout)
    {
        var icon = new Bitmap(22, 22);
        using Graphics graphics = Graphics.FromImage(icon);
        graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        using var pen = new Pen(Color.White, 1.6F);
        graphics.DrawRectangle(pen, new Rectangle(2, 2, 17, 17));

        if (layout is 2 or 4)
            graphics.DrawLine(pen, 10.5F, 2, 10.5F, 19);
        if (layout == 3)
        {
            graphics.DrawLine(pen, 10.5F, 2, 10.5F, 19);
            graphics.DrawLine(pen, 10.5F, 10.5F, 19, 10.5F);
        }
        else if (layout == 4)
        {
            graphics.DrawLine(pen, 2, 10.5F, 19, 10.5F);
        }

        return icon;
    }

    private static Bitmap CreateWhiteIcon(Image source, int width, int height)
    {
        using var sourceBitmap = new Bitmap(source, new Size(width, height));
        var icon = new Bitmap(width, height);
        for (int y = 0; y < icon.Height; y++)
        for (int x = 0; x < icon.Width; x++)
        {
            Color pixel = sourceBitmap.GetPixel(x, y);
            icon.SetPixel(x, y, Color.FromArgb(pixel.A, Color.White));
        }
        return icon;
    }

    // 활성 문서가 변경되거나 현재 문서가 닫히면 측정 결과를 초기화합니다.
    private void DockPanel1_ActiveDocumentChanged(
        object? sender,
        EventArgs e)
    {
        ResetDxfMeasurementStatus();
    }

    private void ResetDxfMeasurementStatus()
    {
        if (measurementStatusLabel is null)
            return;

        measurementStatusLabel.Text =
            "DXF 측정 결과: -";
    }



    // 현재 활성 Dxf파일의 전체 피처수를 하단바에 표시한다. 
    private void ShowActiveDxfFeatureCount()
    {
        if (dockPanel1.ActiveDocument is not Docment_Dxf document) // 만약 DXF파일자체가 안열려있거나 지정이 안되어있을경우
        {
            measurementStatusLabel!.Text = " 피처수를 확인할 DXF파일을 먼저 열어주시길 바랍니다.";
            return;
        }

        int featureCount = document.GetFeatureCount();

        measurementStatusLabel!.Text = $"DXF 피처 수: {featureCount:N0}";
    }
    // 현재 활성 DXF파일의 전체 포인트 수를 하단바에 표시한다. 
    private void ShowActiveDxfPointCount()
    {
        if(dockPanel1.ActiveDocument is not Docment_Dxf document)
        {
            measurementStatusLabel!.Text = " 포인트 수를 확인할 Dxf 파일을 먼저 열어주시길 바랍니다.";
            return; 
        }

        int pointCount = document.GetPointCount();

        measurementStatusLabel!.Text = $"포인트수 : {pointCount:N0} (중복 포함)";

        
    }



    private void ZoomActiveDocument(bool zoomIn)
    {
        if (dockPanel1.ActiveDocument is not IViewportDocument document)
        {
            statusLabel.Text = "확대할 CAD 도면을 먼저 열어 주세요.";
            return;
        }

        if (zoomIn) document.ZoomIn();
        else document.ZoomOut();
    }

    // 활성 문서를 DockPanel 밖의 일반 Windows 창으로 분리합니다.
    private void FloatActiveDocument()
    {
        // 현재 선택된 문서가 없거나 선택된 문서가 이미 종료되었거나 화면 분할용으로 만들어진 빈화면일경우 창분리 X
        if (dockPanel1.ActiveDocument is not DockContent document
            || document.IsDisposed
            || emptySplitDocuments.Contains(document))
        {
            statusLabel.Text = "분리할 문서 탭을 먼저 선택해 주세요.";
            return;
        }

        if (document.DockState == DockState.Float) //이미 분리되어 있는 경우 
        {
            ConfigureFloatingWindow(document, activate: true);
            statusLabel.Text = "선택한 문서는 이미 독립 창으로 분리되어 있습니다.";
            return;
        }

        Screen screen = Screen.FromControl(this);
        Rectangle workingArea = screen.WorkingArea;
        int width = Math.Max(640, (int)(workingArea.Width * .72));
        int height = Math.Max(480, (int)(workingArea.Height * .72));
        width = Math.Min(width, workingArea.Width);
        height = Math.Min(height, workingArea.Height);



        var floatBounds = new Rectangle(
            workingArea.Left + (workingArea.Width - width) / 2,
            workingArea.Top + (workingArea.Height - height) / 2,
            width,
            height);

        document.DockAreas |= DockAreas.Float | DockAreas.Document;
        document.FloatAt(floatBounds);
        if (!floatingDocuments.Contains(document))
            floatingDocuments.Add(document);

        // FloatWindow는 FloatAt 이후 생성되므로 메시지 큐에서 한 번 뒤에 일반 창 속성을 적용합니다.
        BeginInvoke(() => ConfigureFloatingWindow(document, activate: true));
        statusLabel.Text = $"'{document.Text.TrimEnd('*')}' 탭을 독립 창으로 분리했습니다.";
    }

    private static void ConfigureFloatingWindow(DockContent document, bool activate)
    {
        FloatWindow? window = document.FloatPane?.FloatWindow;
        if (window is null || window.IsDisposed) return;

        window.FormBorderStyle = FormBorderStyle.Sizable;
        window.MaximizeBox = true;
        window.MinimizeBox = true;
        window.ShowInTaskbar = true;
        window.Text = document.Text.TrimEnd('*');
        if (activate)
        {
            window.Show();
            window.Activate();
        }
    }

    // 활성 또는 가장 최근에 분리한 문서를 중앙 문서 탭으로 되돌립니다.
    private void DockFloatingDocument()
    {
        floatingDocuments.RemoveAll(document => document.IsDisposed);

        DockContent? document = dockPanel1.ActiveDocument as DockContent;
        if (document?.DockState != DockState.Float)
        {
            document = floatingDocuments.LastOrDefault(candidate =>
                !candidate.IsDisposed && candidate.DockState == DockState.Float);
        }

        if (document is null || document.DockState != DockState.Float)
        {
            statusLabel.Text = "중앙 화면으로 복귀할 독립 문서 창이 없습니다.";
            return;
        }

        document.Show(dockPanel1, DockState.Document);
        document.Activate();
        floatingDocuments.Remove(document);
        statusLabel.Text = $"'{document.Text.TrimEnd('*')}' 문서를 중앙 탭으로 복귀했습니다.";
    }

    private void ShowCrossSectionDrawing() =>
        ShowEngineeringSection(EngineeringSectionKind.CrossSection);

    private void ShowLongitudinalDrawing() =>
        ShowEngineeringSection(EngineeringSectionKind.Longitudinal);

    private void ShowEngineeringSection(EngineeringSectionKind kind)
    {
        EngineeringSectionDocument? opened = dockPanel1.Documents
            .OfType<EngineeringSectionDocument>()
            .FirstOrDefault(document => document.Kind == kind && !document.IsDisposed);

        if (opened is not null)
        {
            opened.Activate();
            return;
        }

        var document = new EngineeringSectionDocument(kind);
        document.Show(dockPanel1, DockState.Document);
        document.Activate();
        statusLabel.Text = kind == EngineeringSectionKind.CrossSection
            ? "샘플 횡단면도를 열었습니다."
            : "샘플 종단면도를 열었습니다.";
    }

    private void ShowActiveDxf3D()
    {
        if (dockPanel1.ActiveDocument is not Docment_Dxf sourceDocument)
        {
            statusLabel.Text = "3D로 표시할 DXF 문서를 먼저 선택해 주세요.";
            return;
        }

        Dxf3DDocument? opened = dockPanel1.Documents
            .OfType<Dxf3DDocument>()
            .FirstOrDefault(document =>
                ReferenceEquals(document.SourceDocument, sourceDocument) && !document.IsDisposed);

        if (opened is not null)
        {
            opened.Activate();
            return;
        }

        var document3D = new Dxf3DDocument(sourceDocument, sourceDocument.GetDxfFile());
        document3D.Show(dockPanel1, DockState.Document);
        document3D.Activate();
        statusLabel.Text = "DXF 3D 와이어프레임을 열었습니다.";
    }

    // 3D 보기는 원본을 변형하지 않으므로 원본 DXF 탭을 다시 활성화해 2D 보기로 돌아갑니다.
    private void ShowDxf2D()
    {
        if (dockPanel1.ActiveDocument is Dxf3DDocument document3D)
        {
            Docment_Dxf sourceDocument = document3D.SourceDocument;
            if (sourceDocument.IsDisposed)
            {
                statusLabel.Text = "원본 DXF 문서가 닫혀 있어 2D 보기로 돌아갈 수 없습니다.";
                return;
            }

            sourceDocument.Activate();
            statusLabel.Text = "원본 DXF 2D 보기로 돌아왔습니다.";
            return;
        }

        if (dockPanel1.ActiveDocument is Docment_Dxf)
        {
            statusLabel.Text = "현재 문서는 이미 DXF 2D 보기입니다.";
            return;
        }

        statusLabel.Text = "2D로 표시할 DXF 또는 DXF 3D 문서를 먼저 선택해 주세요.";
    }

    private void SetWorkspaceSplit(int requestedCount)
    {
        // 이전 분할에서 만들었던 빈 칸은 실제 문서로 계산되지 않도록 먼저 제거합니다.
        foreach (DockContent emptyDocument in emptySplitDocuments.ToArray())
        {
            if (!emptyDocument.IsDisposed)
                emptyDocument.Close();
        }
        emptySplitDocuments.Clear();

        List<DockContent> documents = dockPanel1.Documents.OfType<DockContent>()
            .Where(document => !document.IsDisposed).ToList();

        if (documents.Count == 0)
        {
            statusLabel.Text = "분할할 문서를 먼저 열어 주세요.";
            return;
        }

        // 열린 문서가 부족해도 요청한 분할 수 자체는 유지합니다.
        int paneCount = requestedCount == 1 ? 1 : Math.Clamp(requestedCount, 2, 4);

        while (documents.Count < paneCount)
        {
            DockContent emptyDocument = CreateEmptySplitDocument();
            emptySplitDocuments.Add(emptyDocument);
            documents.Add(emptyDocument);
        }

        dockPanel1.SuspendLayout(true);
        try
        {
            DockContent first = documents[0];
            first.Show(dockPanel1, DockState.Document);
            DockPane basePane = first.Pane!;
            foreach (DockContent document in documents.Skip(1))
                document.Show(basePane, null);

            if (paneCount == 1)
            {
                first.Activate();
                statusLabel.Text = "화면 분할을 해제했습니다.";
                return;
            }

            var paneLeaders = new List<DockContent> { first };
            DockContent second = documents[1];
            second.Show(first.Pane!, DockAlignment.Right, 0.5);
            paneLeaders.Add(second);

            if (paneCount >= 3)
            {
                DockContent third = documents[2];
                third.Show(second.Pane!, DockAlignment.Bottom, 0.5);
                paneLeaders.Add(third);
            }

            if (paneCount >= 4)
            {
                DockContent fourth = documents[3];
                fourth.Show(first.Pane!, DockAlignment.Bottom, 0.5);
                paneLeaders.Add(fourth);
            }

            for (int index = paneCount; index < documents.Count; index++)
                documents[index].Show(paneLeaders[index % paneCount].Pane!, null);

            first.Activate();
            statusLabel.Text = $"열린 문서를 {paneCount}개 영역으로 분할했습니다.";
        }
        finally
        {
            dockPanel1.ResumeLayout(true, true);
            BeginInvoke(HideEmptySplitPaneChrome);
        }
    }

    // 빈 칸을 유지하기 위한 내부 자리표시 문서는 남겨 두되 탭과 창 제목은 화면에 표시하지 않습니다.
    private void HideEmptySplitPaneChrome()
    {
        foreach (DockContent emptyDocument in emptySplitDocuments)
        {
            if (emptyDocument.IsDisposed || emptyDocument.Pane is null)
                continue;

            emptyDocument.Pane.TabStripControl.Visible = false;
        }
    }

    private static DockContent CreateEmptySplitDocument()
    {
        return new DockContent
        {
            Text = string.Empty,
            TabText = string.Empty,
            BackColor = Color.FromArgb(239, 244, 248),
            CloseButton = false,
            CloseButtonVisible = false,
            ShowHint = DockState.Document
        };
    }
}
