﻿namespace cad;

// [추가 기능 영역]
// 원본 파일 열기와 DXF 가져오기 코드를 건드리지 않고 편집 탭 기능만 분리해 관리하기 위해 추가한 partial 파일입니다.
// 이후 편집 기능도 기존 함수 사이에 삽입하지 않고 이 파일 아래쪽에 함수와 추가 이유를 함께 작성합니다.
public partial class Form1
{
    // 점과 선의 색상·크기를 설정하는 자동 닫힘 팝업을 보관합니다.
    private ToolStripDropDown? pointLineStylePopup;

    // 현재 점/선 연속 입력 모드가 켜져 있는지 나타냅니다.
    private bool isPointLineModeActive;

    // 선택 버튼이 활성화되어 원본 DXF 객체를 클릭할 수 있는 상태인지 나타냅니다.
    private bool isSelectionModeActive;

    // 선택 모드를 시작한 DXF 문서를 기억해 모드를 종료할 때 정확히 해제합니다.
    private Docment_Dxf? selectionDocument;

    // 선택 모드의 오른쪽 속성 패널에 표시할 DXF 내부 레이어 목록과 빠른 표시 버튼 영역입니다.
    private CheckedListBox? selectionLayerList;
    private Panel? selectionLayerButtons;
    private Button? selectionLayerColorButton;

    // 점/선 입력 모드를 시작한 DXF 문서를 기억합니다.
    private IPointLineEditableDocument? pointLineEditDocument;

    // 새 .cad 탭에서 점/선 입력을 시작했을 때 해당 임시 문서를 기억합니다.
    private CadDocument? pointLineCadDocument;

    // 사용자가 선택한 점 색상, 점 크기, 선 색상과 선 두께를 보관합니다.
    private DxfEditStyle pointLineEditStyle = DxfEditStyle.Default;

    // 편집 탭의 기능을 한 곳에서 초기화하기 위해 추가했습니다.
    // 선택·추가·수정·삭제·레이어·실행 취소 버튼에 아이콘을 적용하고 추가 명령을 연결합니다.
    private void ConfigureEditTab()
    {
        ConfigureRibbonButton(menuEdit, "select.png");
        ConfigureRibbonButton(menuAreaSelect, "area_select.png");
        ConfigureRibbonButton(menuPointLineAdd, "point_line_add.png");
        ConfigureRibbonButton(menuModify, "modify.png");
        ConfigureRibbonButton(menuDeleteFeature, "delete.png");
        ConfigureRibbonButton(menuFreeLine, "free_line.png");
        ConfigureRibbonButton(menuLayer, "layer.png");
        ConfigureRibbonButton(menuUndo, "undo.png");
        ConfigureRibbonButton(menuRedo, "redo.png");
        ConfigurePointLineStylePopup();
        ConfigureUndoRedoCommands();
        menuEdit.Click += SelectButton_Click;
    }

    // 버튼과 키보드가 같은 편집 기록을 사용하도록 추가했습니다.
    // 실행 취소·다시 입력 리본 버튼과 Ctrl+Z·Ctrl+Y 단축키를 DXF 편집 기능에 연결합니다.
    private void ConfigureUndoRedoCommands()
    {
        menuUndo.Click += UndoEditButton_Click;
        menuRedo.Click += RedoEditButton_Click;
        KeyPreview = true;
        KeyDown += FormEditShortcut_KeyDown;
    }

    // 실행 취소 리본 버튼을 누르면 활성 DXF 문서의 마지막 점/선 추가 작업을 제거합니다.
    private void UndoEditButton_Click(object? sender, EventArgs e)
    {
        UndoActiveDxfEdit();
    }

    // 다시 입력 리본 버튼을 누르면 활성 DXF 문서에서 마지막으로 취소한 작업을 복원합니다.
    private void RedoEditButton_Click(object? sender, EventArgs e)
    {
        RedoActiveDxfEdit();
    }

    // 메인 폼에서 Ctrl+Z와 Ctrl+Y를 감지하고 활성 문서가 DXF일 때만 편집 기록을 처리합니다.
    private void FormEditShortcut_KeyDown(object? sender, KeyEventArgs e)
    {
        if (!e.Control) return;

        if (e.KeyCode == Keys.Z)
        {
            UndoActiveDxfEdit();
            e.SuppressKeyPress = true;
        }
        else if (e.KeyCode == Keys.Y)
        {
            RedoActiveDxfEdit();
            e.SuppressKeyPress = true;
        }
    }

    // DXF 자체 편집 레이어의 마지막 점을 취소하고 공용 .cad 점 목록도 같은 순서로 맞춥니다.
    private void UndoActiveDxfEdit()
    {
        bool undone;
        if (dockPanel1.ActiveDocument is IPointLineEditableDocument document)
        {
            undone = document.UndoPointLineEdit();
            if (undone) UndoCadWorkspacePoint();
            else undone = UndoCadImport();
        }
        else
        {
            undone = UndoCadWorkspaceOrImport();
        }

        statusLabel.Text = undone
            ? "실행 취소: 마지막 점과 연결선을 제거했습니다."
            : "실행 취소할 점/선 작업이 없습니다.";
    }

    // DXF 자체 편집 레이어의 마지막 취소 점을 복원하고 공용 .cad 점 목록도 같은 순서로 맞춥니다.
    private void RedoActiveDxfEdit()
    {
        bool redone;
        if (dockPanel1.ActiveDocument is IPointLineEditableDocument document)
        {
            redone = document.RedoPointLineEdit();
            if (redone) RedoCadWorkspacePoint();
            else redone = RedoCadImport();
        }
        else
        {
            redone = RedoCadWorkspaceOrImport();
        }

        statusLabel.Text = redone
            ? "다시 입력: 취소한 점과 연결선을 복원했습니다."
            : "다시 입력할 점/선 작업이 없습니다.";
    }

    // 점/선 모드에서 표시 속성을 사용자가 직접 정할 수 있도록 추가했습니다.
    // 점 색상·선 색상·점 크기·선 두께를 고르는 설정 팝업을 구성합니다.
    private void ConfigurePointLineStylePopup()
    {
        var stylePanel = new PointLineStylePanel(pointLineEditStyle);
        stylePanel.EditStyleChanged += PointLineStyleChanged;

        var host = new ToolStripControlHost(stylePanel)
        {
            AutoSize = false,
            Margin = Padding.Empty,
            Padding = Padding.Empty,
            Size = stylePanel.Size
        };

        pointLineStylePopup = new ToolStripDropDown
        {
            AutoClose = true,
            AutoSize = false,
            Padding = new Padding(1),
            Size = new Size(stylePanel.Width + 4, stylePanel.Height + 4)
        };
        pointLineStylePopup.Items.Add(host);
        menuPointLineAdd.Click += PointLineAddButton_Click;
    }

    // 별도의 시작·종료 항목 없이 같은 버튼으로 모드를 전환할 수 있도록 추가했습니다.
    // 점/선 추가 버튼을 누를 때마다 연속 입력 모드를 시작하거나 종료합니다.
    private void PointLineAddButton_Click(object? sender, EventArgs e)
    {
        if (isPointLineModeActive) StopPointLineMode();
        else StartPointLineMode();
    }

    // 중앙 문서 위의 투명 CAD 오버레이에서 연속 점/선 입력을 시작하고 버튼을 눌린 모양으로 표시합니다.
    private void StartPointLineMode()
    {
        if (isSelectionModeActive) StopSelectionMode();
        pointLineEditDocument = dockPanel1.ActiveDocument as IPointLineEditableDocument;
        pointLineCadDocument = dockPanel1.ActiveDocument as CadDocument;
        isPointLineModeActive = true;
        SetPointLineButtonPressed(true);

        if (dockPanel1.ActiveDocument is Docment_Dxf dxfDocument)
            dxfDocument.LoadCadWorkspacePoints(cadWorkspacePoints, pointLineEditStyle);

        if (pointLineCadDocument is not null)
        {
            // 새 도면 1.cad에서는 투명 오버레이가 아니라 탭 안의 CadCanvas에 직접 추가합니다.
            SetCadOverlayInputMode(false);
            pointLineCadDocument.SetPointLineMode(true, pointLineEditStyle);
        }
        else if (pointLineEditDocument is not null)
        {
            SetCadOverlayInputMode(false);
            pointLineEditDocument.SetCadPointAddedCallback(AddCadWorkspacePoint);
            pointLineEditDocument.SetPointLineEditMode(DxfEditMode.AddPointLine, pointLineEditStyle);
        }
        else
        {
            SetCadOverlayInputMode(true);
        }

        dockPanel1.Cursor = Cursors.Default;
        statusLabel.Text = "CAD 점/선 추가 중: 열린 문서 위를 클릭하세요.";
        pointLineStylePopup?.Show(menuPointLineAdd, new Point(0, menuPointLineAdd.Height));
    }

    // 연속 점/선 입력을 종료하고 버튼과 커서를 일반 상태로 복원합니다.
    private void StopPointLineMode()
    {
        pointLineStylePopup?.Close();
        pointLineCadDocument?.SetPointLineMode(false, pointLineEditStyle);
        pointLineCadDocument = null;
        pointLineEditDocument?.SetCadPointAddedCallback(null);
        pointLineEditDocument?.SetPointLineEditMode(DxfEditMode.None, pointLineEditStyle);
        pointLineEditDocument = null;
        isPointLineModeActive = false;
        SetCadOverlayInputMode(false);
        dockPanel1.Cursor = Cursors.Default;
        SetPointLineButtonPressed(false);
        statusLabel.Text = "점/선 추가 모드를 종료했습니다.";
    }

    // 입력 모드에 따라 점/선 추가 버튼의 배경색·글자색·테두리를 변경합니다.
    private void SetPointLineButtonPressed(bool pressed)
    {
        menuPointLineAdd.Tag = pressed ? PressedRibbonButtonTag : null;
        menuPointLineAdd.BackColor = pressed ? Color.FromArgb(27, 94, 174) : Color.FromArgb(247, 250, 253);
        menuPointLineAdd.ForeColor = pressed ? Color.White : Color.FromArgb(28, 45, 62);
        menuPointLineAdd.FlatAppearance.BorderSize = pressed ? 1 : 0;
        menuPointLineAdd.FlatAppearance.BorderColor = pressed ? Color.FromArgb(12, 66, 135) : Color.FromArgb(247, 250, 253);
    }

    // 설정 패널에서 속성이 바뀌면 현재 DXF 문서의 점과 선 표시에도 즉시 적용합니다.
    private void PointLineStyleChanged(DxfEditStyle style)
    {
        pointLineEditStyle = style;
        pointLineCadDocument?.UpdatePointLineStyle(style);
        pointLineEditDocument?.UpdatePointLineEditStyle(style);
        UpdateCadWorkspaceStyle(style);
    }

    // 선택 버튼을 누르면 원본 DXF 객체를 클릭해 속성을 확인하는 모드를 켜거나 끕니다.
    private void SelectButton_Click(object? sender, EventArgs e)
    {
        if (isSelectionModeActive) StopSelectionMode();
        else StartSelectionMode();
    }

    // 활성 DXF 문서에 선택 모드를 켜고, 선택 결과를 오른쪽 속성 패널에 연결합니다.
    private void StartSelectionMode()
    {
        if (dockPanel1.ActiveDocument is not Docment_Dxf document)
        {
            MessageBox.Show("\uBA3C\uC800 DXF \uD30C\uC77C\uC744 \uC5F4\uC5B4 \uC8FC\uC138\uC694.", "\uC120\uD0DD", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (isPointLineModeActive) StopPointLineMode();

        selectionDocument = document;
        isSelectionModeActive = true;
        SetSelectionButtonPressed(true);
        SetWorkSelectionModeVisible(true);
        ShowSelectionLayerList(document);
        document.SetSelectionMode(true, ShowSelectedEntityProperties);
        statusLabel.Text = "\uC120\uD0DD \uBAA8\uB4DC: \uC120\uACFC \uD3F4\uB9AC\uC120\uC744 \uD074\uB9AD\uD558\uC138\uC694.";
    }

    // 선택 모드를 종료하고 선택 강조 및 오른쪽 속성 표시를 초기 안내 상태로 되돌립니다.
    private void StopSelectionMode()
    {
        selectionDocument?.SetSelectionMode(false, null);
        selectionDocument = null;
        isSelectionModeActive = false;
        SetSelectionButtonPressed(false);
        SetWorkSelectionModeVisible(false);
        HideSelectionLayerList();
        UpdateRightPanelSelectionInfo(null);
        propertyTitle.Text = "\uC18D\uC131 / \uC124\uC815";
        propertyGuide.Text = "\uC120\uD0DD\uD55C \uAC1D\uCCB4\uC758 \uC18D\uC131\uC774 \uD45C\uC2DC\uB429\uB2C8\uB2E4.";
        statusLabel.Text = "\uC120\uD0DD \uBAA8\uB4DC\uB97C \uC885\uB8CC\uD588\uC2B5\uB2C8\uB2E4.";
    }

    // 선택한 객체의 종류, DXF 레이어명과 기본 형상 정보를 오른쪽 패널에 표시합니다.
    private void ShowSelectedEntityProperties(DxfSelectionInfo? selection)
    {
        propertyTitle.Text = "\uC120\uD0DD / \uB808\uC774\uC5B4";
        propertyGuide.Text = selection is null
            ? "\uAC1D\uCCB4\uB97C \uC120\uD0DD\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4. \uC120 \uB610\uB294 \uD3F4\uB9AC\uC120 \uAC00\uAE4C\uC774\uB97C \uD074\uB9AD\uD558\uC138\uC694."
            : $"\uC885\uB958: {selection.EntityType}\r\n\uB808\uC774\uC5B4: {selection.LayerName}\r\n{selection.Detail}";
        UpdateRightPanelSelectionInfo(selection);

        // 도면에서 객체를 클릭하면 오른쪽 목록에서도 같은 레이어 행을 선택해 현재 위치를 알립니다.
        if (selection is not null && selectionLayerList is not null)
        {
            int layerIndex = selectionLayerList.FindStringExact(selection.LayerName);
            if (layerIndex >= 0)
            {
                selectionLayerList.SelectedIndex = layerIndex;
                selectionLayerList.TopIndex = layerIndex;
            }
        }
    }

    // 선택 모드가 켜졌을 때 버튼을 눌린 형태로 표시합니다.
    private void SetSelectionButtonPressed(bool pressed)
    {
        menuEdit.Tag = pressed ? PressedRibbonButtonTag : null;
        menuEdit.BackColor = pressed ? Color.FromArgb(27, 94, 174) : Color.FromArgb(247, 250, 253);
        menuEdit.ForeColor = pressed ? Color.White : Color.FromArgb(28, 45, 62);
        menuEdit.FlatAppearance.BorderSize = pressed ? 1 : 0;
        menuEdit.FlatAppearance.BorderColor = pressed ? Color.FromArgb(12, 66, 135) : Color.FromArgb(247, 250, 253);
    }

    // 선택 모드일 때만 오른쪽 속성 패널 아래에 DXF 내부 레이어의 표시 목록을 넣습니다.
    private void ShowSelectionLayerList(Docment_Dxf document)
    {
        HideSelectionLayerList();

        selectionLayerButtons = new Panel
        {
            Dock = DockStyle.Bottom,
            Height = 40,
            Padding = new Padding(8, 6, 8, 6)
        };

        // 작업 패널 안에서도 세 버튼이 한 줄에 모두 보이도록 폭을 맞춥니다.
        var showAll = new Button { Text = "\uC804\uCCB4 \uD45C\uC2DC", Left = 8, Top = 5, Width = 72, Height = 28 };
        showAll.Click += (_, _) => SetAllSelectionLayers(document, true);
        var hideAll = new Button { Text = "\uC804\uCCB4 \uC228\uAE40", Left = 86, Top = 5, Width = 72, Height = 28 };
        hideAll.Click += (_, _) => SetAllSelectionLayers(document, false);
        selectionLayerColorButton = new Button { Text = "\uC0C9\uC0C1 \uBCC0\uACBD", Left = 164, Top = 5, Width = 84, Height = 28, Enabled = false };
        selectionLayerColorButton.Click += (_, _) => ChangeSelectedLayerColor(document);
        selectionLayerButtons.Controls.Add(showAll);
        selectionLayerButtons.Controls.Add(hideAll);
        selectionLayerButtons.Controls.Add(selectionLayerColorButton);

        selectionLayerList = new CheckedListBox
        {
            Dock = DockStyle.Fill,
            CheckOnClick = true,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("\uB9D1\uC740 \uACE0\uB515", 9F),
            IntegralHeight = false
        };

        foreach (string layerName in document.GetLayerNames())
        {
            selectionLayerList.Items.Add(layerName, document.IsLayerVisible(layerName));
        }

        selectionLayerList.ItemCheck += (_, eventArgs) =>
        {
            if (selectionLayerList.Items[eventArgs.Index] is string layerName)
            {
                document.SetLayerVisible(layerName, eventArgs.NewValue == CheckState.Checked);
            }
        };

        selectionLayerList.SelectedIndexChanged += (_, _) => UpdateLayerColorButton(document);

        Control selectionHost = selectionLayerHost ?? propertyPanel;
        selectionHost.Controls.Add(selectionLayerList);
        selectionHost.Controls.Add(selectionLayerButtons);
        selectionHost.Controls.SetChildIndex(selectionLayerList, 0);
        selectionHost.Controls.SetChildIndex(selectionLayerButtons, 1);
        propertyTitle.Text = "\uC120\uD0DD / \uB808\uC774\uC5B4";
        propertyGuide.Text = "\uB808\uC774\uC5B4\uB97C \uCCB4\uD06C\uD558\uBA74 \uD654\uBA74\uC5D0 \uD45C\uC2DC\uB429\uB2C8\uB2E4.\r\n\uC120 \uB610\uB294 \uD3F4\uB9AC\uC120\uC744 \uD074\uB9AD\uD558\uBA74 \uC18D\uC131\uC744 \uBCFC \uC218 \uC788\uC2B5\uB2C8\uB2E4.";
    }

    // 전체 표시·숨김 버튼이 체크 상태와 실제 도면 가시성을 함께 바꾸도록 처리합니다.
    private void SetAllSelectionLayers(Docment_Dxf document, bool isVisible)
    {
        if (selectionLayerList is null) return;

        for (int index = 0; index < selectionLayerList.Items.Count; index++)
        {
            if (selectionLayerList.Items[index] is string layerName)
            {
                selectionLayerList.SetItemChecked(index, isVisible);
                document.SetLayerVisible(layerName, isVisible);
            }
        }
    }

    // 목록에서 선택한 레이어의 현재 색상을 버튼에 미리 보여 줍니다.
    private void UpdateLayerColorButton(Docment_Dxf document)
    {
        if (selectionLayerColorButton is null) return;

        if (selectionLayerList?.SelectedItem is not string layerName)
        {
            selectionLayerColorButton.Enabled = false;
            selectionLayerColorButton.Text = "\uC0C9\uC0C1 \uBCC0\uACBD";
            selectionLayerColorButton.BackColor = SystemColors.Control;
            return;
        }

        selectionLayerColorButton.Enabled = true;
        selectionLayerColorButton.Text = "\uC0C9\uC0C1 \uBCC0\uACBD";
        selectionLayerColorButton.BackColor = document.GetLayerColor(layerName);
        selectionLayerColorButton.ForeColor = selectionLayerColorButton.BackColor.GetBrightness() < 0.45F ? Color.White : Color.Black;
    }

    // 선택한 레이어의 색상을 ColorDialog에서 고르고 해당 레이어 도형에 즉시 적용합니다.
    private void ChangeSelectedLayerColor(Docment_Dxf document)
    {
        if (selectionLayerList?.SelectedItem is not string layerName) return;

        using var dialog = new ColorDialog { Color = document.GetLayerColor(layerName), FullOpen = true };
        if (dialog.ShowDialog() != DialogResult.OK) return;

        document.SetLayerColor(layerName, dialog.Color);
        UpdateLayerColorButton(document);
    }

    // 선택 모드를 끝내면 선택 전용 레이어 목록을 제거해 레이어 버튼 영역은 빈 상태로 유지합니다.
    private void HideSelectionLayerList()
    {
        Control selectionHost = selectionLayerHost ?? propertyPanel;
        if (selectionLayerList is not null)
        {
            selectionHost.Controls.Remove(selectionLayerList);
            selectionLayerList.Dispose();
            selectionLayerList = null;
        }

        if (selectionLayerButtons is not null)
        {
            selectionHost.Controls.Remove(selectionLayerButtons);
            selectionLayerButtons.Dispose();
            selectionLayerButtons = null;
        }

        selectionLayerColorButton = null;
    }

    // [LAS·DEM 추가 기능] DXF 전용 Importer로 보내지 않을 지형 자료 확장자를 구분합니다.
    private static bool IsLasOrDemDocument(string path)
    {
        string extension = Path.GetExtension(path);
        return extension.Equals(".las", StringComparison.OrdinalIgnoreCase)
            || extension.Equals(".laz", StringComparison.OrdinalIgnoreCase)
            || extension.Equals(".dem", StringComparison.OrdinalIgnoreCase)
            || extension.Equals(".tif", StringComparison.OrdinalIgnoreCase)
            || extension.Equals(".tiff", StringComparison.OrdinalIgnoreCase)
            || extension.Equals(".asc", StringComparison.OrdinalIgnoreCase);
    }

    // [LAS·DEM 추가 기능] 동일 파일의 중복 탭을 막고 중앙 점/선 작업 문서로 엽니다.
    // 파일 선택은 Tab_File에서 하지만 실제 작업 문서 구성은 요청대로 Tab_Edit에 배치했습니다.
    private void OpenLasOrDemDocument(string path)
    {
        string fullPath = Path.GetFullPath(path);
        TerrainEditDocument? opened = dockPanel1.Documents
            .OfType<TerrainEditDocument>()
            .FirstOrDefault(document => string.Equals(document.DocumentPath, fullPath, StringComparison.OrdinalIgnoreCase));

        if (opened is not null)
        {
            opened.Activate();
            return;
        }

        var document = new TerrainEditDocument(fullPath);
        document.Show(dockPanel1, WeifenLuo.WinFormsUI.Docking.DockState.Document);
        document.Activate();
    }
}

// 점과 선의 색상 및 크기를 한 화면에서 선택할 수 있는 팝업 내용 패널입니다.
internal sealed class PointLineStylePanel : UserControl
{
    // 사용자가 속성을 변경했을 때 최신 스타일을 전달하는 이벤트입니다.
    internal event Action<DxfEditStyle>? EditStyleChanged;

    // 현재 선택한 점과 선의 표시 속성입니다.
    private Color pointColor;
    private Color lineColor;
    private float pointSize;
    private float lineWidth;

    // 색상 선택표에서 공통으로 사용할 기본 색상 목록입니다.
    private static readonly Color[] PaletteColors =
    {
        Color.Black, Color.FromArgb(90, 90, 90), Color.FromArgb(155, 0, 30),
        Color.FromArgb(230, 35, 40), Color.FromArgb(255, 120, 30), Color.FromArgb(255, 195, 25),
        Color.FromArgb(30, 170, 85), Color.FromArgb(20, 150, 210), Color.FromArgb(75, 95, 200),
        Color.FromArgb(155, 70, 175)
    };

    // 초기 스타일을 받아 색상표와 크기 입력 컨트롤을 구성합니다.
    internal PointLineStylePanel(DxfEditStyle initialStyle)
    {
        pointColor = initialStyle.PointColor;
        lineColor = initialStyle.LineColor;
        pointSize = initialStyle.PointSize;
        lineWidth = initialStyle.LineWidth;
        Size = new Size(350, 194);
        BackColor = Color.White;
        BorderStyle = BorderStyle.FixedSingle;

        Controls.Add(CreateLabel("점/선 표시 설정", 12, 10, 320, true));
        Controls.Add(CreateLabel("점 색상", 12, 42, 70, false));
        Controls.Add(CreateColorRow(68, pointColor, color => { pointColor = color; RaiseStyleChanged(); }));
        Controls.Add(CreateLabel("선 색상", 12, 100, 70, false));
        Controls.Add(CreateColorRow(126, lineColor, color => { lineColor = color; RaiseStyleChanged(); }));
        Controls.Add(CreateLabel("점 크기", 12, 164, 58, false));
        Controls.Add(CreateSizeInput(70, 160, pointSize, 2, 20, value => { pointSize = value; RaiseStyleChanged(); }));
        Controls.Add(CreateLabel("선 두께", 180, 164, 58, false));
        Controls.Add(CreateSizeInput(244, 160, lineWidth, 1, 10, value => { lineWidth = value; RaiseStyleChanged(); }));
    }

    // 팝업 제목과 각 설정 항목에 사용할 라벨을 생성합니다.
    private static Label CreateLabel(string text, int left, int top, int width, bool title)
    {
        return new Label
        {
            Text = text, Left = left, Top = top, Width = width, Height = 22,
            Font = new Font("맑은 고딕", title ? 10F : 9F, title ? FontStyle.Bold : FontStyle.Regular),
            ForeColor = Color.FromArgb(35, 48, 61)
        };
    }

    // 지정한 색상을 선택할 수 있는 원형 버튼의 가로 색상표를 생성합니다.
    private static FlowLayoutPanel CreateColorRow(int top, Color selectedColor, Action<Color> colorSelected)
    {
        var row = new FlowLayoutPanel { Left = 10, Top = top, Width = 326, Height = 28, WrapContents = false };
        var buttons = new List<ColorSwatchButton>();

        foreach (Color color in PaletteColors)
        {
            var button = new ColorSwatchButton(color);
            button.SetSelected(color.ToArgb() == selectedColor.ToArgb());
            button.Click += (_, _) =>
            {
                foreach (ColorSwatchButton item in buttons) item.SetSelected(false);
                button.SetSelected(true);
                colorSelected(button.SwatchColor);
            };
            buttons.Add(button);
            row.Controls.Add(button);
        }
        return row;
    }

    // 점 크기 또는 선 두께를 숫자로 선택하는 입력 컨트롤을 생성합니다.
    private static NumericUpDown CreateSizeInput(int left, int top, float value, int minimum, int maximum, Action<float> valueChanged)
    {
        var input = new NumericUpDown
        {
            Left = left, Top = top, Width = 72, Minimum = minimum, Maximum = maximum,
            DecimalPlaces = 1, Increment = 0.5M, Value = (decimal)value
        };
        input.ValueChanged += (_, _) => valueChanged((float)input.Value);
        return input;
    }

    // 현재 선택된 속성을 하나의 스타일 값으로 만들어 변경 이벤트를 발생시킵니다.
    private void RaiseStyleChanged()
    {
        EditStyleChanged?.Invoke(new DxfEditStyle(pointColor, pointSize, lineColor, lineWidth));
    }
}

// 색상을 원형으로 보여 주고 선택 상태를 바깥 테두리로 표시하는 버튼입니다.
internal sealed class ColorSwatchButton : Control
{
    // 이 버튼이 나타내는 실제 색상입니다.
    internal Color SwatchColor { get; }

    // 선택 상태의 내부 저장값입니다.
    private bool selected;

    // 지정한 색상을 가진 원형 색상 버튼을 초기화합니다.
    internal ColorSwatchButton(Color color)
    {
        SwatchColor = color;
        Size = new Size(30, 26);
        Margin = new Padding(1, 0, 1, 0);
        Cursor = Cursors.Hand;
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
    }

    // 현재 색상표에서 이 버튼의 선택 상태를 변경하고 화면을 다시 그립니다.
    internal void SetSelected(bool value)
    {
        selected = value;
        Invalidate();
    }

    // 원형 색상과 선택 여부를 나타내는 파란색 바깥 테두리를 화면에 그립니다.
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        if (selected)
        {
            using var selectionPen = new Pen(Color.FromArgb(20, 105, 190), 2F);
            e.Graphics.DrawEllipse(selectionPen, new Rectangle(3, 1, 23, 23));
        }
        using var brush = new SolidBrush(SwatchColor);
        using var borderPen = new Pen(Color.FromArgb(100, 100, 100));
        e.Graphics.FillEllipse(brush, new Rectangle(7, 5, 15, 15));
        e.Graphics.DrawEllipse(borderPen, new Rectangle(7, 5, 15, 15));
    }

    // 마우스로 색상 버튼을 누르면 일반 Click 이벤트를 발생시킵니다.
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button == MouseButtons.Left) OnClick(EventArgs.Empty);
    }
}

// [LAS·DEM 추가 기능] LAS·DEM 파일을 중앙 탭으로 열고 Tab_Edit 점/선 도구를 사용하도록 추가한 문서입니다.
// 실제 포인트클라우드·고도 렌더링은 전용 파서가 필요하므로 현재는 파일 정보와 편집 캔버스를 제공합니다.
internal sealed class TerrainEditDocument : WeifenLuo.WinFormsUI.Docking.DockContent, IPointLineEditableDocument
{
    private readonly TerrainEditCanvas canvas;

    // 동일 LAS·DEM 파일의 중복 열기를 검사할 때 사용하는 정규화된 전체 경로입니다.
    internal string DocumentPath { get; }

    // 파일 이름을 문서 탭에 표시하고 점/선 입력 캔버스를 배치합니다.
    internal TerrainEditDocument(string path)
    {
        DocumentPath = Path.GetFullPath(path);
        Text = Path.GetFileName(path);
        TabText = Path.GetFileName(path);
        DockAreas = WeifenLuo.WinFormsUI.Docking.DockAreas.Document | WeifenLuo.WinFormsUI.Docking.DockAreas.Float;
        canvas = new TerrainEditCanvas(DocumentPath) { Dock = DockStyle.Fill };
        Controls.Add(canvas);
    }

    // Tab_Edit의 점/선 모드 상태를 LAS·DEM 캔버스에 전달합니다.
    void IPointLineEditableDocument.SetPointLineEditMode(DxfEditMode mode, DxfEditStyle style) => canvas.SetEditMode(mode, style);

    // 설정 팝업에서 선택한 표시 스타일을 LAS·DEM 캔버스에 전달합니다.
    void IPointLineEditableDocument.UpdatePointLineEditStyle(DxfEditStyle style) => canvas.UpdateEditStyle(style);

    // 실행 취소 명령을 LAS·DEM 편집 기록에 적용합니다.
    bool IPointLineEditableDocument.UndoPointLineEdit() => canvas.UndoEdit();

    // 다시 입력 명령을 LAS·DEM 편집 기록에 적용합니다.
    bool IPointLineEditableDocument.RedoPointLineEdit() => canvas.RedoEdit();

    // LAS·DEM 편집 캔버스의 점·선과 원본 파일 경로를 .cad 저장 구조로 변환합니다.
    CadDrawingFile IPointLineEditableDocument.CreateCadDrawing() => canvas.CreateCadDrawing();

    // 지형 문서에서 입력한 점을 폼 전체의 공용 CAD 작업 모델로 전달할 콜백을 연결합니다.
    void IPointLineEditableDocument.SetCadPointAddedCallback(Action<DxfEditPoint>? pointAdded) =>
        canvas.SetCadPointAddedCallback(pointAdded);
}

// LAS·DEM 문서에서 클릭한 점과 연결선을 화면 좌표 기준으로 보관하고 표시하는 Tab_Edit 캔버스입니다.
internal sealed class TerrainEditCanvas : Control
{
    private readonly string filePath;
    private readonly List<DxfEditPoint> points = new();
    private readonly List<DxfEditLine> lines = new();
    private readonly Stack<DxfEditAction> undoActions = new();
    private readonly Stack<DxfEditAction> redoActions = new();
    private DxfEditPoint? previousPoint;
    private DxfEditMode editMode;
    private DxfEditStyle editStyle = DxfEditStyle.Default;
    private Action<DxfEditPoint>? cadPointAdded;

    // 배경과 점·선을 깜빡임 없이 표시하도록 더블 버퍼 캔버스를 초기화합니다.
    internal TerrainEditCanvas(string path)
    {
        filePath = path;
        BackColor = Color.FromArgb(242, 246, 240);
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
    }

    // 점/선 모드 시작과 종료에 맞춰 스타일, 직전 점과 커서를 갱신합니다.
    internal void SetEditMode(DxfEditMode mode, DxfEditStyle style)
    {
        editMode = mode;
        editStyle = style;
        previousPoint = null;
        Cursor = mode == DxfEditMode.AddPointLine ? Cursors.Cross : Cursors.Default;
        Invalidate();
    }

    // 팝업에서 바꾼 색상과 크기를 기존 점·선에도 즉시 적용합니다.
    internal void UpdateEditStyle(DxfEditStyle style)
    {
        editStyle = style;
        Invalidate();
    }

    // Form1 공용 CAD 작업 모델에 새 점을 전달할 콜백을 등록하거나 해제합니다.
    internal void SetCadPointAddedCallback(Action<DxfEditPoint>? pointAdded)
    {
        cadPointAdded = pointAdded;
    }

    // 마지막 클릭으로 만든 점과 연결선을 함께 제거합니다.
    internal bool UndoEdit()
    {
        if (undoActions.Count == 0) return false;
        DxfEditAction action = undoActions.Pop();
        if (points.Count > 0) points.RemoveAt(points.Count - 1);
        if (action.Line is not null && lines.Count > 0) lines.RemoveAt(lines.Count - 1);
        previousPoint = action.PreviousPoint;
        redoActions.Push(action);
        Invalidate();
        return true;
    }

    // 마지막으로 취소한 점과 연결선을 다시 복원합니다.
    internal bool RedoEdit()
    {
        if (redoActions.Count == 0) return false;
        DxfEditAction action = redoActions.Pop();
        points.Add(action.Point);
        if (action.Line is DxfEditLine line) lines.Add(line);
        previousPoint = action.Point;
        undoActions.Push(action);
        Invalidate();
        return true;
    }

    // 점/선 모드에서 클릭 위치에 점을 추가하고 직전 점과 선으로 연결합니다.
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (editMode != DxfEditMode.AddPointLine || e.Button != MouseButtons.Left) return;

        var point = new DxfEditPoint(e.X, ClientSize.Height - e.Y);
        DxfEditPoint? previous = previousPoint;
        DxfEditLine? line = null;
        points.Add(point);
        if (previousPoint is DxfEditPoint start)
        {
            line = new DxfEditLine(start, point);
            lines.Add(line.Value);
        }

        previousPoint = point;
        cadPointAdded?.Invoke(point);
        undoActions.Push(new DxfEditAction(point, line, previous));
        redoActions.Clear();
        Invalidate();
    }

    // 파일 안내 배경과 현재 메모리에 있는 점·선을 차례로 화면에 그립니다.
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        DrawBackground(e.Graphics);
        using var linePen = new Pen(editStyle.LineColor, editStyle.LineWidth);
        using var pointBrush = new SolidBrush(editStyle.PointColor);
        foreach (DxfEditLine line in lines) e.Graphics.DrawLine(linePen, ToScreen(line.Start), ToScreen(line.End));
        foreach (DxfEditPoint point in points)
        {
            PointF screen = ToScreen(point);
            float radius = Math.Max(1F, editStyle.PointSize / 2F);
            e.Graphics.FillEllipse(pointBrush, screen.X - radius, screen.Y - radius, radius * 2F, radius * 2F);
        }
    }

    // 실제 지형 렌더러가 연결되기 전 파일 종류와 점/선 편집 가능 상태를 안내합니다.
    private void DrawBackground(Graphics graphics)
    {
        using var gridPen = new Pen(Color.FromArgb(220, 228, 218));
        for (int x = 0; x < Width; x += 50) graphics.DrawLine(gridPen, x, 0, x, Height);
        for (int y = 0; y < Height; y += 50) graphics.DrawLine(gridPen, 0, y, Width, y);
        using var titleFont = new Font("맑은 고딕", 14F, FontStyle.Bold);
        using var bodyFont = new Font("맑은 고딕", 9F);
        using var titleBrush = new SolidBrush(Color.FromArgb(37, 66, 53));
        using var bodyBrush = new SolidBrush(Color.FromArgb(85, 105, 94));
        graphics.DrawString($"{Path.GetExtension(filePath).ToUpperInvariant()} 작업 문서", titleFont, titleBrush, 24, 22);
        graphics.DrawString(Path.GetFileName(filePath), bodyFont, bodyBrush, 25, 57);
        graphics.DrawString("점/선 편집 가능 · 실제 지형 렌더러는 별도 연결 필요", bodyFont, bodyBrush, 25, 80);
    }

    // 작업 좌표의 Y축을 WinForms 화면 좌표로 변환합니다.
    private PointF ToScreen(DxfEditPoint point) => new((float)point.X, ClientSize.Height - (float)point.Y);

    // 현재 지형 편집 좌표와 표시 스타일을 .cad 파일용 데이터로 복사합니다.
    internal CadDrawingFile CreateCadDrawing()
    {
        return CadDrawingFactory.Create(points, editStyle, filePath);
    }
}
