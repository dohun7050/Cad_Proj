global using IxMilia.Dxf;
global using IxMilia.Dxf.Entities;
