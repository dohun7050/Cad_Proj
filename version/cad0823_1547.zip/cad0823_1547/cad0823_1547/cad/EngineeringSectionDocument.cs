using System.Drawing.Drawing2D;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

internal enum EngineeringSectionKind
{
    CrossSection,
    Longitudinal
}

// 실제 설계 데이터가 연결되기 전, 임도 횡단·종단 설계의 주요 개념을 확인할 수 있는 샘플 문서입니다.
internal sealed class EngineeringSectionDocument : DockContent
{
    internal EngineeringSectionKind Kind { get; }

    private readonly SplitContainer layout;
    private readonly Button explanationButton;

    internal EngineeringSectionDocument(EngineeringSectionKind kind)
    {
        Kind = kind;
        Text = kind == EngineeringSectionKind.CrossSection ? "횡단면도" : "종단면도";
        TabText = Text;
        BackColor = Color.White;

        layout = new SplitContainer
        {
            Dock = DockStyle.Fill,
            Orientation = Orientation.Vertical,
            FixedPanel = FixedPanel.Panel2,
            SplitterWidth = 6,
            Panel2Collapsed = true,
            BackColor = Color.FromArgb(190, 200, 210)
        };

        layout.Panel1.Controls.Add(new EngineeringSectionCanvas(kind) { Dock = DockStyle.Fill });
        layout.Panel2.Controls.Add(CreateExplanationPanel(kind));

        explanationButton = new Button
        {
            Width = 116,
            Height = 34,
            Text = "ⓘ  설명 보기",
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(21, 86, 145),
            ForeColor = Color.White,
            Font = new Font("맑은 고딕", 9F, FontStyle.Bold),
            Cursor = Cursors.Hand,
            Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        explanationButton.FlatAppearance.BorderColor = Color.FromArgb(135, 190, 235);
        explanationButton.Click += (_, _) => ToggleExplanation();
        layout.Panel1.Controls.Add(explanationButton);
        explanationButton.BringToFront();
        layout.Panel1.Layout += (_, _) => PositionExplanationButton();

        Controls.Add(layout);
        PositionExplanationButton();
    }

    private void PositionExplanationButton()
    {
        explanationButton.Location = new Point(
            Math.Max(8, layout.Panel1.ClientSize.Width - explanationButton.Width - 18),
            16);
        explanationButton.BringToFront();
    }

    private void ToggleExplanation()
    {
        bool show = layout.Panel2Collapsed;
        layout.Panel2Collapsed = !show;
        if (show)
        {
            int desiredPanelWidth = Math.Min(380, Math.Max(290, layout.ClientSize.Width / 3));
            layout.SplitterDistance = Math.Max(100,
                layout.ClientSize.Width - desiredPanelWidth - layout.SplitterWidth);
        }

        explanationButton.Text = show ? "✕  설명 닫기" : "ⓘ  설명 보기";
        PositionExplanationButton();
    }

    private static Control CreateExplanationPanel(EngineeringSectionKind kind)
    {
        var panel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(247, 249, 251),
            Padding = new Padding(16, 14, 12, 14)
        };

        var title = new Label
        {
            Dock = DockStyle.Top,
            Height = 58,
            Text = kind == EngineeringSectionKind.CrossSection
                ? "횡단면도 값 설명"
                : "종단면도 값 설명",
            Font = new Font("맑은 고딕", 14F, FontStyle.Bold),
            ForeColor = Color.FromArgb(15, 48, 79),
            TextAlign = ContentAlignment.MiddleLeft
        };

        var explanation = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BorderStyle = BorderStyle.None,
            BackColor = panel.BackColor,
            ForeColor = Color.FromArgb(40, 48, 56),
            Font = new Font("맑은 고딕", 9.5F),
            DetectUrls = false,
            ScrollBars = RichTextBoxScrollBars.Vertical,
            Text = GetExplanationText(kind)
        };

        var notice = new Label
        {
            Dock = DockStyle.Bottom,
            Height = 52,
            Padding = new Padding(8),
            BackColor = Color.FromArgb(230, 239, 248),
            ForeColor = Color.FromArgb(35, 73, 108),
            Font = new Font("맑은 고딕", 8.5F),
            Text = "※ 현재 수치는 화면 기능 검증용 예시입니다. 실제 설계 시 DEM·노선·설계기준과 연계해야 합니다."
        };

        panel.Controls.Add(explanation);
        panel.Controls.Add(notice);
        panel.Controls.Add(title);
        return panel;
    }

    private static string GetExplanationText(EngineeringSectionKind kind) =>
        kind == EngineeringSectionKind.CrossSection
            ? """
              1. 측점 STA. 1+240
              노선 시작점에서 1,240 m 떨어진 위치를 뜻합니다. 횡단면은 특정 측점에서 노선 진행 방향과 직각으로 잘라 본 단면입니다.

              2. 기존 지반선
              도로를 만들기 전 실제 지형입니다. 계획 도로면과 비교하여 절토·성토 구간과 단면적을 계산합니다.

              3. 계획 도로면
              시공 후 차량이 통행할 노면의 형상과 높이입니다. 종단면도의 중심선 계획고와 연결되어야 합니다.

              4. 도로폭 3.50 m
              차도와 좌우 여유폭을 포함한 폭입니다. 도로 폭이 커질수록 토공량, 훼손면적, 공사비가 증가합니다.

              5. 차도폭 3.00 m와 노견 0.25 m
              차도는 차량 통행 공간이고 노견은 가장자리 보호·통행 여유·배수를 위한 공간입니다.

              6. 횡단경사 3.0%
              노면의 물을 양쪽으로 배출하기 위한 기울기입니다.
              횡단경사(%) = 높이차 ÷ 수평거리 × 100

              7. CUT(절토)
              기존 지반이 계획면보다 높은 부분을 깎는 영역입니다. 절토고, 암반 여부, 사면 안정성과 굴착비를 검토합니다.

              8. FILL(성토)
              계획면이 기존 지반보다 높은 부분을 흙으로 채우는 영역입니다. 다짐, 침하, 토사유출과 성토사면 안정성을 검토합니다.

              9. 절토사면 1:0.8 / 성토사면 1:1.2
              비탈면의 수직·수평 비율입니다. 실제 기울기는 토질, 암반, 지하수, 사면 높이와 설계기준으로 결정합니다.

              10. 측구와 배수로
              노면수와 산지에서 내려오는 물을 모아 안전하게 배출합니다. 실제 설계에는 폭, 깊이, 종단경사와 설계유량이 필요합니다.

              11. 식생매트 보호
              절·성토사면의 침식과 토사유출을 줄이는 사면보호공입니다.

              12. 거리·표고축
              가로축은 도로 중심으로부터의 좌우 거리, 세로축은 표고입니다. 실제 좌표와 일치하는 축척을 사용해야 합니다.

              추가 산출값
              · 절토·성토 단면적(㎡)
              · 최대 절토고·성토고(m)
              · 전체 시공 영향폭(m)
              · 인접 측점과의 평균단면법에 의한 토공량(㎥)
              """
            : """
              1. 거리와 측점
              가로축은 노선 시작점부터의 누적거리입니다. 1+240은 시작점에서 1,240 m 떨어진 지점입니다.

              2. 표고
              세로축은 높이입니다. 실제 도면에는 표고 기준면과 수직·수평 축척을 함께 표시해야 합니다.

              3. 기존 지반선
              노선 중심선을 따라 DEM 또는 TIN에서 추출한 실제 지반고입니다.

              4. 계획선과 계획고
              완성하려는 도로 중심선의 높이입니다. 기존 지반과 비교하여 절토·성토 및 배수 방향을 결정합니다.

              5. 종단경사
              노선 진행 방향의 높이 변화율입니다.
              종단경사(%) = 높이차 ÷ 수평거리 × 100
              차량 등판, 제동, 배수와 토공량에 직접 영향을 줍니다.

              6. 절토·성토 영역
              기존지반 > 계획고이면 절토, 계획고 > 기존지반이면 성토입니다. 종단면의 높이차만으로 전체 토공량을 구할 수는 없으며 횡단면적이 필요합니다.

              7. PVI
              서로 다른 두 종단경사선의 이론적 교점입니다. 경사가 갑자기 바뀌지 않도록 수직곡선을 설치합니다.

              8. PVC / PVT
              PVC는 수직곡선 시작점, PVT는 수직곡선 종료점입니다. 실제 설계에서는 측점과 계획고를 함께 표시합니다.

              9. VCL = 200 m
              Vertical Curve Length, 즉 수직곡선 길이입니다. 길수록 경사 변화가 완만해져 승차감과 시거 확보에 유리합니다.

              10. K = 20
              수직곡선의 완만한 정도입니다.
              K = 수직곡선 길이 L ÷ 두 경사의 대수차 A
              K가 클수록 일반적으로 곡선이 완만합니다.

              11. 계획고·지반고 표
              각 측점의 정확한 높이를 확인하고 그래프를 검산합니다.
              높이차 = 계획고 - 지반고
              양수는 성토, 음수는 절토로 해석합니다.

              12. 수직과장
              종단면은 높이 변화를 보기 위해 세로축을 가로축보다 크게 표현할 수 있습니다. 실제 경사를 오해하지 않도록 수평·수직 축척을 표기해야 합니다.

              추가 검토값
              · 최대·평균 종단경사
              · 급경사 연속 길이
              · 최대 절토고·성토고와 발생 측점
              · 교량·암거·하천 횡단 위치
              · 정지시거 및 수직곡선 적정성
              """;
}

internal sealed class EngineeringSectionCanvas : Panel
{
    private const float DesignWidth = 1100F;
    private const float DesignHeight = 650F;
    private readonly EngineeringSectionKind kind;

    internal EngineeringSectionCanvas(EngineeringSectionKind kind)
    {
        this.kind = kind;
        BackColor = Color.FromArgb(235, 240, 245);
        SetStyle(ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.ResizeRedraw, true);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        if (ClientSize.Width <= 0 || ClientSize.Height <= 0) return;

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
        e.Graphics.Clear(BackColor);

        float scale = Math.Min(ClientSize.Width / DesignWidth, ClientSize.Height / DesignHeight);
        float offsetX = (ClientSize.Width - DesignWidth * scale) / 2F;
        float offsetY = (ClientSize.Height - DesignHeight * scale) / 2F;

        GraphicsState state = e.Graphics.Save();
        e.Graphics.TranslateTransform(offsetX, offsetY);
        e.Graphics.ScaleTransform(scale, scale);
        if (kind == EngineeringSectionKind.CrossSection)
            DrawCrossSection(e.Graphics);
        else
            DrawLongitudinal(e.Graphics);
        e.Graphics.Restore(state);
    }

    private static void DrawFrame(Graphics graphics, string title, string subtitle)
    {
        using var shadow = new SolidBrush(Color.FromArgb(35, 55, 75));
        graphics.FillRectangle(shadow, 18, 18, 1064, 614);
        using var paper = new SolidBrush(Color.White);
        graphics.FillRectangle(paper, 22, 22, 1056, 606);
        using var header = new SolidBrush(Color.FromArgb(12, 43, 70));
        graphics.FillRectangle(header, 22, 22, 1056, 48);
        using var titleFont = new Font("맑은 고딕", 17F, FontStyle.Bold);
        using var subtitleFont = new Font("맑은 고딕", 11F, FontStyle.Bold);
        graphics.DrawString(title, titleFont, Brushes.White, 38, 31);
        SizeF subtitleSize = graphics.MeasureString(subtitle, subtitleFont);
        graphics.DrawString(subtitle, subtitleFont, Brushes.White, 1060 - subtitleSize.Width, 38);
    }

    private static void DrawCrossSection(Graphics g)
    {
        DrawFrame(g, "횡단면도", "STA. 1+240");

        const float baseY = 535F;
        const float centerX = 550F;
        using var gridPen = new Pen(Color.FromArgb(218, 224, 230), 1F);
        using var axisPen = new Pen(Color.FromArgb(74, 84, 94), 1.4F);
        using var groundPen = new Pen(Color.FromArgb(223, 63, 55), 2.5F);
        using var designPen = new Pen(Color.FromArgb(45, 55, 65), 2.4F);
        using var centerPen = new Pen(Color.FromArgb(75, 98, 120), 1.3F) { DashStyle = DashStyle.Dash };
        using var labelFont = new Font("맑은 고딕", 10F);
        using var boldFont = new Font("맑은 고딕", 11F, FontStyle.Bold);
        using var smallFont = new Font("맑은 고딕", 9F);

        for (int elevation = 630; elevation <= 680; elevation += 10)
        {
            float y = baseY - (elevation - 630) * 7.2F;
            g.DrawLine(gridPen, 72, y, 1028, y);
            g.DrawString(elevation.ToString(), smallFont, Brushes.DimGray, 42, y - 8);
        }
        g.DrawString("표고 (m)", boldFont, Brushes.Black, 35, 83);
        g.DrawLine(axisPen, 72, baseY, 1028, baseY);

        for (int distance = -20; distance <= 20; distance += 5)
        {
            float x = centerX + distance * 22F;
            g.DrawLine(axisPen, x, baseY, x, baseY + 6);
            string text = distance.ToString();
            SizeF size = g.MeasureString(text, smallFont);
            g.DrawString(text, smallFont, Brushes.DimGray, x - size.Width / 2, baseY + 9);
        }
        g.DrawString("거리 (m)", boldFont, Brushes.Black, 982, baseY + 10);

        PointF[] ground =
        {
            new(95, 115), new(160, 170), new(235, 240), new(315, 322), new(390, 410),
            new(468, 446), new(550, 458), new(630, 466), new(700, 492), new(770, 520),
            new(850, 542), new(930, 558), new(1015, 570)
        };

        PointF[] roadTop = { new(470, 420), new(550, 430), new(630, 420) };
        PointF[] roadBottom = { new(452, 448), new(550, 459), new(648, 448) };

        using var cutBrush = new HatchBrush(HatchStyle.ForwardDiagonal,
            Color.FromArgb(130, 230, 92, 76), Color.FromArgb(45, 244, 177, 166));
        PointF[] cutArea =
        {
            ground[0], ground[1], ground[2], ground[3], ground[4], ground[5],
            new(452, 448), new(430, 483), new(390, 483), new(390, 410)
        };
        g.FillPolygon(cutBrush, cutArea);

        using var fillBrush = new HatchBrush(HatchStyle.BackwardDiagonal,
            Color.FromArgb(130, 55, 130, 210), Color.FromArgb(45, 160, 203, 240));
        PointF[] fillArea =
        {
            roadBottom[2], new(705, 480), new(760, 513), new(805, 533),
            ground[9], ground[8], ground[7], ground[6]
        };
        g.FillPolygon(fillBrush, fillArea);

        g.DrawLines(groundPen, ground);
        using var roadBrush = new SolidBrush(Color.FromArgb(210, 215, 218));
        g.FillPolygon(roadBrush, roadTop.Concat(roadBottom.Reverse()).ToArray());
        g.DrawLines(designPen, roadTop);
        g.DrawLines(designPen, roadBottom);
        g.DrawLine(designPen, roadTop[0], roadBottom[0]);
        g.DrawLine(designPen, roadTop[2], roadBottom[2]);

        // 좌측 측구와 절토 비탈면, 우측 성토 비탈면을 표시합니다.
        PointF[] ditch = { new(452, 448), new(440, 468), new(418, 468), new(430, 483), new(390, 483) };
        g.DrawLines(designPen, ditch);
        g.DrawLine(designPen, 390, 483, 315, 322);
        g.DrawLine(designPen, 648, 448, 705, 480);
        g.DrawLine(designPen, 705, 480, 805, 533);
        g.DrawLine(centerPen, centerX, 285, centerX, baseY);

        g.DrawString("CUT", new Font("맑은 고딕", 18F, FontStyle.Bold), Brushes.IndianRed, 120, 110);
        g.DrawString("FILL", new Font("맑은 고딕", 18F, FontStyle.Bold), Brushes.RoyalBlue, 915, 110);

        DrawDimension(g, 470, 630, 190, "도로폭 3.50 m", boldFont);
        DrawDimension(g, 485, 615, 232, "차도폭 3.00 m", labelFont);
        DrawDimension(g, 470, 485, 270, "0.25", smallFont);
        DrawDimension(g, 615, 630, 270, "0.25", smallFont);

        g.DrawString("3.0%", boldFont, Brushes.Black, 492, 380);
        g.DrawString("3.0%", boldFont, Brushes.Black, 580, 380);
        DrawArrow(g, new PointF(530, 405), new PointF(492, 413), Color.FromArgb(45, 55, 65));
        DrawArrow(g, new PointF(570, 405), new PointF(608, 413), Color.FromArgb(45, 55, 65));

        g.DrawString("절토사면 1:0.8", labelFont, Brushes.IndianRed, 220, 270);
        g.DrawString("식생매트 보호", labelFont, Brushes.Black, 160, 355);
        g.DrawString("측구 0.50 m", labelFont, Brushes.Black, 315, 462);
        g.DrawString("노면", labelFont, Brushes.Black, 525, 455);
        g.DrawString("성토사면 1:1.2", labelFont, Brushes.RoyalBlue, 720, 452);
        g.DrawString("식생매트", labelFont, Brushes.Black, 805, 475);
        g.DrawString("배수로", labelFont, Brushes.Black, 900, 522);

        using var badgeBrush = new SolidBrush(Color.FromArgb(12, 82, 170));
        g.FillRoundedRectangle(badgeBrush, new RectangleF(510, 578, 80, 32), 6);
        g.DrawString("1+240", boldFont, Brushes.White, 526, 583);
        g.DrawString("※ 예시 설계단면 · 실제 수치는 노선 및 DEM 연계 후 산정", smallFont,
            Brushes.DimGray, 735, 596);
    }

    private static void DrawLongitudinal(Graphics g)
    {
        DrawFrame(g, "종단면도", "노선 계획고 · 기존지반 비교");
        RectangleF plot = new(95, 105, 930, 380);
        using var gridPen = new Pen(Color.FromArgb(218, 224, 230), 1F);
        using var axisPen = new Pen(Color.FromArgb(74, 84, 94), 1.4F);
        using var groundPen = new Pen(Color.FromArgb(120, 126, 132), 2F);
        using var gradePen = new Pen(Color.FromArgb(238, 70, 61), 2.8F);
        using var stationPen = new Pen(Color.FromArgb(48, 119, 205), 1.5F) { DashStyle = DashStyle.Dash };
        using var curvePen = new Pen(Color.FromArgb(38, 48, 58), 1.5F);
        using var smallFont = new Font("맑은 고딕", 9F);
        using var labelFont = new Font("맑은 고딕", 10F);
        using var boldFont = new Font("맑은 고딕", 10F, FontStyle.Bold);

        for (int elevation = 560; elevation <= 740; elevation += 20)
        {
            float y = plot.Bottom - (elevation - 560) / 180F * plot.Height;
            g.DrawLine(gridPen, plot.Left, y, plot.Right, y);
            g.DrawString(elevation.ToString(), smallFont, Brushes.DimGray, 55, y - 7);
        }
        g.DrawString("표고 (m)", boldFont, Brushes.Black, 43, 82);
        g.DrawLine(axisPen, plot.Left, plot.Bottom, plot.Right, plot.Bottom);

        for (int station = 0; station <= 4000; station += 500)
        {
            float x = plot.Left + station / 4000F * plot.Width;
            g.DrawLine(gridPen, x, plot.Top, x, plot.Bottom);
            string text = station == 0 ? "0+000" : $"{station / 1000}+{station % 1000:000}";
            SizeF size = g.MeasureString(text, smallFont);
            g.DrawString(text, smallFont, Brushes.DimGray, x - size.Width / 2, plot.Bottom + 8);
        }
        g.DrawString("거리 (m)", boldFont, Brushes.Black, 970, plot.Bottom + 25);

        float[] groundElevation = { 568, 588, 605, 620, 640, 650, 664, 676, 671, 684, 700, 714, 723, 735, 742, 748, 746 };
        float[] designElevation = { 568, 580, 593, 606, 618, 630, 642, 654, 666, 674, 680, 685, 688, 684, 679, 684, 690 };
        PointF[] ground = BuildProfile(plot, groundElevation, 560, 750);
        PointF[] design = BuildProfile(plot, designElevation, 560, 750);

        for (int index = 0; index < ground.Length - 1; index++)
        {
            PointF[] area = { ground[index], ground[index + 1], design[index + 1], design[index] };
            float groundMid = (ground[index].Y + ground[index + 1].Y) / 2F;
            float designMid = (design[index].Y + design[index + 1].Y) / 2F;
            using Brush brush = groundMid < designMid
                ? new HatchBrush(HatchStyle.ForwardDiagonal, Color.FromArgb(150, 224, 92, 70), Color.FromArgb(35, 244, 182, 165))
                : new HatchBrush(HatchStyle.BackwardDiagonal, Color.FromArgb(145, 48, 132, 215), Color.FromArgb(35, 162, 205, 243));
            g.FillPolygon(brush, area);
        }
        g.DrawLines(groundPen, ground);
        g.DrawLines(gradePen, design);

        float selectedX = plot.Left + 1240F / 4000F * plot.Width;
        g.DrawLine(stationPen, selectedX, 72, selectedX, 560);
        using var badgeBrush = new SolidBrush(Color.FromArgb(12, 82, 170));
        g.FillRoundedRectangle(badgeBrush, new RectangleF(selectedX - 40, 74, 80, 28), 6);
        g.DrawString("STA. 1+240", boldFont, Brushes.White, selectedX - 34, 79);
        g.FillRoundedRectangle(badgeBrush, new RectangleF(selectedX - 31, 496, 62, 28), 6);
        g.DrawString("1+240", boldFont, Brushes.White, selectedX - 24, 501);

        // 종단곡선과 경사 정보를 도식화합니다.
        DrawVerticalCurve(g, new PointF(210, 255), new PointF(390, 175), new PointF(520, 225),
            "L = 900 m   i = 5.0%", "VCL = 200 m   K = 20.0", curvePen, labelFont);
        DrawVerticalCurve(g, new PointF(610, 210), new PointF(760, 160), new PointF(900, 235),
            "L = 1,100 m   i = -4.5%", "", curvePen, labelFont);

        // 범례
        g.DrawLine(groundPen, 120, 92, 155, 92);
        g.DrawString("기존지반", smallFont, Brushes.Black, 162, 84);
        g.DrawLine(gradePen, 240, 92, 275, 92);
        g.DrawString("계획선", smallFont, Brushes.Black, 282, 84);
        using var cutLegend = new SolidBrush(Color.FromArgb(185, 235, 118, 82));
        using var fillLegend = new SolidBrush(Color.FromArgb(185, 73, 151, 220));
        g.FillRectangle(cutLegend, 350, 85, 24, 13);
        g.DrawString("절토", smallFont, Brushes.Black, 380, 82);
        g.FillRectangle(fillLegend, 435, 85, 24, 13);
        g.DrawString("성토", smallFont, Brushes.Black, 465, 82);

        DrawProfileTable(g, plot, groundElevation, designElevation, smallFont);
    }

    private static PointF[] BuildProfile(RectangleF plot, IReadOnlyList<float> values, float min, float max)
    {
        var result = new PointF[values.Count];
        for (int index = 0; index < values.Count; index++)
        {
            float x = plot.Left + index / (float)(values.Count - 1) * plot.Width;
            float y = plot.Bottom - (values[index] - min) / (max - min) * plot.Height;
            result[index] = new PointF(x, y);
        }
        return result;
    }

    private static void DrawProfileTable(Graphics g, RectangleF plot, IReadOnlyList<float> ground,
        IReadOnlyList<float> design, Font font)
    {
        float top = 545;
        float rowHeight = 23;
        float labelWidth = 90;
        string[] rowLabels = { "계획고", "지반고", "절토/성토" };
        using var borderPen = new Pen(Color.FromArgb(185, 195, 205));
        using var labelBrush = new SolidBrush(Color.FromArgb(238, 242, 246));
        g.FillRectangle(labelBrush, 38, top, labelWidth, rowHeight * 3);
        g.DrawRectangle(borderPen, 38, top, 1010, rowHeight * 3);

        for (int row = 0; row < 3; row++)
        {
            float y = top + row * rowHeight;
            g.DrawLine(borderPen, 38, y, 1048, y);
            g.DrawString(rowLabels[row], font, Brushes.Black, 52, y + 4);
        }

        int[] indices = { 0, 2, 4, 6, 8, 10, 12, 14, 16 };
        for (int column = 0; column < indices.Length; column++)
        {
            int index = indices[column];
            float x = 142 + column * 109;
            g.DrawString(design[index].ToString("0.00"), font, Brushes.Black, x, top + 4);
            g.DrawString(ground[index].ToString("0.00"), font, Brushes.Black, x, top + rowHeight + 4);
            float difference = design[index] - ground[index];
            using var brush = new SolidBrush(difference >= 0 ? Color.RoyalBlue : Color.OrangeRed);
            g.DrawString(difference.ToString("+0.00;-0.00;0.00"), font, brush, x, top + rowHeight * 2 + 4);
        }
    }

    private static void DrawVerticalCurve(Graphics g, PointF start, PointF pvi, PointF end,
        string gradeText, string curveText, Pen pen, Font font)
    {
        g.DrawLine(pen, start, pvi);
        g.DrawLine(pen, pvi, end);
        using var dashPen = new Pen(Color.FromArgb(90, 100, 110), 1F) { DashStyle = DashStyle.Dash };
        g.DrawLine(dashPen, pvi.X, pvi.Y, pvi.X, pvi.Y + 100);
        g.FillEllipse(Brushes.Black, pvi.X - 3, pvi.Y - 3, 6, 6);
        g.DrawString(gradeText, font, Brushes.Black, start.X + 20, start.Y - 45);
        if (!string.IsNullOrEmpty(curveText))
            g.DrawString(curveText, font, Brushes.Black, pvi.X + 10, pvi.Y - 45);
    }

    private static void DrawDimension(Graphics g, float x1, float x2, float y, string text, Font font)
    {
        using var pen = new Pen(Color.FromArgb(55, 65, 75), 1.2F);
        g.DrawLine(pen, x1, y, x2, y);
        g.DrawLine(pen, x1, y - 8, x1, y + 8);
        g.DrawLine(pen, x2, y - 8, x2, y + 8);
        DrawArrowHead(g, new PointF(x1, y), 0F, pen.Color);
        DrawArrowHead(g, new PointF(x2, y), 180F, pen.Color);
        SizeF size = g.MeasureString(text, font);
        g.DrawString(text, font, Brushes.Black, (x1 + x2 - size.Width) / 2F, y - 24);
    }

    private static void DrawArrow(Graphics g, PointF start, PointF end, Color color)
    {
        using var pen = new Pen(color, 1.3F);
        g.DrawLine(pen, start, end);
        float angle = MathF.Atan2(end.Y - start.Y, end.X - start.X) * 180F / MathF.PI;
        DrawArrowHead(g, end, angle + 180F, color);
    }

    private static void DrawArrowHead(Graphics g, PointF point, float angleDegrees, Color color)
    {
        float angle = angleDegrees * MathF.PI / 180F;
        PointF a = new(point.X + MathF.Cos(angle - .45F) * 7F, point.Y + MathF.Sin(angle - .45F) * 7F);
        PointF b = new(point.X + MathF.Cos(angle + .45F) * 7F, point.Y + MathF.Sin(angle + .45F) * 7F);
        using var brush = new SolidBrush(color);
        g.FillPolygon(brush, new[] { point, a, b });
    }
}

internal static class GraphicsExtensions
{
    internal static void FillRoundedRectangle(this Graphics graphics, Brush brush, RectangleF bounds, float radius)
    {
        using var path = new GraphicsPath();
        float diameter = radius * 2F;
        path.AddArc(bounds.Left, bounds.Top, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Top, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.Left, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        graphics.FillPath(brush, path);
    }
}
