﻿namespace cad;

// [DXF 문서 추가 기능 영역]
// 원본 DxfDocument.cs의 가져오기·확대·이동 구조를 유지하기 위해 새 편집 로직은 이 partial 파일에 모았습니다.
// 원본 파일에는 그리기와 마우스 입력을 이 파일로 전달하는 최소 연결 코드만 두었습니다.

// 원본 DxfDocument.cs를 교체하지 않고 추가할 편집 모드를 구분합니다.
internal enum DxfEditMode
{
    None,
    AddPointLine,
    Select
}

// 사용자가 클릭한 DXF 원본 좌표를 보관하기 위해 추가했습니다.
internal readonly record struct DxfEditPoint(double X, double Y);

// 연속된 두 점을 연결하는 추가 선을 보관하기 위해 추가했습니다.
internal readonly record struct DxfEditLine(DxfEditPoint Start, DxfEditPoint End);

// 한 번의 클릭을 점과 연결선 단위로 실행 취소할 수 있도록 작업 기록을 추가했습니다.
internal readonly record struct DxfEditAction(DxfEditPoint Point, DxfEditLine? Line, DxfEditPoint? PreviousPoint);

// 선택한 원본 DXF 객체의 종류·레이어·기본 정보를 속성 패널에 전달합니다.
internal sealed record DxfSelectionInfo(string EntityType, string LayerName, string Detail);

// 점 색상·크기와 선 색상·두께를 설정 팝업에서 전달하기 위해 추가했습니다.
internal readonly record struct DxfEditStyle(Color PointColor, float PointSize, Color LineColor, float LineWidth)
{
    // 사용자가 변경하기 전 적용할 기본 점/선 표시 스타일입니다.
    internal static DxfEditStyle Default => new(
        Color.FromArgb(20, 94, 190), 8F,
        Color.FromArgb(220, 55, 45), 2F);
}

// DXF와 Tab_Edit에서 추가하는 LAS·DEM 문서가 같은 점/선 편집 명령을 사용하도록 공통 기능을 정의합니다.
internal interface IPointLineEditableDocument
{
    void SetPointLineEditMode(DxfEditMode mode, DxfEditStyle style);
    void UpdatePointLineEditStyle(DxfEditStyle style);
    bool UndoPointLineEdit();
    bool RedoPointLineEdit();
    CadDrawingFile CreateCadDrawing();
    void SetCadPointAddedCallback(Action<DxfEditPoint>? pointAdded);
}

public partial class Docment_Dxf : IPointLineEditableDocument
{
    // 탐색기에서 같은 DXF를 중복으로 열지 않도록 원본 파일 경로를 추가로 보관합니다.
    private string? documentPath;

    // 원본 menuOpen_Click에는 영향을 주지 않고 탐색기로 연 문서의 전체 경로만 저장합니다.
    internal void SetDocumentPath(string path)
    {
        documentPath = path;
    }

    // 탐색기에서 이미 열린 DXF 문서를 찾을 때 저장해 둔 전체 경로를 반환합니다.
    internal string? GetDocumentPath()
    {
        return documentPath;
    }

    // 기존 생성자가 만든 DrawingPanel을 찾아 별도 편집 기능과 연결하기 위해 추가했습니다.
    private DxfCanvas? EditingPanel => drawingPanels.FirstOrDefault();

    // 편집 탭에서 선택한 점/선 입력 모드와 표시 스타일을 기존 DrawingPanel에 전달합니다.
    internal void SetEditMode(DxfEditMode mode, DxfEditStyle style)
    {
        EditingPanel?.SetEditMode(mode, style);
    }

    // 설정 팝업에서 바꾼 색상과 크기를 기존 도면 위의 편집 형상에 즉시 반영합니다.
    internal void UpdateEditStyle(DxfEditStyle style)
    {
        EditingPanel?.UpdateEditStyle(style);
    }

    // .cad에서 불러온 기존 점 목록을 DXF 자체 편집 레이어에 복원해 원본 도면 위에 표시합니다.
    internal void LoadCadWorkspacePoints(IReadOnlyList<DxfEditPoint> points, DxfEditStyle style)
    {
        EditingPanel?.LoadCadWorkspacePoints(points, style);
    }

    // 리본 버튼이나 Ctrl+Z가 요청한 마지막 점/선 작업의 실행 취소 결과를 반환합니다.
    internal bool UndoEdit()
    {
        return EditingPanel?.UndoEdit() == true;
    }

    // 리본 버튼이나 Ctrl+Y가 요청한 점/선 작업의 다시 입력 결과를 반환합니다.
    internal bool RedoEdit()
    {
        return EditingPanel?.RedoEdit() == true;
    }

    // 현재 DXF 문서에서 사용된 내부 레이어 목록을 레이어 팝업에 제공합니다.
    internal IReadOnlyList<string> GetLayerNames()
    {
        return EditingPanel?.GetLayerNames() ?? Array.Empty<string>();
    }

    // 레이어 팝업이 현재 레이어의 표시 여부를 조회할 때 사용합니다.
    internal bool IsLayerVisible(string layerName)
    {
        return EditingPanel?.IsLayerVisible(layerName) ?? false;
    }

    // 레이어 팝업의 체크 상태 변경을 실제 도면 패널에 전달합니다.
    internal void SetLayerVisible(string layerName, bool isVisible)
    {
        foreach (DxfCanvas panel in drawingPanels) panel.SetLayerVisible(layerName, isVisible);
    }

    // 선택 화면에서 레이어별 현재 표시 색상을 조회합니다.
    internal Color GetLayerColor(string layerName)
    {
        return EditingPanel?.GetLayerColor(layerName) ?? Color.Black;
    }

    // 선택 화면에서 지정한 색상을 해당 레이어의 모든 도형에 적용합니다.
    internal void SetLayerColor(string layerName, Color color)
    {
        foreach (DxfCanvas panel in drawingPanels) panel.SetLayerColor(layerName, color);
    }

    // 선택 버튼이 현재 DXF 도면에서 객체 선택 모드를 켜거나 끌 때 사용합니다.
    internal void SetSelectionMode(bool isEnabled, Action<DxfSelectionInfo?>? selectionChanged)
    {
        EditingPanel?.SetSelectionMode(isEnabled, selectionChanged);
    }

    // 공통 편집 명령을 기존 DXF 편집 모드 함수에 연결하기 위해 추가했습니다.
    void IPointLineEditableDocument.SetPointLineEditMode(DxfEditMode mode, DxfEditStyle style) => SetEditMode(mode, style);

    // 공통 스타일 명령을 기존 DXF 스타일 변경 함수에 연결하기 위해 추가했습니다.
    void IPointLineEditableDocument.UpdatePointLineEditStyle(DxfEditStyle style) => UpdateEditStyle(style);

    // 공통 실행 취소 명령을 기존 DXF 실행 취소 함수에 연결하기 위해 추가했습니다.
    bool IPointLineEditableDocument.UndoPointLineEdit() => UndoEdit();

    // 공통 다시 입력 명령을 기존 DXF 다시 입력 함수에 연결하기 위해 추가했습니다.
    bool IPointLineEditableDocument.RedoPointLineEdit() => RedoEdit();

    // 현재 DXF 문서에 추가한 점·선과 원본 경로를 .cad 저장 구조로 변환합니다.
    CadDrawingFile IPointLineEditableDocument.CreateCadDrawing()
    {
        return EditingPanel?.CreateCadDrawing(documentPath)
            ?? CadDrawingFactory.Create(Array.Empty<DxfEditPoint>(), DxfEditStyle.Default, documentPath);
    }

    // 문서에서 입력한 점을 폼 전체의 공용 CAD 작업 모델에도 전달하도록 콜백을 연결합니다.
    void IPointLineEditableDocument.SetCadPointAddedCallback(Action<DxfEditPoint>? pointAdded)
    {
        EditingPanel?.SetCadPointAddedCallback(pointAdded);
    }

}

public partial class DxfCanvas
{
    // DXF 내부 레이어별 화면 표시 여부입니다.
    private readonly Dictionary<string, bool> layerVisibility = new(StringComparer.OrdinalIgnoreCase);

    // 레이어별 화면 표시 색상입니다. 지정하지 않은 레이어는 검정색으로 그립니다.
    private readonly Dictionary<string, Color> layerColors = new(StringComparer.OrdinalIgnoreCase);

    // 도면을 그릴 때마다 레이어 테이블을 다시 순회하지 않도록 초기화 여부를 보관합니다.
    private bool areLayerSettingsInitialized;

    // 현재 선택되어 강조 표시할 원본 DXF 객체입니다.
    private DxfEntity? selectedEntity;

    // 선택 결과를 Form1의 오른쪽 속성 패널로 전달합니다.
    private Action<DxfSelectionInfo?>? selectionChanged;

    // DXF 엔티티에 레이어명이 비어 있는 경우에도 일관되게 기본 레이어로 관리합니다.
    private static string NormalizeLayerName(string? layerName) =>
        string.IsNullOrWhiteSpace(layerName) ? "0" : layerName;

    // 불러온 DXF에서 실제로 사용된 레이어 목록을 만들고, 새 레이어는 기본적으로 표시합니다.
    private void InitializeLayerSettings()
    {
        if (areLayerSettingsInitialized) return;

        // DXF의 TABLES/LAYER에 저장된 원본 레이어 색상과 켜짐 상태를 먼저 읽습니다.
        foreach (DxfLayer layer in dxf.Layers)
        {
            string layerName = NormalizeLayerName(layer.Name);
            if (!layerVisibility.ContainsKey(layerName))
            {
                layerVisibility.Add(layerName, layer.IsLayerOn && !layer.Color.IsTurnedOff);
            }

            if (!layerColors.ContainsKey(layerName))
            {
                layerColors.Add(layerName, ToDrawingColor(layer.Color));
            }
        }

        // 레이어 테이블에 없는 이름으로 참조된 엔티티는 안전하게 검정색·표시 상태로 처리합니다.
        foreach (string layerName in dxf.Entities
            .Select(entity => NormalizeLayerName(entity.Layer))
            .Distinct(StringComparer.OrdinalIgnoreCase))
        {
            if (!layerVisibility.ContainsKey(layerName))
            {
                layerVisibility.Add(layerName, true);
            }

            if (!layerColors.ContainsKey(layerName))
            {
                layerColors.Add(layerName, Color.Black);
            }
        }

        areLayerSettingsInitialized = true;
    }

    // DXF의 AutoCAD Color Index(ACI)를 WinForms Color로 변환합니다.
    private static Color ToDrawingColor(DxfColor dxfColor)
    {
        if (dxfColor.IsByLayer || dxfColor.IsByBlock || dxfColor.IsByEntity)
        {
            return Color.Black;
        }

        return dxfColor.Index switch
        {
            1 => Color.Red,
            2 => Color.Yellow,
            3 => Color.Lime,
            4 => Color.Cyan,
            5 => Color.Blue,
            6 => Color.Magenta,
            7 => Color.Black,
            8 => Color.FromArgb(128, 128, 128),
            9 => Color.FromArgb(192, 192, 192),
            _ => GetExtendedAciColor(dxfColor.Index)
        };
    }

    // 기본 ACI 1~9 이외의 색상은 ACI 색상환 순서에 맞춰 안정적인 표시 색으로 변환합니다.
    private static Color GetExtendedAciColor(byte index)
    {
        if (index == 0) return Color.Black;

        int normalized = Math.Clamp(index, (byte)10, (byte)249) - 10;
        double hue = (normalized / 10 % 24) * 15.0;
        double saturation = normalized % 10 < 5 ? 0.55 : 0.85;
        double brightness = 0.35 + (normalized % 5) * 0.14;
        return ColorFromHsv(hue, saturation, brightness);
    }

    // HSV 값을 WinForms RGB Color로 변환합니다.
    private static Color ColorFromHsv(double hue, double saturation, double brightness)
    {
        double chroma = brightness * saturation;
        double x = chroma * (1 - Math.Abs((hue / 60 % 2) - 1));
        double match = brightness - chroma;
        (double red, double green, double blue) components = hue switch
        {
            < 60 => (chroma, x, 0),
            < 120 => (x, chroma, 0),
            < 180 => (0, chroma, x),
            < 240 => (0, x, chroma),
            < 300 => (x, 0, chroma),
            _ => (chroma, 0, x)
        };

        return Color.FromArgb(
            (int)Math.Round((components.red + match) * 255),
            (int)Math.Round((components.green + match) * 255),
            (int)Math.Round((components.blue + match) * 255));
    }

    // 레이어 버튼이 표시할 DXF 내부 레이어명을 반환합니다.
    internal IReadOnlyList<string> GetLayerNames()
    {
        InitializeLayerSettings();
        return layerVisibility.Keys.OrderBy(name => name, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    // 지정한 레이어가 화면에 표시되어야 하는지 반환합니다.
    internal bool IsLayerVisible(string? layerName)
    {
        InitializeLayerSettings();
        return layerVisibility.TryGetValue(NormalizeLayerName(layerName), out bool isVisible) && isVisible;
    }

    // 레이어 창의 체크 상태를 저장하고 도면을 즉시 다시 그립니다.
    internal void SetLayerVisible(string layerName, bool isVisible)
    {
        InitializeLayerSettings();
        layerVisibility[NormalizeLayerName(layerName)] = isVisible;
        Invalidate();
    }

    // 해당 레이어의 현재 화면 표시 색상을 반환합니다.
    internal Color GetLayerColor(string layerName)
    {
        InitializeLayerSettings();
        return layerColors.TryGetValue(NormalizeLayerName(layerName), out Color color) ? color : Color.Black;
    }

    // 해당 레이어의 화면 표시 색상을 저장하고 도면을 다시 그립니다.
    internal void SetLayerColor(string layerName, Color color)
    {
        InitializeLayerSettings();
        layerColors[NormalizeLayerName(layerName)] = color;
        Invalidate();
    }

    // 원본 DrawingPanel에 현재 점/선 입력 상태를 추가합니다.
    private DxfEditMode editMode;

    // 원본 DXF 선과 구분하여 그릴 편집 형상의 표시 스타일을 추가합니다.
    private DxfEditStyle editStyle = DxfEditStyle.Default;

    // 사용자가 DXF 위에 추가한 점을 원본 좌표로 보관합니다.
    private readonly List<DxfEditPoint> addedPoints = new();

    // 연속 클릭으로 생성한 연결선을 원본 좌표로 보관합니다.
    private readonly List<DxfEditLine> addedLines = new();

    // 다음 클릭점과 연결할 직전 점을 기억합니다.
    private DxfEditPoint? previousPoint;

    // Ctrl+Z로 되돌릴 점/선 추가 작업을 최근 순서대로 보관합니다.
    private readonly Stack<DxfEditAction> undoActions = new();

    // Ctrl+Y로 다시 적용할 취소 작업을 최근 순서대로 보관합니다.
    private readonly Stack<DxfEditAction> redoActions = new();

    // 문서에서 추가한 점을 보이지 않는 공용 .cad 작업 모델에 전달하는 함수입니다.
    private Action<DxfEditPoint>? cadPointAdded;

    // 원본 OnMouseUp에서 화면 이동과 편집 모드를 구분할 수 있도록 현재 상태를 제공합니다.
    private bool IsEditingPointLine => editMode == DxfEditMode.AddPointLine;

    // 선택 버튼의 켜짐 상태에 따라 클릭을 객체 선택으로 처리합니다.
    private bool IsSelectingEntity => editMode == DxfEditMode.Select;

    // Form1의 공용 CAD 작업 모델에 새 점을 전달할 콜백을 등록하거나 해제합니다.
    internal void SetCadPointAddedCallback(Action<DxfEditPoint>? pointAdded)
    {
        cadPointAdded = pointAdded;
    }

    // 선택 모드를 바꾸고 이전 선택은 초기화합니다.
    internal void SetSelectionMode(bool isEnabled, Action<DxfSelectionInfo?>? changed)
    {
        editMode = isEnabled ? DxfEditMode.Select : DxfEditMode.None;
        selectionChanged = changed;
        selectedEntity = null;
        Cursor = isEnabled ? Cursors.Hand : Cursors.Default;
        if (!isEnabled)
        {
            selectionChanged?.Invoke(null);
        }
        Focus();
        Invalidate();
    }


    // 편집 버튼의 토글 상태에 맞춰 입력 모드, 스타일과 마우스 커서를 변경합니다.
    internal void SetEditMode(DxfEditMode mode, DxfEditStyle style)
    {
        editMode = mode;
        editStyle = style;
        previousPoint = null;
        Cursor = mode == DxfEditMode.None ? Cursors.Default : Cursors.Cross;
        Focus();
        Invalidate();
    }

    // 선택 모드에서 클릭한 위치와 가장 가까운 표시 가능 객체를 찾아 선택합니다.
    private bool TrySelectDxfEntity(Point screenPoint)
    {
        if (!IsSelectingEntity) return false;

        DxfEditPoint clickPoint = ToEditingDxfPoint(screenPoint);
        double tolerance = Math.Max(2.0, 7.0 / Math.Max(scale, 0.0001));
        DxfEntity? closestEntity = null;
        double closestDistance = double.MaxValue;

        foreach (DxfEntity entity in dxf.Entities)
        {
            if (!IsLayerVisible(entity.Layer)) continue;

            double distance = GetEntityDistance(entity, clickPoint);
            if (distance <= tolerance && distance < closestDistance)
            {
                closestEntity = entity;
                closestDistance = distance;
            }
        }

        selectedEntity = closestEntity;
        selectionChanged?.Invoke(CreateSelectionInfo(closestEntity));
        Invalidate();
        return true;
    }

    // LINE·LWPOLYLINE·POLYLINE에 대해 클릭점과 선분 사이의 최단거리를 계산합니다.
    private static double GetEntityDistance(DxfEntity entity, DxfEditPoint point)
    {
        return entity switch
        {
            DxfLine line => DistanceToSegment(point, line.P1.X, line.P1.Y, line.P2.X, line.P2.Y),
            DxfLwPolyline polyline => DistanceToPolyline(point, polyline.Vertices.Select(vertex => new DxfEditPoint(vertex.X, vertex.Y))),
            DxfPolyline polyline => DistanceToPolyline(point, polyline.Vertices.Select(vertex => new DxfEditPoint(vertex.Location.X, vertex.Location.Y))),
            _ => double.MaxValue
        };
    }

    // 여러 꼭짓점으로 구성된 폴리선의 모든 구간 중 가장 가까운 거리를 반환합니다.
    private static double DistanceToPolyline(DxfEditPoint point, IEnumerable<DxfEditPoint> vertices)
    {
        DxfEditPoint? previous = null;
        double closestDistance = double.MaxValue;
        foreach (DxfEditPoint current in vertices)
        {
            if (previous is DxfEditPoint start)
            {
                closestDistance = Math.Min(closestDistance, DistanceToSegment(point, start.X, start.Y, current.X, current.Y));
            }
            previous = current;
        }
        return closestDistance;
    }

    // 점에서 하나의 선분까지의 거리를 계산합니다.
    private static double DistanceToSegment(DxfEditPoint point, double x1, double y1, double x2, double y2)
    {
        double dx = x2 - x1;
        double dy = y2 - y1;
        if (dx == 0 && dy == 0) return Math.Sqrt(Math.Pow(point.X - x1, 2) + Math.Pow(point.Y - y1, 2));

        double ratio = ((point.X - x1) * dx + (point.Y - y1) * dy) / (dx * dx + dy * dy);
        ratio = Math.Clamp(ratio, 0, 1);
        double distanceX = point.X - (x1 + ratio * dx);
        double distanceY = point.Y - (y1 + ratio * dy);
        return Math.Sqrt(distanceX * distanceX + distanceY * distanceY);
    }

    // 선택한 객체를 속성 패널에 표시하기 쉬운 값으로 변환합니다.
    private static DxfSelectionInfo? CreateSelectionInfo(DxfEntity? entity)
    {
        if (entity is null) return null;
        string layerName = NormalizeLayerName(entity.Layer);
        return entity switch
        {
            DxfLine line => new DxfSelectionInfo("LINE", layerName, $"({line.P1.X:N2}, {line.P1.Y:N2}) → ({line.P2.X:N2}, {line.P2.Y:N2})"),
            DxfLwPolyline polyline => new DxfSelectionInfo("LWPOLYLINE", layerName, $"Vertices: {polyline.Vertices.Count}"),
            DxfPolyline polyline => new DxfSelectionInfo("POLYLINE", layerName, $"Vertices: {polyline.Vertices.Count}"),
            _ => null
        };
    }

    // 선택 객체를 기본 도면 색상과 구분되는 파란색으로 덧그립니다.
    private void DrawSelectedEntity(Graphics graphics)
    {
        if (selectedEntity is null) return;

        using var selectionPen = new Pen(Color.FromArgb(20, 105, 190), 3F);
        switch (selectedEntity)
        {
            case DxfLine line:
                graphics.DrawLine(selectionPen, ToScreenPoint(line.P1.X, line.P1.Y, scale, offsetX, offsetY), ToScreenPoint(line.P2.X, line.P2.Y, scale, offsetX, offsetY));
                break;
            case DxfLwPolyline polyline:
                DrawSelectedPolyline(graphics, selectionPen, polyline.Vertices.Select(vertex => new DxfEditPoint(vertex.X, vertex.Y)));
                break;
            case DxfPolyline polyline:
                DrawSelectedPolyline(graphics, selectionPen, polyline.Vertices.Select(vertex => new DxfEditPoint(vertex.Location.X, vertex.Location.Y)));
                break;
        }
    }

    // 선택된 폴리선의 각 구간을 강조 표시합니다.
    private void DrawSelectedPolyline(Graphics graphics, Pen pen, IEnumerable<DxfEditPoint> vertices)
    {
        DxfEditPoint? previous = null;
        foreach (DxfEditPoint current in vertices)
        {
            if (previous is DxfEditPoint start)
            {
                graphics.DrawLine(pen, ToScreenPoint(start.X, start.Y, scale, offsetX, offsetY), ToScreenPoint(current.X, current.Y, scale, offsetX, offsetY));
            }
            previous = current;
        }
    }

    // 변경된 점과 선의 색상·크기를 저장하고 화면을 다시 그립니다.
    internal void UpdateEditStyle(DxfEditStyle style)
    {
        editStyle = style;
        Invalidate();
    }

    // .cad 점 순서를 DXF 좌표 그대로 복원하고 연속된 점 사이의 편집 선분을 다시 구성합니다.
    internal void LoadCadWorkspacePoints(IReadOnlyList<DxfEditPoint> points, DxfEditStyle style)
    {
        addedPoints.Clear();
        addedLines.Clear();
        undoActions.Clear();
        redoActions.Clear();
        editStyle = style;

        DxfEditPoint? previous = null;
        foreach (DxfEditPoint point in points)
        {
            addedPoints.Add(point);
            if (previous is DxfEditPoint start)
                addedLines.Add(new DxfEditLine(start, point));
            previous = point;
        }

        previousPoint = previous;
        Invalidate();
    }

    // WinForms 화면 클릭 위치를 기존 확대 배율과 오프셋을 사용해 DXF 좌표로 되돌립니다.
    private DxfEditPoint ToEditingDxfPoint(Point screenPoint)
    {
        double x = (screenPoint.X - offsetX) / scale + minX;
        double y = (ClientSize.Height - screenPoint.Y - offsetY) / scale + minY;
        return new DxfEditPoint(x, y);
    }

    // 편집 모드일 때 클릭 위치에 점을 추가하고 직전 점이 있으면 선으로 연결합니다.
    private bool TryAddEditingPoint(Point screenPoint)
    {
        if (!IsEditingPointLine) return false;

        DxfEditPoint point = ToEditingDxfPoint(screenPoint);
        DxfEditPoint? pointBeforeClick = previousPoint;
        DxfEditLine? addedLine = null;

        addedPoints.Add(point);
        if (previousPoint is DxfEditPoint start)
        {
            addedLine = new DxfEditLine(start, point);
            addedLines.Add(addedLine.Value);
        }

        previousPoint = point;
        cadPointAdded?.Invoke(point);
        undoActions.Push(new DxfEditAction(point, addedLine, pointBeforeClick));
        redoActions.Clear();
        Invalidate();
        return true;
    }

    // 마지막 클릭으로 생성된 점과 연결선을 함께 제거하고 redo 기록으로 이동합니다.
    internal bool UndoEdit()
    {
        if (undoActions.Count == 0) return false;

        DxfEditAction action = undoActions.Pop();
        if (addedPoints.Count > 0) addedPoints.RemoveAt(addedPoints.Count - 1);
        if (action.Line is not null && addedLines.Count > 0) addedLines.RemoveAt(addedLines.Count - 1);

        previousPoint = action.PreviousPoint;
        redoActions.Push(action);
        Invalidate();
        return true;
    }

    // 마지막으로 취소한 점과 연결선을 원래 좌표에 복원하고 undo 기록으로 되돌립니다.
    internal bool RedoEdit()
    {
        if (redoActions.Count == 0) return false;

        DxfEditAction action = redoActions.Pop();
        addedPoints.Add(action.Point);
        if (action.Line is DxfEditLine line) addedLines.Add(line);

        previousPoint = action.Point;
        undoActions.Push(action);
        Invalidate();
        return true;
    }

    // 원본 DXF 렌더링이 끝난 뒤 설정한 색상과 크기로 추가 점·선을 덧그립니다.
    private void DrawEditingOverlay(Graphics graphics)
    {
        using var pointBrush = new SolidBrush(editStyle.PointColor);
        using var linePen = new Pen(editStyle.LineColor, editStyle.LineWidth);

        foreach (DxfEditLine line in addedLines)
        {
            PointF start = ToScreenPoint(line.Start.X, line.Start.Y, scale, offsetX, offsetY);
            PointF end = ToScreenPoint(line.End.X, line.End.Y, scale, offsetX, offsetY);
            graphics.DrawLine(linePen, start, end);
        }

        foreach (DxfEditPoint point in addedPoints)
        {
            PointF screenPoint = ToScreenPoint(point.X, point.Y, scale, offsetX, offsetY);
            DrawEditingPoint(graphics, pointBrush, screenPoint, editStyle.PointSize);
        }
    }

    // 확대 배율과 관계없이 설정한 화면 크기로 원형 점을 표시합니다.
    private static void DrawEditingPoint(Graphics graphics, Brush brush, PointF point, float size)
    {
        float radius = Math.Max(1F, size / 2F);
        graphics.FillEllipse(brush, point.X - radius, point.Y - radius, radius * 2, radius * 2);
    }

    // 현재 DXF 원본 좌표 점 목록과 표시 스타일을 .cad 파일용 데이터로 복사합니다.
    internal CadDrawingFile CreateCadDrawing(string? sourceFile)
    {
        return CadDrawingFactory.Create(addedPoints, editStyle, sourceFile);
    }

}
