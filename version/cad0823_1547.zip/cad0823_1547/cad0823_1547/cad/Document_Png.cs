using WeifenLuo.WinFormsUI.Docking;

namespace cad;

// TreeView에서 선택한 PNG 파일을 중앙 도킹 탭에 표시합니다.
internal sealed class Document_Png : DockContent
{
    private readonly PictureBox pictureBox;

    internal string DocumentPath { get; }

    internal Document_Png(string path)
    {
        if (!Path.GetExtension(path).Equals(".png", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("PNG 파일만 열 수 있습니다.", nameof(path));

        if (!File.Exists(path))
            throw new FileNotFoundException("이미지 파일을 찾을 수 없습니다.", path);

        DocumentPath = Path.GetFullPath(path);
        Text = Path.GetFileName(path);
        TabText = Path.GetFileName(path);
        ToolTipText = DocumentPath;
        DockAreas = DockAreas.Document | DockAreas.Float;

        var viewport = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            BackColor = Color.FromArgb(45, 45, 48)
        };

        pictureBox = new PictureBox
        {
            SizeMode = PictureBoxSizeMode.AutoSize,
            Location = Point.Empty,
            Image = LoadImageWithoutLock(DocumentPath)
        };

        viewport.Controls.Add(pictureBox);
        Controls.Add(viewport);
    }

    // 원본 파일 스트림을 즉시 닫아 이미지가 열린 동안에도 이동·삭제할 수 있게 합니다.
    private static Image LoadImageWithoutLock(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using var source = Image.FromStream(stream);
        return new Bitmap(source);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            pictureBox.Image?.Dispose();
            pictureBox.Dispose();
        }

        base.Dispose(disposing);
    }
}
