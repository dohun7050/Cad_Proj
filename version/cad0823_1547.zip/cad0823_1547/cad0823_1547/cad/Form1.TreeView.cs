﻿using System.Diagnostics;
using System.Runtime.InteropServices;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

public partial class Form1
{
    // 프로젝트 탐색기가 표시하고 수정할 유일한 ProjectFiles 폴더 경로입니다.
    private readonly string projectRoot = ResolveProjectRoot();

    // 복사 또는 잘라내기 대상으로 기억한 실제 파일·폴더 경로입니다.
    private string? clipboardPath;

    // 현재 기억한 경로가 잘라내기 작업인지 복사 작업인지 구분합니다.
    private bool clipboardCut;

    // 선택 노드의 실제 경로를 반환하며 선택이 없으면 프로젝트 루트를 반환합니다.
    private string SelectedPath => treeView1.SelectedNode?.Tag as string ?? projectRoot;

    // 실행 위치에서 상위 폴더를 탐색하여 솔루션 파일 옆의 ProjectFiles 하나만 사용합니다.
    private static string ResolveProjectRoot()
    {
        DirectoryInfo? directory = new DirectoryInfo(AppContext.BaseDirectory);

        while (directory is not null)
        {
            string solutionPath = Path.Combine(directory.FullName, "cad.slnx");
            string projectFilesPath = Path.Combine(directory.FullName, "ProjectFiles");

            if (File.Exists(solutionPath))
                return projectFilesPath;

            directory = directory.Parent;
        }

        throw new DirectoryNotFoundException(
            "cad.slnx 옆의 ProjectFiles 폴더 위치를 찾을 수 없습니다.");
    }

    // 실제 ProjectFiles의 폴더와 파일을 다시 읽어 왼쪽 TreeView를 새로 구성합니다.
    private void LoadFileTree()
    {
        treeView1.BeginUpdate();
        treeView1.Nodes.Clear();
        if (!Directory.Exists(projectRoot))
        {
            treeView1.Nodes.Add(new TreeNode("ProjectFiles 폴더가 없습니다."));
            treeView1.EndUpdate();
            return;
        }
        var root = CreateNode(new DirectoryInfo(projectRoot));
        treeView1.Nodes.Add(root);
        treeView1.EndUpdate();
    }

    // 전달받은 파일 시스템 항목과 하위 항목을 재귀적으로 TreeNode로 변환합니다.
    private TreeNode CreateNode(FileSystemInfo info)
    {
        bool isDirectory = info is DirectoryInfo; // DirectoryInfo인지 FileInfo인지 구분
        var node = new TreeNode(info.Name) { Tag = info.FullName, ImageKey = isDirectory ? "folder" : "file", SelectedImageKey = isDirectory ? "folder" : "file" };
        if (info is DirectoryInfo directory)
        {
            try
            {
                foreach (DirectoryInfo child in directory.GetDirectories().OrderBy(x => x.Name)) node.Nodes.Add(CreateNode(child));
                foreach (FileInfo child in directory.GetFiles().OrderBy(x => x.Name)) node.Nodes.Add(CreateNode(child));
            }
            catch (UnauthorizedAccessException) { }
        }
        return node;
    }

    // 지정한 실제 경로에 대응하는 TreeNode를 찾아 선택 상태로 표시합니다.
    private void SelectTreeNode(string fullPath)
    {
        TreeNode? FindNode(TreeNodeCollection nodes)
        {
            foreach (TreeNode node in nodes)
            {
                if (node.Tag is string path && string.Equals(path, fullPath, StringComparison.OrdinalIgnoreCase))
                    return node;

                TreeNode? child = FindNode(node.Nodes);
                if (child is not null) return child;
            }
            return null;
        }

        TreeNode? selected = FindNode(treeView1.Nodes);
        if (selected is null) return;

        treeView1.SelectedNode = selected;
    }

    // 현재 선택 항목이 폴더면 그 폴더를, 파일이면 파일이 들어 있는 부모 폴더를 반환합니다.
    private string SelectedDirectory()
    {
        string path = SelectedPath;
        return Directory.Exists(path) ? path : Path.GetDirectoryName(path) ?? projectRoot;
    }

    // 우클릭 메뉴의 폴더 추가를 누르면 선택 위치에 새 폴더를 생성합니다.
    private void AddFolder_Click(object? sender, EventArgs e)
    {
        string name = Prompt("새 폴더 이름", "폴더 추가");
        if (string.IsNullOrWhiteSpace(name)) return;
        Directory.CreateDirectory(Path.Combine(SelectedDirectory(), SafeName(name)));
        LoadFileTree();
    }

    // 우클릭 메뉴의 파일 추가를 누르면 선택 위치에 이름을 지정한 새 파일을 생성합니다.
    private void AddFile_Click(object? sender, EventArgs e)
    {
        string name = Prompt("새 파일 이름 (예: 노선.dxf)", "파일 추가");
        if (string.IsNullOrWhiteSpace(name)) return;
        string path = Path.Combine(SelectedDirectory(), SafeName(name));
        if (!File.Exists(path)) File.WriteAllText(path, "새 CAD 프로젝트 파일");
        LoadFileTree();
    }

    // 선택한 파일 또는 폴더를 확인 대화상자 후 실제 디스크에서 삭제합니다.
    private void Delete_Click(object? sender, EventArgs e)
    {
        string path = SelectedPath;
        if (path == projectRoot || (!File.Exists(path) && !Directory.Exists(path))) return;
        if (MessageBox.Show($"'{Path.GetFileName(path)}'을(를) 삭제할까요?", "삭제 확인", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        if (File.Exists(path)) File.Delete(path); else Directory.Delete(path, true);
        LoadFileTree();
    }

    // 폴더 선택 대화상자로 이동 위치를 받아 선택 항목을 옮깁니다.
    private void Move_Click(object? sender, EventArgs e)
    {
        string source = SelectedPath;
        if (source == projectRoot) return;
        using var dialog = new FolderBrowserDialog { Description = "이동할 대상 폴더 선택", InitialDirectory = projectRoot };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        MovePath(source, dialog.SelectedPath);
    }

    // 원본 항목을 ProjectFiles 내부의 대상 폴더로 이동하고 탐색기를 갱신합니다.
    private void MovePath(string source, string targetDirectory)
    {
        if (!targetDirectory.StartsWith(projectRoot, StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("ProjectFiles 폴더 내부로만 이동할 수 있습니다.");
            return;
        }
        string destination = Path.Combine(targetDirectory, Path.GetFileName(source));
        if (File.Exists(destination) || Directory.Exists(destination)) { MessageBox.Show("대상 폴더에 같은 이름이 있습니다."); return; }
        if (File.Exists(source)) File.Move(source, destination); else if (Directory.Exists(source)) Directory.Move(source, destination);
        LoadFileTree();
    }

    // TreeView 항목을 끌기 시작하면 이동 또는 문서 열기용 드래그 작업을 시작합니다.
    private void Tree_ItemDrag(object? sender, ItemDragEventArgs e) => DoDragDrop(e.Item!, DragDropEffects.Move | DragDropEffects.Copy);

    // TreeView 안으로 드래그한 데이터가 노드일 때만 이동 표시를 허용합니다.
    private void Tree_DragEnter(object? sender, DragEventArgs e) => e.Effect = e.Data?.GetDataPresent(typeof(TreeNode)) == true ? DragDropEffects.Move : DragDropEffects.None;

    // TreeView에서 끌어온 항목을 놓은 대상 폴더로 실제 이동합니다.
    private void Tree_DragDrop(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(TreeNode)) is not TreeNode sourceNode) return;
        TreeNode? targetNode = treeView1.GetNodeAt(treeView1.PointToClient(new Point(e.X, e.Y)));
        string? source = sourceNode.Tag as string;
        string? target = targetNode?.Tag as string;
        if (source is null || target is null || !Directory.Exists(target) || source == projectRoot) return;
        MovePath(source, target);
    }

    // 탐색기의 지원 파일을 더블클릭하면 공용 작업공간이나 중앙 문서로 엽니다.
    private void Tree_NodeMouseDoubleClick(object? sender, TreeNodeMouseClickEventArgs e)
    {
        TreeNode? node = e.Node;
        if (node?.Tag is not string path) return;

        if (IsCadDocument(path))
        {
            OpenCadWorkspace(path);
        }
        else if (IsTextDocument(path))
        {
            OpenTextDocument(path);
        }
        else if (IsDxfDocument(path))
        {
            try
            {
                OpenDxfDocument(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "DXF 열기 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        else if (IsPngDocument(path)) OpenPngDocumentSafely(path);
        else if (IsJpgDocument(path)) OpenJpgDocumentSafely(path);
    }

    // 중앙 DockPanel로 끌어온 노드가 지원되는 CAD·TXT 또는 DXF인지 검사합니다.
    private void DockPanel_DragEnter(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(TreeNode)) is TreeNode node
            && node.Tag is string path
            && (IsCadDocument(path) || IsTextDocument(path) || IsDxfDocument(path)
                || IsPngDocument(path) || IsJpgDocument(path)))
            e.Effect = DragDropEffects.Copy;
        else
            e.Effect = DragDropEffects.None;
    }

    // 중앙 DockPanel에 놓은 CAD·TXT 또는 DXF 파일을 공용 작업공간이나 문서 탭으로 엽니다.
    private void DockPanel_DragDrop(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(TreeNode)) is not TreeNode node || node.Tag is not string path) return;

        if (IsCadDocument(path)) OpenCadWorkspace(path);
        else if (IsTextDocument(path)) OpenTextDocument(path);
        else if (IsDxfDocument(path))
        {
            try
            {
                OpenDxfDocument(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "DXF 열기 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        else if (IsPngDocument(path)) OpenPngDocumentSafely(path);
        else if (IsJpgDocument(path)) OpenJpgDocumentSafely(path);
    }

    // 지정 경로가 실제로 존재하는 TXT 문서인지 확인합니다.
    private static bool IsTextDocument(string path) =>
        File.Exists(path) && Path.GetExtension(path).Equals(".txt", StringComparison.OrdinalIgnoreCase);

    // 프로젝트 탐색기와 파일 열기에서 사용할 수 있는 임도 CAD 작업 파일인지 확인합니다.
    private static bool IsCadDocument(string path) =>
        File.Exists(path) && Path.GetExtension(path).Equals(".cad", StringComparison.OrdinalIgnoreCase);

    // 프로젝트 탐색기에서 열 수 있는 DXF 파일인지 확장자와 실제 존재 여부를 확인합니다.
    private static bool IsDxfDocument(string path) =>
        File.Exists(path) && Path.GetExtension(path).Equals(".dxf", StringComparison.OrdinalIgnoreCase);

    private static bool IsPngDocument(string path) =>
        File.Exists(path) && Path.GetExtension(path).Equals(".png", StringComparison.OrdinalIgnoreCase);

    private static bool IsJpgDocument(string path)
    {
        if (!File.Exists(path)) return false;
        string extension = Path.GetExtension(path);
        return extension.Equals(".jpg", StringComparison.OrdinalIgnoreCase)
            || extension.Equals(".jpeg", StringComparison.OrdinalIgnoreCase);
    }

    // TXT 파일을 새 도킹 문서로 열거나 이미 열려 있으면 기존 문서를 활성화합니다.
    private void OpenTextDocument(string path)
    {
        Document_Txt? opened = dockPanel1.Documents
            .OfType<Document_Txt>()
            .FirstOrDefault(document => string.Equals(document.DocumentPath, path, StringComparison.OrdinalIgnoreCase));

        if (opened != null)
        {
            opened.Activate();
            return;
        }

        var document = new Document_Txt(path);
        document.Show(dockPanel1, DockState.Document);
        document.Activate();
    }

    private void OpenPngDocument(string path)
    {
        Document_Png? opened = dockPanel1.Documents
            .OfType<Document_Png>()
            .FirstOrDefault(document => string.Equals(document.DocumentPath, path, StringComparison.OrdinalIgnoreCase));

        if (opened != null)
        {
            opened.Activate();
            return;
        }

        var document = new Document_Png(path);
        document.Show(dockPanel1, DockState.Document);
        document.Activate();
    }

    private void OpenPngDocumentSafely(string path)
    {
        try
        {
            OpenPngDocument(path);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "이미지 열기 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void OpenJpgDocument(string path)
    {
        Document_Jpg? opened = dockPanel1.Documents
            .OfType<Document_Jpg>()
            .FirstOrDefault(document => string.Equals(document.DocumentPath, path, StringComparison.OrdinalIgnoreCase));

        if (opened != null)
        {
            opened.Activate();
            return;
        }

        var document = new Document_Jpg(path);
        document.Show(dockPanel1, DockState.Document);
        document.Activate();
    }

    private void OpenJpgDocumentSafely(string path)
    {
        try
        {
            OpenJpgDocument(path);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "JPG 이미지 열기 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    // Windows 파일 탐색기를 열고 현재 선택한 파일 또는 폴더 위치를 표시합니다.
    private void OpenFolder_Click(object? sender, EventArgs e) => Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{SelectedPath}\"") { UseShellExecute = true });

    // 실제 ProjectFiles 내용을 다시 읽어 프로젝트 탐색기를 새로 고칩니다.
    private void Refresh_Click(object? sender, EventArgs e) => LoadFileTree();

    // 노드를 마우스 오른쪽 버튼으로 누르면 해당 노드를 먼저 선택합니다.
    private void Tree_NodeMouseClick(object? sender, TreeNodeMouseClickEventArgs e)
    {
        if (e.Button == MouseButtons.Right) treeView1.SelectedNode = e.Node;
    }

    // Ctrl+C/X/V, Delete, F2 단축키를 탐색기의 복사·이동·삭제·이름 변경 기능에 연결합니다.
    private void Tree_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Control && e.KeyCode == Keys.C) { CopySelected(false); e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.X) { CopySelected(true); e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.V) { PasteSelected(); e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.Delete) { Delete_Click(sender, e); e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.F2) { RenameSelected(); e.SuppressKeyPress = true; }
    }

    // 우클릭 복사 메뉴를 선택하면 현재 항목을 복사 대상으로 기억합니다.
    private void CopyMenu_Click(object? sender, EventArgs e) => CopySelected(false);

    // 우클릭 잘라내기 메뉴를 선택하면 현재 항목을 이동 대상으로 기억합니다.
    private void CutMenu_Click(object? sender, EventArgs e) => CopySelected(true);

    // 우클릭 붙여넣기 메뉴를 선택하면 기억한 항목을 현재 폴더에 붙여넣습니다.
    private void PasteMenu_Click(object? sender, EventArgs e) => PasteSelected();

    // 우클릭 이름 바꾸기 메뉴를 선택하면 현재 항목의 이름을 변경합니다.
    private void RenameMenu_Click(object? sender, EventArgs e) => RenameSelected();

    // 선택 항목과 복사·잘라내기 상태를 내부 클립보드 필드에 저장합니다.
    private void CopySelected(bool cut)
    {
        string path = SelectedPath;
        if (path == projectRoot || (!File.Exists(path) && !Directory.Exists(path))) return;
        clipboardPath = path;
        clipboardCut = cut;
        statusLabel.Text = cut ? $"잘라내기: {Path.GetFileName(path)}" : $"복사: {Path.GetFileName(path)}";
    }

    // 기억한 파일 또는 폴더를 현재 위치에 복사하거나 이동합니다.
    private void PasteSelected()
    {
        if (string.IsNullOrWhiteSpace(clipboardPath) || (!File.Exists(clipboardPath) && !Directory.Exists(clipboardPath))) return;
        string targetDirectory = SelectedDirectory();
        if (Directory.Exists(clipboardPath) && targetDirectory.StartsWith(clipboardPath + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("폴더를 자기 하위 폴더에 붙여넣을 수 없습니다.");
            return;
        }
        string destination = UniqueDestination(targetDirectory, Path.GetFileName(clipboardPath));
        if (clipboardCut)
        {
            if (File.Exists(clipboardPath)) File.Move(clipboardPath, destination);
            else Directory.Move(clipboardPath, destination);
            clipboardPath = null;
            clipboardCut = false;
        }
        else if (File.Exists(clipboardPath))
        {
            File.Copy(clipboardPath, destination);
        }
        else
        {
            CopyDirectory(clipboardPath, destination);
        }
        LoadFileTree();
    }

    // 선택한 파일 또는 폴더를 사용자가 입력한 새 이름으로 변경합니다.
    private void RenameSelected()
    {
        string source = SelectedPath;
        if (source == projectRoot || (!File.Exists(source) && !Directory.Exists(source))) return;
        string name = Prompt("새 이름", "이름 바꾸기");
        if (string.IsNullOrWhiteSpace(name)) return;
        string destination = Path.Combine(Path.GetDirectoryName(source)!, SafeName(name));
        if (File.Exists(destination) || Directory.Exists(destination)) { MessageBox.Show("같은 이름이 이미 있습니다."); return; }
        if (File.Exists(source)) File.Move(source, destination); else Directory.Move(source, destination);
        LoadFileTree();
    }

    // 같은 이름이 이미 존재하면 복사본 번호를 붙여 충돌하지 않는 대상 경로를 만듭니다.
    private static string UniqueDestination(string directory, string name)
    {
        string destination = Path.Combine(directory, name);
        if (!File.Exists(destination) && !Directory.Exists(destination)) return destination;
        string extension = Path.GetExtension(name);
        string baseName = Path.GetFileNameWithoutExtension(name);
        int number = 2;
        do { destination = Path.Combine(directory, $"{baseName} - 복사본 {number}{extension}"); number++; }
        while (File.Exists(destination) || Directory.Exists(destination));
        return destination;
    }

    // 원본 폴더의 모든 파일과 하위 폴더를 대상 위치로 재귀 복사합니다.
    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (string file in Directory.GetFiles(source)) File.Copy(file, Path.Combine(destination, Path.GetFileName(file)));
        foreach (string directory in Directory.GetDirectories(source)) CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)));
    }
}
