using System.Buffers.Binary;
using cad.Models;

namespace cad.Importers;

internal sealed class ShpImporter : IFileImporter
{
    public bool CanImport(string filePath) => Path.GetExtension(filePath)
        .Equals(".shp", StringComparison.OrdinalIgnoreCase);

    public ImportResult Import(string filePath)
    {
        if (!CanImport(filePath)) return Failure("Shapefile이 아닙니다.");
        if (!File.Exists(filePath)) return Failure("SHP 파일을 찾을 수 없습니다.");

        string stem = Path.Combine(Path.GetDirectoryName(filePath)!, Path.GetFileNameWithoutExtension(filePath));
        var missing = new List<string>();
        if (!File.Exists(stem + ".shx")) missing.Add(".shx");
        if (!File.Exists(stem + ".dbf")) missing.Add(".dbf");
        if (missing.Count > 0)
            return Failure("같은 폴더에 같은 이름의 " + string.Join(", ", missing) + " 파일이 필요합니다.");

        try
        {
            IReadOnlyList<GeoFeature> features = ReadShapes(filePath);
            if (features.Count == 0)
                return Failure("SHP에서 표시 가능한 점·선·폴리곤을 찾지 못했습니다.");

            var data = new GeoLayerData
            {
                Features = features,
                DisplayColor = Color.FromArgb(42, 116, 181)
            };
            return new ImportResult
            {
                IsSuccess = true,
                Message = "Shapefile을 불러왔습니다.",
                Layer = new ProjectLayer
                {
                    Name = Path.GetFileName(filePath), FilePath = Path.GetFullPath(filePath),
                    FileType = "SHP", SourceData = data
                }
            };
        }
        catch (Exception exception)
        {
            return Failure("Shapefile을 읽지 못했습니다. " + exception.Message);
        }
    }

    private static IReadOnlyList<GeoFeature> ReadShapes(string path)
    {
        using FileStream stream = File.OpenRead(path);
        using var reader = new BinaryReader(stream);
        if (ReadBigEndianInt32(reader) != 9994)
            throw new InvalidDataException("올바른 Shapefile 헤더가 아닙니다.");

        stream.Position = 100;
        var features = new List<GeoFeature>();
        while (stream.Position + 8 <= stream.Length)
        {
            _ = ReadBigEndianInt32(reader);
            int contentWords = ReadBigEndianInt32(reader);
            long recordEnd = stream.Position + contentWords * 2L;
            if (contentWords < 2 || recordEnd > stream.Length) break;

            int shapeType = reader.ReadInt32();
            switch (shapeType)
            {
                case 0: break;
                case 1 or 11 or 21: features.Add(ReadPoint(reader)); break;
                case 3 or 13 or 23: features.Add(ReadParts(reader, GeoGeometryKind.Polyline)); break;
                case 5 or 15 or 25: features.Add(ReadParts(reader, GeoGeometryKind.Polygon)); break;
                case 8 or 18 or 28: features.Add(ReadMultiPoint(reader)); break;
            }
            stream.Position = recordEnd;
        }
        return features;
    }

    private static GeoFeature ReadPoint(BinaryReader reader)
    {
        var point = new GeoPoint(reader.ReadDouble(), reader.ReadDouble());
        return new GeoFeature(GeoGeometryKind.Point, new[] { new[] { point } });
    }

    private static GeoFeature ReadMultiPoint(BinaryReader reader)
    {
        reader.BaseStream.Position += 32;
        int count = reader.ReadInt32();
        var parts = new List<IReadOnlyList<GeoPoint>>(count);
        for (int index = 0; index < count; index++)
            parts.Add(new[] { new GeoPoint(reader.ReadDouble(), reader.ReadDouble()) });
        return new GeoFeature(GeoGeometryKind.Point, parts);
    }

    private static GeoFeature ReadParts(BinaryReader reader, GeoGeometryKind kind)
    {
        reader.BaseStream.Position += 32;
        int partCount = reader.ReadInt32();
        int pointCount = reader.ReadInt32();
        var starts = new int[partCount + 1];
        for (int index = 0; index < partCount; index++) starts[index] = reader.ReadInt32();
        starts[partCount] = pointCount;

        var points = new GeoPoint[pointCount];
        for (int index = 0; index < pointCount; index++)
            points[index] = new GeoPoint(reader.ReadDouble(), reader.ReadDouble());

        var parts = new List<IReadOnlyList<GeoPoint>>(partCount);
        for (int index = 0; index < partCount; index++)
            parts.Add(points[starts[index]..starts[index + 1]]);
        return new GeoFeature(kind, parts);
    }

    private static int ReadBigEndianInt32(BinaryReader reader)
    {
        Span<byte> bytes = stackalloc byte[4];
        if (reader.Read(bytes) != 4) throw new EndOfStreamException();
        return BinaryPrimitives.ReadInt32BigEndian(bytes);
    }

    private static ImportResult Failure(string message) => new() { IsSuccess = false, Message = message };
}
