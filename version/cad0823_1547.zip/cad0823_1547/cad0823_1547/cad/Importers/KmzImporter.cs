using System.Globalization;
using System.IO.Compression;
using System.Xml.Linq;
using cad.Models;

namespace cad.Importers;

internal sealed class KmzImporter : IFileImporter
{
    public bool CanImport(string filePath) => Path.GetExtension(filePath)
        .Equals(".kmz", StringComparison.OrdinalIgnoreCase);

    public ImportResult Import(string filePath)
    {
        if (!CanImport(filePath)) return Failure("KMZ 파일이 아닙니다.");
        if (!File.Exists(filePath)) return Failure("KMZ 파일을 찾을 수 없습니다.");

        try
        {
            using ZipArchive archive = ZipFile.OpenRead(filePath);
            ZipArchiveEntry? entry = archive.Entries.FirstOrDefault(item =>
                item.FullName.EndsWith(".kml", StringComparison.OrdinalIgnoreCase));
            if (entry is null) return Failure("KMZ 내부에서 KML 문서를 찾지 못했습니다.");

            using Stream input = entry.Open();
            XDocument document = XDocument.Load(input);
            var features = new List<GeoFeature>();

            foreach (XElement element in document.Descendants())
            {
                switch (element.Name.LocalName)
                {
                    case "Point": AddPoint(element, features); break;
                    case "LineString": AddLine(element, features); break;
                    case "Polygon": AddPolygon(element, features); break;
                }
            }

            if (features.Count == 0)
                return Failure("KMZ에서 표시 가능한 점·선·폴리곤을 찾지 못했습니다.");

            return Success(filePath, new GeoLayerData
            {
                Features = features,
                DisplayColor = Color.FromArgb(220, 70, 55)
            });
        }
        catch (Exception exception)
        {
            return Failure("KMZ 파일을 읽지 못했습니다. " + exception.Message);
        }
    }

    private static void AddPoint(XElement element, ICollection<GeoFeature> output)
    {
        GeoPoint[] points = Coordinates(element).Take(1).ToArray();
        if (points.Length == 1) output.Add(new GeoFeature(GeoGeometryKind.Point, new[] { points }));
    }

    private static void AddLine(XElement element, ICollection<GeoFeature> output)
    {
        GeoPoint[] points = Coordinates(element).ToArray();
        if (points.Length > 1) output.Add(new GeoFeature(GeoGeometryKind.Polyline, new[] { points }));
    }

    private static void AddPolygon(XElement element, ICollection<GeoFeature> output)
    {
        IReadOnlyList<GeoPoint>[] rings = element.Descendants()
            .Where(item => item.Name.LocalName == "LinearRing")
            .Select(item => (IReadOnlyList<GeoPoint>)Coordinates(item).ToArray())
            .Where(ring => ring.Count > 2).ToArray();
        if (rings.Length > 0) output.Add(new GeoFeature(GeoGeometryKind.Polygon, rings));
    }

    private static IEnumerable<GeoPoint> Coordinates(XElement element)
    {
        string? text = element.Descendants()
            .FirstOrDefault(item => item.Name.LocalName == "coordinates")?.Value;
        if (string.IsNullOrWhiteSpace(text)) yield break;

        foreach (string token in text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries))
        {
            string[] values = token.Split(',');
            if (values.Length < 2
                || !double.TryParse(values[0], NumberStyles.Float, CultureInfo.InvariantCulture, out double x)
                || !double.TryParse(values[1], NumberStyles.Float, CultureInfo.InvariantCulture, out double y))
                continue;
            double? z = values.Length > 2
                && double.TryParse(values[2], NumberStyles.Float, CultureInfo.InvariantCulture, out double parsedZ)
                ? parsedZ : null;
            yield return new GeoPoint(x, y, z);
        }
    }

    private static ImportResult Success(string path, GeoLayerData data) => new()
    {
        IsSuccess = true,
        Message = "KMZ 파일을 불러왔습니다.",
        Layer = new ProjectLayer
        {
            Name = Path.GetFileName(path), FilePath = Path.GetFullPath(path),
            FileType = "KMZ", SourceData = data
        }
    };

    private static ImportResult Failure(string message) => new() { IsSuccess = false, Message = message };
}
