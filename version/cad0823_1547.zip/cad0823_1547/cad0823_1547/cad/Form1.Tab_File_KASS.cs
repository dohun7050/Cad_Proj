﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.Net.Http;
using System.Text.Json;
using System.Text;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using WeifenLuo.WinFormsUI.Docking;

namespace cad
{
    public partial class Form1 : Form
    {
        // 코드에 포함된 API 키로 국토지리정보원 항공사진 지도를 중앙 DockPanel에 엽니다.
        // 이미 항공사진 탭이 열려 있다면 중복 생성하지 않고 기존 탭을 활성화합니다.
        private void menuAerialPhoto_Click(object? sender, EventArgs e)
        {
            NgiiAerialMapDocument? opened = dockPanel1.Documents
                .OfType<NgiiAerialMapDocument>()
                .FirstOrDefault();

            if (opened is not null)
            {
                opened.Activate();
                return;
            }

            var document = new NgiiAerialMapDocument();
            document.Show(dockPanel1, DockState.Document);
            document.Activate();
            statusLabel.Text = "국토지리정보원 항공사진 지도를 불러오는 중입니다.";
        }

        // 국토정보플랫폼 로그인 페이지를 사용자의 기본 웹 브라우저에서 엽니다.
        private void menuNgiiPortal_Click(object? sender, EventArgs e)
        {
            const string portalUrl = "https://ngii.go.kr/sso/forward.do?targetUrl=https://map.ngii.go.kr/mn/login.do&returnUrl=https://map.ngii.go.kr/mn/mainPage.do";

            try
            {
                Process.Start(new ProcessStartInfo(portalUrl)
                {
                    UseShellExecute = true
                });
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    "국토정보플랫폼을 열지 못했습니다.\r\n" + exception.Message,
                    "바로가기 오류",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }

    // 항공사진 지도에서 전달되는 사각형 선택 영역의 화면 좌표를 보관합니다.
    internal sealed class AerialAreaExportMessage
    {
        public string Type { get; set; } = string.Empty;
        public double X { get; set; }
        public double Y { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public string Query { get; set; } = string.Empty;
    }

    // 항공사진 지도 문서에 사각형 영역 선택 도구와 PNG/JPG 저장 기능을 추가합니다.
    internal sealed partial class NgiiAerialMapDocument
    {
        private bool areaImageExportConfigured;

        // WebView2의 페이지 이동 완료 및 웹 메시지 이벤트를 한 번만 연결합니다.
        // 지도 HTML이 준비되면 사용자가 드래그할 수 있는 사각형 선택 도구를 삽입합니다.
        private void ConfigureAreaImageExport()
        {
            if (areaImageExportConfigured) return;
            areaImageExportConfigured = true;
            webView.CoreWebView2.NavigationCompleted += AreaImageExport_NavigationCompleted;
            webView.CoreWebView2.WebMessageReceived += AreaImageExport_WebMessageReceived;
        }

        // 항공사진 지도 오른쪽 위에 영역 저장 버튼과 드래그 선택 레이어를 생성합니다.
        private async void AreaImageExport_NavigationCompleted(object? sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (!e.IsSuccess) return;

            await webView.CoreWebView2.ExecuteScriptAsync("""
                (() => {
                  if (document.getElementById('cad-area-export-button')) return;

                  const searchPanel = document.createElement('div');
                  searchPanel.id = 'cad-region-search-panel';
                  Object.assign(searchPanel.style, {
                    position: 'fixed', top: '16px', left: '16px', zIndex: '2147483645',
                    display: 'flex', gap: '6px', alignItems: 'center', padding: '8px',
                    border: '1px solid #b8c5d1', borderRadius: '6px', background: 'rgba(255,255,255,.96)',
                    boxShadow: '0 2px 7px rgba(0,0,0,.20)', font: "13px 'Malgun Gothic'"
                  });

                  const searchInput = document.createElement('input');
                  searchInput.type = 'text';
                  searchInput.placeholder = '지역명 또는 주소 검색';
                  searchInput.title = '예: 서울특별시 종로구, 대전역';
                  Object.assign(searchInput.style, {
                    width: '230px', height: '34px', padding: '0 10px', boxSizing: 'border-box',
                    border: '1px solid #9daab6', borderRadius: '4px', outline: 'none'
                  });

                  const searchButton = document.createElement('button');
                  searchButton.textContent = '검색';
                  Object.assign(searchButton.style, {
                    height: '34px', padding: '0 14px', border: '1px solid #0b4f87',
                    borderRadius: '4px', background: '#0d5fa6', color: '#ffffff',
                    font: "600 13px 'Malgun Gothic'", cursor: 'pointer'
                  });

                  const searchStatus = document.createElement('span');
                  searchStatus.style.display = 'none';
                  searchStatus.style.marginLeft = '4px';
                  searchStatus.style.color = '#334155';

                  const requestRegionSearch = () => {
                    const query = searchInput.value.trim();
                    if (!query) {
                      searchInput.focus();
                      return;
                    }
                    searchButton.disabled = true;
                    searchButton.textContent = '검색 중';
                    searchStatus.style.display = 'none';
                    chrome.webview.postMessage({ type: 'search-region', query });
                  };

                  searchButton.addEventListener('click', requestRegionSearch);
                  searchInput.addEventListener('keydown', event => {
                    if (event.key === 'Enter') {
                      event.preventDefault();
                      requestRegionSearch();
                    }
                  });

                  window.cadRegionSearchResult = (success, message, longitude, latitude) => {
                    searchButton.disabled = false;
                    searchButton.textContent = '검색';
                    searchStatus.textContent = message;
                    searchStatus.style.color = success ? '#166534' : '#b42318';
                    searchStatus.style.display = 'inline';
                    if (!success) return;

                    const center = proj4('EPSG:4326', 'EPSG:5179', [longitude, latitude]);
                    const map = window.ngiiMap && window.ngiiMap._getMap();
                    if (map) map.getView().animate({ center, zoom: 14, duration: 700 });
                  };

                  searchPanel.appendChild(searchInput);
                  searchPanel.appendChild(searchButton);
                  searchPanel.appendChild(searchStatus);
                  document.body.appendChild(searchPanel);

                  const button = document.createElement('button');
                  button.id = 'cad-area-export-button';
                  button.textContent = '영역 이미지 저장';
                  Object.assign(button.style, {
                    position: 'fixed', top: '16px', right: '16px', zIndex: '2147483647',
                    height: '38px', padding: '0 16px', border: '1px solid #0b4f87',
                    borderRadius: '5px', background: '#0d5fa6', color: '#ffffff',
                    font: "600 13px 'Malgun Gothic'", cursor: 'pointer', boxShadow: '0 2px 7px rgba(0,0,0,.25)'
                  });

                  const overlay = document.createElement('div');
                  overlay.id = 'cad-area-export-overlay';
                  Object.assign(overlay.style, {
                    position: 'fixed', inset: '0', zIndex: '2147483646',
                    pointerEvents: 'none', cursor: 'crosshair', background: 'transparent'
                  });

                  const rectangle = document.createElement('div');
                  Object.assign(rectangle.style, {
                    position: 'absolute', display: 'none', border: '2px solid #ffcc33',
                    background: 'rgba(255, 204, 51, .18)', boxSizing: 'border-box'
                  });
                  overlay.appendChild(rectangle);
                  document.body.appendChild(overlay);
                  document.body.appendChild(button);

                  let selecting = false;
                  let dragging = false;
                  let startX = 0;
                  let startY = 0;

                  const finish = () => {
                    selecting = false;
                    dragging = false;
                    overlay.style.pointerEvents = 'none';
                    rectangle.style.display = 'none';
                    button.style.display = 'block';
                    button.textContent = '영역 이미지 저장';
                    button.style.background = '#0d5fa6';
                  };

                  window.cadAreaExportDone = finish;

                  button.addEventListener('click', () => {
                    if (selecting) {
                      finish();
                      return;
                    }
                    selecting = true;
                    overlay.style.pointerEvents = 'auto';
                    button.textContent = '선택 취소';
                    button.style.background = '#9b2c2c';
                  });

                  overlay.addEventListener('mousedown', event => {
                    if (!selecting || event.button !== 0) return;
                    event.preventDefault();
                    dragging = true;
                    startX = event.clientX;
                    startY = event.clientY;
                    rectangle.style.left = startX + 'px';
                    rectangle.style.top = startY + 'px';
                    rectangle.style.width = '0px';
                    rectangle.style.height = '0px';
                    rectangle.style.display = 'block';
                  });

                  overlay.addEventListener('mousemove', event => {
                    if (!dragging) return;
                    const left = Math.min(startX, event.clientX);
                    const top = Math.min(startY, event.clientY);
                    const width = Math.abs(event.clientX - startX);
                    const height = Math.abs(event.clientY - startY);
                    rectangle.style.left = left + 'px';
                    rectangle.style.top = top + 'px';
                    rectangle.style.width = width + 'px';
                    rectangle.style.height = height + 'px';
                  });

                  overlay.addEventListener('mouseup', event => {
                    if (!dragging) return;
                    dragging = false;
                    const left = Math.min(startX, event.clientX);
                    const top = Math.min(startY, event.clientY);
                    const width = Math.abs(event.clientX - startX);
                    const height = Math.abs(event.clientY - startY);
                    if (width < 10 || height < 10) {
                      finish();
                      return;
                    }

                    overlay.style.pointerEvents = 'none';
                    rectangle.style.display = 'none';
                    button.style.display = 'none';
                    requestAnimationFrame(() => requestAnimationFrame(() => {
                      chrome.webview.postMessage({ type: 'export-area', x: left, y: top, width, height });
                    }));
                  });

                  document.addEventListener('keydown', event => {
                    if (event.key === 'Escape' && selecting) finish();
                  });
                })();
                """);
        }

        // JavaScript에서 받은 메시지를 구분하여 지역 검색 또는 항공사진 영역 저장을 실행합니다.
        private async void AreaImageExport_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            bool restoreAreaSelection = false;

            try
            {
                AerialAreaExportMessage? selection = JsonSerializer.Deserialize<AerialAreaExportMessage>(
                    e.WebMessageAsJson,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                if (selection is null) return;

                if (selection.Type == "search-region")
                {
                    await SearchAerialRegionAsync(selection.Query);
                    return;
                }

                if (selection.Type != "export-area") return;
                restoreAreaSelection = true;
                await SaveSelectedAerialAreaAsync(selection);
            }
            catch (Exception exception)
            {
                await SendRegionSearchResultAsync(false, "처리 중 오류가 발생했습니다.", 0, 0);
                MessageBox.Show(exception.Message, "항공사진 지도 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (restoreAreaSelection) await RestoreAreaSelectionToolAsync();
            }
        }

        // 입력한 국내 지역명이나 주소를 검색하고 검색 결과의 위도·경도로 NGII 지도를 이동시킵니다.
        private async Task SearchAerialRegionAsync(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
            {
                await SendRegionSearchResultAsync(false, "검색어를 입력하세요.", 0, 0);
                return;
            }

            string requestUrl = "https://nominatim.openstreetmap.org/search"
                + "?format=jsonv2&limit=1&countrycodes=kr&accept-language=ko&q="
                + Uri.EscapeDataString(query.Trim());

            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
            client.DefaultRequestHeaders.UserAgent.ParseAdd("ForestRoadCAD/1.0 (WinForms region search)");
            using HttpResponseMessage response = await client.GetAsync(requestUrl);
            response.EnsureSuccessStatusCode();
            string json = await response.Content.ReadAsStringAsync();

            using JsonDocument document = JsonDocument.Parse(json);
            if (document.RootElement.GetArrayLength() == 0)
            {
                await SendRegionSearchResultAsync(false, "검색 결과가 없습니다.", 0, 0);
                return;
            }

            JsonElement result = document.RootElement[0];
            string latitudeText = result.GetProperty("lat").GetString() ?? string.Empty;
            string longitudeText = result.GetProperty("lon").GetString() ?? string.Empty;
            string displayName = result.TryGetProperty("display_name", out JsonElement nameElement)
                ? nameElement.GetString() ?? query
                : query;

            if (!double.TryParse(latitudeText, NumberStyles.Float, CultureInfo.InvariantCulture, out double latitude)
                || !double.TryParse(longitudeText, NumberStyles.Float, CultureInfo.InvariantCulture, out double longitude))
            {
                await SendRegionSearchResultAsync(false, "검색 좌표를 해석하지 못했습니다.", 0, 0);
                return;
            }

            await SendRegionSearchResultAsync(true, displayName, longitude, latitude);
        }

        // C# 지역 검색 결과를 JavaScript에 안전하게 전달하여 검색 상태와 지도 중심을 갱신합니다.
        private async Task SendRegionSearchResultAsync(bool success, string message, double longitude, double latitude)
        {
            if (webView.CoreWebView2 is null) return;

            string successValue = success ? "true" : "false";
            string messageValue = JsonSerializer.Serialize(message);
            string longitudeValue = longitude.ToString("R", CultureInfo.InvariantCulture);
            string latitudeValue = latitude.ToString("R", CultureInfo.InvariantCulture);
            await webView.CoreWebView2.ExecuteScriptAsync(
                $"window.cadRegionSearchResult && window.cadRegionSearchResult({successValue}, {messageValue}, {longitudeValue}, {latitudeValue});");
        }

        // WebView2 전체 화면을 PNG로 캡처하고 CSS 선택 좌표를 실제 캡처 픽셀 좌표로 변환하여 잘라냅니다.
        // 저장 대화상자에서 선택한 확장자에 따라 PNG 또는 JPG로 기록합니다.
        private async Task SaveSelectedAerialAreaAsync(AerialAreaExportMessage selection)
        {
            using var dialog = new SaveFileDialog
            {
                Title = "선택한 항공사진 영역 저장",
                Filter = "PNG 이미지 (*.png)|*.png|JPEG 이미지 (*.jpg;*.jpeg)|*.jpg;*.jpeg",
                FilterIndex = 1,
                DefaultExt = "png",
                AddExtension = true,
                OverwritePrompt = true,
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
                FileName = $"항공사진_{DateTime.Now:yyyyMMdd_HHmmss}"
            };

            if (dialog.ShowDialog(this) != DialogResult.OK) return;
            if (webView.ClientSize.Width <= 0 || webView.ClientSize.Height <= 0)
                throw new InvalidOperationException("항공사진 화면 크기가 올바르지 않습니다.");

            using var stream = new MemoryStream();
            await webView.CoreWebView2.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png, stream);
            stream.Position = 0;
            using var fullImage = new Bitmap(stream);

            double scaleX = (double)fullImage.Width / webView.ClientSize.Width;
            double scaleY = (double)fullImage.Height / webView.ClientSize.Height;
            int left = Math.Clamp((int)Math.Floor(selection.X * scaleX), 0, fullImage.Width - 1);
            int top = Math.Clamp((int)Math.Floor(selection.Y * scaleY), 0, fullImage.Height - 1);
            int right = Math.Clamp((int)Math.Ceiling((selection.X + selection.Width) * scaleX), left + 1, fullImage.Width);
            int bottom = Math.Clamp((int)Math.Ceiling((selection.Y + selection.Height) * scaleY), top + 1, fullImage.Height);

            using Bitmap selectedImage = fullImage.Clone(
                Rectangle.FromLTRB(left, top, right, bottom),
                PixelFormat.Format32bppArgb);
            SaveSelectedAreaBitmap(selectedImage, dialog.FileName);
            MessageBox.Show("선택한 항공사진 영역을 저장했습니다.", "영역 저장 완료", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // 선택 영역 비트맵을 파일 확장자에 맞춰 PNG로 저장하거나 흰 배경의 JPG로 변환해 저장합니다.
        private static void SaveSelectedAreaBitmap(Bitmap image, string path)
        {
            string extension = Path.GetExtension(path);
            if (extension.Equals(".jpg", StringComparison.OrdinalIgnoreCase)
                || extension.Equals(".jpeg", StringComparison.OrdinalIgnoreCase))
            {
                using var jpegImage = new Bitmap(image.Width, image.Height, PixelFormat.Format24bppRgb);
                using Graphics graphics = Graphics.FromImage(jpegImage);
                graphics.Clear(Color.White);
                graphics.DrawImageUnscaled(image, 0, 0);
                jpegImage.Save(path, ImageFormat.Jpeg);
                return;
            }

            image.Save(path, ImageFormat.Png);
        }

        // 저장 완료·취소·오류 후 사각형 선택 레이어와 버튼을 원래 상태로 되돌립니다.
        private async Task RestoreAreaSelectionToolAsync()
        {
            if (webView.CoreWebView2 is null) return;
            await webView.CoreWebView2.ExecuteScriptAsync("window.cadAreaExportDone && window.cadAreaExportDone();");
        }
    }
}
