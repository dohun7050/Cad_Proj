﻿using System.Drawing.Drawing2D;
using IxMilia.Dxf;
using IxMilia.Dxf.Entities;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

// 현재 DXF의 좌표를 간단한 직교 투영으로 표시하는 회전 가능한 3D 와이어프레임 문서입니다.
internal sealed class Dxf3DDocument : DockContent
{
    internal Docment_Dxf SourceDocument { get; }

    internal Dxf3DDocument(Docment_Dxf sourceDocument, DxfFile dxf)
    {
        SourceDocument = sourceDocument;
        Text = $"3D - {sourceDocument.Text.TrimEnd('*')}";
        TabText = Text;
        BackColor = Color.FromArgb(9, 22, 34);
        Controls.Add(new Dxf3DCanvas(dxf) { Dock = DockStyle.Fill });
    }
}

internal readonly record struct Dxf3DPoint(double X, double Y, double Z);
internal readonly record struct Dxf3DSegment(Dxf3DPoint Start, Dxf3DPoint End);

internal sealed class Dxf3DCanvas : Panel
{
    private readonly List<Dxf3DSegment> segments = new(); // LINE 과 POLYLINE을 구성하는 선분 저장. 
    private readonly List<Dxf3DPoint> standalonePoints = new(); //DXF POINT 객체 저장 
    private readonly Dxf3DPoint center;
    private readonly double modelRadius;
    private readonly double zRange;
    private float yaw = -35F;
    private float pitch = 32F;
    private float zoom = 1F;
    private float verticalExaggeration = 1.8F;
    private Point lastMouse;
    private bool rotating;

    internal Dxf3DCanvas(DxfFile dxf)
    {
        BackColor = Color.FromArgb(9, 22, 34);
        Cursor = Cursors.Hand;
        TabStop = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.ResizeRedraw, true);

        ReadGeometry(dxf);
        List<Dxf3DPoint> points = segments.SelectMany(segment => new[] { segment.Start, segment.End })
            .Concat(standalonePoints).ToList();
        if (points.Count == 0)
        {
            center = new Dxf3DPoint(0, 0, 0);
            modelRadius = 1;
            zRange = 0;
        }
        else
        {
            double minX = points.Min(point => point.X);
            double maxX = points.Max(point => point.X);
            double minY = points.Min(point => point.Y);
            double maxY = points.Max(point => point.Y);
            double minZ = points.Min(point => point.Z);
            double maxZ = points.Max(point => point.Z);
            center = new Dxf3DPoint((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2);
            modelRadius = Math.Max(1, Math.Max(maxX - minX, maxY - minY) / 2);
            zRange = maxZ - minZ;
        }

        MouseDown += OnCanvasMouseDown;
        MouseMove += OnCanvasMouseMove;
        MouseUp += (_, _) => rotating = false;
        MouseLeave += (_, _) => rotating = false;
        MouseWheel += OnCanvasMouseWheel;
        DoubleClick += (_, _) => ResetView();
    }

    private void ReadGeometry(DxfFile dxf)
    {
        foreach (DxfEntity entity in dxf.Entities) // 엔티티 전체 순회 
        {
            switch (entity)
            {
                case DxfLine line:
                    segments.Add(new Dxf3DSegment(ToPoint(line.P1), ToPoint(line.P2)));
                    break;

                case DxfPolyline polyline:
                    AddPath(polyline.Vertices.Select(vertex => ToPoint(vertex.Location)).ToList(), polyline.IsClosed);
                    break;

                case DxfLwPolyline polyline:
                    AddPath(polyline.Vertices
                        .Select(vertex => new Dxf3DPoint(vertex.X, vertex.Y, polyline.Elevation)).ToList(),
                        polyline.IsClosed);
                    break;

                case DxfModelPoint point:
                    standalonePoints.Add(ToPoint(point.Location));
                    break;
            }
        }
    }

    private void AddPath(IReadOnlyList<Dxf3DPoint> points, bool closed)
    {
        for (int index = 1; index < points.Count; index++)
            segments.Add(new Dxf3DSegment(points[index - 1], points[index]));

        if (closed && points.Count > 2)
            segments.Add(new Dxf3DSegment(points[^1], points[0]));
    }

    private static Dxf3DPoint ToPoint(DxfPoint point) => new(point.X, point.Y, point.Z);

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.Clear(BackColor);

        DrawHeader(e.Graphics);
        if (segments.Count == 0 && standalonePoints.Count == 0)
        {
            using var emptyFont = new Font("맑은 고딕", 12F, FontStyle.Bold);
            const string message = "3D로 표시할 POINT, LINE 또는 POLYLINE 엔티티가 없습니다.";
            SizeF size = e.Graphics.MeasureString(message, emptyFont);
            e.Graphics.DrawString(message, emptyFont, Brushes.White,
                (ClientSize.Width - size.Width) / 2F, (ClientSize.Height - size.Height) / 2F);
            return;
        }

        Rectangle viewport = new(38, 72, Math.Max(1, ClientSize.Width - 76), Math.Max(1, ClientSize.Height - 116));
        float drawingScale = Math.Min(viewport.Width, viewport.Height) * .43F / (float)modelRadius * zoom;
        DrawGroundGrid(e.Graphics, viewport, drawingScale);

        using var wirePen = new Pen(Color.FromArgb(92, 210, 235), 1.05F);
        using var highPen = new Pen(Color.FromArgb(245, 181, 72), 1.35F);
        foreach (Dxf3DSegment segment in segments)
        {
            PointF a = Project(segment.Start, viewport, drawingScale);
            PointF b = Project(segment.End, viewport, drawingScale);
            double averageZ = (segment.Start.Z + segment.End.Z) / 2;
            e.Graphics.DrawLine(zRange > 0 && averageZ >= center.Z ? highPen : wirePen, a, b);
        }

        using var pointBrush = new SolidBrush(Color.FromArgb(250, 106, 92));
        foreach (Dxf3DPoint point in standalonePoints)
        {
            PointF screen = Project(point, viewport, drawingScale);
            e.Graphics.FillEllipse(pointBrush, screen.X - 2.5F, screen.Y - 2.5F, 5F, 5F);
        }

        DrawAxes(e.Graphics, viewport, drawingScale);
        DrawFooter(e.Graphics);
    }

    private PointF Project(Dxf3DPoint point, Rectangle viewport, float drawingScale)
    {
        double x = point.X - center.X;
        double y = point.Y - center.Y;
        double z = (point.Z - center.Z) * verticalExaggeration;
        double yawRadians = yaw * Math.PI / 180;
        double pitchRadians = pitch * Math.PI / 180;

        double rotatedX = Math.Cos(yawRadians) * x - Math.Sin(yawRadians) * y;
        double rotatedY = Math.Sin(yawRadians) * x + Math.Cos(yawRadians) * y;
        double screenVertical = Math.Sin(pitchRadians) * rotatedY + Math.Cos(pitchRadians) * z;

        return new PointF(
            viewport.Left + viewport.Width / 2F + (float)rotatedX * drawingScale,
            viewport.Top + viewport.Height / 2F - (float)screenVertical * drawingScale);
    }

    private void DrawGroundGrid(Graphics graphics, Rectangle viewport, float scale)
    {
        using var gridPen = new Pen(Color.FromArgb(36, 82, 105), 1F);
        double interval = modelRadius / 5;
        for (int index = -5; index <= 5; index++)
        {
            double offset = index * interval;
            Dxf3DPoint a = new(center.X - modelRadius, center.Y + offset, center.Z);
            Dxf3DPoint b = new(center.X + modelRadius, center.Y + offset, center.Z);
            Dxf3DPoint c = new(center.X + offset, center.Y - modelRadius, center.Z);
            Dxf3DPoint d = new(center.X + offset, center.Y + modelRadius, center.Z);
            graphics.DrawLine(gridPen, Project(a, viewport, scale), Project(b, viewport, scale));
            graphics.DrawLine(gridPen, Project(c, viewport, scale), Project(d, viewport, scale));
        }
    }

    private void DrawAxes(Graphics graphics, Rectangle viewport, float scale)
    {
        double length = modelRadius * .22;
        Dxf3DPoint origin = center;
        PointF o = Project(origin, viewport, scale);
        DrawAxis(graphics, o, Project(new Dxf3DPoint(center.X + length, center.Y, center.Z), viewport, scale), "X", Color.IndianRed);
        DrawAxis(graphics, o, Project(new Dxf3DPoint(center.X, center.Y + length, center.Z), viewport, scale), "Y", Color.LightGreen);
        DrawAxis(graphics, o, Project(new Dxf3DPoint(center.X, center.Y, center.Z + length / verticalExaggeration), viewport, scale), "Z", Color.DeepSkyBlue);
    }

    private static void DrawAxis(Graphics graphics, PointF origin, PointF end, string label, Color color)
    {
        using var pen = new Pen(color, 2.2F) { EndCap = LineCap.ArrowAnchor };
        using var font = new Font("Segoe UI", 9F, FontStyle.Bold);
        using var brush = new SolidBrush(color);
        graphics.DrawLine(pen, origin, end);
        graphics.DrawString(label, font, brush, end.X + 3, end.Y - 8);
    }

    private void DrawHeader(Graphics graphics)
    {
        using var headerBrush = new SolidBrush(Color.FromArgb(13, 43, 66));
        using var titleFont = new Font("맑은 고딕", 12F, FontStyle.Bold);
        using var infoFont = new Font("맑은 고딕", 9F);
        graphics.FillRectangle(headerBrush, 0, 0, ClientSize.Width, 54);
        graphics.DrawString("DXF 3D 와이어프레임", titleFont, Brushes.White, 18, 14);
        string info = zRange <= .000001
            ? "Z 범위: 0 (2D DXF)"
            : $"Z 범위: {zRange:N2} · 수직과장: {verticalExaggeration:0.0}×";
        SizeF size = graphics.MeasureString(info, infoFont);
        graphics.DrawString(info, infoFont, Brushes.LightSteelBlue,
            Math.Max(230, ClientSize.Width - size.Width - 18), 18);
    }

    private void DrawFooter(Graphics graphics)
    {
        using var font = new Font("맑은 고딕", 9F);
        graphics.DrawString("좌클릭 드래그: 회전   ·   마우스 휠: 확대/축소   ·   더블클릭: 보기 초기화",
            font, Brushes.LightSteelBlue, 18, Math.Max(58, ClientSize.Height - 31));
    }

    private void OnCanvasMouseDown(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;
        Focus();
        rotating = true;
        lastMouse = e.Location;
        Cursor = Cursors.SizeAll;
    }

    private void OnCanvasMouseMove(object? sender, MouseEventArgs e)
    {
        if (!rotating) return;
        yaw += (e.X - lastMouse.X) * .45F;
        pitch = Math.Clamp(pitch - (e.Y - lastMouse.Y) * .35F, -85F, 85F);
        lastMouse = e.Location;
        Invalidate();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        rotating = false;
        Cursor = Cursors.Hand;
    }

    private void OnCanvasMouseWheel(object? sender, MouseEventArgs e)
    {
        zoom = Math.Clamp(zoom * (e.Delta > 0 ? 1.12F : 1F / 1.12F), .15F, 12F);
        Invalidate();
    }

    private void ResetView()
    {
        yaw = -35F;
        pitch = 32F;
        zoom = 1F;
        Invalidate();
    }
}
