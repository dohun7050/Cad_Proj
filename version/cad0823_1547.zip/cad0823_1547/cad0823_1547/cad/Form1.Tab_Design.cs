﻿namespace cad;

public partial class Form1
{
    // 설계 탭의 종단면·횡단면·토공·배수/구조물 버튼에 아이콘을 적용합니다.
    private void ConfigureDesignTab()
    {
        ConfigureRibbonButton(menuProfile, "profile.png");
        ConfigureRibbonButton(menuCrossSection, "cross_section.png");
        ConfigureRibbonButton(menuEarthwork, "earthwork.png");
        ConfigureRibbonButton(menuDrainage, "drainage.png");
    }
}
