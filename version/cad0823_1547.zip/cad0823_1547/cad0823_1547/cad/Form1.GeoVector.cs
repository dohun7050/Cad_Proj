using cad.Importers;
using cad.Models;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

public partial class Form1
{
    private static bool IsGeoVectorDocument(string path)
    {
        string extension = Path.GetExtension(path);
        return extension.Equals(".shp", StringComparison.OrdinalIgnoreCase)
            || extension.Equals(".kmz", StringComparison.OrdinalIgnoreCase);
    }

    private void OpenGeoVectorDocument(string path)
    {
        string fullPath = Path.GetFullPath(path);
        GeoVectorDocument? opened = dockPanel1.Documents
            .OfType<GeoVectorDocument>()
            .FirstOrDefault(document => string.Equals(
                document.DocumentPath, fullPath, StringComparison.OrdinalIgnoreCase));
        if (opened is not null)
        {
            opened.Activate();
            return;
        }

        IFileImporter importer = Path.GetExtension(fullPath).Equals(".kmz", StringComparison.OrdinalIgnoreCase)
            ? new KmzImporter() : new ShpImporter();
        ImportResult result = importer.Import(fullPath);
        if (!result.IsSuccess || result.Layer?.SourceData is not GeoLayerData data)
        {
            MessageBox.Show(result.Message, "공간 파일 불러오기 오류",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        l.Add(result.Layer);
        label1.Text = $"객체: {data.Features.Count:N0}  |  점: {data.PointCount:N0}  |  선: {data.LineCount:N0}  |  영역: {data.PolygonCount:N0}";
        statusLabel.Text = $"{result.Layer.FileType} 불러오기 완료: {result.Layer.Name}";

        var document = new GeoVectorDocument(data, fullPath);
        document.Show(dockPanel1, DockState.Document);
        document.Activate();
    }
}
