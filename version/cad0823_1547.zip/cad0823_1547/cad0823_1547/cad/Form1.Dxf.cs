﻿using cad.Importers;
using cad.Models;
using IxMilia.Dxf;
using IxMilia.Dxf.Entities;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

// [DXF 탐색기 연동 추가 기능 영역]
// 원본 menuOpen_Click과 DxfImporter를 유지하면서 탐색기 더블클릭·드래그 열기를 지원하기 위해 분리했습니다.
public partial class Form1
{
    // 현재 프로젝트에서 성공적으로 불러온 DXF 레이어 목록을 보관합니다.
    private readonly List<ProjectLayer> projectLayers = new();

    // 파일 버튼의 menuOpen_Click은 원본 Form1.Tab_File.cs 형식을 그대로 사용합니다.
    // 이 파일에는 프로젝트 탐색기에서 DXF를 여는 보조 기능만 남겨 중복 이벤트 함수를 방지했습니다.

    // 선택한 DXF가 프로젝트 밖에 있으면 탐색기에서 현재 선택한 폴더로 복사합니다.
    private string CopyDxfIntoProject(string sourcePath)
    {
        string fullSourcePath = Path.GetFullPath(sourcePath);
        Directory.CreateDirectory(projectRoot);

        if (IsInsideProject(fullSourcePath)) return fullSourcePath;

        string targetDirectory = SelectedDirectory();
        if (!Directory.Exists(targetDirectory) || !IsInsideProject(targetDirectory))
            targetDirectory = projectRoot;

        string destination = UniqueDestination(targetDirectory, Path.GetFileName(fullSourcePath));
        File.Copy(fullSourcePath, destination);
        LoadFileTree();
        return destination;
    }

    // 경로가 현재 ProjectFiles 폴더 또는 그 하위에 있는지 상대 경로로 안전하게 검사합니다.
    private bool IsInsideProject(string path)
    {
        string relativePath = Path.GetRelativePath(projectRoot, Path.GetFullPath(path));
        return relativePath != ".."
            && !relativePath.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal)
            && !Path.IsPathRooted(relativePath);
    }

    // DXF를 파싱하고 범위를 계산한 뒤 DockPanel의 문서 탭으로 표시합니다.
    private void OpenDxfDocument(string filePath)
    {
        string fullPath = Path.GetFullPath(filePath);
        Docment_Dxf? opened = dockPanel1.Documents
            .OfType<Docment_Dxf>()
            .FirstOrDefault(document => string.Equals(document.GetDocumentPath(), fullPath, StringComparison.OrdinalIgnoreCase));

        if (opened is not null)
        {
            opened.Activate();
            ApplyCadWorkspaceToActiveDxf();
            return;
        }

        var importer = new DxfImporter();
        ImportResult result = importer.Import(fullPath);
        if (!result.IsSuccess || result.Layer?.SourceData is not DxfFile dxfFile)
        {
            throw new InvalidDataException(result.Message.Length > 0 ? result.Message : "DXF 파일을 읽을 수 없습니다.");
        }

        if (!DxfGeometry.TryGetBounds(dxfFile, out double minX, out double minY, out double maxX, out double maxY))
        {
            throw new InvalidDataException("표시할 수 있는 LINE, POLYLINE, CIRCLE 또는 ARC 엔티티가 없습니다.");
        }

        // 첫 DXF의 실제 범위를 중앙 CAD 기준 좌표계에 적용해 기존 점·선과 등고선 위치를 동기화합니다.
        SynchronizeCadWorkspaceWithDxfBounds(minX, minY, maxX, maxY);

        if (!projectLayers.Any(layer => string.Equals(layer.FilePath, fullPath, StringComparison.OrdinalIgnoreCase)))
            projectLayers.Add(result.Layer);

        int lineCount = dxfFile.Entities.OfType<DxfLine>().Count();
        int polylineCount = dxfFile.Entities.OfType<DxfPolyline>().Count()
            + dxfFile.Entities.OfType<DxfLwPolyline>().Count();
        int circleAndArcCount = dxfFile.Entities.OfType<DxfCircle>().Count()
            + dxfFile.Entities.OfType<DxfArc>().Count();

        label1.Text = $"객체: {dxfFile.Entities.Count}  |  선: {lineCount}  |  폴리선: {polylineCount}  |  원/호: {circleAndArcCount}";

        // 원본 DxfDocument 생성자의 title 매개변수 형식을 유지하므로 탭에는 파일 이름만 전달합니다.
        // 탐색기 중복 열기 검사용 전체 경로는 새 DocumentPath 속성에 별도로 저장합니다.
        var document = new Docment_Dxf(dxfFile, Path.GetFileName(fullPath), minX, minY, maxX, maxY);
        document.SetDocumentPath(fullPath);
        document.Show(dockPanel1, DockState.Document);
        document.Activate();
        ApplyCadWorkspaceToActiveDxf();
    }
}
