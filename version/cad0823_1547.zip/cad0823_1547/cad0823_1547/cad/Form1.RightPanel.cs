﻿using System.Drawing.Drawing2D;

namespace cad;

public partial class Form1
{
    private const int ExpandedRightPanelWidth = 340;
    private const int CollapsedRightPanelWidth = 38;

    private readonly Dictionary<RightPanelPage, Control> rightPanelPages = [];
    private readonly Dictionary<RightPanelPage, RightPanelTabButton> rightPanelTabs = [];
    private Panel? rightPageHost;
    // 기존 DXF 선택 기능이 레이어 목록을 표시할 작업 패널 안의 전용 영역입니다.
    private Panel? selectionLayerHost;
    private Label? selectionInfoLabel;
    private readonly List<Control> workSelectionControls = [];
    private readonly List<Control> workQuickSettingControls = [];
    private Panel? workDefaultPlaceholder;
    private RightPanelPage activeRightPanelPage = RightPanelPage.Properties;
    private bool rightPanelExpanded = true;

    private enum RightPanelPage { Properties, Work, Review, Report }

    private void ConfigureRightPanel()
    {
        propertyPanel.SuspendLayout();
        propertyPanel.Controls.Clear();
        propertyPanel.Width = ExpandedRightPanelWidth;
        propertyPanel.BackColor = Color.White;
        propertyPanel.Padding = Padding.Empty;

        var tabRail = new Panel
        {
            Dock = DockStyle.Right,
            Width = CollapsedRightPanelWidth,
            BackColor = Color.FromArgb(232, 240, 249),
            Padding = new Padding(0, 6, 0, 0)
        };
        rightPageHost = new Panel { Dock = DockStyle.Fill, BackColor = Color.White };

        AddRightPanelPage(RightPanelPage.Report, "보고서", BuildReportPage(), tabRail);
        AddRightPanelPage(RightPanelPage.Review, "검토", BuildReviewPage(), tabRail);
        AddRightPanelPage(RightPanelPage.Work, "작업", BuildWorkPage(), tabRail);
        AddRightPanelPage(RightPanelPage.Properties, "속성", BuildPropertiesPage(), tabRail);

        var pinButton = new Button
        {
            Dock = DockStyle.Top,
            Height = 31,
            Text = "📌",
            Font = new Font("Segoe UI Emoji", 10F),
            FlatStyle = FlatStyle.Flat,
            FlatAppearance = { BorderSize = 0 },
            BackColor = Color.FromArgb(232, 240, 249),
            Cursor = Cursors.Hand,
            AccessibleName = "오른쪽 패널 접기 또는 펼치기"
        };
        pinButton.Click += (_, _) => ToggleRightPanel();
        tabRail.Controls.Add(pinButton);

        propertyPanel.Controls.Add(rightPageHost);
        propertyPanel.Controls.Add(tabRail);
        propertyPanel.ResumeLayout();
        AttachRightPanelMenuLinks();
        ShowRightPanelPage(RightPanelPage.Properties);
    }

    private void AddRightPanelPage(RightPanelPage page, string title, Control content, Panel tabRail)
    {
        content.Dock = DockStyle.Fill;
        content.Visible = false;
        rightPageHost!.Controls.Add(content);
        rightPanelPages.Add(page, content);

        var tab = new RightPanelTabButton
        {
            Dock = DockStyle.Top,
            Height = page == RightPanelPage.Report ? 66 : 58,
            Text = title,
            AccessibleName = $"{title} 패널"
        };
        tab.Click += (_, _) =>
        {
            if (activeRightPanelPage == page && rightPanelExpanded)
            {
                ToggleRightPanel();
                return;
            }
            OpenRightPanel(page);
        };
        tabRail.Controls.Add(tab);
        rightPanelTabs.Add(page, tab);
    }

    private void ShowRightPanelPage(RightPanelPage page)
    {
        activeRightPanelPage = page;
        foreach ((RightPanelPage key, Control content) in rightPanelPages)
            content.Visible = key == page && rightPanelExpanded;
        foreach ((RightPanelPage key, RightPanelTabButton tab) in rightPanelTabs)
            tab.SetSelected(key == page);
    }

    private void ToggleRightPanel()
    {
        rightPanelExpanded = !rightPanelExpanded;
        propertyPanel.Width = rightPanelExpanded ? ExpandedRightPanelWidth : CollapsedRightPanelWidth;
        ShowRightPanelPage(activeRightPanelPage);
    }

    private void OpenRightPanel(RightPanelPage page)
    {
        rightPanelExpanded = true;
        propertyPanel.Width = ExpandedRightPanelWidth;
        ShowRightPanelPage(page);
    }

    private void AttachRightPanelMenuLinks()
    {
        menuReview.Click += (_, _) => OpenRightPanel(RightPanelPage.Review);
        menuReport.Click += (_, _) => OpenRightPanel(RightPanelPage.Report);
        menuOutput.Click += (_, _) => OpenRightPanel(RightPanelPage.Report);
        Button[] workButtons =
        [
            menuEdit, menuAreaSelect, menuPointLineAdd, menuModify, menuDeleteFeature, menuFreeLine,
            menuTerrain, menuHydrology, menuEnvironment, menuConstraint, menuRouteSearch,
            menuAlignment, menuProfile, menuCrossSection, menuEarthwork, menuDrainage
        ];
        foreach (Button button in workButtons)
            button.Click += (_, _) => OpenRightPanel(RightPanelPage.Work);
    }

    private static Panel CreateScrollablePage(string title, string description)
    {
        var page = new Panel { BackColor = Color.White, AutoScroll = true, Padding = new Padding(14, 0, 14, 16) };
        var content = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Color.White,
            Padding = new Padding(0, 14, 0, 8)
        };
        content.Controls.Add(CreatePageTitle(title, description));
        page.Controls.Add(content);
        return page;
    }

    private static FlowLayoutPanel GetPageContent(Panel page) => (FlowLayoutPanel)page.Controls[0];

    private static Control CreatePageTitle(string title, string description)
    {
        var container = new Panel { Width = 258, Height = 55, Margin = new Padding(0, 0, 0, 10) };
        container.Controls.Add(new Label
        {
            Dock = DockStyle.Top,
            Height = 25,
            Text = title,
            Font = new Font("맑은 고딕", 11F, FontStyle.Bold),
            ForeColor = Color.FromArgb(20, 50, 80)
        });
        container.Controls.Add(new Label
        {
            Dock = DockStyle.Bottom,
            Height = 25,
            Text = description,
            Font = new Font("맑은 고딕", 8.5F),
            ForeColor = Color.FromArgb(102, 116, 130)
        });
        return container;
    }

    private static Label CreateSectionTitle(string text) => new()
    {
        Width = 258,
        Height = 31,
        Text = text,
        Padding = new Padding(0, 10, 0, 0),
        Margin = new Padding(0, 4, 0, 2),
        Font = new Font("맑은 고딕", 9F, FontStyle.Bold),
        ForeColor = Color.FromArgb(35, 82, 124),
        BorderStyle = BorderStyle.FixedSingle
    };

    private static Control CreateField(string label, Control editor)
    {
        var row = new TableLayoutPanel { Width = 258, Height = 31, ColumnCount = 2, Margin = new Padding(0, 2, 0, 2) };
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 84));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        row.Controls.Add(new Label
        {
            Text = label,
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("맑은 고딕", 8.5F),
            ForeColor = Color.FromArgb(62, 77, 91)
        }, 0, 0);
        editor.Dock = DockStyle.Fill;
        editor.Font = new Font("맑은 고딕", 8.5F);
        row.Controls.Add(editor, 1, 0);
        return row;
    }

    private static ComboBox CreateCombo(params string[] items)
    {
        var combo = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, FlatStyle = FlatStyle.Flat };
        combo.Items.AddRange(items);
        if (combo.Items.Count > 0) combo.SelectedIndex = 0;
        return combo;
    }

    // 선 종류를 이름만이 아니라 실제 선 모양과 함께 선택할 수 있도록 합니다.
    private static ComboBox CreateLineTypeCombo()
    {
        var combo = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList,
            FlatStyle = FlatStyle.Flat,
            DrawMode = DrawMode.OwnerDrawFixed,
            ItemHeight = 24
        };
        combo.Items.AddRange(
        [
            new LineTypeItem("실선", DashStyle.Solid),
            new LineTypeItem("점선", DashStyle.Dot),
            new LineTypeItem("파선", DashStyle.Dash),
            new LineTypeItem("점쇄선", DashStyle.DashDot),
            new LineTypeItem("이점쇄선", DashStyle.DashDotDot),
            new LineTypeItem("중심선", DashStyle.DashDot),
            new LineTypeItem("숨은선", DashStyle.Dash)
        ]);
        combo.SelectedIndex = 0;
        combo.DrawItem += (_, e) =>
        {
            if (e.Index < 0 || combo.Items[e.Index] is not LineTypeItem item) return;
            bool selected = (e.State & DrawItemState.Selected) != 0;
            e.Graphics.FillRectangle(selected ? SystemBrushes.Highlight : SystemBrushes.Window, e.Bounds);
            using var pen = new Pen(selected ? Color.White : Color.FromArgb(34, 65, 95), 1.6F) { DashStyle = item.Style };
            int middle = e.Bounds.Top + e.Bounds.Height / 2;
            e.Graphics.DrawLine(pen, e.Bounds.Left + 8, middle, e.Bounds.Left + 74, middle);
            TextRenderer.DrawText(e.Graphics, item.Name, e.Font, new Rectangle(e.Bounds.Left + 84, e.Bounds.Top, e.Bounds.Width - 88, e.Bounds.Height),
                selected ? SystemColors.HighlightText : Color.FromArgb(45, 60, 73), TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
        };
        return combo;
    }

    // 슬라이더와 숫자 입력을 함께 제공해 마우스와 정확한 수치 입력을 모두 지원합니다.
    private static Control CreateSliderEditor(int minimum, int maximum, int value, int decimalPlaces, string suffix)
    {
        var editor = new TableLayoutPanel { ColumnCount = 2, Margin = Padding.Empty, Padding = Padding.Empty };
        editor.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        editor.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 64));
        var slider = new TrackBar
        {
            Minimum = minimum,
            Maximum = maximum,
            Value = Math.Clamp(value, minimum, maximum),
            TickStyle = TickStyle.None,
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 0, 4, 0)
        };
        decimal scale = decimalPlaces == 0 ? 1 : (decimal)Math.Pow(10, decimalPlaces);
        var number = new NumericUpDown
        {
            Minimum = minimum / scale,
            Maximum = maximum / scale,
            Value = value / scale,
            DecimalPlaces = decimalPlaces,
            Increment = decimalPlaces == 0 ? 1 : 1 / scale,
            Dock = DockStyle.Fill,
            TextAlign = HorizontalAlignment.Right
        };
        bool isSynchronizing = false;
        slider.ValueChanged += (_, _) =>
        {
            if (isSynchronizing) return;
            isSynchronizing = true;
            number.Value = slider.Value / scale;
            isSynchronizing = false;
        };
        number.ValueChanged += (_, _) =>
        {
            if (isSynchronizing) return;
            isSynchronizing = true;
            slider.Value = (int)(number.Value * scale);
            isSynchronizing = false;
        };
        editor.Controls.Add(slider, 0, 0);
        editor.Controls.Add(number, 1, 0);
        var container = new Panel { Height = 30, Margin = Padding.Empty };
        editor.Dock = DockStyle.Fill;
        container.Controls.Add(editor);
        if (!string.IsNullOrEmpty(suffix)) number.AccessibleName = $"{suffix} 값 입력";
        return container;
    }

    // 좁은 속성 패널에서도 깨지지 않도록 미리보기와 선택 버튼만 둡니다.
    private static Control CreateColorEditor()
    {
        var editor = new Panel { Height = 30, Margin = Padding.Empty };
        var preview = new Panel
        {
            BackColor = Color.FromArgb(35, 103, 180),
            Dock = DockStyle.Left,
            Width = 30,
            BorderStyle = BorderStyle.FixedSingle,
            Margin = new Padding(0, 3, 5, 3)
        };
        var choose = new Label
        {
            Text = "색상 선택",
            Dock = DockStyle.Fill,
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.White,
            ForeColor = Color.FromArgb(43, 79, 115),
            TextAlign = ContentAlignment.MiddleCenter,
            Cursor = Cursors.Hand,
            Margin = new Padding(5, 1, 0, 1)
        };
        choose.Click += (_, _) =>
        {
            using var dialog = new ColorDialog { Color = preview.BackColor, FullOpen = true };
            if (dialog.ShowDialog() != DialogResult.OK) return;
            preview.BackColor = dialog.Color;
        };
        editor.Controls.Add(choose);
        editor.Controls.Add(preview);
        return editor;
    }

    private sealed record LineTypeItem(string Name, DashStyle Style)
    {
        public override string ToString() => Name;
    }

    private static Button CreateActionButton(string text, bool primary = false) => new()
    {
        Text = text,
        Width = 124,
        Height = 34,
        Margin = new Padding(0, 10, 8, 0),
        FlatStyle = FlatStyle.Flat,
        FlatAppearance = { BorderSize = 1, BorderColor = primary ? Color.FromArgb(35, 103, 180) : Color.FromArgb(174, 190, 207) },
        BackColor = primary ? Color.FromArgb(35, 103, 180) : Color.White,
        ForeColor = primary ? Color.White : Color.FromArgb(43, 79, 115),
        Cursor = Cursors.Hand
    };

    // 두 개의 실행 버튼이 줄바꿈되지 않도록 같은 폭의 한 행으로 고정합니다.
    private static Control CreateActionButtonRow(string leftText, string rightText)
    {
        var row = new TableLayoutPanel
        {
            Width = 258,
            Height = 44,
            ColumnCount = 2,
            Padding = new Padding(0, 10, 0, 0),
            Margin = Padding.Empty
        };
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        var left = CreateActionButton(leftText);
        left.Dock = DockStyle.Fill;
        left.Margin = new Padding(0, 0, 4, 0);
        var right = CreateActionButton(rightText, primary: true);
        right.Dock = DockStyle.Fill;
        right.Margin = new Padding(4, 0, 0, 0);
        row.Controls.Add(left, 0, 0);
        row.Controls.Add(right, 1, 0);
        return row;
    }

    // 오른쪽 패널 폭에 맞춰 한 노선을 선명하게 확인하는 비교표입니다.
    private static Control CreateRouteComparisonTable()
    {
        var table = new TableLayoutPanel
        {
            Width = 258,
            Height = 302,
            Margin = new Padding(0, 2, 0, 6),
            ColumnCount = 2,
            RowCount = 9,
            BackColor = Color.White,
            CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
        };
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 180));
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
        for (int row = 1; row < 9; row++) table.RowStyles.Add(new RowStyle(SizeType.Absolute, 33));

        Label CreateCell(string text, bool header = false) => new()
        {
            Text = text,
            Dock = DockStyle.Fill,
            Margin = Padding.Empty,
            Padding = new Padding(5, 0, 5, 0),
            BackColor = header ? Color.FromArgb(232, 240, 249) : Color.White,
            ForeColor = header ? Color.FromArgb(36, 72, 108) : Color.FromArgb(52, 65, 77),
            Font = new Font("맑은 고딕", 8F, header ? FontStyle.Bold : FontStyle.Regular),
            TextAlign = header ? ContentAlignment.MiddleCenter : ContentAlignment.MiddleLeft
        };
        table.Controls.Add(CreateCell("비교 항목", header: true), 0, 0);
        table.Controls.Add(CreateCell("산정값", header: true), 1, 0);

        int tableRow = 1;
        foreach (string item in new[]
        {
            "총 길이 (km)",
            "급경사지 통과 (구간 수 / 연장 m)",
            "하천 횡단 횟수 (회)",
            "보호구역 침범 여부 (침범 없음 / 침범 m²)",
            "절토량 (m³)",
            "성토량 (m³)",
            "절/성토 비용 (백만원)",
            "예상 공사비 (백만원)"
        })
        {
            table.Controls.Add(CreateCell(item), 0, tableRow);
            table.Controls.Add(CreateCell("-"), 1, tableRow);
            tableRow++;
        }
        return table;
    }

    private Control BuildPropertiesPage()
    {
        Panel page = CreateScrollablePage("속성", "선택한 객체의 기본·스타일 정보를 편집합니다.");
        FlowLayoutPanel content = GetPageContent(page);
        content.Controls.Add(CreateSectionTitle("선택 객체"));
        content.Controls.Add(CreateField("객체 이름", new ComboBox { Text = "선택한 객체 없음", DropDownStyle = ComboBoxStyle.DropDown, Items = { "선택한 객체 없음" } }));
        content.Controls.Add(CreateField("객체 유형", ReadOnlyText("선택 대기")));
        

        content.Controls.Add(CreateSectionTitle("객체 스타일"));
        content.Controls.Add(CreateField("색상", CreateColorEditor()));
        content.Controls.Add(CreateField("선종류", CreateLineTypeCombo()));
        content.Controls.Add(CreateField("선굵기 (mm)", CreateSliderEditor(5, 200, 25, 2, "선굵기 mm")));
        content.Controls.Add(CreateField("투명도 (%)", CreateSliderEditor(0, 100, 0, 0, "투명도 %")));
        var toggles = new FlowLayoutPanel { Width = 258, Height = 30, Margin = new Padding(0, 2, 0, 2) };
        
        content.Controls.Add(toggles);

        content.Controls.Add(CreateSectionTitle("객체 정보"));
        foreach ((string label, string value) in new[] { ("객체 ID", "-"), ("원본 파일", "-"), ("정점 / 연장", "-"), ("최종 수정", "-") })
            content.Controls.Add(CreateField(label, ReadOnlyText(value)));
        content.Controls.Add(CreateActionButtonRow("되돌리기", "적용"));
        return page;
    }

    private static TextBox ReadOnlyText(string text) => new() { Text = text, ReadOnly = true, BackColor = Color.FromArgb(246, 248, 250) };

    private Control BuildWorkPage()
    {
        Panel page = CreateScrollablePage("작업", "현재 도구의 선택 옵션과 빠른 설정입니다.");
        FlowLayoutPanel content = GetPageContent(page);
        

        AddWorkSelectionControl(content, CreateSectionTitle("선택 / 레이어"));
        selectionInfoLabel = new Label
        {
            Width = 258,
            Height = 62,
            Text = "DXF 선택 모드에서 선 또는 폴리선을 클릭하면\n객체 유형·레이어·정점 정보가 표시됩니다.",
            Padding = new Padding(8),
            ForeColor = Color.FromArgb(78, 95, 111),
            BackColor = Color.FromArgb(247, 250, 253),
            Margin = new Padding(0, 2, 0, 4)
        };
        AddWorkSelectionControl(content, selectionInfoLabel);
        selectionLayerHost = new Panel
        {
            Width = 258,
            Height = 400,
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.White,
            Margin = new Padding(0, 0, 0, 4)
        };
        AddWorkSelectionControl(content, selectionLayerHost);

        // 기본 작업 화면은 도구를 고르기 전의 빈 영역만 보여 줍니다.
        workDefaultPlaceholder = new Panel
        {
            Width = 258,
            Height = 180,
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.White,
            Margin = new Padding(0, 4, 0, 4)
        };
        content.Controls.Add(workDefaultPlaceholder);

        AddWorkQuickSettingControl(content, CreateSectionTitle("빠른 설정"));
        AddWorkQuickSettingControl(content, CreateField("기준 프리셋", CreateCombo("기본 임도", "급경사지", "환경보전형", "경제성 우선")));
        AddWorkQuickSettingControl(content, CreateField("최대 종단경사", new TextBox { Text = "12.0 %" }));
        AddWorkQuickSettingControl(content, CreateField("최소 곡선반경", new TextBox { Text = "20 m" }));
        AddWorkQuickSettingControl(content, CreateField("수계 회피거리", new TextBox { Text = "20 m" }));
        AddWorkQuickSettingControl(content, CreateField("우선 목표", CreateCombo("환경 영향 최소", "연장 최소", "토공 최소", "균형형")));
        var detailButton = CreateActionButton("상세 설정 열기", primary: true);
        detailButton.Width = 258;
        content.Controls.Add(detailButton);
        return page;
    }

    private void AddWorkSelectionControl(FlowLayoutPanel content, Control control)
    {
        control.Visible = false;
        workSelectionControls.Add(control);
        content.Controls.Add(control);
    }

    private void AddWorkQuickSettingControl(FlowLayoutPanel content, Control control)
    {
        control.Visible = false;
        workQuickSettingControls.Add(control);
        content.Controls.Add(control);
    }

    // DXF 선택 도구를 켤 때만 기존 선택·레이어와 그 빠른 설정을 표시합니다.
    private void SetWorkSelectionModeVisible(bool visible)
    {
        foreach (Control control in workSelectionControls) control.Visible = visible;
        foreach (Control control in workQuickSettingControls) control.Visible = visible;
        if (workDefaultPlaceholder is not null) workDefaultPlaceholder.Visible = !visible;
    }

    // 기존 DXF 선택 코드가 전달하는 정보를 작업 패널의 선택 요약 영역에 표시합니다.
    private void UpdateRightPanelSelectionInfo(DxfSelectionInfo? selection)
    {
        if (selectionInfoLabel is null) return;
        selectionInfoLabel.Text = selection is null
            ? "객체를 선택하지 않았습니다.\n선 또는 폴리선 가까이를 클릭하세요."
            : $"종류: {selection.EntityType}\n레이어: {selection.LayerName}\n{selection.Detail}";
    }

    private Control BuildReviewPage()
    {
        Panel page = CreateScrollablePage("검토", "설계 기준과 금지·주의 구역 저촉을 확인합니다.");
        FlowLayoutPanel content = GetPageContent(page);
        var summary = new TableLayoutPanel { Width = 258, Height = 68, ColumnCount = 3, Margin = new Padding(0, 0, 0, 7) };
        foreach ((string text, Color color) in new[] { ("부적합\n0", Color.FromArgb(201, 64, 64)), ("주의\n0", Color.FromArgb(207, 142, 29)), ("통과\n0", Color.FromArgb(40, 137, 87)) })
        {
            int index = summary.Controls.Count;
            summary.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33F));
            summary.Controls.Add(new Label { Text = text, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("맑은 고딕", 10F, FontStyle.Bold), ForeColor = color, BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(2) }, index, 0);
        }
        content.Controls.Add(summary);
        content.Controls.Add(CreateField("검토 범위", CreateCombo("전체 프로젝트", "현재 노선", "선택 객체", "현재 구간")));
        content.Controls.Add(CreateField("표시", CreateCombo("미조치 항목", "전체 항목", "오류만", "주의만")));
        content.Controls.Add(CreateSectionTitle("검토 항목"));
        content.Controls.Add(new Label { Width = 258, Height = 74, Text = "아직 검토 결과가 없습니다.\n검토 실행 후 금지구역·수계·경사·곡선반경 기준을 확인합니다.", Padding = new Padding(8), ForeColor = Color.FromArgb(96, 111, 125), BackColor = Color.FromArgb(247, 250, 253) });
        var runButton = CreateActionButton("검토 실행", primary: true);
        runButton.Width = 258;
        content.Controls.Add(runButton);
        return page;
    }

    private Control BuildReportPage()
    {
        Panel page = CreateScrollablePage("보고서", "설계 결과와 검토 내용을 산출물로 구성합니다.");
        FlowLayoutPanel content = GetPageContent(page);
        content.Controls.Add(CreateSectionTitle("노선 대안 비교"));
        content.Controls.Add(CreateField("표시 노선", CreateCombo("노선 1", "노선 2", "노선 3", "노선 4", "노선 5")));
        content.Controls.Add(CreateRouteComparisonTable());
        
        content.Controls.Add(CreateSectionTitle("출력 설정"));
        content.Controls.Add(CreateField("출력 형식", CreateCombo("PDF 보고서", "Excel 수량표", "CAD 도면", "이미지")));
        content.Controls.Add(CreateField("대상 범위", CreateCombo("전체 노선", "현재 노선", "선택 구간")));
        content.Controls.Add(CreateField("도면 축척", CreateCombo("1:1,000", "1:2,500", "1:5,000")));
        content.Controls.Add(CreateActionButtonRow("미리보기", "내보내기"));
        return page;
    }

    private sealed class RightPanelTabButton : Control
    {
        private bool selected;
        public void SetSelected(bool value)
        {
            selected = value;
            Invalidate();
        }

        public RightPanelTabButton()
        {
            Cursor = Cursors.Hand;
            Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            ForeColor = Color.FromArgb(54, 78, 101);
            BackColor = Color.FromArgb(232, 240, 249);
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var background = new SolidBrush(selected ? Color.White : BackColor);
            e.Graphics.FillRectangle(background, ClientRectangle);
            using var border = new Pen(Color.FromArgb(184, 201, 217));
            e.Graphics.DrawRectangle(border, 0, 0, Width - 1, Height - 1);
            if (selected)
            {
                using var indicator = new SolidBrush(Color.FromArgb(37, 105, 180));
                e.Graphics.FillRectangle(indicator, 0, 0, 3, Height);
            }
            string verticalText = string.Join(Environment.NewLine, Text.ToCharArray());
            TextRenderer.DrawText(e.Graphics, verticalText, Font, ClientRectangle, selected ? Color.FromArgb(25, 82, 145) : ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }
    }
}
