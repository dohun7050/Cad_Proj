﻿namespace cad;

public partial class Form1
{
    // 상단 탭 전환 및 EPSG 변경 시 하단 상태 표시줄을 갱신합니다.
    private void UpdateBottomStatus(int index = 0)
    {
        string epsgText = epsg?.ToString() ?? "미지정";
        statusLabel.Text = $"좌표계 EPSG: {epsgText}   |   축척 1:5,000";
    }
}
