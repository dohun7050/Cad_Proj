﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace cad;

// 프로그램에서 추가한 점과 폴리라인을 저장하는 전용 .cad 문서의 최상위 구조입니다.
internal sealed class CadDrawingFile
{
    // 새로 저장하는 .cad 파일의 공식 형식 표식입니다.
    public string Format { get; set; } = "IMDO-CAD";
    public int Version { get; set; } = 1;
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public string? SourceFile { get; set; }
    public CadPointStyle PointStyle { get; set; } = new();
    public CadLineStyle LineStyle { get; set; } = new();
    public List<CadPointData> Points { get; set; } = new();
    public List<CadPolylineData> Polylines { get; set; } = new();
}

// .cad 파일에 기록할 점의 표시 색상과 화면 크기를 정의합니다.
internal sealed class CadPointStyle
{
    public string Color { get; set; } = "#FF145EBE";
    public float Size { get; set; } = 8F;
}

// .cad 파일에 기록할 선의 표시 색상과 화면 두께를 정의합니다.
internal sealed class CadLineStyle
{
    public string Color { get; set; } = "#FFDC372D";
    public float Width { get; set; } = 2F;
}

// 폴리라인에서 참조할 수 있도록 고유 ID와 실제 X/Y 위치를 보관합니다.
internal sealed class CadPointData
{
    public string Id { get; set; } = string.Empty;
    public double X { get; set; }
    public double Y { get; set; }
}

// 선을 좌표 복사본이 아닌 점 ID 포인터의 순서로 표현하고 길이 정보를 함께 보관합니다.
internal sealed class CadPolylineData
{
    public string Id { get; set; } = "L0001";
    public List<string> PointIds { get; set; } = new();
    public List<CadLineSegmentData> Segments { get; set; } = new();
    public double TotalLength { get; set; }
}

// 폴리라인의 각 구간이 참조하는 두 점과 해당 구간의 계산 길이를 보관합니다.
internal sealed class CadLineSegmentData
{
    public string StartPointId { get; set; } = string.Empty;
    public string EndPointId { get; set; } = string.Empty;
    public double Length { get; set; }
}

// 아래의 DXF·TXT 화면은 그대로 보이게 하면서 .cad 점과 선만 위에 표시하는 투명 편집 레이어입니다.
internal sealed class TransparentCadOverlay : Control
{
    private const int WmNcHitTest = 0x0084;
    private const int HtTransparent = -1;

    // 점/선 모드를 시작한 순간의 DXF·TXT 화면을 오버레이 배경으로 보관합니다.
    private Bitmap? backgroundSnapshot;

    // 점/선 모드일 때만 오버레이가 마우스 입력을 받도록 나타냅니다.
    [System.ComponentModel.Browsable(false)]
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal bool InputEnabled { get; set; }

    // 아래 문서가 없을 때 투명 배경 대신 기본 CAD 작업 배경을 사용할지 나타냅니다.
    [System.ComponentModel.Browsable(false)]
    [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
    internal bool UseSolidCadBackground { get; set; }

    // 투명 배경과 이중 버퍼링을 활성화하여 아래 문서를 가리지 않고 점과 선만 그립니다.
    internal TransparentCadOverlay()
    {
        SetStyle(ControlStyles.UserPaint
            | ControlStyles.AllPaintingInWmPaint
            | ControlStyles.OptimizedDoubleBuffer
            | ControlStyles.SupportsTransparentBackColor
            | ControlStyles.ResizeRedraw, true);
        BackColor = Color.Transparent;
    }

    // 아래 DockPanel의 현재 화면을 비트맵으로 캡처해 점·선 아래에 표시할 배경으로 준비합니다.
    internal void CaptureBackground(Control source)
    {
        backgroundSnapshot?.Dispose();
        backgroundSnapshot = null;
        if (source.ClientSize.Width <= 0 || source.ClientSize.Height <= 0) return;

        var snapshot = new Bitmap(source.ClientSize.Width, source.ClientSize.Height);
        try
        {
            source.DrawToBitmap(snapshot, source.ClientRectangle);
            backgroundSnapshot = snapshot;
        }
        catch
        {
            snapshot.Dispose();
        }
    }

    // 점/선 모드를 끝낼 때 캡처했던 문서 화면 비트맵을 해제합니다.
    internal void ClearBackground()
    {
        backgroundSnapshot?.Dispose();
        backgroundSnapshot = null;
    }

    // WinForms 형제 컨트롤 투명화 대신 캡처한 DXF·TXT 화면을 배경에 그려 검은 화면을 방지합니다.
    protected override void OnPaintBackground(PaintEventArgs e)
    {
        if (UseSolidCadBackground)
            e.Graphics.Clear(Color.FromArgb(43, 61, 88));
        else if (backgroundSnapshot is not null)
            e.Graphics.DrawImage(backgroundSnapshot, ClientRectangle);
        else
            base.OnPaintBackground(e);
    }

    // 점/선 모드가 아닐 때는 마우스 판정을 아래 DockPanel 문서로 통과시킵니다.
    protected override void WndProc(ref Message message)
    {
        if (message.Msg == WmNcHitTest && !InputEnabled)
        {
            message.Result = new IntPtr(HtTransparent);
            return;
        }

        base.WndProc(ref message);
    }
}

public partial class Form1
{
    // .cad 불러오기 전후의 공용 작업 상태를 Ctrl+Z/Ctrl+Y로 복원하기 위해 보관합니다.
    private sealed record CadWorkspaceState(
        List<DxfEditPoint> Points,
        DxfEditStyle Style,
        string? FilePath,
        bool FitToView);

    // 화면에는 별도 문서로 보이지 않지만 프로젝트 전체에서 공유하는 .cad 점 목록입니다.
    private readonly List<DxfEditPoint> cadWorkspacePoints = new();

    // 공용 CAD 작업공간에서 실행 취소한 점을 다시 입력하기 위해 보관합니다.
    private readonly Stack<DxfEditPoint> cadWorkspaceRedoPoints = new();

    // 공용 CAD 작업공간의 현재 점·선 색상과 크기입니다.
    private DxfEditStyle cadWorkspaceStyle = DxfEditStyle.Default;

    // 현재 공용 CAD 작업공간을 불러온 .cad 파일의 전체 경로입니다.
    private string? currentCadFilePath;

    // .cad에서 불러온 실제 대좌표를 파란 작업공간 안에 자동 맞춤 표시할지 나타냅니다.
    private bool isCadWorkspaceFitToView;

    // 마지막 .cad 불러오기 직전 상태입니다.
    private CadWorkspaceState? cadImportUndoState;

    // Ctrl+Z로 취소한 .cad 불러오기 결과를 Ctrl+Y로 다시 적용하기 위한 상태입니다.
    private CadWorkspaceState? cadImportRedoState;

    // 불러온 점 이후에 새로 입력한 점부터 먼저 취소하기 위한 기준 점 개수입니다.
    private int cadImportedBaselinePointCount;

    // 중앙 CAD의 로컬 좌표가 첫 DXF의 실제 X·Y 좌표계로 변환되었는지 나타냅니다.
    private bool cadWorkspaceUsesDxfCoordinates;

    // DXF·TXT 문서보다 위에서 점과 선만 표시하는 투명 CAD 오버레이를 보관합니다.
    private Control? cadWorkspaceSurface;

    // 중앙 내용 패널의 DockPanel 위에 투명 CAD 오버레이를 생성합니다.
    private void ConfigureCadWorkspace()
    {
        var overlay = new TransparentCadOverlay
        {
            Dock = DockStyle.Fill,
            UseSolidCadBackground = true,
            Visible = true
        };
        overlay.MouseDown += CadWorkspace_MouseDown;
        overlay.Paint += CadWorkspace_Paint;
        contentPanel.Controls.Add(overlay);
        contentPanel.Controls.SetChildIndex(overlay, 0);
        overlay.BringToFront();
        cadWorkspaceSurface = overlay;
        dockPanel1.Visible = true;
        dockPanel1.ActiveDocumentChanged += CadWorkspace_ActiveDocumentChanged;
    }

    // DXF 창을 닫거나 문서를 전환할 때 CAD 점·선의 표시 위치와 입력 대상을 현재 화면에 맞게 자동 갱신합니다.
    private void CadWorkspace_ActiveDocumentChanged(object? sender, EventArgs e)
    {
        if (dockPanel1.ActiveDocument is Docment_Dxf)
        {
            ApplyCadWorkspaceToActiveDxf();
            return;
        }

        pointLineEditDocument?.SetCadPointAddedCallback(null);
        pointLineEditDocument = null;

        if (dockPanel1.ActiveDocument is null)
        {
            if (isPointLineModeActive)
                SetCadOverlayInputMode(true);
            else
                ShowStandaloneCadWorkspace();
        }
        else
        {
            SetCadOverlayInputMode(false);
        }
    }

    // 점/선 모드일 때만 투명 오버레이가 클릭을 받고 평상시에는 아래 문서로 클릭을 통과시킵니다.
    private void SetCadOverlayInputMode(bool enabled)
    {
        if (cadWorkspaceSurface is not TransparentCadOverlay overlay) return;

        if (enabled)
        {
            overlay.UseSolidCadBackground = dockPanel1.ActiveDocument is null;
            if (!overlay.UseSolidCadBackground) overlay.CaptureBackground(dockPanel1);
        }
        else
        {
            overlay.ClearBackground();
            overlay.UseSolidCadBackground = dockPanel1.ActiveDocument is null;
        }

        overlay.InputEnabled = enabled;
        overlay.Cursor = enabled ? Cursors.Cross : Cursors.Default;
        overlay.Visible = enabled || dockPanel1.ActiveDocument is null;
        if (overlay.Visible) overlay.BringToFront();
        overlay.Invalidate();
    }

    // DXF 문서가 없어도 .cad 파일의 점과 선을 파란 독립 작업 화면에 즉시 표시합니다.
    private void ShowStandaloneCadWorkspace()
    {
        if (cadWorkspaceSurface is not TransparentCadOverlay overlay) return;

        overlay.ClearBackground();
        overlay.UseSolidCadBackground = true;
        overlay.InputEnabled = false;
        overlay.Cursor = Cursors.Default;
        overlay.Visible = true;
        if (overlay.Visible) overlay.BringToFront();
        overlay.Invalidate();
    }

    // .cad 파일을 연 직후에는 점·선을 즉시 보여 주되 클릭은 아래 문서로 통과시키는 읽기 전용 미리보기를 표시합니다.
    private void ShowCadWorkspacePreview()
    {
        if (cadWorkspaceSurface is not TransparentCadOverlay overlay) return;

        overlay.CaptureBackground(dockPanel1);
        overlay.InputEnabled = false;
        overlay.Cursor = Cursors.Default;
        overlay.Visible = cadWorkspacePoints.Count > 0;
        if (overlay.Visible) overlay.BringToFront();
        overlay.Invalidate();
    }

    // 열려 있는 문서가 없고 점/선 모드일 때 파란 배경 클릭 좌표를 공용 CAD 모델에 추가합니다.
    private void CadWorkspace_MouseDown(object? sender, MouseEventArgs e)
    {
        if (!isPointLineModeActive
            || e.Button != MouseButtons.Left)
            return;

        AddCadWorkspacePoint(FromCadWorkspaceScreen(e.Location, GetCadWorkspaceSize()));
    }

    // 아래 문서의 종류와 관계없이 투명 오버레이 위에 공용 CAD 모델의 선과 점만 표시합니다.
    private void CadWorkspace_Paint(object? sender, PaintEventArgs e)
    {
        if (cadWorkspacePoints.Count == 0) return;
        e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        using var linePen = new Pen(cadWorkspaceStyle.LineColor, cadWorkspaceStyle.LineWidth);
        using var pointBrush = new SolidBrush(cadWorkspaceStyle.PointColor);

        for (int index = 1; index < cadWorkspacePoints.Count; index++)
        {
            e.Graphics.DrawLine(linePen,
                ToCadWorkspaceScreen(cadWorkspacePoints[index - 1], GetCadWorkspaceSize()),
                ToCadWorkspaceScreen(cadWorkspacePoints[index], GetCadWorkspaceSize()));
        }
        foreach (DxfEditPoint point in cadWorkspacePoints)
        {
            PointF screen = ToCadWorkspaceScreen(point, GetCadWorkspaceSize());
            float radius = Math.Max(1F, cadWorkspaceStyle.PointSize / 2F);
            e.Graphics.FillEllipse(pointBrush, screen.X - radius, screen.Y - radius, radius * 2F, radius * 2F);
        }
    }

    // DXF·LAS·DEM 또는 파란 배경에서 입력한 점을 공용 .cad 작업 모델에 추가합니다.
    private void AddCadWorkspacePoint(DxfEditPoint point)
    {
        cadWorkspacePoints.Add(point);
        cadWorkspaceRedoPoints.Clear();
        if (pointLineEditDocument is null)
            SetCadOverlayInputMode(isPointLineModeActive);
        InvalidateCadWorkspace();
    }

    // 첫 DXF를 불러올 때 중앙 화면의 로컬 좌표를 DXF 실제 범위에 비례 배치하여 하나의 X·Y 좌표계로 맞춥니다.
    private void SynchronizeCadWorkspaceWithDxfBounds(double minX, double minY, double maxX, double maxY)
    {
        if (cadWorkspaceUsesDxfCoordinates) return;

        Size canvasSize = GetCadWorkspaceSize();
        double canvasWidth = Math.Max(canvasSize.Width, 1);
        double canvasHeight = Math.Max(canvasSize.Height, 1);
        double dxfWidth = Math.Max(maxX - minX, 1D);
        double dxfHeight = Math.Max(maxY - minY, 1D);

        for (int index = 0; index < cadWorkspacePoints.Count; index++)
        {
            DxfEditPoint point = cadWorkspacePoints[index];
            double synchronizedX = minX + point.X / canvasWidth * dxfWidth;
            double synchronizedY = minY + point.Y / canvasHeight * dxfHeight;
            cadWorkspacePoints[index] = new DxfEditPoint(synchronizedX, synchronizedY);
        }

        cadWorkspaceRedoPoints.Clear();
        cadWorkspaceUsesDxfCoordinates = true;
        isCadWorkspaceFitToView = true;
        InvalidateCadWorkspace();
    }

    // 공용 CAD 작업 모델에서 마지막 점과 그 점으로 이어진 마지막 선분을 제거합니다.
    private bool UndoCadWorkspacePoint()
    {
        if (cadWorkspacePoints.Count == 0) return false;
        int lastIndex = cadWorkspacePoints.Count - 1;
        cadWorkspaceRedoPoints.Push(cadWorkspacePoints[lastIndex]);
        cadWorkspacePoints.RemoveAt(lastIndex);
        InvalidateCadWorkspace();
        return true;
    }

    // 공용 CAD 작업 모델에서 마지막으로 취소한 점과 연결선을 복원합니다.
    private bool RedoCadWorkspacePoint()
    {
        if (cadWorkspaceRedoPoints.Count == 0) return false;
        cadWorkspacePoints.Add(cadWorkspaceRedoPoints.Pop());
        InvalidateCadWorkspace();
        return true;
    }

    // 현재 공용 CAD 점·스타일·파일 경로·화면 맞춤 상태를 독립 복사본으로 만듭니다.
    private CadWorkspaceState CaptureCadWorkspaceState()
    {
        return new CadWorkspaceState(
            cadWorkspacePoints.ToList(),
            cadWorkspaceStyle,
            currentCadFilePath,
            isCadWorkspaceFitToView);
    }

    // 저장해 둔 CAD 작업 상태를 메모리와 활성 DXF 또는 독립 CAD 화면에 함께 복원합니다.
    private void RestoreCadWorkspaceState(CadWorkspaceState state)
    {
        cadWorkspacePoints.Clear();
        cadWorkspacePoints.AddRange(state.Points);
        cadWorkspaceRedoPoints.Clear();
        cadWorkspaceStyle = state.Style;
        pointLineEditStyle = state.Style;
        currentCadFilePath = state.FilePath;
        isCadWorkspaceFitToView = state.FitToView;

        if (dockPanel1.ActiveDocument is Docment_Dxf dxfDocument)
        {
            SetCadOverlayInputMode(false);
            dxfDocument.LoadCadWorkspacePoints(cadWorkspacePoints, cadWorkspaceStyle);
        }
        else if (cadWorkspacePoints.Count > 0)
        {
            ShowStandaloneCadWorkspace();
        }
        else
        {
            SetCadOverlayInputMode(false);
        }

        InvalidateCadWorkspace();
    }

    // 새 점이 남아 있지 않을 때 마지막 .cad 불러오기 전체를 한 번의 작업으로 취소합니다.
    private bool UndoCadImport()
    {
        if (cadImportUndoState is null || cadWorkspacePoints.Count > cadImportedBaselinePointCount)
            return false;

        CadWorkspaceState restoreState = cadImportUndoState;
        cadImportRedoState = CaptureCadWorkspaceState();
        cadImportUndoState = null;
        RestoreCadWorkspaceState(restoreState);
        cadImportedBaselinePointCount = cadWorkspacePoints.Count;
        return true;
    }

    // Ctrl+Z로 취소했던 .cad 불러오기 결과를 다시 적용합니다.
    private bool RedoCadImport()
    {
        if (cadImportRedoState is null) return false;

        CadWorkspaceState restoreState = cadImportRedoState;
        cadImportUndoState = CaptureCadWorkspaceState();
        cadImportRedoState = null;
        RestoreCadWorkspaceState(restoreState);
        cadImportedBaselinePointCount = cadWorkspacePoints.Count;
        return true;
    }

    // 독립 CAD 화면에서는 새 점을 먼저 취소하고 없으면 파일 불러오기 자체를 취소합니다.
    private bool UndoCadWorkspaceOrImport()
    {
        if (cadWorkspacePoints.Count > cadImportedBaselinePointCount)
            return UndoCadWorkspacePoint();

        return UndoCadImport() || UndoCadWorkspacePoint();
    }

    // 독립 CAD 화면에서는 취소한 점을 먼저 복원하고 없으면 파일 불러오기를 다시 적용합니다.
    private bool RedoCadWorkspaceOrImport()
    {
        return RedoCadWorkspacePoint() || RedoCadImport();
    }

    // 설정 팝업에서 바뀐 점·선 스타일을 공용 CAD 작업공간에도 반영합니다.
    private void UpdateCadWorkspaceStyle(DxfEditStyle style)
    {
        cadWorkspaceStyle = style;
        InvalidateCadWorkspace();
    }

    // 공용 CAD 좌표를 직접 화면 좌표로 표시하거나 불러온 전체 범위에 맞춰 파란 배경 안으로 변환합니다.
    private PointF ToCadWorkspaceScreen(DxfEditPoint point, Size workspaceSize)
    {
        if (!isCadWorkspaceFitToView || cadWorkspacePoints.Count == 0)
            return new PointF((float)point.X, workspaceSize.Height - (float)point.Y);

        GetCadWorkspaceTransform(workspaceSize, out double minX, out double minY, out double scale, out double offsetX, out double offsetY);
        float x = (float)((point.X - minX) * scale + offsetX);
        float y = (float)(workspaceSize.Height - ((point.Y - minY) * scale + offsetY));
        return new PointF(x, y);
    }

    // 자동 맞춤 화면에서 클릭한 픽셀 위치를 원래 .cad 좌표로 역변환합니다.
    private DxfEditPoint FromCadWorkspaceScreen(Point screenPoint, Size workspaceSize)
    {
        if (!isCadWorkspaceFitToView || cadWorkspacePoints.Count == 0)
            return new DxfEditPoint(screenPoint.X, workspaceSize.Height - screenPoint.Y);

        GetCadWorkspaceTransform(workspaceSize, out double minX, out double minY, out double scale, out double offsetX, out double offsetY);
        double x = (screenPoint.X - offsetX) / scale + minX;
        double y = (workspaceSize.Height - screenPoint.Y - offsetY) / scale + minY;
        return new DxfEditPoint(x, y);
    }

    // 실제 CAD 그리기 표면의 현재 크기를 반환합니다.
    private Size GetCadWorkspaceSize() => cadWorkspaceSurface?.ClientSize ?? dockPanel1.ClientSize;

    // DockPanel이 아니라 실제 DocumentWindow를 다시 그리도록 요청합니다.
    private void InvalidateCadWorkspace()
    {
        cadWorkspaceSurface?.Invalidate();
        if (dockPanel1.ActiveDocument is CadDocument cadDocument)
            cadDocument.RefreshCanvas();
        dockPanel1.Invalidate();
    }

    // 현재 공용 점의 전체 범위와 화면 크기를 이용해 여백·배율·가운데 정렬 위치를 계산합니다.
    private void GetCadWorkspaceTransform(
        Size workspaceSize,
        out double minX,
        out double minY,
        out double scale,
        out double offsetX,
        out double offsetY)
    {
        const double margin = 40D;
        minX = cadWorkspacePoints.Min(point => point.X);
        minY = cadWorkspacePoints.Min(point => point.Y);
        double maxX = cadWorkspacePoints.Max(point => point.X);
        double maxY = cadWorkspacePoints.Max(point => point.Y);
        double width = Math.Max(maxX - minX, 1D);
        double height = Math.Max(maxY - minY, 1D);
        double availableWidth = Math.Max(workspaceSize.Width - margin * 2D, 1D);
        double availableHeight = Math.Max(workspaceSize.Height - margin * 2D, 1D);
        scale = Math.Min(availableWidth / width, availableHeight / height);
        offsetX = margin + (availableWidth - width * scale) / 2D;
        offsetY = margin + (availableHeight - height * scale) / 2D;
    }

    // 파일 탭의 내보내기 버튼에서 활성 문서의 편집 점·선을 .cad 파일로 저장합니다.
    private void menuExport_Click(object? sender, EventArgs e)
    {
        CadDrawingFile drawing = CadDrawingFactory.Create(cadWorkspacePoints, cadWorkspaceStyle, null);
        if (drawing.Points.Count == 0)
        {
            MessageBox.Show("내보낼 점과 선이 없습니다.", "CAD 내보내기", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var dialog = new SaveFileDialog
        {
            Title = "CAD 작업 파일 내보내기",
            Filter = "임도 CAD 작업 파일 (*.cad)|*.cad",
            DefaultExt = "cad",
            AddExtension = true,
            FileName = CreateCadFileName(drawing.SourceFile)
        };

        if (dialog.ShowDialog() != DialogResult.OK) return;

        try
        {
            SaveCadDrawing(dialog.FileName, drawing);
            statusLabel.Text = $"CAD 내보내기 완료: {dialog.FileName}";
        }
        catch (Exception exception)
        {
            MessageBox.Show(
                "CAD 파일을 저장하지 못했습니다.\r\n" + exception.Message,
                "CAD 내보내기 오류",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    // 원본 파일 이름을 기준으로 저장 대화상자의 기본 .cad 파일 이름을 생성합니다.
    private static string CreateCadFileName(string? sourceFile)
    {
        string name = string.IsNullOrWhiteSpace(sourceFile)
            ? "새_CAD_작업"
            : Path.GetFileNameWithoutExtension(sourceFile);
        return name + ".cad";
    }

    // .cad 데이터 구조를 읽기 쉬운 UTF-8 JSON으로 직렬화하여 디스크에 저장합니다.
    private static void SaveCadDrawing(string path, CadDrawingFile drawing)
    {
        var options = new JsonSerializerOptions
        {
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
        string json = JsonSerializer.Serialize(drawing, options);
        File.WriteAllText(path, json, new System.Text.UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
    }

    // 메모리에 불러온 .cad 점·선을 현재 활성 DXF의 자체 편집 레이어에 즉시 적용합니다.
    private void ApplyCadWorkspaceToActiveDxf()
    {
        if (dockPanel1.ActiveDocument is Docment_Dxf dxfDocument && cadWorkspacePoints.Count > 0)
        {
            SetCadOverlayInputMode(false);
            dxfDocument.LoadCadWorkspacePoints(cadWorkspacePoints, cadWorkspaceStyle);
        }
    }

    // .cad JSON을 검증한 뒤 점 포인터 순서와 표시 스타일을 공용 CAD 작업 모델에 복원합니다.
    private void OpenCadWorkspace(string path)
    {
        try
        {
            string json = File.ReadAllText(path);
            CadDrawingFile? drawing = JsonSerializer.Deserialize<CadDrawingFile>(json);
            ValidateCadDrawing(drawing);

            List<DxfEditPoint> loadedPoints = GetOrderedCadPoints(drawing!);
            DxfEditStyle loadedStyle = new(
                ParseCadColor(drawing!.PointStyle.Color),
                drawing.PointStyle.Size,
                ParseCadColor(drawing.LineStyle.Color),
                drawing.LineStyle.Width);

            cadImportUndoState = CaptureCadWorkspaceState();
            cadImportRedoState = null;
            cadWorkspacePoints.Clear();
            cadWorkspacePoints.AddRange(loadedPoints);
            cadWorkspaceRedoPoints.Clear();
            cadWorkspaceStyle = loadedStyle;
            pointLineEditStyle = loadedStyle;
            currentCadFilePath = Path.GetFullPath(path);
            isCadWorkspaceFitToView = true;
            cadWorkspaceUsesDxfCoordinates = true;
            cadImportedBaselinePointCount = cadWorkspacePoints.Count;
            SetCadOverlayInputMode(false);
            if (dockPanel1.ActiveDocument is Docment_Dxf)
                ApplyCadWorkspaceToActiveDxf();
            else
                ShowStandaloneCadWorkspace();
            InvalidateCadWorkspace();
            statusLabel.Text = $"CAD 작업 파일 불러오기 완료: {currentCadFilePath}";
        }
        catch (Exception exception)
        {
            MessageBox.Show(
                "CAD 작업 파일을 불러오지 못했습니다.\r\n" + exception.Message,
                "CAD 불러오기 오류",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    // 역직렬화한 파일이 우리 프로그램의 지원 가능한 .cad 형식인지 확인합니다.
    private static void ValidateCadDrawing(CadDrawingFile? drawing)
    {
        if (drawing is null) throw new InvalidDataException("파일 내용이 비어 있거나 올바른 JSON이 아닙니다.");
        // 과거 버전이 잘못 기록한 Forest-CAD도 읽을 수 있게 호환합니다.
        // 새로 내보내는 파일은 CadDrawingFile의 기본값에 따라 IMDO-CAD로 통일됩니다.
        bool isSupportedFormat = string.Equals(drawing.Format, "IMDO-CAD", StringComparison.Ordinal)
            || string.Equals(drawing.Format, "Forest-CAD", StringComparison.Ordinal);
        if (!isSupportedFormat)
            throw new InvalidDataException("지원하지 않는 CAD 파일 형식입니다: " + drawing.Format);
        if (drawing.Version != 1)
            throw new InvalidDataException($"지원하지 않는 CAD 파일 버전입니다: {drawing.Version}");
        if (drawing.Points is null || drawing.PointStyle is null || drawing.LineStyle is null)
            throw new InvalidDataException("점 또는 표시 스타일 정보가 없습니다.");
        if (drawing.PointStyle.Size <= 0F || drawing.LineStyle.Width <= 0F)
            throw new InvalidDataException("점 크기와 선 두께는 0보다 커야 합니다.");
    }

    // 폴리라인의 PointIds 포인터 순서를 우선 사용하고 없으면 Points 저장 순서로 좌표를 복원합니다.
    private static List<DxfEditPoint> GetOrderedCadPoints(CadDrawingFile drawing)
    {
        var pointsById = drawing.Points.ToDictionary(point => point.Id, StringComparer.OrdinalIgnoreCase);
        List<string>? pointIds = drawing.Polylines?
            .FirstOrDefault(polyline => polyline.PointIds is { Count: > 0 })?
            .PointIds;

        if (pointIds is null)
            return drawing.Points.Select(point => new DxfEditPoint(point.X, point.Y)).ToList();

        var result = new List<DxfEditPoint>(pointIds.Count);
        foreach (string pointId in pointIds)
        {
            if (!pointsById.TryGetValue(pointId, out CadPointData? point))
                throw new InvalidDataException($"폴리라인이 존재하지 않는 점을 참조합니다: {pointId}");
            result.Add(new DxfEditPoint(point.X, point.Y));
        }
        return result;
    }

    // .cad의 #AARRGGBB 또는 #RRGGBB 색상 문자열을 System.Drawing.Color로 변환합니다.
    private static Color ParseCadColor(string value)
    {
        string hex = value.Trim().TrimStart('#');
        if (hex.Length == 6) hex = "FF" + hex;
        if (hex.Length != 8 || !uint.TryParse(hex, System.Globalization.NumberStyles.HexNumber, null, out uint argb))
            throw new InvalidDataException($"올바르지 않은 색상 값입니다: {value}");
        return Color.FromArgb(unchecked((int)argb));
    }
}

internal static class CadDrawingFactory
{
    // 현재 점 목록과 표시 스타일을 점 ID 참조 방식의 단일 폴리라인 .cad 데이터로 변환합니다.
    internal static CadDrawingFile Create(IReadOnlyList<DxfEditPoint> points, DxfEditStyle style, string? sourceFile)
    {
        var drawing = new CadDrawingFile
        {
            SourceFile = sourceFile,
            PointStyle = new CadPointStyle { Color = ToArgbHex(style.PointColor), Size = style.PointSize },
            LineStyle = new CadLineStyle { Color = ToArgbHex(style.LineColor), Width = style.LineWidth }
        };

        for (int index = 0; index < points.Count; index++)
        {
            DxfEditPoint point = points[index];
            drawing.Points.Add(new CadPointData
            {
                Id = CreatePointId(index),
                X = point.X,
                Y = point.Y
            });
        }

        if (drawing.Points.Count >= 2)
        {
            var polyline = new CadPolylineData();
            polyline.PointIds.AddRange(drawing.Points.Select(point => point.Id));
            for (int index = 1; index < drawing.Points.Count; index++)
            {
                CadPointData start = drawing.Points[index - 1];
                CadPointData end = drawing.Points[index];
                double length = Math.Sqrt(Math.Pow(end.X - start.X, 2D) + Math.Pow(end.Y - start.Y, 2D));
                polyline.Segments.Add(new CadLineSegmentData
                {
                    StartPointId = start.Id,
                    EndPointId = end.Id,
                    Length = length
                });
                polyline.TotalLength += length;
            }
            drawing.Polylines.Add(polyline);
        }

        return drawing;
    }

    // 점 배열의 순번을 고정 폭의 사람이 읽기 쉬운 포인터 ID로 변환합니다.
    private static string CreatePointId(int zeroBasedIndex) => $"P{zeroBasedIndex + 1:0000}";

    // 투명도를 포함한 System.Drawing.Color를 #AARRGGBB 문자열로 변환합니다.
    private static string ToArgbHex(Color color) => $"#{color.ToArgb():X8}";
}
