﻿using WeifenLuo.WinFormsUI.Docking;
using IxMilia.Dxf;
using IxMilia.Dxf.Entities;
namespace cad;

public partial class Form1 : Form
{
    // 메인 화면의 컨트롤, 도킹 테마, 탐색기와 리본 메뉴를 초기화하는 생성자입니다.
    internal int? epsg = null;
    public Form1()
    {
        InitializeComponent();
        dockPanel1.Theme = new VS2015BlueTheme();
        ConfigureCadWorkspace();
        OpenInitialCadDocument();
        LoadFileTree();
        ApplyRibbonStyle();
        ConfigureBottomToolbar();
        minimizeButton.BringToFront();
        maximizeButton.BringToFront();
        closeButton.BringToFront();
        ShowMenu(0);
        ConfigureRightPanel();
    
        // 처음 실행할 때도 작업표시줄을 침범하지 않는 사용자 정의 최대화를 적용합니다.
        MaximizeButton_Click(this, EventArgs.Empty);
    }
    internal void SetEpsg(int? i)
    {
        epsg = i;
        UpdateBottomStatus();
    }
    // 프로그램을 열면 항상 빈 .cad 도면 탭부터 시작합니다.
    // 실제 파일은 사용자가 저장 위치를 정할 때만 생성됩니다.
    private void OpenInitialCadDocument()
    {
        var document = new CadDocument(cadWorkspacePoints, cadWorkspaceStyle);
        document.Show(dockPanel1, DockState.Document);
        document.Activate();
    }

    private void menuSetting_Click(object sender, EventArgs e)
    {
        var form = new Setting(this);
        form.Show(this);
    }
    
}
