using ForestRoad.Cad;
namespace OkseongRoad.Terrain;
public record Station(double Distance, double X, double Y, double Z);
public record RoadRoute(List<CadPoint> Vertices, List<Station> Stations, double Length, double MaximumAngle)
{
    public double MaximumGrade=>LongitudinalGrade.ToPercent(MaximumAngle);
}
public static partial class RoutePlanner
{
    // Primitive integer offsets provide 176 headings, including shallow contour-following
    // directions unavailable on an eight-neighbor grid. Each entire edge is validated.
    public static readonly IReadOnlyList<(int X,int Y)> Directions =
        (from y in Enumerable.Range(-8,17)
         from x in Enumerable.Range(-8,17)
         where (x!=0||y!=0) && Gcd(Math.Abs(x),Math.Abs(y))==1
         orderby x*x+y*y
         select (x,y)).ToArray();
    static int Gcd(int a,int b){while(b!=0){(a,b)=(b,a%b);}return a;}
    public static double Distance(CadPoint a,CadPoint b)=>Math.Sqrt((a.X-b.X)*(a.X-b.X)+(a.Y-b.Y)*(a.Y-b.Y));
    // Allocation-free equivalent of TerrainGrid.At, used ONLY by route slope validation.
    // DEM building, public coordinate interpolation and file processing remain unchanged.
    static bool TrySearchElevation(TerrainGrid grid,double x,double y,out double z)=>grid.TryElevation(x,y,out z);
    public static bool Allowed(TerrainGrid grid,CadPoint a,CadPoint b,double angle,out double peak)
    {
        peak=0; double length=Distance(a,b);
        if(!double.IsFinite(angle)||angle<=0||angle>=90||!double.IsFinite(length))return false;
        if(length<1e-9) return Math.Abs(a.Z-b.Z)<1e-7;
        // Bilinear terrain is quadratic along a straight segment. Check analytic derivatives
        // within each crossed grid cell, including both sides of grid boundaries.
        var cuts=new List<double>{0,1};
        if(Math.Abs(b.X-a.X)>1e-9)
            for(int i=(int)Math.Ceiling((Math.Min(a.X,b.X)-grid.X)/grid.Step);i<=(int)Math.Floor((Math.Max(a.X,b.X)-grid.X)/grid.Step);i++)
            {double t=(grid.X+i*grid.Step-a.X)/(b.X-a.X);if(t>1e-9 && t<1-1e-9)cuts.Add(t);}
        if(Math.Abs(b.Y-a.Y)>1e-9)
            for(int j=(int)Math.Ceiling((Math.Min(a.Y,b.Y)-grid.Y)/grid.Step);j<=(int)Math.Floor((Math.Max(a.Y,b.Y)-grid.Y)/grid.Step);j++)
            {double t=(grid.Y+j*grid.Step-a.Y)/(b.Y-a.Y);if(t>1e-9 && t<1-1e-9)cuts.Add(t);}
        cuts.Sort();
        for(int k=1;k<cuts.Count;k++)
        {
            double t0=cuts[k-1],t1=cuts[k],dt=t1-t0;if(dt<1e-10)continue;
            bool Height(double t,out double z)=>TrySearchElevation(grid,a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t,out z);
            if(!Height(t0,out double z0)||!Height((t0+t1)/2,out double zm)||!Height(t1,out double z1))return false;
            double dz=z1-z0, curvature=z1+z0-2*zm;
            double slope=Math.Max(Math.Abs(dz-2*curvature),Math.Abs(dz+2*curvature))/(length*dt);
            peak=Math.Max(peak,Math.Atan(slope)*180/Math.PI);
            if(peak>angle+1e-7)return false;
        }
        return true;
    }
    public static RoadRoute FindByGrade(TerrainGrid grid,CadPoint start,CadPoint end,double maximumGrade=10,CancellationToken ct=default)
        =>Find(grid,start,end,LongitudinalGrade.ToAngle(maximumGrade),20,ct);
    public static List<RoadRoute> FindCandidatesByGrade(TerrainGrid grid,CadPoint start,CadPoint end,double maximumGrade=10,int count=5,CancellationToken ct=default,IProgress<int>? progress=null,RouteQualityOptions? quality=null)
        =>FindCandidates(grid,start,end,LongitudinalGrade.ToAngle(maximumGrade),count,ct,progress,quality);
    // Angular entry points remain for smoothing and existing callers; defaults also represent 10%.
    public static RoadRoute Find(TerrainGrid grid,CadPoint start,CadPoint end,double angle=LongitudinalGrade.DefaultAngle,double stationSpacing=20,CancellationToken ct=default)
        =>FindCore(grid,start,end,angle,stationSpacing,ct,null,null);
    static RoadRoute FindCore(TerrainGrid grid,CadPoint start,CadPoint end,double angle,double stationSpacing,CancellationToken ct,double[]? penalties,Dictionary<long,bool>? edges,double turnWeight=0)
    {
        ct.ThrowIfCancellationRequested();
        if(!double.IsFinite(angle)||angle<=0||angle>=90||!double.IsFinite(stationSpacing)||stationSpacing<=0)throw new ArgumentException("경사 기준과 측점 간격을 확인하세요.");
        if(!double.IsFinite(start.X)||!double.IsFinite(start.Y)||!double.IsFinite(end.X)||!double.IsFinite(end.Y))throw new ArgumentException("시작점·종점 좌표가 유효하지 않습니다.");
        start=grid.At(start.X,start.Y)??throw new InvalidOperationException("시작점에 유효한 지형 고도가 없습니다.");
        end=grid.At(end.X,end.Y)??throw new InvalidOperationException("종점에 유효한 지형 고도가 없습니다.");
        if(Distance(start,end)<0.001)throw new InvalidOperationException("시작점과 종점을 다르게 지정하세요.");
        string limit=$"{LongitudinalGrade.ToPercent(angle):0.###}%";
        // A feasible straight edge is globally shortest in horizontal distance.
        if((penalties is null||!penalties.Any(p=>p>0))&&Allowed(grid,start,end,angle,out _))
            return RoadGeometry.Create(grid,[start,end],angle,ct,stationSpacing)!;

        // Integrate corridor penalties along the entire edge. Endpoint-only costs let long
        // grid edges jump across penalized cells, rewarding repeated zigzags at their borders.
        double TravelCost(CadPoint a,CadPoint b)
        {
            double distance=Distance(a,b);
            if(penalties is null)return distance;
            int samples=Math.Max(1,(int)Math.Ceiling(distance/(grid.Step/2)));
            double sum=0;
            for(int i=0;i<samples;i++)
            {
                ct.ThrowIfCancellationRequested();double t=(i+.5)/samples;
                int x=Math.Clamp((int)Math.Round((a.X+(b.X-a.X)*t-grid.X)/grid.Step),0,grid.Width-1);
                int y=Math.Clamp((int)Math.Round((a.Y+(b.Y-a.Y)*t-grid.Y)/grid.Step),0,grid.Height-1);
                sum+=penalties[y*grid.Width+x];
            }
            return distance*(1+sum/samples);
        }
        var travelCosts=new Dictionary<long,double>();
        var neighbors=new Dictionary<int,SearchEdge[]>();int cachedNeighbors=0;
        // Arrival headings change turn costs, but terrain-valid outgoing edges do not.
        // Keep the same direction order and objective; bound the additional cache memory.
        SearchEdge[] Neighbors(int id,CadPoint a)
        {
            if(neighbors.TryGetValue(id,out var cached))return cached;
            var usable=new List<SearchEdge>();int ax=id%grid.Width,ay=id/grid.Width;
            for(int direction=0;direction<Directions.Count;direction++)
            {
                ct.ThrowIfCancellationRequested();var (dx,dy)=Directions[direction];int x=ax+dx,y=ay+dy;
                if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;
                int next=y*grid.Width+x;if(!double.IsFinite(grid.Values[next]))continue;
                var b=grid.Node(next);long edge=((long)Math.Min(id,next)<<32)|(uint)Math.Max(id,next);
                bool permitted;
                if(edges is null)permitted=Allowed(grid,a,b,angle,out _);
                else if(!edges.TryGetValue(edge,out permitted))
                {permitted=Allowed(grid,a,b,angle,out _);if(edges.Count<1_000_000)edges[edge]=permitted;}
                if(!permitted)continue;
                if(!travelCosts.TryGetValue(edge,out double travel))
                {travel=TravelCost(a,b);if(travelCosts.Count<1_000_000)travelCosts[edge]=travel;}
                usable.Add(new(next,direction,b,travel,Distance(b,end)));
            }
            var result=usable.ToArray();
            if(cachedNeighbors+result.Length<=1_000_000)
            {neighbors[id]=result;cachedNeighbors+=result.Length;}
            return result;
        }

        // A turn cost depends on arrival direction. Never merge different headings into one node.
        int stride=turnWeight>0?Directions.Count+1:1,initialHeading=stride-1;
        var states=new Dictionary<long,(double Cost,long Parent)>();
        var queue=new PriorityQueue<(long Key,double Cost),double>();
        void Enqueue(int id,int heading,double cost,long parent,double? heuristic=null)
        {
            long key=(long)id*stride+heading;
            if(states.TryGetValue(key,out var old)&&cost>=old.Cost-1e-9)return;
            states[key]=(cost,parent);queue.Enqueue((key,cost),cost+(heuristic??Distance(grid.Node(id),end)));
        }
        CadPoint Previous(int id,int heading)
        {
            if(stride==1||heading==initialHeading)return start;
            var d=Directions[heading];var p=grid.Node(id);return new(p.X-d.X*grid.Step,p.Y-d.Y*grid.Step,0);
        }
        // With no turn cost each node expands only once: avoid eagerly testing edges
        // whose destination already has a better cost. Heading-state mode benefits from caching.
        IEnumerable<SearchEdge> SimpleNeighbors(int id,CadPoint a,double currentCost)
        {
            int ax=id%grid.Width,ay=id/grid.Width;
            for(int direction=0;direction<Directions.Count;direction++)
            {
                ct.ThrowIfCancellationRequested();var (dx,dy)=Directions[direction];int x=ax+dx,y=ay+dy;
                if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;
                int next=y*grid.Width+x;if(!double.IsFinite(grid.Values[next]))continue;
                var b=grid.Node(next);long edge=((long)Math.Min(id,next)<<32)|(uint)Math.Max(id,next);
                if(!travelCosts.TryGetValue(edge,out double travel))
                {travel=TravelCost(a,b);if(travelCosts.Count<1_000_000)travelCosts[edge]=travel;}
                if(states.TryGetValue(next,out var old)&&currentCost+travel>=old.Cost-1e-9)continue;
                bool permitted;
                if(edges is null)permitted=Allowed(grid,a,b,angle,out _);
                else if(!edges.TryGetValue(edge,out permitted))
                {permitted=Allowed(grid,a,b,angle,out _);if(edges.Count<1_000_000)edges[edge]=permitted;}
                if(permitted)yield return new(next,direction,b,travel,Distance(b,end));
            }
        }
        int sx=(int)Math.Round((start.X-grid.X)/grid.Step),sy=(int)Math.Round((start.Y-grid.Y)/grid.Step);
        for(int dy=-6;dy<=6;dy++)for(int dx=-6;dx<=6;dx++)
        {
            ct.ThrowIfCancellationRequested();int x=sx+dx,y=sy+dy;
            if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;
            int id=y*grid.Width+x;var p=grid.Node(id);
            if(double.IsFinite(p.Z)&&Distance(start,p)<=grid.Step*6&&Allowed(grid,start,p,angle,out _))
                Enqueue(id,initialHeading,TravelCost(start,p),-1);
        }
        if(queue.Count==0)throw new SearchUnavailableException($"시작점에서 {limit} 이하로 지형 격자에 진입할 수 없습니다. 위치·고도 결측·좌표 단위를 확인하세요.");
        var goals=new Dictionary<int,double>();
        int ex=(int)Math.Round((end.X-grid.X)/grid.Step),ey=(int)Math.Round((end.Y-grid.Y)/grid.Step);
        for(int dy=-6;dy<=6;dy++)for(int dx=-6;dx<=6;dx++)
        {
            ct.ThrowIfCancellationRequested();int x=ex+dx,y=ey+dy;
            if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;
            int id=y*grid.Width+x;var p=grid.Node(id);double distance=Distance(p,end);
            if(double.IsFinite(p.Z)&&distance<=grid.Step*6&&Allowed(grid,p,end,angle,out _))
                goals[id]=TravelCost(p,end);
        }
        if(goals.Count==0)throw new SearchUnavailableException($"종점에 {limit} 이하로 연결할 수 없습니다. 위치·고도 결측·좌표 단위를 확인하세요.");
        long last=-1;double best=double.PositiveInfinity;
        while(queue.TryDequeue(out var item,out double priority))
        {
            ct.ThrowIfCancellationRequested();if(priority>=best-1e-9)break;
            if(item.Cost>states[item.Key].Cost+1e-9)continue;
            int id=(int)(item.Key/stride),heading=(int)(item.Key%stride);var a=grid.Node(id);
            var previous=Previous(id,heading);
            if(goals.TryGetValue(id,out double final))
            {
                double turn=turnWeight>0?RoadGeometry.Turn(previous,a,end):0;
                double candidate=item.Cost+final+turnWeight*turn*turn;
                if(candidate<best){best=candidate;last=item.Key;}
            }
            foreach(var neighbor in stride==1?SimpleNeighbors(id,a,item.Cost):Neighbors(id,a))
            {
                ct.ThrowIfCancellationRequested();
                int next=neighbor.Id,direction=neighbor.Direction;var b=neighbor.Point;
                double turn=turnWeight>0?RoadGeometry.Turn(previous,a,b):0;
                double candidate=item.Cost+neighbor.Travel+turnWeight*turn*turn;
                long nextKey=(long)next*stride+(stride==1?0:direction);
                if(states.TryGetValue(nextKey,out var old)&&candidate>=old.Cost-1e-9)continue;
                Enqueue(next,stride==1?0:direction,candidate,item.Key,neighbor.Heuristic);
            }
        }
        if(last<0)throw new SearchUnavailableException($"최대 종단경사율 {limit} 이하인 연결 노선을 찾지 못했습니다. 도달 상태 {states.Count:N0}개. 경사 기준을 자동 완화하지 않습니다. 고도 결측 및 시작·종점 위치를 확인하세요. 이는 현재 DEM과 탐색 방향에서의 결과입니다.");
        var route=new List<CadPoint>{end};
        for(long key=last;key>=0;key=states[key].Parent)route.Add(grid.Node((int)(key/stride)));
        route.Add(start);route.Reverse();
        return RoadGeometry.Create(grid,route,angle,ct,stationSpacing)??throw new InvalidOperationException("최종 노선의 지형 고도·경사 검증에 실패했습니다.");
    }
    /// <summary>Search alternative corridors by penalizing previously searched routes.
    /// All candidates retain the same endpoints and full-edge slope/NoData validation.</summary>
    public static List<RoadRoute> FindCandidates(TerrainGrid grid,CadPoint start,CadPoint end,double angle=LongitudinalGrade.DefaultAngle,int count=5,CancellationToken ct=default,IProgress<int>? progress=null,RouteQualityOptions? quality=null)
    {
        ct.ThrowIfCancellationRequested();using var session=new CandidateSearchSession(grid,start,end,angle,quality);
        return session.GenerateTo(count,ct,progress);
    }
    readonly record struct SearchEdge(int Id,int Direction,CadPoint Point,double Travel,double Heuristic);
    // Only a genuine search failure triggers refinement; cancellation and invalid input propagate.
    sealed class SearchUnavailableException(string message):InvalidOperationException(message);
    public static bool DistinctCorridor(RoadRoute a,RoadRoute b,double tolerance,CancellationToken ct=default)
    {
        double different=0,total=0;var index=new CorridorIndex(b.Vertices,tolerance,ct);
        foreach(var (p,q) in a.Vertices.Zip(a.Vertices.Skip(1)))
        {
            ct.ThrowIfCancellationRequested();double length=Distance(p,q);int pieces=Math.Max(1,(int)Math.Ceiling(length/Math.Max(1,tolerance)));
            for(int i=0;i<pieces;i++)
            {
                double t=(i+0.5)/pieces;var point=new CadPoint(p.X+(q.X-p.X)*t,p.Y+(q.Y-p.Y)*t,0);
                total+=length/pieces;if(!index.Near(point.X,point.Y))different+=length/pieces;
            }
        }
        return total>0&&different/total>=0.15;
    }

}


