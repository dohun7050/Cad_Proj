using ForestRoad.Cad;
namespace OkseongRoad.Terrain;

public static partial class RoutePlanner
{
    public static CandidateSearchSession CreateCandidateSessionByGrade(TerrainGrid grid,CadPoint start,CadPoint end,double maximumGrade=10,RouteQualityOptions? quality=null)
        =>new(grid,start,end,LongitudinalGrade.ToAngle(maximumGrade),quality);

    public sealed class CandidateSearchSession:IDisposable
    {
        readonly TerrainGrid original;readonly CadPoint start,end;readonly double angle;readonly RouteQualityOptions? quality;
        readonly Dictionary<RoadRoute,RoadRoute?> verifiedCache=new(ReferenceEqualityComparer.Instance);
        Level? level;int factor=1;bool disposed,exhausted;SearchUnavailableException? failure;
        public int RequestedCount {get;private set;}
        public bool IsExhausted=>exhausted;
        public int GridFactor=>factor;
        internal CandidateSearchSession(TerrainGrid grid,CadPoint start,CadPoint end,double angle,RouteQualityOptions? quality)
        {
            if(!double.IsFinite(angle)||angle<=0||angle>=90)throw new ArgumentException("경사 기준을 확인하세요.");
            if(!double.IsFinite(start.X)||!double.IsFinite(start.Y)||!double.IsFinite(end.X)||!double.IsFinite(end.Y))throw new ArgumentException("시작점·종점 좌표가 유효하지 않습니다.");
            this.start=grid.At(start.X,start.Y)??throw new InvalidOperationException("시작점에 유효한 지형 고도가 없습니다.");
            this.end=grid.At(end.X,end.Y)??throw new InvalidOperationException("종점에 유효한 지형 고도가 없습니다.");
            if(Distance(this.start,this.end)<0.001)throw new InvalidOperationException("시작점과 종점을 다르게 지정하세요.");
            if(quality is not null&&(!double.IsFinite(quality.MinimumRadius)||quality.MinimumRadius<0||!double.IsFinite(quality.TurnWeight)||quality.TurnWeight<0))throw new ArgumentException("회전반경과 굴곡 비용은 유한한 0 이상의 값이어야 합니다.");
            original=grid;this.angle=angle;this.quality=quality;
        }
        public List<RoadRoute> GenerateTo(int targetCount,CancellationToken ct=default,IProgress<int>? progress=null)
        {
            ObjectDisposedException.ThrowIf(disposed,this);
            if(targetCount<1||targetCount>5)throw new ArgumentOutOfRangeException(nameof(targetCount));
            while(true)
            {
                ct.ThrowIfCancellationRequested();
                level??=BuildLevel(ct,progress);
                try
                {
                    while(true)
                    {
                        while(!level.Done&&level.Accepted.Count<targetCount)level.Advance(start,end,angle,quality,ct,progress);
                        var result=Snapshot(level.Accepted.Count,ct);
                        if(result.Count>=targetCount||level.Done&&result.Count>0)
                        {RequestedCount=targetCount;exhausted=level.Done&&result.Count<=targetCount;return result.Take(targetCount).ToList();}
                        if(level.Done){failure=new SearchUnavailableException("원본 DEM에서 경사·회전반경을 만족하는 후보가 없습니다.");break;}
                        // A post-verification rejection isn't a reason to abandon this level.
                        // Keep the batch search history and try its remaining attempts first.
                        level.Advance(start,end,angle,quality,ct,progress);
                    }
                }
                catch(SearchUnavailableException error){failure=error;}
                int next=factor*2;
                long width=(long)(original.Width-1)*next+1,height=(long)(original.Height-1)*next+1;
                if(next>8||width*height>1_000_000||original.Step/next<0.25)
                    throw new InvalidOperationException($"176개 방향 및 최대 {factor}배 격자 탐색으로 조건을 만족하는 노선을 찾지 못했습니다. 최대 종단경사율 {LongitudinalGrade.ToPercent(angle):0.###}%와 회전반경 조건을 자동 완화하지 않습니다.\n"+failure.Message,failure);
                factor=next;level=null;verifiedCache.Clear();
            }
        }
        Level BuildLevel(CancellationToken ct,IProgress<int>? progress)
        {
            if(factor==1)return new(original);
            progress?.Report(-factor);int width=(original.Width-1)*factor+1,height=(original.Height-1)*factor+1;
            var values=new double[width*height];
            for(int y=0;y<height;y++)for(int x=0;x<width;x++)
            {ct.ThrowIfCancellationRequested();values[y*width+x]=original.TryElevation(original.X+x*original.Step/factor,original.Y+y*original.Step/factor,out double z)?z:double.NaN;}
            return new(new TerrainGrid(original.X,original.Y,original.Step/factor,width,height,values));
        }
        List<RoadRoute> Snapshot(int target,CancellationToken ct)
        {
            var accepted=level!.Accepted.Take(target).ToList();if(accepted.Count==0)return [];
            double shortest=accepted.Min(r=>r.Length);var result=new List<RoadRoute>();
            foreach(var candidate in accepted.Where(r=>r.Length<=shortest*1.5+level.Grid.Step*2).OrderBy(r=>r.Length))
            {
                ct.ThrowIfCancellationRequested();
                if(!verifiedCache.TryGetValue(candidate,out var road))
                {
                    road=RoadGeometry.Create(original,candidate.Vertices,angle,ct,20);
                    if(road is not null&&quality is {MinimumRadius:>0}&&RoadGeometry.Metrics(road).MinimumRadius<quality.MinimumRadius*(1-1e-4))road=null;
                    ct.ThrowIfCancellationRequested();verifiedCache[candidate]=road;
                }
                if(road is not null&&result.All(old=>DistinctCorridor(road,old,original.Step*2,ct)))result.Add(road);
            }
            return result.OrderBy(r=>r.Length).ToList();
        }
        public void Dispose(){disposed=true;level=null;verifiedCache.Clear();}
        sealed class Level(TerrainGrid grid)
        {
            public TerrainGrid Grid {get;}=grid;
            public List<RoadRoute> Accepted {get;}=[];
            readonly List<RoadRoute> explored=[];
            readonly Dictionary<long,bool> edges=[];
            readonly double[] penalties=new double[grid.Values.Length];
            int penalized,attempts;
            public bool Done {get;private set;}
            public void Advance(CadPoint start,CadPoint end,double angle,RouteQualityOptions? quality,CancellationToken ct,IProgress<int>? progress)
            {
                progress?.Report(attempts+1);
                while(penalized<explored.Count)
                {
                    var marked=new HashSet<int>();var old=explored[penalized];
                    foreach(var (a,b) in old.Vertices.Zip(old.Vertices.Skip(1)))
                    {
                        int steps=Math.Max(1,(int)Math.Ceiling(Distance(a,b)/Grid.Step));
                        for(int k=0;k<=steps;k++)
                        {
                            ct.ThrowIfCancellationRequested();double t=(double)k/steps;
                            var p=new CadPoint(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t,0);
                            if(Distance(p,start)<Grid.Step*5||Distance(p,end)<Grid.Step*5)continue;
                            int x=(int)Math.Round((p.X-Grid.X)/Grid.Step),y=(int)Math.Round((p.Y-Grid.Y)/Grid.Step);
                            for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++)
                            {int u=x+dx,v=y+dy;if(u>=0&&v>=0&&u<Grid.Width&&v<Grid.Height&&dx*dx+dy*dy<=9)marked.Add(v*Grid.Width+u);}
                        }
                    }
                    ct.ThrowIfCancellationRequested();foreach(int id in marked)penalties[id]+=2;penalized++;
                }
                RoadRoute raw;
                try{raw=FindCore(Grid,start,end,angle,20,ct,penalties,edges,quality?.TurnWeight??0);}
                catch(SearchUnavailableException) when(Accepted.Count>0){Done=true;return;}
                var candidate=RoadGeometry.Smooth(Grid,raw,angle,quality?.MinimumRadius??0,ct);
                bool keep=candidate is not null&&!(Accepted.Count>0&&candidate.Length>Accepted.Min(r=>r.Length)*1.5+Grid.Step*2)&&Accepted.All(r=>DistinctCorridor(candidate!,r,Grid.Step*2,ct));
                ct.ThrowIfCancellationRequested();explored.Add(raw);attempts++;if(keep)Accepted.Add(candidate!);
                Done=attempts>=12||Accepted.Count>=5;
            }
        }
    }
}
