using OkseongRoad.Terrain;
namespace OkseongRoad.App;

public sealed partial class MainForm
{
    readonly NumericUpDown additionalCount=new(){Minimum=1,Maximum=4,Value=4,Width=85};
    Button? additionalButton;
    RoutePlanner.CandidateSearchSession? candidateSession;
    int displayedSessionTarget;
    void RefreshAdditionalControls()
    {
        if(additionalButton is null)return;
        bool finished=candidateSession is {IsExhausted:true}&&candidateSession.RequestedCount<=displayedSessionTarget;
        int remaining=5-map.Candidates.Count;bool enabled=operation is null&&map.Candidates.Count>0&&remaining>0&&candidateSession is not null&&!finished;
        additionalCount.Maximum=Math.Max(1,Math.Min(4,remaining));
        additionalCount.Enabled=additionalButton.Enabled=enabled;
        additionalButton.Text=remaining<=0||finished?$"탐색 완료 · 후보 {map.Candidates.Count}개":"추가 후보 생성";
    }
    async Task AddCandidates()
    {
        if(operation is not null)return;
        if(grid is null||map.Candidates.Count==0||candidateSession is null)throw new InvalidOperationException("첫 후보를 먼저 생성하세요.");
        int requested=(int)additionalCount.Value;
        if(requested<1||requested>Math.Min(4,5-map.Candidates.Count))throw new InvalidOperationException("총 탐색 목표는 최대 5개입니다.");
        var terrain=grid;var existing=map.Candidates.ToArray();var start=existing[0].Vertices[0];var end=existing[0].Vertices[^1];
        var hiddenBefore=map.HiddenCandidates.ToHashSet();
        var removedBefore=removedDisplayLayers.Where(k=>k.StartsWith("route:")).Select(k=>int.TryParse(k.AsSpan(6),out int i)?i:-1).ToHashSet();
        var session=candidateSession;int target=Math.Min(5,existing.Length+requested);var selectedRoad=map.Route;
        await Run("추가 후보 탐색 중…",async ct=>
        {
            var progress=new Progress<int>(attempt=>{if(operation?.Token==ct&&!ct.IsCancellationRequested)status.Text=attempt<0?$"격자 {-attempt}배 세분화 재탐색 중":$"기존 탐색 이어서 진행 · 탐색 {attempt}/12 · 목표 {target}개";});
            var watch=System.Diagnostics.Stopwatch.StartNew();
            var roads=await Task.Run(()=>session.GenerateTo(target,ct,progress),ct);
            ct.ThrowIfCancellationRequested();if(IsDisposed)return;
            var prepared=await Task.Run(()=>CalculateRouteResults(terrain,roads,ct),ct);
            ct.ThrowIfCancellationRequested();if(IsDisposed)return;
            // Commit only after all calculations succeed: cancellation keeps the visible routes.
            int selection=Math.Max(0,roads.FindIndex(r=>ReferenceEquals(r,selectedRoad)));
            displayedSessionTarget=target;routeResults=prepared;map.Candidates=roads;map.SelectedCandidate=selection;map.Route=roads[selection];
            removedDisplayLayers.RemoveWhere(k=>k.StartsWith("route:"));
            for(int i=0;i<roads.Count;i++)if(removedBefore.Contains(Array.FindIndex(existing,r=>ReferenceEquals(r,roads[i]))))removedDisplayLayers.Add("route:"+i);
            RefreshLayers();bool savedChanging=changing;changing=true;
            try
            {
                for(int i=0;i<layers.Items.Count;i++)if(layers.Items[i] is DisplayLayer{Kind:"route"} layer)
                {
                    int old=Array.FindIndex(existing,r=>ReferenceEquals(r,roads[layer.RouteIndex]));
                    layers.SetItemChecked(i,old<0||!hiddenBefore.Contains(old));
                }
            }
            finally{changing=savedChanging;}
            ApplyDisplay();syncing=true;
            try
            {
                candidates.Items.Clear();
                for(int i=0;i<roads.Count;i++)candidates.Items.Add($"{i+1}  {roads[i].Length:N0}m / {roads[i].MaximumGrade:F2}%");
                candidates.HorizontalExtent=candidates.Items.Cast<object>().Select(i=>TextRenderer.MeasureText(i.ToString(),candidates.Font).Width+36).DefaultIfEmpty(0).Max();
                candidates.SelectedIndex=selection;
            }
            finally{syncing=false;}
            UpdateRouteResult();map.Invalidate();RefreshAdditionalControls();
            int added=roads.Count(r=>!existing.Any(old=>ReferenceEquals(old,r)));
            status.Text=$"추가 요청 {requested}개 → 새 유효 후보 {added}개 · 총 {roads.Count}개 / 최대 5개 · {watch.Elapsed.TotalSeconds:F2}초"+(roads.Count<target?" · 일괄 생성과 같은 최종 검증으로 후보 수가 줄었습니다.":"");
        });
    }
}
