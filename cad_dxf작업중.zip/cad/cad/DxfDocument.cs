﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using IxMilia.Dxf;
using WeifenLuo.WinFormsUI.Docking;
using System.Windows.Forms;

namespace cad
{
    public class DxfDocument : DockContent
    {
        // 불러온 DXF 도면 전체 데이터
        private readonly DxfFile dxf;
        // 도면을 그릴 중앙 캔버스
        
        public DxfDocument(DxfFile dxf, string title)
        {
            this.dxf = dxf;
            Text = title;
        }
    }
    public class DrawingPanel : Panel
    {
        
    }
}
