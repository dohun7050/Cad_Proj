using IxMilia.Dxf;
using IxMilia.Dxf.Entities;
using cad.Importers;
using cad.Models;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;
public partial class Form1 {

    private readonly List<ProjectLayer> l = new();
    private void ConfigureFileTab() { 
        ConfigureRibbonButton(menuFile,"new_project.png"); 
        ConfigureRibbonButton(menuOpen,"open.png"); 
        ConfigureRibbonButton(menuSave,"save.png"); 
        ConfigureRibbonButton(menuExport,"export.png"); 
    }
    private void menuOpen_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog
        {
            Title = "파일 열기",
            Filter = "모든 파일 (*.*)|*.*",
            InitialDirectory = projectRoot,
            Multiselect = false
        };

        if(dialog.ShowDialog() != DialogResult.OK)
        {
            return;
        }
        var importer = new DxfImporter();
        ImportResult result = importer.Import(dialog.FileName);
        if (!result.IsSuccess)
        {
            MessageBox.Show( result.Message, "DXF 불러오기 오류", MessageBoxButtons.OK, MessageBoxIcon.Error );
            return;
        }
        if (result.Layer is not null)
        {
            l.Add(result.Layer);
        }
        // 레이어 원본 데이터가 DxfFile이면 중앙 DockPanel 탭 열기
        if (result.Layer?.SourceData is DxfFile dxfFile)
        {
            var dxfDocument = new DxfDocument(
                dxfFile,
                result.Layer.Name
            );

            dxfDocument.Show(dockPanel1, DockState.Document);
        }
    }
}
