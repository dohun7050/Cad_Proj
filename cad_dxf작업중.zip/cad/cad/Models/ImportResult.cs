namespace cad.Models;

// 파일 불러오기 작업의 성공 여부, 메시지, 생성된 레이어를 함께 전달
public class ImportResult
{
    // 파일을 정상적으로 불러왔는지 여부
    public bool IsSuccess { get; set; }

    // 성공 또는 실패 원인을 사용자에게 보여줄 메시지
    public string Message { get; set; } = "";

    // 성공했을 때 생성된 프로젝트 레이어
    // 실패하면 null입니다.
    public ProjectLayer? Layer { get; set; }
}
