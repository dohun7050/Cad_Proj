namespace cad.Models;

// DXF, SHP, LAS, DEM 등 여러 파일을 프로그램 안에서 공통된 레이어로 관리
public class ProjectLayer
{
    // TreeView와 화면에 표시할 레이어 이름
    // 예: "임도중심선.dxf"
    public string Name { get; set; } = "";

    // 원본 파일이 저장된 전체 경로
    public string FilePath { get; set; } = "";

    // 파일 종류 예: DXF, SHP, LAS, DEM
    public string FileType { get; set; } = "";

    // 화면에 레이어를 표시할지 여부
    public bool IsVisible { get; set; } = true;

    // 파일 형식별 원본 데이터를 보관
    // DXF는 DxfFile, SHP는 나중에 SHP 데이터 객체가 들어감
    public object? SourceData { get; set; }
}
