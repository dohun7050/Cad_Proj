using WeifenLuo.WinFormsUI.Docking;
using IxMilia.Dxf;
using IxMilia.Dxf.Entities;
namespace cad;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
        dockPanel1.Theme = new VS2015BlueTheme();
        LoadFileTree();
        ApplyRibbonStyle();
        minimizeButton.BringToFront();
        maximizeButton.BringToFront();
        closeButton.BringToFront();
        ShowMenu(0);
    }

    
}