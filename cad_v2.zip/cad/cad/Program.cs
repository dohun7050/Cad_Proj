namespace cad;

internal static class Program
{
    // WinForms 환경을 초기화하고 메인 폼을 실행하는 프로그램 진입점입니다.
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new Form1());
    }
}
