using System.Diagnostics;
using System.Runtime.InteropServices;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

public partial class Form1 : Form
{
    // 프로젝트 탐색기가 읽고 수정할 실제 작업 폴더입니다.
    private readonly string projectRoot = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "cad", "ProjectFiles");
    // 내부 클립보드: 복사/잘라내기 대상과 작업 종류를 기억합니다.
    private string? clipboardPath;
    private bool clipboardCut;

    public Form1()
    {
        InitializeComponent();

        // DockPanelSuite는 문서를 열기 전에 반드시 테마가 지정되어야 합니다.
        dockPanel1.Theme = new VS2015BlueTheme();

        // 실제 프로젝트 폴더를 읽고 화면을 초기화합니다.
        LoadFileTree();
        ApplyRibbonStyle();
        // 제목 표시줄 버튼이 다른 컨트롤 뒤로 가려지지 않도록 항상 앞으로 보냅니다.
        minimizeButton.BringToFront();
        maximizeButton.BringToFront();
        closeButton.BringToFront();
        ShowMenu(0);
    }

    private void LoadFileTree()
    {
        // 실제 ProjectFiles 폴더 구조를 TreeView에 다시 반영합니다.
        // BeginUpdate/EndUpdate는 노드 갱신 중 화면 깜빡임을 줄입니다.
        treeView1.BeginUpdate();
        treeView1.Nodes.Clear();
        if (!Directory.Exists(projectRoot))
        {
            treeView1.Nodes.Add(new TreeNode("ProjectFiles 폴더가 없습니다."));
            treeView1.EndUpdate();
            return;
        }
        var root = CreateNode(new DirectoryInfo(projectRoot));
        treeView1.Nodes.Add(root);
        root.Expand();
        treeView1.EndUpdate();
    }

    private TreeNode CreateNode(FileSystemInfo info)
    {
        // 폴더를 재귀적으로 순회하여 하위 폴더와 파일을 TreeNode로 변환합니다.
        // Tag에는 화면 표시명이 아닌 실제 전체 경로를 저장합니다.
        bool isDirectory = info is DirectoryInfo;
        var node = new TreeNode(info.Name) { Tag = info.FullName, ImageKey = isDirectory ? "folder" : "file", SelectedImageKey = isDirectory ? "folder" : "file" };
        if (info is DirectoryInfo directory)
        {
            try
            {
                foreach (DirectoryInfo child in directory.GetDirectories().OrderBy(x => x.Name)) node.Nodes.Add(CreateNode(child));
                foreach (FileInfo child in directory.GetFiles().OrderBy(x => x.Name)) node.Nodes.Add(CreateNode(child));
            }
            catch (UnauthorizedAccessException) { }
        }
        return node;
    }

    private string SelectedPath => treeView1.SelectedNode?.Tag as string ?? projectRoot;

    private string SelectedDirectory()
    {
        // 파일이 선택되었다면 그 파일의 상위 폴더를 작업 대상으로 사용합니다.
        string path = SelectedPath;
        return Directory.Exists(path) ? path : Path.GetDirectoryName(path) ?? projectRoot;
    }

    private void AddFolder_Click(object? sender, EventArgs e)
    {
        // 우클릭 메뉴에서 새 폴더를 생성합니다.
        string name = Prompt("새 폴더 이름", "폴더 추가");
        if (string.IsNullOrWhiteSpace(name)) return;
        Directory.CreateDirectory(Path.Combine(SelectedDirectory(), SafeName(name)));
        LoadFileTree();
    }

    private void AddFile_Click(object? sender, EventArgs e)
    {
        // 우클릭 메뉴에서 이름을 입력받아 빈 임시 파일을 생성합니다.
        string name = Prompt("새 파일 이름 (예: 노선.dxf)", "파일 추가");
        if (string.IsNullOrWhiteSpace(name)) return;
        string path = Path.Combine(SelectedDirectory(), SafeName(name));
        if (!File.Exists(path)) File.WriteAllText(path, "새 CAD 프로젝트 파일");
        LoadFileTree();
    }

    private void Delete_Click(object? sender, EventArgs e)
    {
        // 프로젝트 루트는 보호하고, 나머지 항목은 확인 후 삭제합니다.
        string path = SelectedPath;
        if (path == projectRoot || (!File.Exists(path) && !Directory.Exists(path))) return;
        if (MessageBox.Show($"'{Path.GetFileName(path)}'을(를) 삭제할까요?", "삭제 확인", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        if (File.Exists(path)) File.Delete(path); else Directory.Delete(path, true);
        LoadFileTree();
    }

    private void Move_Click(object? sender, EventArgs e)
    {
        string source = SelectedPath;
        if (source == projectRoot) return;
        using var dialog = new FolderBrowserDialog { Description = "이동할 대상 폴더 선택", InitialDirectory = projectRoot };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        MovePath(source, dialog.SelectedPath);
    }

    private void MovePath(string source, string targetDirectory)
    {
        // 파일과 폴더가 ProjectFiles 바깥으로 이동하지 않도록 제한합니다.
        if (!targetDirectory.StartsWith(projectRoot, StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("ProjectFiles 폴더 내부로만 이동할 수 있습니다.");
            return;
        }
        string destination = Path.Combine(targetDirectory, Path.GetFileName(source));
        if (File.Exists(destination) || Directory.Exists(destination)) { MessageBox.Show("대상 폴더에 같은 이름이 있습니다."); return; }
        if (File.Exists(source)) File.Move(source, destination); else if (Directory.Exists(source)) Directory.Move(source, destination);
        LoadFileTree();
    }

    // TreeView 노드를 다른 폴더 노드로 끌어 놓으면 실제 파일도 이동합니다.
    private void Tree_ItemDrag(object? sender, ItemDragEventArgs e) => DoDragDrop(e.Item!, DragDropEffects.Move | DragDropEffects.Copy);
    private void Tree_DragEnter(object? sender, DragEventArgs e) => e.Effect = e.Data?.GetDataPresent(typeof(TreeNode)) == true ? DragDropEffects.Move : DragDropEffects.None;
    private void Tree_DragDrop(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(TreeNode)) is not TreeNode sourceNode) return;
        TreeNode? targetNode = treeView1.GetNodeAt(treeView1.PointToClient(new Point(e.X, e.Y)));
        string? source = sourceNode.Tag as string;
        string? target = targetNode?.Tag as string;
        if (source is null || target is null || !Directory.Exists(target) || source == projectRoot) return;
        MovePath(source, target);
    }

    private void Tree_NodeMouseDoubleClick(object? sender, TreeNodeMouseClickEventArgs e)
    {
        // TXT 파일을 더블클릭하면 중앙 DockPanel의 문서 탭으로 엽니다.
        TreeNode? node = e.Node;
        if (node?.Tag is string path && IsTextDocument(path)) OpenTextDocument(path);
    }

    private void DockPanel_DragEnter(object? sender, DragEventArgs e)
    {
        // 프로젝트 탐색기의 TXT 노드만 중앙 작업 영역에서 열기 드롭으로 허용합니다.
        if (e.Data?.GetData(typeof(TreeNode)) is TreeNode node && node.Tag is string path && IsTextDocument(path))
            e.Effect = DragDropEffects.Copy;
        else
            e.Effect = DragDropEffects.None;
    }

    private void DockPanel_DragDrop(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(TreeNode)) is TreeNode node && node.Tag is string path && IsTextDocument(path))
            OpenTextDocument(path);
    }

    private static bool IsTextDocument(string path) =>
        File.Exists(path) && Path.GetExtension(path).Equals(".txt", StringComparison.OrdinalIgnoreCase);

    private void OpenTextDocument(string path)
    {
        // 이미 열린 파일이면 새 탭을 만들지 않고 기존 문서를 활성화합니다.
        CadDocument? opened = dockPanel1.Documents
            .OfType<CadDocument>()
            .FirstOrDefault(document => string.Equals(document.DocumentPath, path, StringComparison.OrdinalIgnoreCase));

        if (opened != null)
        {
            opened.Activate();
            return;
        }

        var document = new CadDocument(path);
        document.Show(dockPanel1, DockState.Document);
        document.Activate();
    }

    private void OpenFolder_Click(object? sender, EventArgs e) => Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{SelectedPath}\"") { UseShellExecute = true });
    private void Refresh_Click(object? sender, EventArgs e) => LoadFileTree();

    private void Tree_NodeMouseClick(object? sender, TreeNodeMouseClickEventArgs e)
    {
        if (e.Button == MouseButtons.Right) treeView1.SelectedNode = e.Node;
    }

    private void Tree_KeyDown(object? sender, KeyEventArgs e)
    {
        // Windows 탐색기와 동일한 파일 작업 단축키를 처리합니다.
        if (e.Control && e.KeyCode == Keys.C) { CopySelected(false); e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.X) { CopySelected(true); e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.V) { PasteSelected(); e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.Delete) { Delete_Click(sender, e); e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.F2) { RenameSelected(); e.SuppressKeyPress = true; }
    }

    private void CopyMenu_Click(object? sender, EventArgs e) => CopySelected(false);
    private void CutMenu_Click(object? sender, EventArgs e) => CopySelected(true);
    private void PasteMenu_Click(object? sender, EventArgs e) => PasteSelected();
    private void RenameMenu_Click(object? sender, EventArgs e) => RenameSelected();

    private void CopySelected(bool cut)
    {
        // 운영체제 클립보드 대신 이 프로젝트 내부에서 사용할 경로를 기억합니다.
        string path = SelectedPath;
        if (path == projectRoot || (!File.Exists(path) && !Directory.Exists(path))) return;
        clipboardPath = path;
        clipboardCut = cut;
        statusLabel.Text = cut ? $"잘라내기: {Path.GetFileName(path)}" : $"복사: {Path.GetFileName(path)}";
    }

    private void PasteSelected()
    {
        // 잘라내기는 이동, 복사는 원본을 유지한 채 새 항목을 생성합니다.
        if (string.IsNullOrWhiteSpace(clipboardPath) || (!File.Exists(clipboardPath) && !Directory.Exists(clipboardPath))) return;
        string targetDirectory = SelectedDirectory();
        if (Directory.Exists(clipboardPath) && targetDirectory.StartsWith(clipboardPath + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("폴더를 자기 하위 폴더에 붙여넣을 수 없습니다.");
            return;
        }
        string destination = UniqueDestination(targetDirectory, Path.GetFileName(clipboardPath));
        if (clipboardCut)
        {
            if (File.Exists(clipboardPath)) File.Move(clipboardPath, destination);
            else Directory.Move(clipboardPath, destination);
            clipboardPath = null;
            clipboardCut = false;
        }
        else if (File.Exists(clipboardPath))
        {
            File.Copy(clipboardPath, destination);
        }
        else
        {
            CopyDirectory(clipboardPath, destination);
        }
        LoadFileTree();
    }

    private void RenameSelected()
    {
        // 파일과 폴더 모두 동일한 방식으로 이름을 바꿉니다.
        string source = SelectedPath;
        if (source == projectRoot || (!File.Exists(source) && !Directory.Exists(source))) return;
        string name = Prompt("새 이름", "이름 바꾸기");
        if (string.IsNullOrWhiteSpace(name)) return;
        string destination = Path.Combine(Path.GetDirectoryName(source)!, SafeName(name));
        if (File.Exists(destination) || Directory.Exists(destination)) { MessageBox.Show("같은 이름이 이미 있습니다."); return; }
        if (File.Exists(source)) File.Move(source, destination); else Directory.Move(source, destination);
        LoadFileTree();
    }

    private static string UniqueDestination(string directory, string name)
    {
        // 같은 이름이 존재하면 '복사본 2', '복사본 3'처럼 충돌을 피합니다.
        string destination = Path.Combine(directory, name);
        if (!File.Exists(destination) && !Directory.Exists(destination)) return destination;
        string extension = Path.GetExtension(name);
        string baseName = Path.GetFileNameWithoutExtension(name);
        int number = 2;
        do { destination = Path.Combine(directory, $"{baseName} - 복사본 {number}{extension}"); number++; }
        while (File.Exists(destination) || Directory.Exists(destination));
        return destination;
    }

    private static void CopyDirectory(string source, string destination)
    {
        // Directory.Copy API가 따로 없으므로 하위 폴더까지 재귀 복사합니다.
        Directory.CreateDirectory(destination);
        foreach (string file in Directory.GetFiles(source)) File.Copy(file, Path.Combine(destination, Path.GetFileName(file)));
        foreach (string directory in Directory.GetDirectories(source)) CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)));
    }
    private void TabChanged(object? sender, EventArgs e) => ShowMenu(tabControl1.SelectedIndex);

    private void ShowMenu(int index)
    {
        // 선택한 상단 탭에 대응하는 리본 메뉴 그룹 하나만 표시합니다.
        projectMenu.Visible = index == 0;
        routeMenu.Visible = index == 1;
        designMenu.Visible = index == 2;
        if (index == 0) projectMenu.BringToFront();
        if (index == 1) routeMenu.BringToFront();
        if (index == 2) designMenu.BringToFront();
        statusLabel.Text = index switch
        {
            0 => "프로젝트 작업   |   좌표계 EPSG:5179   |   축척 1:5,000",
            1 => "전처리 · 노선 작업   |   좌표계 EPSG:5179   |   축척 1:5,000",
            _ => "임도 설계 작업   |   좌표계 EPSG:5179   |   축척 1:5,000"
        };
    }

    private void ApplyRibbonStyle()
    {
        // Icons 폴더에 저장된 Fluent UI PNG와 각 리본 버튼을 연결합니다.
        ConfigureRibbonButton(menuFile, "file.png");
        ConfigureRibbonButton(menuEdit, "edit.png");
        ConfigureRibbonButton(menuOutput, "output.png");
        ConfigureRibbonButton(menuTerrain, "terrain.png");
        ConfigureRibbonButton(menuHydrology, "hydrology.png");
        ConfigureRibbonButton(menuEnvironment, "environment.png");
        ConfigureRibbonButton(menuConstraint, "constraint.png");
        ConfigureRibbonButton(menuRouteSearch, "route.png");
        ConfigureRibbonButton(menuAlignment, "alignment.png");
        ConfigureRibbonButton(menuProfile, "profile.png");
        ConfigureRibbonButton(menuCrossSection, "cross_section.png");
        ConfigureRibbonButton(menuEarthwork, "earthwork.png");
        ConfigureRibbonButton(menuDrainage, "drainage.png");
        ConfigureRibbonButton(menuReview, "review.png");
    }

    // 기본 Windows 제목 표시줄을 제거했으므로 창 제어 버튼을 직접 처리합니다.
    private void MinimizeButton_Click(object? sender, EventArgs e) => WindowState = FormWindowState.Minimized;
    private void MaximizeButton_Click(object? sender, EventArgs e) => WindowState = WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
    private void CloseButton_Click(object? sender, EventArgs e) => Close();
    private void HeaderPanel_DoubleClick(object? sender, EventArgs e) => MaximizeButton_Click(sender, e);
    private void HeaderPanel_MouseDown(object? sender, MouseEventArgs e)
    {
        // 남색 헤더를 드래그하면 일반 제목 표시줄처럼 창이 이동합니다.
        if (e.Button != MouseButtons.Left) return;
        ReleaseCapture();
        SendMessage(Handle, 0xA1, 0x2, 0);
    }

    [DllImport("user32.dll")]
    private static extern bool ReleaseCapture();

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr handle, int message, int wParam, int lParam);

    private static void ConfigureRibbonButton(Button button, string fileName)
    {
        // 출력 폴더의 Icons PNG를 읽어 아이콘 위/이름 아래 형태로 표시합니다.
        string iconPath = Path.Combine(AppContext.BaseDirectory, "Icons", fileName);
        if (File.Exists(iconPath))
        {
            using Image source = Image.FromFile(iconPath);
            button.Image = new Bitmap(source);
        }
        button.ImageAlign = ContentAlignment.TopCenter;
        button.TextAlign = ContentAlignment.BottomCenter;
        button.TextImageRelation = TextImageRelation.ImageAboveText;
        button.Padding = new Padding(4, 6, 4, 5);
        button.Margin = new Padding(4, 2, 4, 2);
        button.FlatAppearance.BorderSize = 0;
        button.Cursor = Cursors.Hand;
        button.MouseEnter += RibbonButton_MouseEnter;
        button.MouseLeave += RibbonButton_MouseLeave;
    }

    private static void RibbonButton_MouseEnter(object? sender, EventArgs e)
    {
        if (sender is Button button) button.BackColor = Color.FromArgb(228, 239, 252);
    }

    private static void RibbonButton_MouseLeave(object? sender, EventArgs e)
    {
        if (sender is Button button) button.BackColor = Color.FromArgb(247, 250, 253);
    }

    private static string SafeName(string name) => string.Concat(name.Where(c => !Path.GetInvalidFileNameChars().Contains(c))).Trim();

    private static string Prompt(string label, string title)
    {
        // 폴더명, 파일명, 변경할 이름을 입력받는 공용 소형 대화상자입니다.
        using var form = new Form { Text = title, Width = 420, Height = 155, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false };
        var text = new TextBox { Left = 18, Top = 38, Width = 365 };
        var ok = new Button { Text = "확인", Left = 223, Top = 76, Width = 78, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "취소", Left = 305, Top = 76, Width = 78, DialogResult = DialogResult.Cancel };
        form.Controls.Add(new Label { Text = label, Left = 18, Top = 14, AutoSize = true }); form.Controls.Add(text); form.Controls.Add(ok); form.Controls.Add(cancel);
        form.AcceptButton = ok; form.CancelButton = cancel;
        return form.ShowDialog() == DialogResult.OK ? text.Text : string.Empty;
    }
}
