namespace cad;
public partial class Form1 { 
    private void ConfigureFileTab() { 
        ConfigureRibbonButton(menuFile,"new_project.png"); 
        ConfigureRibbonButton(menuOpen,"open.png"); 
        ConfigureRibbonButton(menuSave,"save.png"); 
        ConfigureRibbonButton(menuExport,"export.png"); 
    } 
}
