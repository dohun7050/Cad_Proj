namespace Las_Importer;

public partial class Form1 : Form
{
    public Form1() { InitializeComponent(); }
    private void Fit_Click(object? sender, EventArgs e) => viewer.FitAll();

    private async void OpenLas_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog { Title = "LAS 파일 불러오기", Filter = "비압축 LAS (*.las)|*.las" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        openButton.Enabled = false;
        statusLabel.Text = "LAS 데이터를 읽는 중…";
        try
        {
            var data = await Task.Run(() => LasReader.Read(dialog.FileName));
            statusLabel.Text = "전체 포인트를 GPU에 올리는 중…";
            await viewer.SetDataAsync(data);
            if (IsDisposed) return;
            infoBox.Text = $"파일명\r\n{Path.GetFileName(dialog.FileName)}\r\n\r\n" +
                $"LAS 버전 / 포인트 형식\r\n{data.Version} / {data.Format}\r\n\r\n" +
                $"원본 포인트 수\r\n{data.Count:N0}개\r\n\r\n불러온 유효 포인트 수 (제한 없음)\r\n{data.Points.Count:N0}개\r\n\r\n" +
                $"표시 색상\r\n{(data.HasRgb ? "LAS 원본 RGB" : "RGB 없음 — 고도 색상 사용")}\r\n\r\n" +
                $"좌표계 (원본 메타데이터)\r\n{data.Crs}\r\n\r\n" +
                $"X 범위\r\n{data.MinX:F3} ~ {data.MaxX:F3}\r\n\r\nY 범위\r\n{data.MinY:F3} ~ {data.MaxY:F3}\r\n\r\nZ 범위\r\n{data.MinZ:F3} ~ {data.MaxZ:F3}\r\n\r\n" +
                "좌표는 원본 단위입니다. 좌표계 변환은 적용하지 않았습니다.\r\n\r\n" + dialog.FileName;
            statusLabel.Text = "좌클릭: 회전 · 우클릭/가운데: 이동 · 휠: 확대/축소 · 1: 평면 · 3: 입체 · 더블클릭: 전체 보기";
        }
        catch (Exception ex)
        {
            statusLabel.Text = "불러오기 실패";
            MessageBox.Show(this, ex.Message, "LAS 불러오기", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        finally { if (!IsDisposed) openButton.Enabled = true; }
    }
}
