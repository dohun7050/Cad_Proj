using System.ComponentModel;
using System.Runtime.InteropServices;
using OpenTK.GLControl;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
namespace Las_Importer;

public sealed class PointCloudPanel : Panel
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    private struct Vertex { public float X, Y, Z; public byte R, G, B, A; }
    private sealed record Batch(int Vao, int Vbo, int Count);
    private GLControl? gl;
    private readonly List<Batch> batches = new();
    private int program, matrixLocation;
    private bool ready, redraw;
    private string? error;
    private float radius = 1, zoom = 1, pitch, yaw;
    private Vector2 pan;
    private Point last;
    private readonly System.Windows.Forms.Timer frames = new() { Interval = 16 };
    public PointCloudPanel()
    {
        BackColor = Color.Black;
        frames.Tick += (_, _) => { if (redraw && ready) { redraw = false; gl?.Invalidate(); } };
    }
    protected override void OnCreateControl()
    {
        base.OnCreateControl();
        if (gl != null || DesignMode || LicenseManager.UsageMode == LicenseUsageMode.Designtime) return;
        try
        {
            gl = new GLControl(new GLControlSettings { API = ContextAPI.OpenGL, APIVersion = new Version(3, 3), Profile = ContextProfile.Core }) { Dock = DockStyle.Fill };
            gl.Load += (_, _) => InitializeGl();
            gl.Paint += (_, _) => Draw();
            gl.Resize += (_, _) => redraw = true;
            gl.MouseDown += (_, e) => { gl.Focus(); last = e.Location; gl.Capture = true; };
            gl.MouseUp += (_, _) => gl.Capture = false;
            gl.MouseMove += (_, e) =>
            {
                if (e.Button == MouseButtons.Left) { yaw += (e.X - last.X) * .008f; pitch += (e.Y - last.Y) * .008f; }
                else if (e.Button is MouseButtons.Right or MouseButtons.Middle)
                {
                    float units = 2 * radius * 1.15f / zoom / Math.Max(1, gl.Height) / Math.Min(1f, gl.Width / (float)Math.Max(1, gl.Height));
                    pan += new Vector2((e.X - last.X) * units, -(e.Y - last.Y) * units);
                }
                last = e.Location;
                if (e.Button != MouseButtons.None) redraw = true;
            };
            gl.MouseWheel += (_, e) => { zoom = Math.Clamp(zoom * (e.Delta > 0 ? 1.15f : 1 / 1.15f), .02f, 10000); redraw = true; };
            gl.DoubleClick += (_, _) => FitAll();
            gl.KeyDown += (_, e) => { if (e.KeyCode == Keys.D1) FitAll(); if (e.KeyCode == Keys.D3) { pitch = -.65f; yaw = -.35f; redraw = true; } };
            Controls.Add(gl); frames.Start();
        }
        catch (Exception ex) { ShowError(ex); }
    }
    private void ShowError(Exception ex)
    {
        error = "OpenGL 초기화 실패: " + ex.Message; ready = false;
        if (gl != null) gl.Visible = false;
        Invalidate();
    }
    private void InitializeGl()
    {
        try
        {
            gl!.MakeCurrent();
            int vs = Compile(ShaderType.VertexShader, "#version 330 core\nlayout(location=0) in vec3 position; layout(location=1) in vec4 color; uniform mat4 mvp; out vec4 pointColor; void main(){ gl_Position=mvp*vec4(position,1.0); gl_PointSize=2.0; pointColor=color; }");
            int fs = Compile(ShaderType.FragmentShader, "#version 330 core\nin vec4 pointColor; out vec4 outputColor; void main(){ outputColor=pointColor; }");
            program = GL.CreateProgram(); GL.AttachShader(program, vs); GL.AttachShader(program, fs); GL.LinkProgram(program);
            GL.DeleteShader(vs); GL.DeleteShader(fs);
            GL.GetProgram(program, GetProgramParameterName.LinkStatus, out int linked);
            if (linked == 0) throw new InvalidOperationException(GL.GetProgramInfoLog(program));
            matrixLocation = GL.GetUniformLocation(program, "mvp");
            GL.Enable(EnableCap.DepthTest); GL.Enable(EnableCap.ProgramPointSize); GL.ClearColor(0, 0, 0, 1);
            ready = true; redraw = true;
        }
        catch (Exception ex) { ShowError(ex); }
    }
    private static int Compile(ShaderType type, string source)
    {
        int shader = GL.CreateShader(type); GL.ShaderSource(shader, source); GL.CompileShader(shader);
        GL.GetShader(shader, ShaderParameter.CompileStatus, out int ok);
        if (ok == 0) { string log = GL.GetShaderInfoLog(shader); GL.DeleteShader(shader); throw new InvalidOperationException(log); }
        return shader;
    }
    public async Task SetDataAsync(LasData data)
    {
        if (!ready) throw new InvalidOperationException(error ?? "OpenGL 화면이 아직 준비되지 않았습니다.");
        // 큰 지도 좌표는 double로 보존하고 GPU에는 중심 기준 상대 좌표를 보냅니다.
        double cx = (data.MinX + data.MaxX) / 2, cy = (data.MinY + data.MaxY) / 2, cz = (data.MinZ + data.MaxZ) / 2;
        var pending = new List<Batch>();
        try
        {
            const int chunkSize = 262144;
            for (int first = 0; first < data.Points.Count; first += chunkSize)
            {
                int start = first, count = Math.Min(chunkSize, data.Points.Count - first);
                var vertices = await Task.Run(() =>
                {
                    var result = new Vertex[count]; int divisor = data.RgbIs8Bit ? 1 : 257;
                    for (int i = 0; i < count; i++)
                    {
                        var p = data.Points[start + i]; byte r, g, b;
                        if (data.HasRgb) { r = (byte)(p.Red / divisor); g = (byte)(p.Green / divisor); b = (byte)(p.Blue / divisor); }
                        else { int t = (int)Math.Clamp((p.Z - data.MinZ) / Math.Max(1e-9, data.MaxZ - data.MinZ) * 63, 0, 63); r = (byte)(40 + t * 3); g = 190; b = (byte)(240 - t * 3); }
                        result[i] = new Vertex { X = (float)(p.X - cx), Y = (float)(p.Y - cy), Z = (float)(p.Z - cz), R = r, G = g, B = b, A = 255 };
                    }
                    return result;
                });
                if (IsDisposed) return;
                gl!.MakeCurrent(); int vao = GL.GenVertexArray(), vbo = GL.GenBuffer();
                pending.Add(new Batch(vao, vbo, count));
                GL.BindVertexArray(vao); GL.BindBuffer(BufferTarget.ArrayBuffer, vbo);
                GL.BufferData(BufferTarget.ArrayBuffer, vertices.Length * 16, vertices, BufferUsageHint.StaticDraw);
                var uploadError = GL.GetError();
                if (uploadError != ErrorCode.NoError) throw new InvalidOperationException($"GPU 업로드 실패 ({uploadError}). 그래픽 메모리를 확인하세요.");
                GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 16, 0); GL.EnableVertexAttribArray(0);
                GL.VertexAttribPointer(1, 4, VertexAttribPointerType.UnsignedByte, true, 16, 12); GL.EnableVertexAttribArray(1);
            }
            DeleteBatches(batches); batches.AddRange(pending); pending.Clear();
            double dx = data.MaxX - data.MinX, dy = data.MaxY - data.MinY, dz = data.MaxZ - data.MinZ;
            radius = (float)Math.Max(1, Math.Sqrt(dx * dx + dy * dy + dz * dz) / 2); FitAll();
        }
        finally { if (!IsDisposed && ready) { gl!.MakeCurrent(); DeleteBatches(pending); } }
    }
    public void FitAll() { zoom = 1; pitch = yaw = 0; pan = Vector2.Zero; redraw = true; }
    private void Draw()
    {
        if (!ready || gl == null || gl.Width < 1 || gl.Height < 1) return;
        gl.MakeCurrent(); GL.Viewport(0, 0, gl.Width, gl.Height); GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
        float aspect = gl.Width / (float)gl.Height, halfHeight = radius * 1.15f / zoom / Math.Min(1, aspect);
        Matrix4 model = Matrix4.CreateRotationZ(yaw) * Matrix4.CreateRotationX(pitch) * Matrix4.CreateTranslation(pan.X, pan.Y, 0);
        Matrix4 view = Matrix4.LookAt(new Vector3(0, 0, radius * 3), Vector3.Zero, Vector3.UnitY);
        Matrix4 projection = Matrix4.CreateOrthographic(halfHeight * 2 * aspect, halfHeight * 2, radius * .01f, radius * 8);
        Matrix4 mvp = model * view * projection;
        GL.UseProgram(program); GL.UniformMatrix4(matrixLocation, false, ref mvp);
        foreach (var b in batches) { GL.BindVertexArray(b.Vao); GL.DrawArrays(PrimitiveType.Points, 0, b.Count); }
        gl.SwapBuffers();
    }
    private static void DeleteBatches(List<Batch> items) { foreach (var b in items) { GL.DeleteBuffer(b.Vbo); GL.DeleteVertexArray(b.Vao); } items.Clear(); }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        if (gl == null || error != null) TextRenderer.DrawText(e.Graphics, error ?? "OpenGL 3D 점군 영역", Font, ClientRectangle, Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) { frames.Stop(); frames.Dispose(); if (ready && gl is { IsDisposed: false }) { gl.MakeCurrent(); DeleteBatches(batches); GL.DeleteProgram(program); ready = false; } }
        base.Dispose(disposing);
    }
}
