using System.Text;

namespace Las_Importer;

public readonly record struct LasPoint(double X, double Y, double Z, ushort Red = 0, ushort Green = 0, ushort Blue = 0);
public sealed class LasData
{
    public string Version = "", Crs = "정보 없음 — 제공처에서 좌표계와 단위를 확인하세요.";
    public byte Format;
    public ulong Count;
    public bool HasRgb, RgbIs8Bit;
    public double MinX, MaxX, MinY, MaxY, MinZ, MaxZ;
    public List<LasPoint> Points = new();
}

internal static class LasReader
{
    internal static LasData Read(string path)
    {
        using var stream = File.OpenRead(path);
        using var r = new BinaryReader(stream);
        if (stream.Length < 227 || Encoding.ASCII.GetString(r.ReadBytes(4)) != "LASF")
            throw new InvalidDataException("유효한 LAS 파일이 아닙니다.");
        stream.Position = 24;
        byte major = r.ReadByte(), minor = r.ReadByte();
        if (major != 1 || minor > 4) throw new NotSupportedException("이 미리보기는 LAS 1.0~1.4를 지원합니다.");
        stream.Position = 94;
        ushort headerSize = r.ReadUInt16();
        uint offset = r.ReadUInt32(), vlrs = r.ReadUInt32();
        byte format = r.ReadByte();
        ushort recordSize = r.ReadUInt16();
        ulong count = r.ReadUInt32();
        if ((format & 0xC0) != 0) throw new NotSupportedException("압축 LAZ는 지원하지 않습니다. 비압축 LAS를 선택하세요.");
        if (format > 10 || recordSize < 20 || headerSize < 227 || offset < headerSize || offset > stream.Length)
            throw new InvalidDataException("LAS 헤더 정보가 올바르지 않습니다.");
        stream.Position = 131;
        double sx = r.ReadDouble(), sy = r.ReadDouble(), sz = r.ReadDouble();
        double ox = r.ReadDouble(), oy = r.ReadDouble(), oz = r.ReadDouble();
        var data = new LasData { Version = $"{major}.{minor}", Format = format };
        data.MaxX = r.ReadDouble(); data.MinX = r.ReadDouble();
        data.MaxY = r.ReadDouble(); data.MinY = r.ReadDouble();
        data.MaxZ = r.ReadDouble(); data.MinZ = r.ReadDouble();
        ulong evlrOffset = 0; uint evlrCount = 0;
        if (minor == 4)
        {
            if (headerSize < 375) throw new InvalidDataException("LAS 1.4 헤더가 잘렸습니다.");
            stream.Position = 235;
            evlrOffset = r.ReadUInt64(); evlrCount = r.ReadUInt32();
            ulong extendedCount = r.ReadUInt64();
            if (extendedCount > 0) count = extendedCount;
        }
        if (count > (ulong)((stream.Length - offset) / recordSize))
            throw new InvalidDataException("포인트 수에 비해 파일 데이터가 부족합니다.");
        data.Count = count;
        string? wkt = null; int? epsg = null;
        void ReadCrs(string user, ushort id, byte[] bytes)
        {
            if (user != "LASF_Projection") return;
            if (id == 2112) wkt = Encoding.UTF8.GetString(bytes).TrimEnd('\0');
            if (id == 34735 && bytes.Length >= 8)
            {
                int n = BitConverter.ToUInt16(bytes, 6);
                for (int i = 0; i < n && 8 + i * 8 + 8 <= bytes.Length; i++)
                {
                    int p = 8 + i * 8;
                    ushort key = BitConverter.ToUInt16(bytes, p), location = BitConverter.ToUInt16(bytes, p + 2);
                    ushort value = BitConverter.ToUInt16(bytes, p + 6);
                    if (location == 0 && value > 0 && value != 32767 && (key == 3072 || (key == 2048 && epsg == null))) epsg = value;
                }
            }
        }
        stream.Position = headerSize;
        for (uint i = 0; i < vlrs; i++)
        {
            if (stream.Position + 54 > offset) throw new InvalidDataException("VLR 헤더가 손상되었습니다.");
            r.ReadUInt16(); string user = Encoding.ASCII.GetString(r.ReadBytes(16)).TrimEnd('\0', ' ');
            ushort id = r.ReadUInt16(), length = r.ReadUInt16(); r.ReadBytes(32);
            if (stream.Position + length > offset) throw new InvalidDataException("VLR 길이가 올바르지 않습니다.");
            ReadCrs(user, id, r.ReadBytes(length));
        }
        if (evlrCount > 0)
        {
            if (evlrOffset > (ulong)stream.Length) throw new InvalidDataException("EVLR 위치가 올바르지 않습니다.");
            stream.Position = (long)evlrOffset;
            for (uint i = 0; i < evlrCount; i++)
            {
                if (stream.Position + 60 > stream.Length) throw new InvalidDataException("EVLR 헤더가 잘렸습니다.");
                r.ReadUInt16(); string user = Encoding.ASCII.GetString(r.ReadBytes(16)).TrimEnd('\0', ' ');
                ushort id = r.ReadUInt16(); ulong length = r.ReadUInt64(); r.ReadBytes(32);
                if (length > (ulong)(stream.Length - stream.Position)) throw new InvalidDataException("EVLR 길이가 올바르지 않습니다.");
                if (user == "LASF_Projection" && length <= 1048576) ReadCrs(user, id, r.ReadBytes((int)length));
                else stream.Seek((long)length, SeekOrigin.Current);
            }
        }
        if (!string.IsNullOrWhiteSpace(wkt)) data.Crs = "WKT 정의:\r\n" + wkt;
        else if (epsg.HasValue) data.Crs = $"EPSG:{epsg.Value}";
        int rgbOffset = format switch { 2 => 20, 3 or 5 => 28, 7 or 8 or 10 => 30, _ => -1 };
        data.HasRgb = rgbOffset >= 0;
        if (data.HasRgb && recordSize < rgbOffset + 6) throw new InvalidDataException("RGB 포인트 레코드가 잘렸습니다.");
        // RGB는 16비트가 표준이지만 0~255로 저장된 파일도 지원합니다.
        ushort maxColor = 0;
        if (count > int.MaxValue) throw new NotSupportedException("현재 메모리 모델이 지원하는 포인트 수를 초과했습니다.");
        data.Points = new List<LasPoint>((int)count);
        int recordsPerBlock = Math.Max(1, 1048576 / recordSize);
        byte[] buffer = new byte[recordsPerBlock * recordSize];
        stream.Position = offset;
        for (ulong first = 0; first < count;)
        {
            int batch = (int)Math.Min((ulong)recordsPerBlock, count - first);
            stream.ReadExactly(buffer.AsSpan(0, batch * recordSize));
            for (int j = 0; j < batch; j++)
            {
            int start = j * recordSize;
            double x = BitConverter.ToInt32(buffer, start) * sx + ox;
            double y = BitConverter.ToInt32(buffer, start + 4) * sy + oy;
            double z = BitConverter.ToInt32(buffer, start + 8) * sz + oz;
            ushort red = 0, green = 0, blue = 0;
            if (data.HasRgb)
            {
                red = BitConverter.ToUInt16(buffer, start + rgbOffset);
                green = BitConverter.ToUInt16(buffer, start + rgbOffset + 2);
                blue = BitConverter.ToUInt16(buffer, start + rgbOffset + 4);
                maxColor = Math.Max(maxColor, Math.Max(red, Math.Max(green, blue)));
            }
            if (double.IsFinite(x) && double.IsFinite(y) && double.IsFinite(z)) data.Points.Add(new(x, y, z, red, green, blue));
            }
            first += (ulong)batch;
        }
        data.RgbIs8Bit = maxColor <= 255;
        return data;
    }
}
