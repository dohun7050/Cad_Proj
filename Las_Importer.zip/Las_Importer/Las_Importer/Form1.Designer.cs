#nullable enable
namespace Las_Importer;

partial class Form1
{
    private System.ComponentModel.IContainer? components;
    private SplitContainer split = null!;
    private PointCloudPanel viewer = null!;
    private Button openButton = null!;
    private Button fitButton = null!;
    private RichTextBox infoBox = null!;
    private Label statusLabel = null!;
    private Label heading = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        split = new SplitContainer();
        viewer = new PointCloudPanel();
        openButton = new Button();
        fitButton = new Button();
        infoBox = new RichTextBox();
        statusLabel = new Label();
        heading = new Label();
        ((System.ComponentModel.ISupportInitialize)split).BeginInit();
        split.Panel1.SuspendLayout();
        split.Panel2.SuspendLayout();
        split.SuspendLayout();
        SuspendLayout();
        split.Dock = DockStyle.Fill;
        split.Size = new Size(1100, 650);
        split.SplitterDistance = 750;
        split.FixedPanel = FixedPanel.Panel2;
        split.Panel1MinSize = 300;
        split.Panel2MinSize = 280;
        split.Name = "splitMain";
        viewer.Dock = DockStyle.Fill;
        viewer.Name = "lasViewport";
        split.Panel1.Controls.Add(viewer);
        split.Panel2.Padding = new Padding(12);
        split.Panel2.BackColor = Color.WhiteSmoke;
        heading.Text = "LAS 데이터 정보";
        heading.Dock = DockStyle.Top;
        heading.Height = 40;
        heading.Font = new Font("맑은 고딕", 12, FontStyle.Bold);
        openButton.Text = "LAS 파일 불러오기";
        openButton.Name = "btnOpenLas";
        openButton.Dock = DockStyle.Top;
        openButton.Height = 42;
        openButton.Click += OpenLas_Click;
        fitButton.Text = "전체 보기";
        fitButton.Dock = DockStyle.Top;
        fitButton.Height = 34;
        fitButton.Click += Fit_Click;
        infoBox.Dock = DockStyle.Fill;
        infoBox.Name = "txtLasInfo";
        infoBox.ReadOnly = true;
        infoBox.BorderStyle = BorderStyle.None;
        infoBox.BackColor = Color.WhiteSmoke;
        infoBox.Font = new Font("맑은 고딕", 10);
        infoBox.Text = "아직 불러온 파일이 없습니다.\n\nLAS 파일을 선택하면 좌표계, 포인트 수와 X/Y/Z 범위가 표시됩니다.";
        split.Panel2.Controls.Add(infoBox);
        split.Panel2.Controls.Add(fitButton);
        split.Panel2.Controls.Add(openButton);
        split.Panel2.Controls.Add(heading);
        statusLabel.Dock = DockStyle.Bottom;
        statusLabel.Height = 30;
        statusLabel.TextAlign = ContentAlignment.MiddleLeft;
        statusLabel.Text = "OpenGL 3D · 좌클릭: 회전 · 우클릭: 이동 · 휠: 확대/축소 · 키보드 1: 평면 · 3: 입체";
        AutoScaleDimensions = new SizeF(7, 15);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1100, 680);
        MinimumSize = new Size(850, 500);
        Controls.Add(split);
        Controls.Add(statusLabel);
        Name = "Form1";
        Text = "LAS Importer — 점군 미리보기";
        StartPosition = FormStartPosition.CenterScreen;
        split.Panel1.ResumeLayout(false);
        split.Panel2.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)split).EndInit();
        split.ResumeLayout(false);
        ResumeLayout(false);
    }
}
