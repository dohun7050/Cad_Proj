using System.Diagnostics;

namespace cad;

public partial class Form1 : Form
{
    private readonly string projectRoot = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "cad", "ProjectFiles");
    private string? clipboardPath;
    private bool clipboardCut;

    public Form1()
    {
        InitializeComponent();
        EnsureSampleFiles();
        LoadFileTree();
        ApplyRibbonStyle();
        ShowMenu(0);
    }

    private void EnsureSampleFiles()
    {
        string[] folders = { "01_원본자료", "02_전처리", "03_노선", "04_설계", "05_성과품" };
        foreach (string folder in folders) Directory.CreateDirectory(Path.Combine(projectRoot, folder));

        CreateSample("01_원본자료", "백운산_DEM.tif", "DEM raster placeholder");
        CreateSample("01_원본자료", "산림경계.shp", "SHP placeholder");
        CreateSample("01_원본자료", "기준점.csv", "ID,X,Y,Z\nP001,287532.123,4123567.890,642.123");
        CreateSample("02_전처리", "지형망_TIN.dxf", "DXF placeholder");
        CreateSample("03_노선", "후보노선_A.dxf", "DXF route placeholder");
        CreateSample("03_노선", "후보노선_B.dxf", "DXF route placeholder");
        CreateSample("04_설계", "종단면_설계.xml", "LandXML placeholder");
        CreateSample("05_성과품", "설계검토서.txt", "임도 설계 검토 결과 예제 파일");
    }

    private void CreateSample(string folder, string name, string content)
    {
        string path = Path.Combine(projectRoot, folder, name);
        if (!File.Exists(path)) File.WriteAllText(path, content);
    }

    private void LoadFileTree()
    {
        treeView1.BeginUpdate();
        treeView1.Nodes.Clear();
        var root = CreateNode(new DirectoryInfo(projectRoot));
        treeView1.Nodes.Add(root);
        root.Expand();
        treeView1.EndUpdate();
    }

    private TreeNode CreateNode(FileSystemInfo info)
    {
        bool isDirectory = info is DirectoryInfo;
        var node = new TreeNode(info.Name) { Tag = info.FullName, ImageKey = isDirectory ? "folder" : "file", SelectedImageKey = isDirectory ? "folder" : "file" };
        if (info is DirectoryInfo directory)
        {
            try
            {
                foreach (DirectoryInfo child in directory.GetDirectories().OrderBy(x => x.Name)) node.Nodes.Add(CreateNode(child));
                foreach (FileInfo child in directory.GetFiles().OrderBy(x => x.Name)) node.Nodes.Add(CreateNode(child));
            }
            catch (UnauthorizedAccessException) { }
        }
        return node;
    }

    private string SelectedPath => treeView1.SelectedNode?.Tag as string ?? projectRoot;

    private string SelectedDirectory()
    {
        string path = SelectedPath;
        return Directory.Exists(path) ? path : Path.GetDirectoryName(path) ?? projectRoot;
    }

    private void AddFolder_Click(object? sender, EventArgs e)
    {
        string name = Prompt("새 폴더 이름", "폴더 추가");
        if (string.IsNullOrWhiteSpace(name)) return;
        Directory.CreateDirectory(Path.Combine(SelectedDirectory(), SafeName(name)));
        LoadFileTree();
    }

    private void AddFile_Click(object? sender, EventArgs e)
    {
        string name = Prompt("새 파일 이름 (예: 노선.dxf)", "파일 추가");
        if (string.IsNullOrWhiteSpace(name)) return;
        string path = Path.Combine(SelectedDirectory(), SafeName(name));
        if (!File.Exists(path)) File.WriteAllText(path, "새 CAD 프로젝트 파일");
        LoadFileTree();
    }

    private void Delete_Click(object? sender, EventArgs e)
    {
        string path = SelectedPath;
        if (path == projectRoot || (!File.Exists(path) && !Directory.Exists(path))) return;
        if (MessageBox.Show($"'{Path.GetFileName(path)}'을(를) 삭제할까요?", "삭제 확인", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        if (File.Exists(path)) File.Delete(path); else Directory.Delete(path, true);
        LoadFileTree();
    }

    private void Move_Click(object? sender, EventArgs e)
    {
        string source = SelectedPath;
        if (source == projectRoot) return;
        using var dialog = new FolderBrowserDialog { Description = "이동할 대상 폴더 선택", InitialDirectory = projectRoot };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        MovePath(source, dialog.SelectedPath);
    }

    private void MovePath(string source, string targetDirectory)
    {
        if (!targetDirectory.StartsWith(projectRoot, StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("ProjectFiles 폴더 내부로만 이동할 수 있습니다.");
            return;
        }
        string destination = Path.Combine(targetDirectory, Path.GetFileName(source));
        if (File.Exists(destination) || Directory.Exists(destination)) { MessageBox.Show("대상 폴더에 같은 이름이 있습니다."); return; }
        if (File.Exists(source)) File.Move(source, destination); else if (Directory.Exists(source)) Directory.Move(source, destination);
        LoadFileTree();
    }

    private void Tree_ItemDrag(object? sender, ItemDragEventArgs e) => DoDragDrop(e.Item!, DragDropEffects.Move);
    private void Tree_DragEnter(object? sender, DragEventArgs e) => e.Effect = e.Data?.GetDataPresent(typeof(TreeNode)) == true ? DragDropEffects.Move : DragDropEffects.None;
    private void Tree_DragDrop(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(TreeNode)) is not TreeNode sourceNode) return;
        TreeNode? targetNode = treeView1.GetNodeAt(treeView1.PointToClient(new Point(e.X, e.Y)));
        string? source = sourceNode.Tag as string;
        string? target = targetNode?.Tag as string;
        if (source is null || target is null || !Directory.Exists(target) || source == projectRoot) return;
        MovePath(source, target);
    }

    private void OpenFolder_Click(object? sender, EventArgs e) => Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{SelectedPath}\"") { UseShellExecute = true });
    private void Refresh_Click(object? sender, EventArgs e) => LoadFileTree();

    private void Tree_NodeMouseClick(object? sender, TreeNodeMouseClickEventArgs e)
    {
        if (e.Button == MouseButtons.Right) treeView1.SelectedNode = e.Node;
    }

    private void Tree_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Control && e.KeyCode == Keys.C) { CopySelected(false); e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.X) { CopySelected(true); e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.V) { PasteSelected(); e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.Delete) { Delete_Click(sender, e); e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.F2) { RenameSelected(); e.SuppressKeyPress = true; }
    }

    private void CopyMenu_Click(object? sender, EventArgs e) => CopySelected(false);
    private void CutMenu_Click(object? sender, EventArgs e) => CopySelected(true);
    private void PasteMenu_Click(object? sender, EventArgs e) => PasteSelected();
    private void RenameMenu_Click(object? sender, EventArgs e) => RenameSelected();

    private void CopySelected(bool cut)
    {
        string path = SelectedPath;
        if (path == projectRoot || (!File.Exists(path) && !Directory.Exists(path))) return;
        clipboardPath = path;
        clipboardCut = cut;
        statusLabel.Text = cut ? $"잘라내기: {Path.GetFileName(path)}" : $"복사: {Path.GetFileName(path)}";
    }

    private void PasteSelected()
    {
        if (string.IsNullOrWhiteSpace(clipboardPath) || (!File.Exists(clipboardPath) && !Directory.Exists(clipboardPath))) return;
        string targetDirectory = SelectedDirectory();
        if (Directory.Exists(clipboardPath) && targetDirectory.StartsWith(clipboardPath + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("폴더를 자기 하위 폴더에 붙여넣을 수 없습니다.");
            return;
        }
        string destination = UniqueDestination(targetDirectory, Path.GetFileName(clipboardPath));
        if (clipboardCut)
        {
            if (File.Exists(clipboardPath)) File.Move(clipboardPath, destination);
            else Directory.Move(clipboardPath, destination);
            clipboardPath = null;
            clipboardCut = false;
        }
        else if (File.Exists(clipboardPath))
        {
            File.Copy(clipboardPath, destination);
        }
        else
        {
            CopyDirectory(clipboardPath, destination);
        }
        LoadFileTree();
    }

    private void RenameSelected()
    {
        string source = SelectedPath;
        if (source == projectRoot || (!File.Exists(source) && !Directory.Exists(source))) return;
        string name = Prompt("새 이름", "이름 바꾸기");
        if (string.IsNullOrWhiteSpace(name)) return;
        string destination = Path.Combine(Path.GetDirectoryName(source)!, SafeName(name));
        if (File.Exists(destination) || Directory.Exists(destination)) { MessageBox.Show("같은 이름이 이미 있습니다."); return; }
        if (File.Exists(source)) File.Move(source, destination); else Directory.Move(source, destination);
        LoadFileTree();
    }

    private static string UniqueDestination(string directory, string name)
    {
        string destination = Path.Combine(directory, name);
        if (!File.Exists(destination) && !Directory.Exists(destination)) return destination;
        string extension = Path.GetExtension(name);
        string baseName = Path.GetFileNameWithoutExtension(name);
        int number = 2;
        do { destination = Path.Combine(directory, $"{baseName} - 복사본 {number}{extension}"); number++; }
        while (File.Exists(destination) || Directory.Exists(destination));
        return destination;
    }

    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (string file in Directory.GetFiles(source)) File.Copy(file, Path.Combine(destination, Path.GetFileName(file)));
        foreach (string directory in Directory.GetDirectories(source)) CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)));
    }
    private void TabChanged(object? sender, EventArgs e) => ShowMenu(tabControl1.SelectedIndex);

    private void ShowMenu(int index)
    {
        projectMenu.Visible = index == 0;
        routeMenu.Visible = index == 1;
        designMenu.Visible = index == 2;
        if (index == 0) projectMenu.BringToFront();
        if (index == 1) routeMenu.BringToFront();
        if (index == 2) designMenu.BringToFront();
        canvasTitle.Text = index switch
        {
            0 => "프로젝트 작업 영역",
            1 => "전처리 · 노선 작업 영역",
            _ => "임도 설계 작업 영역"
        };
    }

    private void ApplyRibbonStyle()
    {
        ConfigureRibbonButton(menuFile, "file.png");
        ConfigureRibbonButton(menuEdit, "edit.png");
        ConfigureRibbonButton(menuOutput, "output.png");
        ConfigureRibbonButton(menuTerrain, "terrain.png");
        ConfigureRibbonButton(menuHydrology, "hydrology.png");
        ConfigureRibbonButton(menuEnvironment, "environment.png");
        ConfigureRibbonButton(menuConstraint, "constraint.png");
        ConfigureRibbonButton(menuRouteSearch, "route.png");
        ConfigureRibbonButton(menuAlignment, "alignment.png");
        ConfigureRibbonButton(menuProfile, "profile.png");
        ConfigureRibbonButton(menuCrossSection, "cross_section.png");
        ConfigureRibbonButton(menuEarthwork, "earthwork.png");
        ConfigureRibbonButton(menuDrainage, "drainage.png");
        ConfigureRibbonButton(menuReview, "review.png");
    }

    private static void ConfigureRibbonButton(Button button, string fileName)
    {
        string iconPath = Path.Combine(AppContext.BaseDirectory, "Icons", fileName);
        if (File.Exists(iconPath))
        {
            using Image source = Image.FromFile(iconPath);
            button.Image = new Bitmap(source);
        }
        button.ImageAlign = ContentAlignment.TopCenter;
        button.TextAlign = ContentAlignment.BottomCenter;
        button.TextImageRelation = TextImageRelation.ImageAboveText;
        button.Padding = new Padding(4, 6, 4, 5);
        button.Margin = new Padding(4, 2, 4, 2);
        button.FlatAppearance.BorderSize = 0;
        button.Cursor = Cursors.Hand;
        button.MouseEnter += RibbonButton_MouseEnter;
        button.MouseLeave += RibbonButton_MouseLeave;
    }

    private static void RibbonButton_MouseEnter(object? sender, EventArgs e)
    {
        if (sender is Button button) button.BackColor = Color.FromArgb(228, 239, 252);
    }

    private static void RibbonButton_MouseLeave(object? sender, EventArgs e)
    {
        if (sender is Button button) button.BackColor = Color.FromArgb(247, 250, 253);
    }

    private static string SafeName(string name) => string.Concat(name.Where(c => !Path.GetInvalidFileNameChars().Contains(c))).Trim();

    private static string Prompt(string label, string title)
    {
        using var form = new Form { Text = title, Width = 420, Height = 155, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false };
        var text = new TextBox { Left = 18, Top = 38, Width = 365 };
        var ok = new Button { Text = "확인", Left = 223, Top = 76, Width = 78, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "취소", Left = 305, Top = 76, Width = 78, DialogResult = DialogResult.Cancel };
        form.Controls.Add(new Label { Text = label, Left = 18, Top = 14, AutoSize = true }); form.Controls.Add(text); form.Controls.Add(ok); form.Controls.Add(cancel);
        form.AcceptButton = ok; form.CancelButton = cancel;
        return form.ShowDialog() == DialogResult.OK ? text.Text : string.Empty;
    }
}
