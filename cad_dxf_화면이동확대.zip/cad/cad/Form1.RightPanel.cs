namespace cad;
public partial class Form1 { }
