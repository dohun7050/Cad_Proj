﻿using IxMilia.Dxf;
using IxMilia.Dxf.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace cad
{
    public class DxfDocument : DockContent
    {
        // 불러온 DXF 도면 전체 데이터
        private readonly DxfFile dxf;
        // 도면을 그릴 중앙 캔버스
        
        public DxfDocument(DxfFile dxf, string title, double minX, double minY, double maxX, double maxY)
        {
            
            Text = title;
            var drawingPanel = new DrawingPanel(
            dxf,
            minX,
            minY,
            maxX,
            maxY
            );
            Controls.Add(drawingPanel);
        }
    }
    public class DrawingPanel : Panel
    {
        private readonly DxfFile dxf;
        private readonly double minX;
        private readonly double minY;
        private readonly double maxX;
        private readonly double maxY;
        private const float Margin = 30;
        private bool isFirstDraw = true;
        private double scale = 1.0;

        //현재 도면의 화면 위치 offset
        private double offsetX;
        private double offsetY;

        // 드래그 중인지 표시
        private bool isMoving = false;

        // 마우스를 처음 누른 화면 위치
        private Point startPoint;

        // 누르기 전 도면의 화면 위치
        private double startOffsetX;
        private double startOffsetY;

        public DrawingPanel(DxfFile dxf, double minx, double miny, double maxx, double maxy)
        {
            this.dxf = dxf;
            this.minX = minx;
            this.minY = miny;
            this.maxX = maxx;
            this.maxY = maxy;

            Dock = DockStyle.Fill;
            BackColor = Color.White;
            ResizeRedraw = true;
            DoubleBuffered = true;
            TabStop = true;
            MouseEnter += (sender, e) => Focus();
            //화면 깜빡임을 줄이기
        }

        //dxf좌표를 화면 winform 좌표로 변경
        private PointF ToScreenPoint(double dxfx, double dxfy, double scale, double offsetx, double offsety)
        {
            // 도면의 가장 왼쪽(minX)을 0 기준으로 옮긴 뒤,
            // 화면 배율을 곱하고 여백·가운데 정렬 위치(offsetX)를 더함
            float screenx = (float)((dxfx - minX) * scale + offsetx);
            // DXF는 Y가 위로 증가하지만,
            // WinForms 화면은 Y가 아래로 증가
            // 그래서 패널 높이에서 값을 빼서 Y축 방향을 반대로 만들기
            float screeny = (float)(ClientSize.Height - ((dxfy - minY) * scale + offsety));

            // WinForms가 사용하는 화면상의 한 점(X, Y)을 반환
            return new PointF(screenx, screeny);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            double w = maxX - minX;
            double h = maxY - minY;

            if(w<=0|| h <= 0)
            {
                return;
            }
            
            double screenW = ClientSize.Width - Margin * 2;
            double screenH = ClientSize.Height - Margin * 2;

            if (isFirstDraw)
            {
                double scaleX = screenW / w;
                double scaleY = screenH / h;

                //둘 중 작은 값을 사용->도묜이 가로 / 세로 모두 화면 밖으로 나가지 않음
                scale = Math.Min(scaleX, scaleY);

                // 화면에 남는 가로 공간의 절반만큼 옮겨 가로 중앙 정렬
                offsetX = Margin + (screenW - w * scale) / 2;
                // 화면에 남는 가로 공간의 절반만큼 옮겨 가로 중앙 정렬
                offsetY = Margin + (screenH - h * scale) / 2;
                isFirstDraw = false;
            }
            // 대각선·곡선 부드럽게 처리
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            using var pen = new Pen(Color.Black, 1);
            foreach( var en in dxf.Entities)
            {
                if(en is DxfLine line)
                {
                    PointF startP = ToScreenPoint(line.P1.X, line.P1.Y, scale, offsetX, offsetY);
                    PointF endP = ToScreenPoint(line.P2.X, line.P2.Y, scale, offsetX, offsetY);
                    e.Graphics.DrawLine(pen, startP, endP);
                }
                else if(en is DxfLwPolyline lwp)
                {
                    if (lwp.Vertices.Count < 2)
                    {
                        continue;
                    }
                    for(int i=1; i<lwp.Vertices.Count; i++)
                    {
                        var prev = lwp.Vertices[i - 1];
                        var curr = lwp.Vertices[i];

                        PointF startP = ToScreenPoint(prev.X, prev.Y, scale, offsetX, offsetY);
                        PointF endP = ToScreenPoint(curr.X, curr.Y, scale, offsetX, offsetY);
                        e.Graphics.DrawLine(pen, startP, endP);
                    }
                }
            }
           
        }
        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);
            //e.Delta : 휠 방향 -> 양수 : 위로 굴림 / 음수 : 아래로 굴림
            if(e.Delta < 0)
            {
                scale /= 1.2;
            }
            else
            {
                scale *= 1.2;
                
            }
            Invalidate();
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if(e.Button == MouseButtons.Left)
            {
                Focus();
                isMoving = true;

                // 클릭한 화면 위치를 기억
                startPoint = e.Location;

                // 클릭 순간의 도면 위치를 기억
                startOffsetX = offsetX;
                startOffsetY = offsetY;

                Capture = true;
                Cursor = Cursors.SizeAll;
            }
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if (!isMoving)
            {
                return;
            }
            // 현재 마우스 - 처음 클릭한 마우스 = 이동 거리
            double moveX = e.X - startPoint.X;
            double moveY = e.Y - startPoint.Y;

            // 처음 도면 위치 + 마우스 가로 이동 거리
            offsetX = startOffsetX + moveX;

            // Y축 방향이 반대라 세로 이동은 뺍니다.
            offsetY = startOffsetY - moveY;

            Invalidate();
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);

            if(e.Button == MouseButtons.Left)
            {
                isMoving = false;
                Capture = false;
                Cursor = Cursors.Default;
            }
        }
    }
}
