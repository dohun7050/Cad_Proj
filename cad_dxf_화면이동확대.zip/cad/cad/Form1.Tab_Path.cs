namespace cad;
public partial class Form1 { 
    private void ConfigurePathTab() { 
        ConfigureRibbonButton(menuTerrain,"terrain.png"); 
        ConfigureRibbonButton(menuHydrology,"hydrology.png"); 
        ConfigureRibbonButton(menuEnvironment,"environment.png"); 
        ConfigureRibbonButton(menuConstraint,"constraint.png"); 
        ConfigureRibbonButton(menuRouteSearch,"route.png"); 
        ConfigureRibbonButton(menuAlignment,"alignment.png"); 
    } 
}
