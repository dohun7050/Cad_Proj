namespace cad;
public partial class Form1 { 
    private void ConfigureResultTab() { 
        ConfigureRibbonButton(menuOutput,"route_compare.png"); 
        ConfigureRibbonButton(menuReport,"report.png"); 
        ConfigureRibbonButton(menuDrawing,"drawing.png"); 
        ConfigureRibbonButton(menuReview,"review.png"); 
    } 
}
