namespace cad.Models;

// DXF, SHP, LAS, DEM 등 여러 파일을 프로그램 안에서 공통된 레이어로 관리
public class ProjectLayer
{
    // TreeView와 화면에 표시할 레이어 이름
    // 예: "임도중심선.dxf"
    public string Name { get; set; } = "";

    // 원본 파일이 저장된 전체 경로
    public string FilePath { get; set; } = "";

    // 파일 종류 예: DXF, SHP, LAS, DEM
    public string FileType { get; set; } = "";

    // 화면에 레이어를 표시할지 여부
    public bool IsVisible { get; set; } = true;

    // 파일 형식별 원본 데이터를 보관
    // DXF는 DxfFile, SHP는 나중에 SHP 데이터 객체가 들어감
    public object? SourceData { get; set; }
}

// 파일 불러오기 작업의 성공 여부, 메시지, 생성된 레이어를 함께 전달
public class ImportResult
{
    // 파일을 정상적으로 불러왔는지 여부
    public bool IsSuccess { get; set; }

    // 성공 또는 실패 원인을 사용자에게 보여줄 메시지
    public string Message { get; set; } = "";

    // 성공했을 때 생성된 프로젝트 레이어
    // 실패하면 null
    public ProjectLayer? Layer { get; set; }
}
