namespace cad;
public partial class Form1 { 
    private void ConfigureDesignTab() { 
        ConfigureRibbonButton(menuProfile,"profile.png"); 
        ConfigureRibbonButton(menuCrossSection,"cross_section.png"); 
        ConfigureRibbonButton(menuEarthwork,"earthwork.png"); 
        ConfigureRibbonButton(menuDrainage,"drainage.png"); 
    } 
}
