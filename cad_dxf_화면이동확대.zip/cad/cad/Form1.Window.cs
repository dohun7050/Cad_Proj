using System.Diagnostics;
using System.Runtime.InteropServices;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

public partial class Form1
{
    private void MinimizeButton_Click(object? sender, EventArgs e) => WindowState = FormWindowState.Minimized;
    private void MaximizeButton_Click(object? sender, EventArgs e) => WindowState = WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
    private void CloseButton_Click(object? sender, EventArgs e) => Close();
    private void HeaderPanel_DoubleClick(object? sender, EventArgs e) => MaximizeButton_Click(sender, e);
    private void HeaderPanel_MouseDown(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;
        ReleaseCapture();
        SendMessage(Handle, 0xA1, 0x2, 0);
    }

    [DllImport("user32.dll")]
    private static extern bool ReleaseCapture();

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr handle, int message, int wParam, int lParam);
}
