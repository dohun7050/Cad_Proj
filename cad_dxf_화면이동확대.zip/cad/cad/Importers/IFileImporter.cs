using cad.Models;

namespace cad.Importers;

// 모든 파일 형식 Importer가 따라야 하는 공통 규칙입니다.
public interface IFileImporter
{
    // 현재 Importer가 전달받은 파일을 처리할 수 있는지 확인합니다.
    bool CanImport(string filePath);

    // 파일을 읽고 공통 ProjectLayer 형태로 변환합니다.
    ImportResult Import(string filePath);
}
