using cad.Models;
using IxMilia.Dxf;

namespace cad.Importers;

// DXF 파일만 읽는 Importer
public class DxfImporter : IFileImporter
{
    // 파일 확장자가 .dxf이면 이 Importer가 처리
    // OrdinalIgnoreCase를 사용하므로 .DXF도 처리
    public bool CanImport(string filePath)
    {
        return Path.GetExtension(filePath)
            .Equals(".dxf", StringComparison.OrdinalIgnoreCase);
    }

    // IxMilia.Dxf로 DXF 파일을 읽어 ProjectLayer로 변환
    public ImportResult Import(string filePath)
    {
        try
        {
            // DXF 내부의 Entities, Layers, Blocks 등을 메모리로 읽기
            DxfFile dxfFile = DxfFile.Load(filePath);

            // 다른 파일 형식과 동일하게 관리할 공통 레이어를 만들기
            var layer = new ProjectLayer
            {
                Name = Path.GetFileName(filePath),
                FilePath = filePath,
                FileType = "DXF",
                SourceData = dxfFile
            };

            return new ImportResult
            {
                IsSuccess = true,
                Message = "DXF 파일을 불러왔습니다.",
                Layer = layer
            };
        }
        catch (Exception ex)
        {
            // 파일이 손상됐거나 DXF 형식이 아닐 때 오류 내용을 반환
            return new ImportResult
            {
                IsSuccess = false,
                Message = ex.Message
            };
        }
    }
}
