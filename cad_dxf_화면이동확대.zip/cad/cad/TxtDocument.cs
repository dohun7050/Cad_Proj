using WeifenLuo.WinFormsUI.Docking;

namespace cad;

public sealed class TxtDocument : DockContent
{
    // 이 도킹 문서가 연결된 실제 TXT 파일 경로입니다.
    private readonly string filePath;
    private readonly RichTextBox editor;

    // 같은 파일이 이미 열려 있는지 확인할 때 사용하는 공개 경로입니다.
    public string DocumentPath => filePath;

    // 지정한 TXT 파일을 편집할 도킹 문서 창을 중앙 문서 또는 독립 플로팅 창으로 초기화하는 생성자입니다.
    // 내용이 수정되면 탭 제목 뒤에 *를 표시하여 저장 전 상태임을 알립니다.
    public TxtDocument(string path)
    {
        filePath = path;
        Text = Path.GetFileName(path);
        TabText = Path.GetFileName(path);
        DockAreas = DockAreas.Document | DockAreas.Float;
        HideOnClose = false;
        BackColor = Color.White;

        editor = new RichTextBox
        {
            Dock = DockStyle.Fill,
            BorderStyle = BorderStyle.None,
            Font = new Font("Consolas", 11F),
            BackColor = Color.FromArgb(250, 252, 254),
            ForeColor = Color.FromArgb(35, 48, 61),
            AcceptsTab = true,
            WordWrap = false,
            Text = File.Exists(path) ? File.ReadAllText(path) : string.Empty
        };

        editor.TextChanged += (_, _) => Text = TabText = Path.GetFileName(filePath) + " *";
        Controls.Add(editor);
    }

    // 변경된 문서 창이 닫힐 때 편집 내용을 원본 TXT 파일에 저장하는 함수입니다.
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (Text.EndsWith(" *", StringComparison.Ordinal)) File.WriteAllText(filePath, editor.Text);
        base.OnFormClosing(e);
    }
}
