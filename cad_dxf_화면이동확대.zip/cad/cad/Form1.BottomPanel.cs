namespace cad;
public partial class Form1 { 
    private void UpdateBottomStatus(int index) { 
        string name=index switch {
            0=>"파일 작업",1=>"편집 작업",2=>"전처리/노선 작업",3=>"설계 작업",_=>"결과 출력"
        }; 
        statusLabel.Text=$"{name}   |   좌표계 EPSG:5179   |   축척 1:5,000"; 
    } 
}
