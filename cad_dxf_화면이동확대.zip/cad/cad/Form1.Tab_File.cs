using IxMilia.Dxf;
using IxMilia.Dxf.Entities;
using cad.Importers;
using cad.Models;
using WeifenLuo.WinFormsUI.Docking;
using System.Text;

namespace cad;
public partial class Form1 {

    private readonly List<ProjectLayer> l = new();
    private void ConfigureFileTab() { 
        ConfigureRibbonButton(menuFile,"new_project.png"); 
        ConfigureRibbonButton(menuOpen,"open.png"); 
        ConfigureRibbonButton(menuSave,"save.png"); 
        ConfigureRibbonButton(menuExport,"export.png"); 
    }
    private void menuOpen_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog
        {
            Title = "파일 열기",
            Filter = "모든 파일 (*.*)|*.*",
            InitialDirectory = projectRoot,
            Multiselect = false
        };

        if(dialog.ShowDialog() != DialogResult.OK)
        {
            return;
        }
        var importer = new DxfImporter();
        ImportResult result = importer.Import(dialog.FileName);
        if (!result.IsSuccess)
        {
            MessageBox.Show( result.Message, "DXF 불러오기 오류", MessageBoxButtons.OK, MessageBoxIcon.Error );
            return;
        }
        if (result.Layer is not null)
        {
            l.Add(result.Layer);
        }
        // 레이어 원본 데이터가 DxfFile이면 중앙 DockPanel 탭 열기
        if (result.Layer?.SourceData is DxfFile dxfFile)
        {
            int line = dxfFile.Entities.OfType<DxfLine>().Count();
            int pline = dxfFile.Entities.OfType<DxfPolyline>().Count();
            int lw_pline = dxfFile.Entities.OfType<DxfLwPolyline>().Count();

            double minX = double.MaxValue;
            double minY = double.MaxValue;
            double maxX = double.MinValue;
            double maxY = double.MinValue;

            void Total_Area(double x, double y)
            {
                if (x < minX) minX = x;
                if (y < minY) minY = y;
                if (x > maxX) maxX = x;
                if (y > maxY) maxY = y;
            }
            // 하단 상태 패널 오른쪽에 현재 DXF의 객체 개수를 표시합니다.
            label1.Text = $"객체: {dxfFile.Entities.Count}  |  선: {line}  |  폴리선: {pline + lw_pline}  |  영역: 0";
            //int text = dxfFile.Entities.OfType<DxfText>().Count(entity => entity is DxfText || entity is DxfMText); 
            MessageBox.Show($"전체 객체 : {dxfFile.Entities.Count}");
            var str = new StringBuilder();
            int count = 0;
            foreach(var en in dxfFile.Entities)
            {
               
                string layer_name = en.Layer;
                if (en is DxfLine l)
                {
                    // Line의 시작점(P1) 좌표
                    double sX = l.P1.X;
                    double sY = l.P1.Y;

                    // Line의 끝점은 P1이 아니라 P2
                    double eX = l.P2.X;
                    double eY = l.P2.Y;

                    // 시작점과 끝점을 전체 도면 범위에 포함
                    Total_Area(sX, sY);
                    Total_Area(eX, eY);
                    //MessageBox.Show($"레이어 : {layer_name}\t 시작점 {sX},{sY}");
                }
                else if(en is DxfLwPolyline lwp)
                {
                    // LwPolyline을 구성하는 모든 꼭짓점을 확인
                    foreach( var v in lwp.Vertices)
                    {
                        double x = v.X;
                        double y = v.Y;

                        // 현재 꼭짓점을 전체 도면 범위에 포함
                        Total_Area(x, y);
                    }
                    //MessageBox.Show($"레이어 : {layer_name}");
                }
                else if (en is DxfPolyline pl)
                {
                    // 일반 Polyline의 좌표는 Vertex 안의 Location에 
                    foreach (var v in pl.Vertices)
                    {
                        double x = v.Location.X;
                        double y = v.Location.Y;

                        // 현재 꼭짓점을 전체 도면 범위에 포함합니다.
                        Total_Area(x, y);
                    }
                }
                count++;
            }

            double totalWidth = maxX - minX;
            double totalHeight = maxY - minY;

            // 전체 Line과 Polyline을 검사한 좌표 범위를 확인
            //MessageBox.Show(
            //    $"X 범위: {minX:N2} ~ {maxX:N2}\n" +
            //    $"Y 범위: {minY:N2} ~ {maxY:N2}\n" +
            //    $"도면 폭: {totalWidth:N2}\n" +
            //    $"도면 높이: {totalHeight:N2}",
            //    "전체 좌표 범위"
            //);
            var dxfDocument = new DxfDocument(
                dxfFile,
                result.Layer.Name,
                minX,
                minY,
                maxX,
                maxY
            );

            dxfDocument.Show(dockPanel1, DockState.Document);
        }
        
    }
}
