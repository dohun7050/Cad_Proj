#nullable enable

namespace cad;

using WeifenLuo.WinFormsUI.Docking;

partial class Form1
{
    private System.ComponentModel.IContainer? components;
    private TabControl tabControl1 = null!;
    private Panel headerPanel = null!;
    private Label brandLabel = null!;
    private Button minimizeButton = null!;
    private Button maximizeButton = null!;
    private Button closeButton = null!;
    private TabPage fileTab = null!;
    private TabPage editTab = null!;
    private TabPage routeTab = null!;
    private TabPage designTab = null!;
    private TabPage outputTab = null!;
    private Panel ribbonPanel = null!;
    private FlowLayoutPanel fileMenu = null!;
    private FlowLayoutPanel editMenu = null!;
    private FlowLayoutPanel routeMenu = null!;
    private FlowLayoutPanel designMenu = null!;
    private FlowLayoutPanel outputMenu = null!;
    private Button menuFile = null!;
    private Button menuOpen = null!;
    private Button menuSave = null!;
    private Button menuExport = null!;
    private Button menuEdit = null!;
    private Button menuAreaSelect = null!;
    private Panel editSeparator1 = null!;
    private Button menuPointLineAdd = null!;
    private Button menuModify = null!;
    private Button menuDeleteFeature = null!;
    private Button menuFreeLine = null!;
    private Panel editSeparator2 = null!;
    private Button menuLayer = null!;
    private Panel editSeparator3 = null!;
    private Button menuUndo = null!;
    private Button menuRedo = null!;
    private Button menuOutput = null!;
    private Button menuReport = null!;
    private Button menuDrawing = null!;
    private Button menuTerrain = null!;
    private Button menuHydrology = null!;
    private Button menuEnvironment = null!;
    private Button menuConstraint = null!;
    private Button menuRouteSearch = null!;
    private Button menuAlignment = null!;
    private Button menuProfile = null!;
    private Button menuCrossSection = null!;
    private Button menuEarthwork = null!;
    private Button menuDrainage = null!;
    private Button menuReview = null!;
    private Panel sidebar = null!;
    private Label sidebarTitle = null!;
    private ContextMenuStrip treeContextMenu = null!;
    private ToolStripMenuItem newFolderMenu = null!;
    private ToolStripMenuItem newFileMenu = null!;
    private ToolStripMenuItem copyMenu = null!;
    private ToolStripMenuItem cutMenu = null!;
    private ToolStripMenuItem pasteMenu = null!;
    private ToolStripMenuItem renameMenu = null!;
    private ToolStripMenuItem deleteMenu = null!;
    private ToolStripMenuItem refreshMenu = null!;
    private ToolStripMenuItem openFolderMenu = null!;
    private TreeView treeView1 = null!;
    private Panel contentPanel = null!;
    private DockPanel dockPanel1 = null!;
    private Panel propertyPanel = null!;
    private Label propertyTitle = null!;
    private Label propertyGuide = null!;
    private Panel statusPanel = null!;
    private Label statusLabel = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        tabControl1 = new TabControl();
        fileTab = new TabPage();
        editTab = new TabPage();
        routeTab = new TabPage();
        designTab = new TabPage();
        outputTab = new TabPage();
        headerPanel = new Panel();
        brandLabel = new Label();
        minimizeButton = new Button();
        maximizeButton = new Button();
        closeButton = new Button();
        ribbonPanel = new Panel();
        fileMenu = new FlowLayoutPanel();
        menuFile = new Button();
        menuOpen = new Button();
        menuSave = new Button();
        menuExport = new Button();
        editMenu = new FlowLayoutPanel();
        menuEdit = new Button();
        menuAreaSelect = new Button();
        editSeparator1 = new Panel();
        menuPointLineAdd = new Button();
        menuModify = new Button();
        menuDeleteFeature = new Button();
        menuFreeLine = new Button();
        editSeparator2 = new Panel();
        menuLayer = new Button();
        editSeparator3 = new Panel();
        menuUndo = new Button();
        menuRedo = new Button();
        routeMenu = new FlowLayoutPanel();
        menuTerrain = new Button();
        menuHydrology = new Button();
        menuEnvironment = new Button();
        menuConstraint = new Button();
        menuRouteSearch = new Button();
        designMenu = new FlowLayoutPanel();
        menuAlignment = new Button();
        menuProfile = new Button();
        menuCrossSection = new Button();
        menuEarthwork = new Button();
        menuDrainage = new Button();
        menuReview = new Button();
        outputMenu = new FlowLayoutPanel();
        menuOutput = new Button();
        menuReport = new Button();
        menuDrawing = new Button();
        sidebar = new Panel();
        treeView1 = new TreeView();
        treeContextMenu = new ContextMenuStrip(components);
        newFolderMenu = new ToolStripMenuItem();
        newFileMenu = new ToolStripMenuItem();
        copyMenu = new ToolStripMenuItem();
        cutMenu = new ToolStripMenuItem();
        pasteMenu = new ToolStripMenuItem();
        renameMenu = new ToolStripMenuItem();
        deleteMenu = new ToolStripMenuItem();
        refreshMenu = new ToolStripMenuItem();
        openFolderMenu = new ToolStripMenuItem();
        sidebarTitle = new Label();
        contentPanel = new Panel();
        dockPanel1 = new DockPanel();
        propertyPanel = new Panel();
        propertyGuide = new Label();
        propertyTitle = new Label();
        statusPanel = new Panel();
        statusLabel = new Label();
        vS2015BlueTheme1 = new VS2015BlueTheme();
        label1 = new Label();
        tabControl1.SuspendLayout();
        headerPanel.SuspendLayout();
        ribbonPanel.SuspendLayout();
        fileMenu.SuspendLayout();
        editMenu.SuspendLayout();
        routeMenu.SuspendLayout();
        designMenu.SuspendLayout();
        outputMenu.SuspendLayout();
        sidebar.SuspendLayout();
        treeContextMenu.SuspendLayout();
        contentPanel.SuspendLayout();
        propertyPanel.SuspendLayout();
        statusPanel.SuspendLayout();
        SuspendLayout();
        // 
        // tabControl1
        // 
        tabControl1.Appearance = TabAppearance.FlatButtons;
        tabControl1.Controls.Add(fileTab);
        tabControl1.Controls.Add(editTab);
        tabControl1.Controls.Add(routeTab);
        tabControl1.Controls.Add(designTab);
        tabControl1.Controls.Add(outputTab);
        tabControl1.Dock = DockStyle.Top;
        tabControl1.Font = new Font("맑은 고딕", 10F, FontStyle.Bold);
        tabControl1.ItemSize = new Size(160, 36);
        tabControl1.Location = new Point(0, 42);
        tabControl1.Name = "tabControl1";
        tabControl1.SelectedIndex = 0;
        tabControl1.Size = new Size(1600, 43);
        tabControl1.SizeMode = TabSizeMode.Fixed;
        tabControl1.TabIndex = 6;
        tabControl1.SelectedIndexChanged += TabChanged;
        // 
        // fileTab
        // 
        fileTab.Location = new Point(4, 40);
        fileTab.Name = "fileTab";
        fileTab.Size = new Size(1592, 0);
        fileTab.TabIndex = 0;
        fileTab.Text = "파일";
        fileTab.UseVisualStyleBackColor = true;
        // 
        // editTab
        // 
        editTab.Location = new Point(4, 40);
        editTab.Name = "editTab";
        editTab.Size = new Size(1592, 0);
        editTab.TabIndex = 1;
        editTab.Text = "편집";
        editTab.UseVisualStyleBackColor = true;
        // 
        // routeTab
        // 
        routeTab.Location = new Point(4, 40);
        routeTab.Name = "routeTab";
        routeTab.Size = new Size(1592, 0);
        routeTab.TabIndex = 2;
        routeTab.Text = "전처리/노선";
        routeTab.UseVisualStyleBackColor = true;
        // 
        // designTab
        // 
        designTab.Location = new Point(4, 40);
        designTab.Name = "designTab";
        designTab.Size = new Size(1592, 0);
        designTab.TabIndex = 3;
        designTab.Text = "설계";
        designTab.UseVisualStyleBackColor = true;
        // 
        // outputTab
        // 
        outputTab.Location = new Point(4, 40);
        outputTab.Name = "outputTab";
        outputTab.Size = new Size(1592, 0);
        outputTab.TabIndex = 4;
        outputTab.Text = "결과 출력";
        outputTab.UseVisualStyleBackColor = true;
        // 
        // headerPanel
        // 
        headerPanel.BackColor = Color.FromArgb(7, 38, 67);
        headerPanel.Controls.Add(brandLabel);
        headerPanel.Controls.Add(minimizeButton);
        headerPanel.Controls.Add(maximizeButton);
        headerPanel.Controls.Add(closeButton);
        headerPanel.Dock = DockStyle.Top;
        headerPanel.Location = new Point(0, 0);
        headerPanel.Name = "headerPanel";
        headerPanel.Size = new Size(1600, 42);
        headerPanel.TabIndex = 7;
        headerPanel.DoubleClick += HeaderPanel_DoubleClick;
        headerPanel.MouseDown += HeaderPanel_MouseDown;
        // 
        // brandLabel
        // 
        brandLabel.AutoSize = true;
        brandLabel.Font = new Font("맑은 고딕", 12F, FontStyle.Bold);
        brandLabel.ForeColor = Color.White;
        brandLabel.Location = new Point(16, 10);
        brandLabel.Name = "brandLabel";
        brandLabel.Size = new Size(135, 21);
        brandLabel.TabIndex = 0;
        brandLabel.Text = "산림로 CAD 설계";
        brandLabel.MouseDown += HeaderPanel_MouseDown;
        // 
        // minimizeButton
        // 
        minimizeButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        minimizeButton.BackColor = Color.FromArgb(7, 38, 67);
        minimizeButton.FlatAppearance.BorderSize = 0;
        minimizeButton.FlatStyle = FlatStyle.Flat;
        minimizeButton.Font = new Font("Segoe UI", 11F);
        minimizeButton.ForeColor = Color.White;
        minimizeButton.Location = new Point(1464, 0);
        minimizeButton.Name = "minimizeButton";
        minimizeButton.Size = new Size(45, 42);
        minimizeButton.TabIndex = 1;
        minimizeButton.TabStop = false;
        minimizeButton.Text = "─";
        minimizeButton.UseVisualStyleBackColor = false;
        minimizeButton.Click += MinimizeButton_Click;
        // 
        // maximizeButton
        // 
        maximizeButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        maximizeButton.BackColor = Color.FromArgb(7, 38, 67);
        maximizeButton.FlatAppearance.BorderSize = 0;
        maximizeButton.FlatStyle = FlatStyle.Flat;
        maximizeButton.Font = new Font("Segoe UI", 10F);
        maximizeButton.ForeColor = Color.White;
        maximizeButton.Location = new Point(1509, 0);
        maximizeButton.Name = "maximizeButton";
        maximizeButton.Size = new Size(45, 42);
        maximizeButton.TabIndex = 2;
        maximizeButton.TabStop = false;
        maximizeButton.Text = "□";
        maximizeButton.UseVisualStyleBackColor = false;
        maximizeButton.Click += MaximizeButton_Click;
        // 
        // closeButton
        // 
        closeButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        closeButton.BackColor = Color.FromArgb(7, 38, 67);
        closeButton.FlatAppearance.BorderSize = 0;
        closeButton.FlatStyle = FlatStyle.Flat;
        closeButton.Font = new Font("Segoe UI", 11F);
        closeButton.ForeColor = Color.White;
        closeButton.Location = new Point(1554, 0);
        closeButton.Name = "closeButton";
        closeButton.Size = new Size(46, 42);
        closeButton.TabIndex = 3;
        closeButton.TabStop = false;
        closeButton.Text = "×";
        closeButton.UseVisualStyleBackColor = false;
        closeButton.Click += CloseButton_Click;
        // 
        // ribbonPanel
        // 
        ribbonPanel.BackColor = Color.FromArgb(250, 252, 255);
        ribbonPanel.Controls.Add(fileMenu);
        ribbonPanel.Controls.Add(editMenu);
        ribbonPanel.Controls.Add(routeMenu);
        ribbonPanel.Controls.Add(designMenu);
        ribbonPanel.Controls.Add(outputMenu);
        ribbonPanel.Dock = DockStyle.Top;
        ribbonPanel.Location = new Point(0, 85);
        ribbonPanel.Name = "ribbonPanel";
        ribbonPanel.Size = new Size(1600, 104);
        ribbonPanel.TabIndex = 5;
        // 
        // fileMenu
        // 
        fileMenu.BackColor = Color.FromArgb(250, 252, 255);
        fileMenu.Controls.Add(menuFile);
        fileMenu.Controls.Add(menuOpen);
        fileMenu.Controls.Add(menuSave);
        fileMenu.Controls.Add(menuExport);
        fileMenu.Dock = DockStyle.Fill;
        fileMenu.Location = new Point(0, 0);
        fileMenu.Name = "fileMenu";
        fileMenu.Padding = new Padding(18, 8, 0, 0);
        fileMenu.Size = new Size(1600, 104);
        fileMenu.TabIndex = 0;
        // 
        // menuFile
        // 
        menuFile.BackColor = Color.FromArgb(247, 250, 253);
        menuFile.FlatStyle = FlatStyle.Flat;
        menuFile.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuFile.Location = new Point(21, 11);
        menuFile.Name = "menuFile";
        menuFile.Size = new Size(128, 84);
        menuFile.TabIndex = 0;
        menuFile.Text = "새 프로젝트";
        menuFile.UseVisualStyleBackColor = false;
        // 
        // menuOpen
        // 
        menuOpen.BackColor = Color.FromArgb(247, 250, 253);
        menuOpen.FlatStyle = FlatStyle.Flat;
        menuOpen.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuOpen.Location = new Point(155, 11);
        menuOpen.Name = "menuOpen";
        menuOpen.Size = new Size(128, 84);
        menuOpen.TabIndex = 1;
        menuOpen.Text = "열기";
        menuOpen.UseVisualStyleBackColor = false;
        menuOpen.Click += menuOpen_Click;
        // 
        // menuSave
        // 
        menuSave.BackColor = Color.FromArgb(247, 250, 253);
        menuSave.FlatStyle = FlatStyle.Flat;
        menuSave.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuSave.Location = new Point(289, 11);
        menuSave.Name = "menuSave";
        menuSave.Size = new Size(128, 84);
        menuSave.TabIndex = 2;
        menuSave.Text = "저장";
        menuSave.UseVisualStyleBackColor = false;
        // 
        // menuExport
        // 
        menuExport.BackColor = Color.FromArgb(247, 250, 253);
        menuExport.FlatStyle = FlatStyle.Flat;
        menuExport.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuExport.Location = new Point(423, 11);
        menuExport.Name = "menuExport";
        menuExport.Size = new Size(128, 84);
        menuExport.TabIndex = 3;
        menuExport.Text = "내보내기";
        menuExport.UseVisualStyleBackColor = false;
        // 
        // editMenu
        // 
        editMenu.BackColor = Color.FromArgb(250, 252, 255);
        editMenu.Controls.Add(menuEdit);
        editMenu.Controls.Add(menuAreaSelect);
        editMenu.Controls.Add(editSeparator1);
        editMenu.Controls.Add(menuPointLineAdd);
        editMenu.Controls.Add(menuModify);
        editMenu.Controls.Add(menuDeleteFeature);
        editMenu.Controls.Add(menuFreeLine);
        editMenu.Controls.Add(editSeparator2);
        editMenu.Controls.Add(menuLayer);
        editMenu.Controls.Add(editSeparator3);
        editMenu.Controls.Add(menuUndo);
        editMenu.Controls.Add(menuRedo);
        editMenu.Dock = DockStyle.Fill;
        editMenu.Location = new Point(0, 0);
        editMenu.Name = "editMenu";
        editMenu.Padding = new Padding(18, 8, 0, 0);
        editMenu.Size = new Size(1600, 104);
        editMenu.TabIndex = 1;
        editMenu.Visible = false;
        // 
        // menuEdit
        // 
        menuEdit.BackColor = Color.FromArgb(247, 250, 253);
        menuEdit.FlatStyle = FlatStyle.Flat;
        menuEdit.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuEdit.Location = new Point(21, 11);
        menuEdit.Name = "menuEdit";
        menuEdit.Size = new Size(128, 84);
        menuEdit.TabIndex = 0;
        menuEdit.Text = "선택";
        menuEdit.UseVisualStyleBackColor = false;
        // 
        // menuAreaSelect
        // 
        menuAreaSelect.BackColor = Color.FromArgb(247, 250, 253);
        menuAreaSelect.FlatStyle = FlatStyle.Flat;
        menuAreaSelect.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuAreaSelect.Location = new Point(155, 11);
        menuAreaSelect.Name = "menuAreaSelect";
        menuAreaSelect.Size = new Size(128, 84);
        menuAreaSelect.TabIndex = 1;
        menuAreaSelect.Text = "영역 선택";
        menuAreaSelect.UseVisualStyleBackColor = false;
        // 
        // editSeparator1
        // 
        editSeparator1.BackColor = Color.FromArgb(205, 214, 224);
        editSeparator1.Location = new Point(294, 16);
        editSeparator1.Margin = new Padding(8, 8, 8, 0);
        editSeparator1.Name = "editSeparator1";
        editSeparator1.Size = new Size(1, 68);
        editSeparator1.TabIndex = 2;
        // 
        // menuPointLineAdd
        // 
        menuPointLineAdd.BackColor = Color.FromArgb(247, 250, 253);
        menuPointLineAdd.FlatStyle = FlatStyle.Flat;
        menuPointLineAdd.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuPointLineAdd.Location = new Point(306, 11);
        menuPointLineAdd.Name = "menuPointLineAdd";
        menuPointLineAdd.Size = new Size(128, 84);
        menuPointLineAdd.TabIndex = 3;
        menuPointLineAdd.Text = "점/선 추가";
        menuPointLineAdd.UseVisualStyleBackColor = false;
        // 
        // menuModify
        // 
        menuModify.BackColor = Color.FromArgb(247, 250, 253);
        menuModify.FlatStyle = FlatStyle.Flat;
        menuModify.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuModify.Location = new Point(440, 11);
        menuModify.Name = "menuModify";
        menuModify.Size = new Size(128, 84);
        menuModify.TabIndex = 4;
        menuModify.Text = "수정";
        menuModify.UseVisualStyleBackColor = false;
        // 
        // menuDeleteFeature
        // 
        menuDeleteFeature.BackColor = Color.FromArgb(247, 250, 253);
        menuDeleteFeature.FlatStyle = FlatStyle.Flat;
        menuDeleteFeature.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuDeleteFeature.Location = new Point(574, 11);
        menuDeleteFeature.Name = "menuDeleteFeature";
        menuDeleteFeature.Size = new Size(128, 84);
        menuDeleteFeature.TabIndex = 5;
        menuDeleteFeature.Text = "삭제";
        menuDeleteFeature.UseVisualStyleBackColor = false;
        // 
        // menuFreeLine
        // 
        menuFreeLine.BackColor = Color.FromArgb(247, 250, 253);
        menuFreeLine.FlatStyle = FlatStyle.Flat;
        menuFreeLine.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuFreeLine.Location = new Point(708, 11);
        menuFreeLine.Name = "menuFreeLine";
        menuFreeLine.Size = new Size(128, 84);
        menuFreeLine.TabIndex = 6;
        menuFreeLine.Text = "자유선";
        menuFreeLine.UseVisualStyleBackColor = false;
        // 
        // editSeparator2
        // 
        editSeparator2.BackColor = Color.FromArgb(205, 214, 224);
        editSeparator2.Location = new Point(847, 16);
        editSeparator2.Margin = new Padding(8, 8, 8, 0);
        editSeparator2.Name = "editSeparator2";
        editSeparator2.Size = new Size(1, 68);
        editSeparator2.TabIndex = 7;
        // 
        // menuLayer
        // 
        menuLayer.BackColor = Color.FromArgb(247, 250, 253);
        menuLayer.FlatStyle = FlatStyle.Flat;
        menuLayer.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuLayer.Location = new Point(859, 11);
        menuLayer.Name = "menuLayer";
        menuLayer.Size = new Size(128, 84);
        menuLayer.TabIndex = 8;
        menuLayer.Text = "레이어";
        menuLayer.UseVisualStyleBackColor = false;
        // 
        // editSeparator3
        // 
        editSeparator3.BackColor = Color.FromArgb(205, 214, 224);
        editSeparator3.Location = new Point(998, 16);
        editSeparator3.Margin = new Padding(8, 8, 8, 0);
        editSeparator3.Name = "editSeparator3";
        editSeparator3.Size = new Size(1, 68);
        editSeparator3.TabIndex = 9;
        // 
        // menuUndo
        // 
        menuUndo.BackColor = Color.FromArgb(247, 250, 253);
        menuUndo.FlatStyle = FlatStyle.Flat;
        menuUndo.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuUndo.Location = new Point(1010, 11);
        menuUndo.Name = "menuUndo";
        menuUndo.Size = new Size(128, 84);
        menuUndo.TabIndex = 10;
        menuUndo.Text = "실행 취소";
        menuUndo.UseVisualStyleBackColor = false;
        // 
        // menuRedo
        // 
        menuRedo.BackColor = Color.FromArgb(247, 250, 253);
        menuRedo.FlatStyle = FlatStyle.Flat;
        menuRedo.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuRedo.Location = new Point(1144, 11);
        menuRedo.Name = "menuRedo";
        menuRedo.Size = new Size(128, 84);
        menuRedo.TabIndex = 11;
        menuRedo.Text = "다시 입력";
        menuRedo.UseVisualStyleBackColor = false;
        // 
        // routeMenu
        // 
        routeMenu.BackColor = Color.FromArgb(250, 252, 255);
        routeMenu.Controls.Add(menuTerrain);
        routeMenu.Controls.Add(menuHydrology);
        routeMenu.Controls.Add(menuEnvironment);
        routeMenu.Controls.Add(menuConstraint);
        routeMenu.Controls.Add(menuRouteSearch);
        routeMenu.Dock = DockStyle.Fill;
        routeMenu.Location = new Point(0, 0);
        routeMenu.Name = "routeMenu";
        routeMenu.Padding = new Padding(18, 8, 0, 0);
        routeMenu.Size = new Size(1600, 104);
        routeMenu.TabIndex = 2;
        routeMenu.Visible = false;
        // 
        // menuTerrain
        // 
        menuTerrain.BackColor = Color.FromArgb(247, 250, 253);
        menuTerrain.FlatStyle = FlatStyle.Flat;
        menuTerrain.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuTerrain.Location = new Point(21, 11);
        menuTerrain.Name = "menuTerrain";
        menuTerrain.Size = new Size(128, 84);
        menuTerrain.TabIndex = 0;
        menuTerrain.Text = "3D 지형 생성";
        menuTerrain.UseVisualStyleBackColor = false;
        // 
        // menuHydrology
        // 
        menuHydrology.BackColor = Color.FromArgb(247, 250, 253);
        menuHydrology.FlatStyle = FlatStyle.Flat;
        menuHydrology.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuHydrology.Location = new Point(155, 11);
        menuHydrology.Name = "menuHydrology";
        menuHydrology.Size = new Size(128, 84);
        menuHydrology.TabIndex = 1;
        menuHydrology.Text = "수권 분석";
        menuHydrology.UseVisualStyleBackColor = false;
        // 
        // menuEnvironment
        // 
        menuEnvironment.BackColor = Color.FromArgb(247, 250, 253);
        menuEnvironment.FlatStyle = FlatStyle.Flat;
        menuEnvironment.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuEnvironment.Location = new Point(289, 11);
        menuEnvironment.Name = "menuEnvironment";
        menuEnvironment.Size = new Size(128, 84);
        menuEnvironment.TabIndex = 2;
        menuEnvironment.Text = "환경 분석";
        menuEnvironment.UseVisualStyleBackColor = false;
        // 
        // menuConstraint
        // 
        menuConstraint.BackColor = Color.FromArgb(247, 250, 253);
        menuConstraint.FlatStyle = FlatStyle.Flat;
        menuConstraint.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuConstraint.Location = new Point(423, 11);
        menuConstraint.Name = "menuConstraint";
        menuConstraint.Size = new Size(128, 84);
        menuConstraint.TabIndex = 3;
        menuConstraint.Text = "제약 조건 설정";
        menuConstraint.UseVisualStyleBackColor = false;
        // 
        // menuRouteSearch
        // 
        menuRouteSearch.BackColor = Color.FromArgb(247, 250, 253);
        menuRouteSearch.FlatStyle = FlatStyle.Flat;
        menuRouteSearch.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuRouteSearch.Location = new Point(557, 11);
        menuRouteSearch.Name = "menuRouteSearch";
        menuRouteSearch.Size = new Size(128, 84);
        menuRouteSearch.TabIndex = 4;
        menuRouteSearch.Text = "노선 탐색";
        menuRouteSearch.UseVisualStyleBackColor = false;
        // 
        // designMenu
        // 
        designMenu.BackColor = Color.FromArgb(250, 252, 255);
        designMenu.Controls.Add(menuAlignment);
        designMenu.Controls.Add(menuProfile);
        designMenu.Controls.Add(menuCrossSection);
        designMenu.Controls.Add(menuEarthwork);
        designMenu.Controls.Add(menuDrainage);
        designMenu.Controls.Add(menuReview);
        designMenu.Dock = DockStyle.Fill;
        designMenu.Location = new Point(0, 0);
        designMenu.Name = "designMenu";
        designMenu.Padding = new Padding(18, 8, 0, 0);
        designMenu.Size = new Size(1600, 104);
        designMenu.TabIndex = 3;
        designMenu.Visible = false;
        // 
        // menuAlignment
        // 
        menuAlignment.BackColor = Color.FromArgb(247, 250, 253);
        menuAlignment.FlatStyle = FlatStyle.Flat;
        menuAlignment.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuAlignment.Location = new Point(21, 11);
        menuAlignment.Name = "menuAlignment";
        menuAlignment.Size = new Size(128, 84);
        menuAlignment.TabIndex = 0;
        menuAlignment.Text = "선형 완화";
        menuAlignment.UseVisualStyleBackColor = false;
        // 
        // menuProfile
        // 
        menuProfile.BackColor = Color.FromArgb(247, 250, 253);
        menuProfile.FlatStyle = FlatStyle.Flat;
        menuProfile.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuProfile.Location = new Point(155, 11);
        menuProfile.Name = "menuProfile";
        menuProfile.Size = new Size(128, 84);
        menuProfile.TabIndex = 1;
        menuProfile.Text = "종단면 설정";
        menuProfile.UseVisualStyleBackColor = false;
        // 
        // menuCrossSection
        // 
        menuCrossSection.BackColor = Color.FromArgb(247, 250, 253);
        menuCrossSection.FlatStyle = FlatStyle.Flat;
        menuCrossSection.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuCrossSection.Location = new Point(289, 11);
        menuCrossSection.Name = "menuCrossSection";
        menuCrossSection.Size = new Size(128, 84);
        menuCrossSection.TabIndex = 2;
        menuCrossSection.Text = "횡단면 설정";
        menuCrossSection.UseVisualStyleBackColor = false;
        // 
        // menuEarthwork
        // 
        menuEarthwork.BackColor = Color.FromArgb(247, 250, 253);
        menuEarthwork.FlatStyle = FlatStyle.Flat;
        menuEarthwork.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuEarthwork.Location = new Point(423, 11);
        menuEarthwork.Name = "menuEarthwork";
        menuEarthwork.Size = new Size(128, 84);
        menuEarthwork.TabIndex = 3;
        menuEarthwork.Text = "토공 분석";
        menuEarthwork.UseVisualStyleBackColor = false;
        // 
        // menuDrainage
        // 
        menuDrainage.BackColor = Color.FromArgb(247, 250, 253);
        menuDrainage.FlatStyle = FlatStyle.Flat;
        menuDrainage.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuDrainage.Location = new Point(557, 11);
        menuDrainage.Name = "menuDrainage";
        menuDrainage.Size = new Size(128, 84);
        menuDrainage.TabIndex = 4;
        menuDrainage.Text = "배수/구조물";
        menuDrainage.UseVisualStyleBackColor = false;
        // 
        // menuReview
        // 
        menuReview.BackColor = Color.FromArgb(247, 250, 253);
        menuReview.FlatStyle = FlatStyle.Flat;
        menuReview.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuReview.Location = new Point(691, 11);
        menuReview.Name = "menuReview";
        menuReview.Size = new Size(128, 84);
        menuReview.TabIndex = 5;
        menuReview.Text = "검토";
        menuReview.UseVisualStyleBackColor = false;
        // 
        // outputMenu
        // 
        outputMenu.BackColor = Color.FromArgb(250, 252, 255);
        outputMenu.Controls.Add(menuOutput);
        outputMenu.Controls.Add(menuReport);
        outputMenu.Controls.Add(menuDrawing);
        outputMenu.Dock = DockStyle.Fill;
        outputMenu.Location = new Point(0, 0);
        outputMenu.Name = "outputMenu";
        outputMenu.Padding = new Padding(18, 8, 0, 0);
        outputMenu.Size = new Size(1600, 104);
        outputMenu.TabIndex = 4;
        outputMenu.Visible = false;
        // 
        // menuOutput
        // 
        menuOutput.BackColor = Color.FromArgb(247, 250, 253);
        menuOutput.FlatStyle = FlatStyle.Flat;
        menuOutput.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuOutput.Location = new Point(21, 11);
        menuOutput.Name = "menuOutput";
        menuOutput.Size = new Size(128, 84);
        menuOutput.TabIndex = 0;
        menuOutput.Text = "노선 비교";
        menuOutput.UseVisualStyleBackColor = false;
        // 
        // menuReport
        // 
        menuReport.BackColor = Color.FromArgb(247, 250, 253);
        menuReport.FlatStyle = FlatStyle.Flat;
        menuReport.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuReport.Location = new Point(155, 11);
        menuReport.Name = "menuReport";
        menuReport.Size = new Size(128, 84);
        menuReport.TabIndex = 1;
        menuReport.Text = "보고서";
        menuReport.UseVisualStyleBackColor = false;
        // 
        // menuDrawing
        // 
        menuDrawing.BackColor = Color.FromArgb(247, 250, 253);
        menuDrawing.FlatStyle = FlatStyle.Flat;
        menuDrawing.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        menuDrawing.Location = new Point(289, 11);
        menuDrawing.Name = "menuDrawing";
        menuDrawing.Size = new Size(128, 84);
        menuDrawing.TabIndex = 2;
        menuDrawing.Text = "도면 생성";
        menuDrawing.UseVisualStyleBackColor = false;
        // 
        // sidebar
        // 
        sidebar.BackColor = Color.White;
        sidebar.Controls.Add(treeView1);
        sidebar.Controls.Add(sidebarTitle);
        sidebar.Dock = DockStyle.Left;
        sidebar.Location = new Point(0, 189);
        sidebar.Name = "sidebar";
        sidebar.Padding = new Padding(0, 0, 1, 0);
        sidebar.Size = new Size(315, 675);
        sidebar.TabIndex = 3;
        // 
        // treeView1
        // 
        treeView1.AllowDrop = true;
        treeView1.BorderStyle = BorderStyle.None;
        treeView1.ContextMenuStrip = treeContextMenu;
        treeView1.Dock = DockStyle.Fill;
        treeView1.Font = new Font("맑은 고딕", 9.5F);
        treeView1.HideSelection = false;
        treeView1.Indent = 22;
        treeView1.ItemHeight = 28;
        treeView1.LineColor = Color.FromArgb(185, 198, 212);
        treeView1.Location = new Point(0, 42);
        treeView1.Name = "treeView1";
        treeView1.ShowNodeToolTips = true;
        treeView1.Size = new Size(314, 633);
        treeView1.TabIndex = 0;
        treeView1.ItemDrag += Tree_ItemDrag;
        treeView1.NodeMouseClick += Tree_NodeMouseClick;
        treeView1.NodeMouseDoubleClick += Tree_NodeMouseDoubleClick;
        treeView1.DragDrop += Tree_DragDrop;
        treeView1.DragEnter += Tree_DragEnter;
        treeView1.KeyDown += Tree_KeyDown;
        // 
        // treeContextMenu
        // 
        treeContextMenu.Items.AddRange(new ToolStripItem[] { newFolderMenu, newFileMenu, copyMenu, cutMenu, pasteMenu, renameMenu, deleteMenu, refreshMenu, openFolderMenu });
        treeContextMenu.Name = "treeContextMenu";
        treeContextMenu.Size = new Size(191, 202);
        // 
        // newFolderMenu
        // 
        newFolderMenu.Name = "newFolderMenu";
        newFolderMenu.ShortcutKeyDisplayString = "Ctrl+Shift+N";
        newFolderMenu.Size = new Size(190, 22);
        newFolderMenu.Text = "새 폴더";
        newFolderMenu.Click += AddFolder_Click;
        // 
        // newFileMenu
        // 
        newFileMenu.Name = "newFileMenu";
        newFileMenu.Size = new Size(190, 22);
        newFileMenu.Text = "새 파일";
        newFileMenu.Click += AddFile_Click;
        // 
        // copyMenu
        // 
        copyMenu.Name = "copyMenu";
        copyMenu.ShortcutKeys = Keys.Control | Keys.C;
        copyMenu.Size = new Size(190, 22);
        copyMenu.Text = "복사";
        copyMenu.Click += CopyMenu_Click;
        // 
        // cutMenu
        // 
        cutMenu.Name = "cutMenu";
        cutMenu.ShortcutKeys = Keys.Control | Keys.X;
        cutMenu.Size = new Size(190, 22);
        cutMenu.Text = "잘라내기";
        cutMenu.Click += CutMenu_Click;
        // 
        // pasteMenu
        // 
        pasteMenu.Name = "pasteMenu";
        pasteMenu.ShortcutKeys = Keys.Control | Keys.V;
        pasteMenu.Size = new Size(190, 22);
        pasteMenu.Text = "붙여넣기";
        pasteMenu.Click += PasteMenu_Click;
        // 
        // renameMenu
        // 
        renameMenu.Name = "renameMenu";
        renameMenu.ShortcutKeys = Keys.F2;
        renameMenu.Size = new Size(190, 22);
        renameMenu.Text = "이름 바꾸기";
        renameMenu.Click += RenameMenu_Click;
        // 
        // deleteMenu
        // 
        deleteMenu.Name = "deleteMenu";
        deleteMenu.ShortcutKeys = Keys.Delete;
        deleteMenu.Size = new Size(190, 22);
        deleteMenu.Text = "삭제";
        deleteMenu.Click += Delete_Click;
        // 
        // refreshMenu
        // 
        refreshMenu.Name = "refreshMenu";
        refreshMenu.ShortcutKeys = Keys.F5;
        refreshMenu.Size = new Size(190, 22);
        refreshMenu.Text = "새로고침";
        refreshMenu.Click += Refresh_Click;
        // 
        // openFolderMenu
        // 
        openFolderMenu.Name = "openFolderMenu";
        openFolderMenu.Size = new Size(190, 22);
        openFolderMenu.Text = "파일 탐색기에서 열기";
        openFolderMenu.Click += OpenFolder_Click;
        // 
        // sidebarTitle
        // 
        sidebarTitle.BackColor = Color.FromArgb(232, 240, 249);
        sidebarTitle.Dock = DockStyle.Top;
        sidebarTitle.Font = new Font("맑은 고딕", 10F, FontStyle.Bold);
        sidebarTitle.Location = new Point(0, 0);
        sidebarTitle.Name = "sidebarTitle";
        sidebarTitle.Padding = new Padding(13, 12, 0, 0);
        sidebarTitle.Size = new Size(314, 42);
        sidebarTitle.TabIndex = 1;
        sidebarTitle.Text = "프로젝트 탐색기";
        // 
        // contentPanel
        // 
        contentPanel.BackColor = Color.FromArgb(218, 226, 235);
        contentPanel.Controls.Add(dockPanel1);
        contentPanel.Dock = DockStyle.Fill;
        contentPanel.Location = new Point(315, 189);
        contentPanel.Name = "contentPanel";
        contentPanel.Padding = new Padding(14);
        contentPanel.Size = new Size(1000, 675);
        contentPanel.TabIndex = 1;
        // 
        // dockPanel1
        // 
        dockPanel1.AllowDrop = true;
        dockPanel1.BackColor = Color.FromArgb(34, 39, 46);
        dockPanel1.Dock = DockStyle.Fill;
        dockPanel1.Location = new Point(14, 14);
        dockPanel1.Name = "dockPanel1";
        dockPanel1.Size = new Size(972, 647);
        dockPanel1.TabIndex = 0;
        dockPanel1.DragDrop += DockPanel_DragDrop;
        dockPanel1.DragEnter += DockPanel_DragEnter;
        // 
        // propertyPanel
        // 
        propertyPanel.BackColor = Color.White;
        propertyPanel.Controls.Add(propertyGuide);
        propertyPanel.Controls.Add(propertyTitle);
        propertyPanel.Dock = DockStyle.Right;
        propertyPanel.Location = new Point(1315, 189);
        propertyPanel.Name = "propertyPanel";
        propertyPanel.Padding = new Padding(1, 0, 0, 0);
        propertyPanel.Size = new Size(285, 675);
        propertyPanel.TabIndex = 2;
        // 
        // propertyGuide
        // 
        propertyGuide.BackColor = Color.White;
        propertyGuide.Dock = DockStyle.Top;
        propertyGuide.ForeColor = Color.FromArgb(92, 108, 124);
        propertyGuide.Location = new Point(1, 43);
        propertyGuide.Name = "propertyGuide";
        propertyGuide.Padding = new Padding(14, 16, 10, 0);
        propertyGuide.Size = new Size(284, 80);
        propertyGuide.TabIndex = 0;
        propertyGuide.Text = "선택한 객체의 속성이 표시됩니다.";
        // 
        // propertyTitle
        // 
        propertyTitle.BackColor = Color.FromArgb(232, 240, 249);
        propertyTitle.Dock = DockStyle.Top;
        propertyTitle.Font = new Font("맑은 고딕", 10F, FontStyle.Bold);
        propertyTitle.Location = new Point(1, 0);
        propertyTitle.Name = "propertyTitle";
        propertyTitle.Padding = new Padding(14, 12, 0, 0);
        propertyTitle.Size = new Size(284, 43);
        propertyTitle.TabIndex = 1;
        propertyTitle.Text = "속성 / 설정";
        // 
        // statusPanel
        // 
        statusPanel.BackColor = Color.FromArgb(5, 34, 60);
        statusPanel.Controls.Add(statusLabel);
        statusPanel.Controls.Add(label1);
        statusPanel.Dock = DockStyle.Bottom;
        statusPanel.Location = new Point(0, 864);
        statusPanel.Name = "statusPanel";
        statusPanel.Size = new Size(1600, 36);
        statusPanel.TabIndex = 4;
        // 
        // statusLabel
        // 
        statusLabel.Dock = DockStyle.Fill;
        statusLabel.ForeColor = Color.White;
        statusLabel.Location = new Point(0, 0);
        statusLabel.Name = "statusLabel";
        statusLabel.Padding = new Padding(12, 9, 0, 0);
        statusLabel.Size = new Size(1600, 36);
        statusLabel.TabIndex = 0;
        statusLabel.Text = "준비   |   좌표계 EPSG:5179   |   축척 1:5,000";
        // 
        // label1
        // 
        label1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        label1.AutoSize = false;
        label1.BackColor = Color.Transparent;
        label1.Dock = DockStyle.Right;
        label1.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
        label1.ForeColor = Color.White;
        label1.Location = new Point(1250, 0);
        label1.Name = "dxfCountLabel";
        label1.Padding = new Padding(0, 0, 12, 0);
        label1.Size = new Size(350, 36);
        label1.TabIndex = 4;
        label1.Text = "객체: 0  |  선: 0  |  폴리선: 0  |  영역: 0";
        label1.TextAlign = ContentAlignment.MiddleRight;
        // 
        // Form1
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.FromArgb(240, 244, 249);
        ClientSize = new Size(1600, 900);
        Controls.Add(contentPanel);
        Controls.Add(propertyPanel);
        Controls.Add(sidebar);
        Controls.Add(statusPanel);
        Controls.Add(ribbonPanel);
        Controls.Add(tabControl1);
        Controls.Add(headerPanel);
        FormBorderStyle = FormBorderStyle.None;
        MinimumSize = new Size(1200, 720);
        Name = "Form1";
        Text = "산림로 CAD 설계";
        WindowState = FormWindowState.Maximized;
        tabControl1.ResumeLayout(false);
        headerPanel.ResumeLayout(false);
        headerPanel.PerformLayout();
        ribbonPanel.ResumeLayout(false);
        fileMenu.ResumeLayout(false);
        editMenu.ResumeLayout(false);
        routeMenu.ResumeLayout(false);
        designMenu.ResumeLayout(false);
        outputMenu.ResumeLayout(false);
        sidebar.ResumeLayout(false);
        treeContextMenu.ResumeLayout(false);
        contentPanel.ResumeLayout(false);
        propertyPanel.ResumeLayout(false);
        statusPanel.ResumeLayout(false);
        statusPanel.PerformLayout();
        ResumeLayout(false);
    }

    private VS2015BlueTheme vS2015BlueTheme1;
    private Label label1;
}
