namespace cad;

public partial class Form1
{
    private void TabChanged(object? sender, EventArgs e) => ShowMenu(tabControl1.SelectedIndex);

    private void ShowMenu(int index)
    {
        fileMenu.Visible = index == 0; editMenu.Visible = index == 1; routeMenu.Visible = index == 2;
        designMenu.Visible = index == 3; outputMenu.Visible = index == 4;
        if (index == 0) fileMenu.BringToFront(); else if (index == 1) editMenu.BringToFront();
        else if (index == 2) routeMenu.BringToFront(); else if (index == 3) designMenu.BringToFront(); else outputMenu.BringToFront();
        UpdateBottomStatus(index);
    }

    private void ApplyRibbonStyle()
    {
        ConfigureFileTab(); ConfigureEditTab(); ConfigurePathTab(); ConfigureDesignTab(); ConfigureResultTab();
    }

    private static void ConfigureRibbonButton(Button button, string fileName)
    {
        string path = Path.Combine(AppContext.BaseDirectory, "Icons", fileName);
        if (File.Exists(path)) { using Image image = Image.FromFile(path); button.Image = new Bitmap(image); }
        button.ImageAlign = ContentAlignment.TopCenter; button.TextAlign = ContentAlignment.BottomCenter;
        button.TextImageRelation = TextImageRelation.ImageAboveText; button.Padding = new Padding(4, 6, 4, 5);
        button.Margin = new Padding(4, 2, 4, 2); button.FlatAppearance.BorderSize = 0; button.Cursor = Cursors.Hand;
        button.MouseEnter += RibbonButton_MouseEnter; button.MouseLeave += RibbonButton_MouseLeave;
    }
    private static void RibbonButton_MouseEnter(object? sender, EventArgs e) { if (sender is Button b) b.BackColor = Color.FromArgb(228,239,252); }
    private static void RibbonButton_MouseLeave(object? sender, EventArgs e) { if (sender is Button b) b.BackColor = Color.FromArgb(247,250,253); }
}
