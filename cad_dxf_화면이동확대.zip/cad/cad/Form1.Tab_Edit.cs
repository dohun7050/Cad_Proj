namespace cad;
public partial class Form1 { 
    private void ConfigureEditTab() { 
        ConfigureRibbonButton(menuEdit,"select.png"); 
        ConfigureRibbonButton(menuAreaSelect,"area_select.png"); 
        ConfigureRibbonButton(menuPointLineAdd,"point_line_add.png"); 
        ConfigureRibbonButton(menuModify,"modify.png"); 
        ConfigureRibbonButton(menuDeleteFeature,"delete.png"); 
        ConfigureRibbonButton(menuFreeLine,"free_line.png"); 
        ConfigureRibbonButton(menuLayer,"layer.png"); 
        ConfigureRibbonButton(menuUndo,"undo.png"); 
        ConfigureRibbonButton(menuRedo,"redo.png"); 
    } 
}
