using System.Diagnostics;
using System.Runtime.InteropServices;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

public partial class Form1
{


    private static string SafeName(string name) => string.Concat(name.Where(c => !Path.GetInvalidFileNameChars().Contains(c))).Trim();

    private static string Prompt(string label, string title)
    {
        using var form = new Form { Text = title, Width = 420, Height = 155, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false };
        var text = new TextBox { Left = 18, Top = 38, Width = 365 };
        var ok = new Button { Text = "확인", Left = 223, Top = 76, Width = 78, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "취소", Left = 305, Top = 76, Width = 78, DialogResult = DialogResult.Cancel };
        form.Controls.Add(new Label { Text = label, Left = 18, Top = 14, AutoSize = true }); form.Controls.Add(text); form.Controls.Add(ok); form.Controls.Add(cancel);
        form.AcceptButton = ok; form.CancelButton = cancel;
        return form.ShowDialog() == DialogResult.OK ? text.Text : string.Empty;
    }
}