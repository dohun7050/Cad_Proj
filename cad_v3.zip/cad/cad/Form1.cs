using System.Diagnostics;
using System.Runtime.InteropServices;
using WeifenLuo.WinFormsUI.Docking;

namespace cad;

public partial class Form1 : Form
{
    // 프로젝트 탐색기가 읽고 수정할 실제 작업 폴더입니다.
    private readonly string projectRoot = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "cad", "ProjectFiles");
    // 내부 클립보드: 복사/잘라내기 대상과 작업 종류를 기억합니다.
    private string? clipboardPath;
    private bool clipboardCut;

    // 메인 폼의 UI, 도킹 테마, 파일 탐색기와 리본 메뉴를 초기화하는 생성자입니다.
    // DockPanelSuite 테마를 먼저 지정하고 창 제어 버튼을 가장 앞으로 배치합니다.
    public Form1()
    {
        InitializeComponent();

        dockPanel1.Theme = new VS2015BlueTheme();
        LoadFileTree();
        ApplyRibbonStyle();
        minimizeButton.BringToFront();
        maximizeButton.BringToFront();
        closeButton.BringToFront();
        ShowMenu(0);
    }

    // 실제 ProjectFiles 폴더 구조를 읽어 왼쪽 TreeView를 새로 구성하는 함수입니다.
    // BeginUpdate/EndUpdate를 사용해 노드 갱신 중 화면 깜빡임을 줄입니다.
    private void LoadFileTree()
    {
        treeView1.BeginUpdate();
        treeView1.Nodes.Clear();
        if (!Directory.Exists(projectRoot))
        {
            treeView1.Nodes.Add(new TreeNode("ProjectFiles 폴더가 없습니다."));
            treeView1.EndUpdate();
            return;
        }
        var root = CreateNode(new DirectoryInfo(projectRoot));
        treeView1.Nodes.Add(root);
        root.Expand();
        treeView1.EndUpdate();
    }

    // 파일 또는 폴더 정보를 재귀 순회하여 하위 항목까지 포함하는 TreeNode로 변환하는 함수입니다.
    // 각 노드의 Tag에는 화면 표시명이 아닌 실제 전체 경로를 저장합니다.
    private TreeNode CreateNode(FileSystemInfo info)
    {
        bool isDirectory = info is DirectoryInfo;
        var node = new TreeNode(info.Name) { Tag = info.FullName, ImageKey = isDirectory ? "folder" : "file", SelectedImageKey = isDirectory ? "folder" : "file" };
        if (info is DirectoryInfo directory)
        {
            try
            {
                foreach (DirectoryInfo child in directory.GetDirectories().OrderBy(x => x.Name)) node.Nodes.Add(CreateNode(child));
                foreach (FileInfo child in directory.GetFiles().OrderBy(x => x.Name)) node.Nodes.Add(CreateNode(child));
            }
            catch (UnauthorizedAccessException) { }
        }
        return node;
    }

    // 현재 선택한 트리 노드의 실제 경로를 반환하는 속성입니다.
    private string SelectedPath => treeView1.SelectedNode?.Tag as string ?? projectRoot;

    // 현재 선택 항목을 기준으로 파일 작업 대상 폴더 경로를 구하는 함수입니다.
    // 파일이 선택되었다면 해당 파일의 상위 폴더를 반환합니다.
    private string SelectedDirectory()
    {
        string path = SelectedPath;
        return Directory.Exists(path) ? path : Path.GetDirectoryName(path) ?? projectRoot;
    }

    // 우클릭 메뉴에서 새 폴더를 생성하는 함수입니다.
    private void AddFolder_Click(object? sender, EventArgs e)
    {
        string name = Prompt("새 폴더 이름", "폴더 추가");
        if (string.IsNullOrWhiteSpace(name)) return;
        Directory.CreateDirectory(Path.Combine(SelectedDirectory(), SafeName(name)));
        LoadFileTree();
    }

    // 우클릭 메뉴에서 새 빈 파일을 생성하는 함수입니다.
    private void AddFile_Click(object? sender, EventArgs e)
    {
        string name = Prompt("새 파일 이름 (예: 노선.dxf)", "파일 추가");
        if (string.IsNullOrWhiteSpace(name)) return;
        string path = Path.Combine(SelectedDirectory(), SafeName(name));
        if (!File.Exists(path)) File.WriteAllText(path, "새 CAD 프로젝트 파일");
        LoadFileTree();
    }

    // 프로젝트 루트는 보호하고 선택한 파일 또는 폴더를 확인 후 삭제하는 함수입니다.
    private void Delete_Click(object? sender, EventArgs e)
    {
        string path = SelectedPath;
        if (path == projectRoot || (!File.Exists(path) && !Directory.Exists(path))) return;
        if (MessageBox.Show($"'{Path.GetFileName(path)}'을(를) 삭제할까요?", "삭제 확인", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        if (File.Exists(path)) File.Delete(path); else Directory.Delete(path, true);
        LoadFileTree();
    }

    // 이동 메뉴를 누르면 대상 폴더 선택 창을 열어 선택 항목을 이동하는 함수입니다.
    private void Move_Click(object? sender, EventArgs e)
    {
        string source = SelectedPath;
        if (source == projectRoot) return;
        using var dialog = new FolderBrowserDialog { Description = "이동할 대상 폴더 선택", InitialDirectory = projectRoot };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        MovePath(source, dialog.SelectedPath);
    }

    // 지정한 파일 또는 폴더를 ProjectFiles 내부의 대상 폴더로 이동하는 함수입니다.
    // ProjectFiles 바깥으로 이동하지 못하도록 경로를 검사합니다.
    private void MovePath(string source, string targetDirectory)
    {
        if (!targetDirectory.StartsWith(projectRoot, StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("ProjectFiles 폴더 내부로만 이동할 수 있습니다.");
            return;
        }
        string destination = Path.Combine(targetDirectory, Path.GetFileName(source));
        if (File.Exists(destination) || Directory.Exists(destination)) { MessageBox.Show("대상 폴더에 같은 이름이 있습니다."); return; }
        if (File.Exists(source)) File.Move(source, destination); else if (Directory.Exists(source)) Directory.Move(source, destination);
        LoadFileTree();
    }

    // TreeView 노드를 다른 폴더 노드로 끌어 놓으면 실제 파일도 이동합니다.
    private void Tree_ItemDrag(object? sender, ItemDragEventArgs e) => DoDragDrop(e.Item!, DragDropEffects.Move | DragDropEffects.Copy);
    // 드래그한 데이터가 TreeNode인지 확인해 폴더 이동 가능 표시를 설정하는 함수입니다.
    private void Tree_DragEnter(object? sender, DragEventArgs e) => e.Effect = e.Data?.GetDataPresent(typeof(TreeNode)) == true ? DragDropEffects.Move : DragDropEffects.None;
    // 트리의 파일·폴더를 다른 폴더에 놓았을 때 실제 경로를 이동하는 함수입니다.
    private void Tree_DragDrop(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(TreeNode)) is not TreeNode sourceNode) return;
        TreeNode? targetNode = treeView1.GetNodeAt(treeView1.PointToClient(new Point(e.X, e.Y)));
        string? source = sourceNode.Tag as string;
        string? target = targetNode?.Tag as string;
        if (source is null || target is null || !Directory.Exists(target) || source == projectRoot) return;
        MovePath(source, target);
    }

    // 프로젝트 탐색기의 TXT 파일을 더블클릭하면 중앙 문서로 여는 함수입니다.
    private void Tree_NodeMouseDoubleClick(object? sender, TreeNodeMouseClickEventArgs e)
    {
        TreeNode? node = e.Node;
        if (node?.Tag is string path && IsTextDocument(path)) OpenTextDocument(path);
    }

    // 중앙 도킹 영역으로 들어온 드래그 항목이 열 수 있는 TXT 파일인지 판정하는 함수입니다.
    private void DockPanel_DragEnter(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(TreeNode)) is TreeNode node && node.Tag is string path && IsTextDocument(path))
            e.Effect = DragDropEffects.Copy;
        else
            e.Effect = DragDropEffects.None;
    }

    // 중앙 도킹 영역에 놓인 TXT 파일을 문서 탭으로 여는 함수입니다.
    private void DockPanel_DragDrop(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(TreeNode)) is TreeNode node && node.Tag is string path && IsTextDocument(path))
            OpenTextDocument(path);
    }

    // 전달된 경로가 실제로 존재하는 TXT 파일인지 검사하는 함수입니다.
    private static bool IsTextDocument(string path) =>
        File.Exists(path) && Path.GetExtension(path).Equals(".txt", StringComparison.OrdinalIgnoreCase);

    // TXT 파일을 중앙 도킹 문서 탭으로 열거나 이미 열렸다면 기존 탭을 활성화하는 함수입니다.
    private void OpenTextDocument(string path)
    {
        CadDocument? opened = dockPanel1.Documents
            .OfType<CadDocument>()
            .FirstOrDefault(document => string.Equals(document.DocumentPath, path, StringComparison.OrdinalIgnoreCase));

        if (opened != null)
        {
            opened.Activate();
            return;
        }

        var document = new CadDocument(path);
        document.Show(dockPanel1, DockState.Document);
        document.Activate();
    }

    // 선택 항목을 Windows 파일 탐색기에서 표시하는 함수입니다.
    private void OpenFolder_Click(object? sender, EventArgs e) => Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{SelectedPath}\"") { UseShellExecute = true });

    // 실제 폴더 내용을 다시 읽어 프로젝트 탐색기를 새로고침하는 함수입니다.
    private void Refresh_Click(object? sender, EventArgs e) => LoadFileTree();

    // 우클릭한 노드를 현재 선택 노드로 지정해 컨텍스트 메뉴 대상을 맞추는 함수입니다.
    private void Tree_NodeMouseClick(object? sender, TreeNodeMouseClickEventArgs e)
    {
        if (e.Button == MouseButtons.Right) treeView1.SelectedNode = e.Node;
    }

    // 프로젝트 탐색기의 복사·잘라내기·붙여넣기·삭제·이름 변경 단축키를 처리하는 함수입니다.
    private void Tree_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Control && e.KeyCode == Keys.C) { CopySelected(false); e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.X) { CopySelected(true); e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.V) { PasteSelected(); e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.Delete) { Delete_Click(sender, e); e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.F2) { RenameSelected(); e.SuppressKeyPress = true; }
    }

    // 우클릭 메뉴의 복사 명령을 처리하는 함수입니다.
    private void CopyMenu_Click(object? sender, EventArgs e) => CopySelected(false);
    // 우클릭 메뉴의 잘라내기 명령을 처리하는 함수입니다.
    private void CutMenu_Click(object? sender, EventArgs e) => CopySelected(true);
    // 우클릭 메뉴의 붙여넣기 명령을 처리하는 함수입니다.
    private void PasteMenu_Click(object? sender, EventArgs e) => PasteSelected();
    // 우클릭 메뉴의 이름 바꾸기 명령을 처리하는 함수입니다.
    private void RenameMenu_Click(object? sender, EventArgs e) => RenameSelected();

    // 선택 항목을 운영체제 클립보드 대신 프로젝트 내부의 복사 또는 잘라내기 대상으로 저장하는 함수입니다.
    private void CopySelected(bool cut)
    {
        string path = SelectedPath;
        if (path == projectRoot || (!File.Exists(path) && !Directory.Exists(path))) return;
        clipboardPath = path;
        clipboardCut = cut;
        statusLabel.Text = cut ? $"잘라내기: {Path.GetFileName(path)}" : $"복사: {Path.GetFileName(path)}";
    }

    // 임시 저장한 파일 또는 폴더를 현재 선택 폴더에 붙여넣는 함수입니다.
    // 잘라내기는 이동하고 복사는 원본을 유지한 채 새 항목을 생성합니다.
    private void PasteSelected()
    {
        if (string.IsNullOrWhiteSpace(clipboardPath) || (!File.Exists(clipboardPath) && !Directory.Exists(clipboardPath))) return;
        string targetDirectory = SelectedDirectory();
        if (Directory.Exists(clipboardPath) && targetDirectory.StartsWith(clipboardPath + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("폴더를 자기 하위 폴더에 붙여넣을 수 없습니다.");
            return;
        }
        string destination = UniqueDestination(targetDirectory, Path.GetFileName(clipboardPath));
        if (clipboardCut)
        {
            if (File.Exists(clipboardPath)) File.Move(clipboardPath, destination);
            else Directory.Move(clipboardPath, destination);
            clipboardPath = null;
            clipboardCut = false;
        }
        else if (File.Exists(clipboardPath))
        {
            File.Copy(clipboardPath, destination);
        }
        else
        {
            CopyDirectory(clipboardPath, destination);
        }
        LoadFileTree();
    }

    // 선택한 파일 또는 폴더의 이름을 같은 방식으로 변경하는 함수입니다.
    private void RenameSelected()
    {
        string source = SelectedPath;
        if (source == projectRoot || (!File.Exists(source) && !Directory.Exists(source))) return;
        string name = Prompt("새 이름", "이름 바꾸기");
        if (string.IsNullOrWhiteSpace(name)) return;
        string destination = Path.Combine(Path.GetDirectoryName(source)!, SafeName(name));
        if (File.Exists(destination) || Directory.Exists(destination)) { MessageBox.Show("같은 이름이 이미 있습니다."); return; }
        if (File.Exists(source)) File.Move(source, destination); else Directory.Move(source, destination);
        LoadFileTree();
    }

    // 이름이 중복될 때 '복사본 2', '복사본 3'처럼 번호를 붙여 사용 가능한 대상 경로를 만드는 함수입니다.
    private static string UniqueDestination(string directory, string name)
    {
        string destination = Path.Combine(directory, name);
        if (!File.Exists(destination) && !Directory.Exists(destination)) return destination;
        string extension = Path.GetExtension(name);
        string baseName = Path.GetFileNameWithoutExtension(name);
        int number = 2;
        do { destination = Path.Combine(directory, $"{baseName} - 복사본 {number}{extension}"); number++; }
        while (File.Exists(destination) || Directory.Exists(destination));
        return destination;
    }

    // 별도 Directory.Copy API 대신 폴더와 모든 하위 파일·폴더를 재귀적으로 복사하는 함수입니다.
    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (string file in Directory.GetFiles(source)) File.Copy(file, Path.Combine(destination, Path.GetFileName(file)));
        foreach (string directory in Directory.GetDirectories(source)) CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)));
    }
    // 상단 탭이 변경되면 대응하는 리본 메뉴를 표시하는 함수입니다.
    private void TabChanged(object? sender, EventArgs e) => ShowMenu(tabControl1.SelectedIndex);

    // 선택된 상단 탭에 해당하는 리본 메뉴만 화면에 표시하는 함수입니다.
    private void ShowMenu(int index)
    {
        fileMenu.Visible = index == 0;
        editMenu.Visible = index == 1;
        routeMenu.Visible = index == 2;
        designMenu.Visible = index == 3;
        outputMenu.Visible = index == 4;
        if (index == 0) fileMenu.BringToFront();
        if (index == 1) editMenu.BringToFront();
        if (index == 2) routeMenu.BringToFront();
        if (index == 3) designMenu.BringToFront();
        if (index == 4) outputMenu.BringToFront();
        statusLabel.Text = index switch
        {
            0 => "파일 작업   |   좌표계 EPSG:5179   |   축척 1:5,000",
            1 => "편집 작업   |   좌표계 EPSG:5179   |   축척 1:5,000",
            2 => "전처리 · 노선 작업   |   좌표계 EPSG:5179   |   축척 1:5,000",
            3 => "임도 설계 작업   |   좌표계 EPSG:5179   |   축척 1:5,000",
            _ => "결과 출력   |   좌표계 EPSG:5179   |   축척 1:5,000"
        };
    }

    // Icons 폴더의 Fluent UI PNG를 연결하고 각 리본 버튼에 공통 시각 스타일을 적용하는 함수입니다.
    private void ApplyRibbonStyle()
    {
        ConfigureRibbonButton(menuFile, "new_project.png");
        ConfigureRibbonButton(menuOpen, "open.png");
        ConfigureRibbonButton(menuSave, "save.png");
        ConfigureRibbonButton(menuExport, "export.png");
        ConfigureRibbonButton(menuEdit, "select.png");
        ConfigureRibbonButton(menuAreaSelect, "area_select.png");
        ConfigureRibbonButton(menuPointLineAdd, "point_line_add.png");
        ConfigureRibbonButton(menuModify, "modify.png");
        ConfigureRibbonButton(menuDeleteFeature, "delete.png");
        ConfigureRibbonButton(menuFreeLine, "free_line.png");
        ConfigureRibbonButton(menuLayer, "layer.png");
        ConfigureRibbonButton(menuUndo, "undo.png");
        ConfigureRibbonButton(menuRedo, "redo.png");
        ConfigureRibbonButton(menuOutput, "route_compare.png");
        ConfigureRibbonButton(menuReport, "report.png");
        ConfigureRibbonButton(menuDrawing, "drawing.png");
        ConfigureRibbonButton(menuTerrain, "terrain.png");
        ConfigureRibbonButton(menuHydrology, "hydrology.png");
        ConfigureRibbonButton(menuEnvironment, "environment.png");
        ConfigureRibbonButton(menuConstraint, "constraint.png");
        ConfigureRibbonButton(menuRouteSearch, "route.png");
        ConfigureRibbonButton(menuAlignment, "alignment.png");
        ConfigureRibbonButton(menuProfile, "profile.png");
        ConfigureRibbonButton(menuCrossSection, "cross_section.png");
        ConfigureRibbonButton(menuEarthwork, "earthwork.png");
        ConfigureRibbonButton(menuDrainage, "drainage.png");
        ConfigureRibbonButton(menuReview, "review.png");
    }

    // 기본 Windows 제목 표시줄을 제거했으므로 창 제어 버튼을 직접 처리합니다.
    // 사용자 정의 제목 표시줄의 최소화 버튼을 처리하는 함수입니다.
    private void MinimizeButton_Click(object? sender, EventArgs e) => WindowState = FormWindowState.Minimized;
    // 사용자 정의 제목 표시줄의 최대화와 복원을 전환하는 함수입니다.
    private void MaximizeButton_Click(object? sender, EventArgs e) => WindowState = WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
    // 사용자 정의 제목 표시줄의 닫기 버튼을 처리하는 함수입니다.
    private void CloseButton_Click(object? sender, EventArgs e) => Close();
    // 제목 표시줄을 더블클릭했을 때 최대화와 복원을 전환하는 함수입니다.
    private void HeaderPanel_DoubleClick(object? sender, EventArgs e) => MaximizeButton_Click(sender, e);
    // 사용자 정의 남색 제목 표시줄을 마우스로 끌어 메인 창을 이동시키는 함수입니다.
    private void HeaderPanel_MouseDown(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;
        ReleaseCapture();
        SendMessage(Handle, 0xA1, 0x2, 0);
    }

    // Windows에 현재 마우스 캡처를 해제하도록 요청하는 네이티브 함수입니다.
    [DllImport("user32.dll")]
    private static extern bool ReleaseCapture();

    // 제목 표시줄 드래그 메시지를 Windows 창에 전달하는 네이티브 함수입니다.
    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr handle, int message, int wParam, int lParam);

    // 출력 폴더의 PNG를 읽어 리본 버튼 하나에 아이콘, 정렬, 여백 및 마우스 효과를 설정하는 함수입니다.
    private static void ConfigureRibbonButton(Button button, string fileName)
    {
        string iconPath = Path.Combine(AppContext.BaseDirectory, "Icons", fileName);
        if (File.Exists(iconPath))
        {
            using Image source = Image.FromFile(iconPath);
            button.Image = new Bitmap(source);
        }
        button.ImageAlign = ContentAlignment.TopCenter;
        button.TextAlign = ContentAlignment.BottomCenter;
        button.TextImageRelation = TextImageRelation.ImageAboveText;
        button.Padding = new Padding(4, 6, 4, 5);
        button.Margin = new Padding(4, 2, 4, 2);
        button.FlatAppearance.BorderSize = 0;
        button.Cursor = Cursors.Hand;
        button.MouseEnter += RibbonButton_MouseEnter;
        button.MouseLeave += RibbonButton_MouseLeave;
    }

    // 마우스가 리본 버튼 위에 들어오면 강조 배경색을 적용하는 함수입니다.
    private static void RibbonButton_MouseEnter(object? sender, EventArgs e)
    {
        if (sender is Button button) button.BackColor = Color.FromArgb(228, 239, 252);
    }

    // 마우스가 리본 버튼을 벗어나면 기본 배경색으로 복원하는 함수입니다.
    private static void RibbonButton_MouseLeave(object? sender, EventArgs e)
    {
        if (sender is Button button) button.BackColor = Color.FromArgb(247, 250, 253);
    }

    // Windows 파일명에 사용할 수 없는 문자를 제거한 안전한 이름을 반환하는 함수입니다.
    private static string SafeName(string name) => string.Concat(name.Where(c => !Path.GetInvalidFileNameChars().Contains(c))).Trim();

    // 폴더명, 파일명 또는 변경할 이름을 입력받기 위한 공용 소형 대화상자를 표시하는 함수입니다.
    private static string Prompt(string label, string title)
    {
        using var form = new Form { Text = title, Width = 420, Height = 155, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false };
        var text = new TextBox { Left = 18, Top = 38, Width = 365 };
        var ok = new Button { Text = "확인", Left = 223, Top = 76, Width = 78, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "취소", Left = 305, Top = 76, Width = 78, DialogResult = DialogResult.Cancel };
        form.Controls.Add(new Label { Text = label, Left = 18, Top = 14, AutoSize = true }); form.Controls.Add(text); form.Controls.Add(ok); form.Controls.Add(cancel);
        form.AcceptButton = ok; form.CancelButton = cancel;
        return form.ShowDialog() == DialogResult.OK ? text.Text : string.Empty;
    }
}
