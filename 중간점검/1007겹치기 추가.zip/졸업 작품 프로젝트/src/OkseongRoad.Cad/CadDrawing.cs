using ACadSharp;
using ACadSharp.Entities;
using ACadSharp.IO;
using CSMath;

namespace ForestRoad.Cad;

public record CadPoint(double X, double Y, double Z);
public record CadFeature(string Layer, string Kind, List<CadPoint> Points)
{
    public int Argb { get; init; } = unchecked((int)0xffc8d8e5);
    public bool Visible { get; init; } = true;
    public string? Text { get; init; }
    public double TextHeight { get; init; } = 2;
    public double Rotation { get; init; }
}
public record CadLayer(string Name, int EntityCount, int DrawableCount);
public record CadBounds(double MinX, double MinY, double MaxX, double MaxY, double MinZ, double MaxZ);
public record CadDrawing(string Source, string Version, string Units, List<CadFeature> Features,
    List<CadLayer> Layers, CadBounds Bounds, List<string> Warnings);

public static class DrawingReader
{
    // Extraction is read-only. Approximation applies to display curves, not survey accuracy.
    public static CadDrawing Read(string filename)
    {
        filename = Path.GetFullPath(filename);
        if (!File.Exists(filename)) throw new FileNotFoundException("도면 파일을 찾을 수 없습니다.", filename);
        var extension = Path.GetExtension(filename).ToLowerInvariant();
        if (extension is not (".dwg" or ".dxf")) throw new ArgumentException("DWG 또는 DXF 파일을 선택하세요.");
        var warnings = new List<string>();
        void Notice(object sender, NotificationEventArgs e)
        {
            if (warnings.Count < 30) warnings.Add(e.Message);
        }
        var doc = extension == ".dwg" ? DwgReader.Read(filename, Notice) : DxfReader.Read(filename, Notice);
        var features = new List<CadFeature>();
        var counts = new Dictionary<string, int>();
        var skipped = new Dictionary<string, int>();
        foreach (var entity in doc.Entities) Visit(entity, null, 0);

        void Visit(Entity entity, string? parentLayer, int depth)
        {
            if (depth > 16) { warnings.Add("블록 중첩이 16단계를 넘어 해당 블록을 생략했습니다."); return; }
            var layer = entity.Layer?.Name ?? "0";
            if (layer == "0" && parentLayer is not null) layer = parentLayer;
            counts[layer] = counts.GetValueOrDefault(layer) + 1;
            var kind = entity.GetType().Name;
            if (entity is Insert insert)
            {
                try { foreach (var child in insert.Explode()) Visit(child, layer, depth + 1); }
                catch (Exception e) { warnings.Add($"블록 {insert.Block?.Name}: {e.Message}"); }
                return;
            }
            try
            {
                List<CadPoint>? points = entity switch
                {
                    Line line => [P(line.StartPoint), P(line.EndPoint)],
                    LwPolyline poly => PolyPoints(poly.Vertices.Select(v => (new XYZ(v.Location.X, v.Location.Y, poly.Elevation), v.Bulge)).ToList(), poly.IsClosed, poly.Normal, true),
                    Polyline2D poly => PolyPoints(poly.Vertices.Select(v => (new XYZ(v.Location.X, v.Location.Y, poly.Elevation), v.Bulge)).ToList(), poly.IsClosed, poly.Normal, true),
                    Polyline3D poly => PolyPoints(poly.Vertices.Select(v => (v.Location, 0.0)).ToList(), poly.IsClosed, XYZ.AxisZ, false),
                    // ACadSharp 3.8 returns these sampled vertices in WCS already.
                    Arc arc => arc.PolygonalVertexes(128).Select(P).ToList(),
                    Circle circle => Closed(circle.PolygonalVertexes(128).Select(P).ToList()),
                    Spline spline => spline.PolygonalVertexes(128).Select(P).ToList(),
                    TextEntity text => [P(text.InsertPoint)],
                    MText text => [P(text.InsertPoint)],
                    ACadSharp.Entities.Point point => [P(point.Location)],
                    _ => null
                };
                if (points is null || points.Count == 0)
                {
                    skipped[kind] = skipped.GetValueOrDefault(kind) + 1;
                    return;
                }
                if (points.Any(p => !double.IsFinite(p.X) || !double.IsFinite(p.Y) || !double.IsFinite(p.Z)))
                { warnings.Add($"{layer}: 유한하지 않은 좌표의 {kind} 생략"); return; }
                var rgb = entity.GetActiveColor().GetRgb();
                features.Add(new CadFeature(layer, kind, points) {
                    Argb = unchecked((int)(0xff000000u | ((uint)rgb[0] << 16) | ((uint)rgb[1] << 8) | rgb[2])),
                    Visible = !(entity.IsInvisible) && (entity.Layer?.IsOn ?? true),
                    Text = entity is TextEntity t ? t.Value : entity is MText mt ? mt.PlainText : null,
                    TextHeight = entity is TextEntity th ? th.Height : entity is MText mh ? mh.Height : 2,
                    Rotation = entity is TextEntity tr ? tr.Rotation : entity is MText mr ? mr.Rotation : 0
                });
            }
            catch (Exception e) { warnings.Add($"{layer} / {kind} 생략: {e.Message}"); }
        }

        if (features.Count == 0) throw new InvalidDataException("표시할 선 또는 점을 추출하지 못했습니다. 객체 형식과 모델 공간을 확인하세요.");
        var vertices = features.SelectMany(f => f.Points).ToList();
        var bounds = new CadBounds(vertices.Min(p => p.X), vertices.Min(p => p.Y), vertices.Max(p => p.X), vertices.Max(p => p.Y), vertices.Min(p => p.Z), vertices.Max(p => p.Z));
        var layers = counts.OrderBy(p => p.Key).Select(p => new CadLayer(p.Key, p.Value, features.Count(f => f.Layer == p.Key))).ToList();
        warnings.Add("모델 공간의 지원 선·점·문자를 표시합니다. 해치·치수·Civil 3D 전용 객체 등은 전체 CAD 렌더링 대상이 아닙니다.");
        warnings.Add("원본 객체의 Z를 보존했습니다. 표고 문자와 선의 고도 연결, 좌표계 변환은 수행하지 않았습니다.");
        if (doc.Header.InsUnits.ToString() != "Meters") warnings.Add("도면 단위가 Meters가 아닙니다. 미터 기반 계산 전에 단위 확인/변환이 필요합니다.");
        if (skipped.Count > 0) warnings.Add("미표시 객체: " + string.Join(", ", skipped.Select(p => $"{p.Key} {p.Value}")));
        if (vertices.All(p => Math.Abs(p.Z) < 1e-9)) warnings.Add("추출한 모든 Z가 0입니다. 실제 등고선 고도가 문자/속성 등에 저장되었는지 확인해야 합니다.");
        warnings.Add("곡선 및 폴리라인의 곡선 구간은 화면 표시용으로 분할 근사합니다. 정밀 지형 계산 전에 분할 정밀도를 검토하세요.");
        return new CadDrawing(filename, doc.Header.Version.ToString(), doc.Header.InsUnits.ToString(), features, layers, bounds, warnings.Distinct().ToList());
    }

    private static CadPoint P(XYZ p) => new(p.X, p.Y, p.Z);

    private static List<CadPoint> Closed(List<CadPoint> points)
    {
        if (points.Count > 1 && points[0] != points[^1]) points.Add(points[0]);
        return points;
    }

    private static List<CadPoint> PolyPoints(List<(XYZ Point, double Bulge)> vertices, bool closed, XYZ normal, bool ocs)
    {
        var result = new List<CadPoint>();
        if (vertices.Count == 0) return result;
        CadPoint Convert(XYZ p) => ocs ? Ocs(p, normal) : P(p);
        result.Add(Convert(vertices[0].Point));
        var edges = closed ? vertices.Count : vertices.Count - 1;
        for (int i = 0; i < edges; i++)
        {
            var (a, bulge) = vertices[i];
            var b = vertices[(i + 1) % vertices.Count].Point;
            double dx = b.X - a.X, dy = b.Y - a.Y, chord = Math.Sqrt(dx * dx + dy * dy);
            if (Math.Abs(bulge) > 1e-12 && chord > 1e-12)
            {
                double theta = 4 * Math.Atan(bulge);
                double offset = chord * (1 - bulge * bulge) / (4 * bulge);
                double cx = (a.X + b.X) / 2 - dy / chord * offset;
                double cy = (a.Y + b.Y) / 2 + dx / chord * offset;
                double radius = Math.Sqrt((a.X - cx) * (a.X - cx) + (a.Y - cy) * (a.Y - cy));
                double start = Math.Atan2(a.Y - cy, a.X - cx);
                int steps = Math.Clamp((int)Math.Ceiling(Math.Abs(theta) / (Math.PI / 90)), 2, 2048);
                for (int j = 1; j < steps; j++)
                {
                    double t = (double)j / steps, angle = start + theta * t;
                    result.Add(Convert(new XYZ(cx + radius * Math.Cos(angle), cy + radius * Math.Sin(angle), a.Z + (b.Z - a.Z) * t)));
                }
            }
            result.Add(Convert(b));
        }
        return result;
    }

    // AutoCAD arbitrary-axis algorithm: OCS -> drawing WCS, preserving elevation.
    private static CadPoint Ocs(XYZ p, XYZ normal)
    {
        double length = Math.Sqrt(normal.X * normal.X + normal.Y * normal.Y + normal.Z * normal.Z);
        if (length < 1e-12) throw new InvalidDataException("객체 법선 벡터가 0입니다.");
        double nx = normal.X / length, ny = normal.Y / length, nz = normal.Z / length;
        double ax, ay, az;
        if (Math.Abs(nx) < 1.0 / 64 && Math.Abs(ny) < 1.0 / 64) (ax, ay, az) = (nz, 0, -nx);
        else (ax, ay, az) = (-ny, nx, 0);
        double al = Math.Sqrt(ax * ax + ay * ay + az * az);
        ax /= al; ay /= al; az /= al;
        double bx = ny * az - nz * ay, by = nz * ax - nx * az, bz = nx * ay - ny * ax;
        return new CadPoint(ax * p.X + bx * p.Y + nx * p.Z,
            ay * p.X + by * p.Y + ny * p.Z, az * p.X + bz * p.Y + nz * p.Z);
    }
}


