﻿using System.Drawing.Drawing2D;
using ForestRoad.Cad;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;
public sealed partial class MapCanvas:Control
{
    public List<CadFeature> Features {get;set;}=[];
    public LasCloud? Cloud {get;set;}
    public RoadRoute? Route {get;set;}
    public CadPoint? Start {get;set;}
    public CadPoint? End {get;set;}
    public bool ContourMode {get;set;}
    public bool OverlayCad {get;set;}
    public bool OriginalOnly {get;set;}=true;
    public bool ShowCloud {get;set;}=true;
    string? pick;
    public string? Pick {get=>pick;set{pick=value;HoverPoint=null;pendingHover=null;HoverChanged?.Invoke(null);Invalidate();}}
    public event Action<CadPoint?>? HoverChanged;
    readonly System.Windows.Forms.Timer hoverTimer=new(){Interval=100};
    Point? pendingHover;
    public event Action<string,CadPoint>? Picked;
    public event Action<CadPoint>? Pointer;
    double minX,minY,maxX=621.36,maxY=1175.20,zoom=1,panX,panY;
    Point? drag;
    public MapCanvas(){InitializeToolbar();Dock=DockStyle.Fill;DoubleBuffered=true;BackColor=Color.FromArgb(23,31,43);Resize+=(_,_)=>Invalidate();hoverTimer.Tick+=(_,_)=>{if(pendingHover is not Point p||Pick is null||!Is3D){hoverTimer.Stop();return;}pendingHover=null;HoverPoint=PickTerrain(p);Cursor=HoverPoint is null?Cursors.No:Cursors.Cross;HoverChanged?.Invoke(HoverPoint);Invalidate();};}
    double ViewScale=>Math.Min(Math.Max(Width-90,1)/Math.Max(maxX-minX,1),Math.Max(Height-90,1)/Math.Max(maxY-minY,1))*zoom;
    public PointF Screen(CadPoint p)=>Is3D?Project(p).Point:new((float)(Width/2.0+panX+(p.X-(minX+maxX)/2)*ViewScale),(float)(Height/2.0+panY-(p.Y-(minY+maxY)/2)*ViewScale));
    public CadPoint World(Point p)=>new((p.X-Width/2.0-panX)/ViewScale+(minX+maxX)/2,(Height/2.0+panY-p.Y)/ViewScale+(minY+maxY)/2,0);
    public void SetBounds(IEnumerable<CadPoint> points)
    {
        var list=points.ToList();if(list.Count==0){minX=minY=minZ=maxZ=0;maxX=621.36;maxY=1175.20;}else{minX=list.Min(p=>p.X);minY=list.Min(p=>p.Y);maxX=list.Max(p=>p.X);maxY=list.Max(p=>p.Y);minZ=list.Min(p=>p.Z);maxZ=list.Max(p=>p.Z);}Fit();
    }
    public void Fit(){zoom=1;panX=panY=0;Invalidate();}
    public void Zoom(double factor){zoom=Math.Clamp(zoom*factor,0.1,100);Invalidate();}
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);if(Is3D){Paint3D(e.Graphics);return;}var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
        if(!OriginalOnly)
        {
            using var gridPen=new Pen(Color.FromArgb(33,43,56));
            for(int x=0;x<Width;x+=50)g.DrawLine(gridPen,x,0,x,Height);
            for(int y=0;y<Height;y+=50)g.DrawLine(gridPen,0,y,Width,y);
        }
        if(Cloud is not null && ShowCloud && !ContourMode && !OriginalOnly)
        {
            int stride=Math.Max(1,(int)Math.Ceiling(Cloud.Points.Count/100_000.0));
            using var ground=new SolidBrush(Color.FromArgb(107,173,156));using var other=new SolidBrush(Color.FromArgb(133,149,181));
            for(int i=0;i<Cloud.Points.Count;i+=stride){var p=Cloud.Points[i];if(p.Withheld)continue;var q=Screen(p.Position);if(q.X<0||q.Y<0||q.X>Width||q.Y>Height)continue;
                if(p.Argb is int rgb){using var brush=new SolidBrush(Color.FromArgb(rgb));g.FillRectangle(brush,q.X,q.Y,2,2);}else g.FillRectangle(p.Classification==2?ground:other,q.X,q.Y,2,2);}
        }
        foreach(var f in Features)
        {
            if(f.Points.Count==0||!f.Visible)continue;
            var pts=f.Points.Select(Screen).ToArray();double z=f.Points[0].Z;
            bool major=Math.Abs(z/5-Math.Round(z/5))<1e-5,basic=Math.Abs(z-Math.Round(z))<1e-5;
            Color color=OverlayCad?Color.FromArgb(255,226,113):ContourMode?(major?Color.FromArgb(245,196,112):basic?Color.FromArgb(132,190,152):Color.FromArgb(69,113,95)):Color.FromArgb(f.Argb);
            if(color.R+color.G+color.B<90)color=Color.LightGray;
            if(f.Text is not null)
            {
                if(ContourMode)continue;using var brush=new SolidBrush(color);float size=(float)Math.Clamp(f.TextHeight*ViewScale,6,80);using var font=new Font("맑은 고딕",size,GraphicsUnit.Pixel);
                var save=g.Save();g.TranslateTransform(pts[0].X,pts[0].Y);g.RotateTransform((float)(-f.Rotation*180/Math.PI));g.DrawString(f.Text,font,brush,0,-size);g.Restore(save);
            }
            else if(pts.Length>1){if(OverlayCad){using var halo=new Pen(Color.FromArgb(170,20,30,40),major?3.5f:2.5f);g.DrawLines(halo,pts);}using var pen=new Pen(color,OverlayCad?(major?1.8f:1.1f):ContourMode?(major?2:basic?1.1f:0.65f):1);g.DrawLines(pen,pts);}
            else{using var brush=new SolidBrush(color);g.FillEllipse(brush,pts[0].X-2,pts[0].Y-2,4,4);}
        }
        if(!OriginalOnly)DrawRoads(g);
        if(!OriginalOnly)
        {
            Marker(Start,"S",Color.FromArgb(78,219,177));Marker(End,"E",Color.FromArgb(255,169,111));
        }
        using var text=new SolidBrush(Color.FromArgb(162,180,199));int northWidth=TextRenderer.MeasureText("↑ Y / 북",Font).Width;
        TextRenderer.DrawText(g,"↑ Y / 북",Font,new Rectangle(Math.Max(0,Width-northWidth-12),18,northWidth,Font.Height+6),Color.FromArgb(162,180,199));
        TextRenderer.DrawText(g,$"X {maxX-minX:N2} × Y {maxY-minY:N2} | 휠 확대 · 우클릭 이동",Font,new Rectangle(18,Math.Max(0,Height-viewToolbar.Height-Font.Height*2-18),Math.Max(1,Width-36),Font.Height*2+6),Color.FromArgb(162,180,199),TextFormatFlags.WordBreak);
        if(Features.Count==0&&(Cloud is null || OriginalOnly))g.DrawString(OriginalOnly?"DWG / DXF 파일을 열어 원본 도면을 확인하세요":"DWG · DXF · LAS 파일을 열어 지형을 확인하세요",Font,text,Math.Max(18,Width/2-210),Height/2);
        void Marker(CadPoint? point,string label,Color color)
        {
            if(point is null)return;var p=Screen(point);using var fill=new SolidBrush(color);using var outline=new Pen(Color.White,2);
            if(label=="S"){g.FillEllipse(fill,p.X-8,p.Y-8,16,16);g.DrawEllipse(outline,p.X-8,p.Y-8,16,16);}else{PointF[] shape=[new(p.X,p.Y-10),new(p.X+10,p.Y),new(p.X,p.Y+10),new(p.X-10,p.Y)];g.FillPolygon(fill,shape);g.DrawPolygon(outline,shape);}g.DrawString(label,Font,fill,p.X+13,p.Y-10);
        }
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);Focus();
        if(e.Button==MouseButtons.Left&&Pick is not null)
        {
            var point=Is3D?PickTerrain(e.Location):World(e.Location);
            if(point is null){PickMissed?.Invoke();return;}
            var mode=Pick;Pick=null;Cursor=Cursors.Default;Picked?.Invoke(mode,point);Invalidate();
        }
        else if(e.Button==MouseButtons.Right||(Is3D&&e.Button==MouseButtons.Left)){drag=e.Location;orbit=Is3D&&e.Button==MouseButtons.Left;Capture=true;}
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if(drag is Point p){if(orbit){yaw+=(e.X-p.X)*0.008;pitch=Math.Clamp(pitch+(e.Y-p.Y)*0.006,-Math.PI/2,Math.PI/2);CameraPreset="FREE";UpdateToolbar();}else{panX+=e.X-p.X;panY+=e.Y-p.Y;}drag=e.Location;Invalidate();}
        if(Is3D&&Pick is not null){pendingHover=e.Location;hoverTimer.Start();}else if(!Is3D)Pointer?.Invoke(World(e.Location));
    }
    protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);drag=null;Capture=false;}
    protected override void OnMouseWheel(MouseEventArgs e)
    {
        if(Is3D)Zoom(e.Delta>0?1.2:1/1.2);
        else{var p=World(e.Location);Zoom(e.Delta>0?1.2:1/1.2);var q=Screen(p);panX+=e.X-q.X;panY+=e.Y-q.Y;Invalidate();}
        base.OnMouseWheel(e);
    }    protected override void OnMouseLeave(EventArgs e){base.OnMouseLeave(e);pendingHover=null;HoverPoint=null;HoverChanged?.Invoke(null);Invalidate();}
    protected override void Dispose(bool disposing){if(disposing)hoverTimer.Dispose();base.Dispose(disposing);}
    internal void CheckHover(Point p){OnMouseMove(new MouseEventArgs(MouseButtons.None,0,p.X,p.Y,0));HoverPoint=PickTerrain(p);HoverChanged?.Invoke(HoverPoint);Invalidate();}

}
