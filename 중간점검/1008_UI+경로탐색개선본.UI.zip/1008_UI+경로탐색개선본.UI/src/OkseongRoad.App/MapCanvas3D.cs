using System.Drawing.Drawing2D;
using ForestRoad.Cad;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;

public sealed partial class MapCanvas
{
    public CadPoint? HoverPoint { get; private set; }
    public CadPoint? ProfilePoint { get; set; }
    readonly ViewToolbar viewToolbar=new();
    public event Action<bool>? ViewModeChanged;
    public string CameraPreset { get; private set; }="ISO";
    void InitializeToolbar()
    {
        Controls.Add(viewToolbar);viewToolbar.Selected+=SelectView;Resize+=(_,_)=>LayoutToolbar();
        viewToolbar.SizeChanged+=(_,_)=>viewToolbar.Location=new Point((Width-viewToolbar.Width)/2,Math.Max(0,Height-viewToolbar.Height-12));LayoutToolbar(); // UI IMPROVEMENT
    }
    void LayoutToolbar(){viewToolbar.Width=Math.Min(680,Math.Max(280,Width-24));viewToolbar.Location=new Point((Width-viewToolbar.Width)/2,Math.Max(0,Height-viewToolbar.Height-12));viewToolbar.BringToFront();}
    void UpdateToolbar(){viewToolbar.Camera=CameraPreset;viewToolbar.Is3D=Is3D;viewToolbar.Invalidate();}
    public void SelectView(string preset)
    {
        if(preset=="2D"){Set3D(false);ViewModeChanged?.Invoke(false);return;}
        if(preset=="3D"){Set3D(true);if(CameraPreset=="FREE")ResetCamera();ViewModeChanged?.Invoke(true);return;}
        Is3D=true;CameraPreset=preset;
        (yaw,pitch)=preset switch{"TOP"=>(0,Math.PI/2),"BOTTOM"=>(0,-Math.PI/2),"LEFT"=>(Math.PI/2,0),"RIGHT"=>(-Math.PI/2,0),"FRONT"=>(Math.PI,0),"BACK"=>(0,0),_=>(-0.65,0.65)};
        HoverPoint=null;pendingHover=null;Fit();UpdateToolbar();ViewModeChanged?.Invoke(true);
    }
    public bool Is3D { get; private set; }
    public double HeightScale { get; set; } = 1;
    public bool HeightColors { get; set; } = true;
    public bool OverlayContours { get; set; }
    public bool ShowSurface { get; set; }
    public TerrainGrid? Terrain { get; set; }
    public List<RoadRoute> Candidates { get; set; } = [];
    public int SelectedCandidate { get; set; }
    public bool ShowAllCandidates { get; set; } = true;
    public double RouteLineWidth { get; set; } = 4;
    public event Action? PickMissed;
    public static readonly Color[] RouteColors=[Color.FromArgb(75,219,255),Color.FromArgb(255,174,78),Color.FromArgb(207,145,255),Color.FromArgb(255,111,150),Color.FromArgb(136,234,153)];
    double minZ, maxZ, yaw = -0.65, pitch = 0.65;
    bool orbit;

    public void Set3D(bool enabled)
    {
        Is3D=enabled;Pick=null;Cursor=Cursors.Default;drag=null;Capture=false;Fit();UpdateToolbar();
    }
    public void ResetCamera(){CameraPreset="ISO";yaw=-0.65;pitch=0.65;Fit();UpdateToolbar();}
    public void TopCamera(){CameraPreset="TOP";yaw=0;pitch=Math.PI/2;Fit();UpdateToolbar();}

    // Recenter before rotation to retain precision with national survey coordinates.
    (PointF Point,double Depth) Project(CadPoint p)
    {
        double x=p.X-(minX+maxX)/2,y=p.Y-(minY+maxY)/2,z=(p.Z-(minZ+maxZ)/2)*HeightScale;
        double u=x*Math.Cos(yaw)-y*Math.Sin(yaw),v=x*Math.Sin(yaw)+y*Math.Cos(yaw);
        double extent=Math.Sqrt(Math.Pow(maxX-minX,2)+Math.Pow(maxY-minY,2)+Math.Pow((maxZ-minZ)*HeightScale,2));
        double scale=Math.Max(1,Math.Min(Width-100,Height-110))/Math.Max(1,extent)*zoom;
        return(new PointF((float)(Width/2.0+panX+u*scale),(float)(Height/2.0+panY-(v*Math.Sin(pitch)+z*Math.Cos(pitch))*scale)), -v*Math.Cos(pitch)+z*Math.Sin(pitch));
    }
    Color ElevationColor(double z)
    {
        double t=Math.Clamp((z-minZ)/Math.Max(maxZ-minZ,1e-9),0,1);
        Color[] stops=[Color.FromArgb(56,107,196),Color.FromArgb(47,176,174),Color.FromArgb(147,201,109),Color.FromArgb(244,199,96),Color.FromArgb(238,113,77)];
        double q=t*4;int i=Math.Min(3,(int)q);double f=q-i;
        return Color.FromArgb((int)(stops[i].R*(1-f)+stops[i+1].R*f),(int)(stops[i].G*(1-f)+stops[i+1].G*f),(int)(stops[i].B*(1-f)+stops[i+1].B*f));
    }
    void Paint3D(Graphics g)
    {
        g.SmoothingMode=SmoothingMode.AntiAlias;
        // Surface triangles use only complete valid cells; never bridge missing elevations.
        if(ShowSurface&&Terrain is {} terrain&&!OriginalOnly)
        {
            var faces=new List<(PointF[] Points,double Depth,double Z,double Shade)>();
            for(int y=0;y<terrain.Height-1;y++)for(int x=0;x<terrain.Width-1;x++)
            {
                int i=y*terrain.Width+x;int[] ids=[i,i+1,i+terrain.Width+1,i+terrain.Width];
                if(ids.Any(k=>!double.IsFinite(terrain.Values[k])))continue;
                var nodes=ids.Select(terrain.Node).ToArray();var projected=nodes.Select(Project).ToArray();
                double nx=-((nodes[1].Z+nodes[2].Z)-(nodes[0].Z+nodes[3].Z))/(2*terrain.Step)*HeightScale;
                double ny=-((nodes[2].Z+nodes[3].Z)-(nodes[0].Z+nodes[1].Z))/(2*terrain.Step)*HeightScale;
                double light=Math.Clamp((0.4*nx-0.5*ny+0.8)/Math.Sqrt(nx*nx+ny*ny+1),0,1);
                faces.Add((projected.Select(p=>p.Point).ToArray(),projected.Average(p=>p.Depth),nodes.Average(p=>p.Z),0.64+0.36*light));
            }
            foreach(var f in faces.OrderBy(f=>f.Depth)){var c=ElevationColor(f.Z);using var brush=new SolidBrush(Color.FromArgb((int)(c.R*f.Shade),(int)(c.G*f.Shade),(int)(c.B*f.Shade)));g.FillPolygon(brush,f.Points);}
        }
        if(Cloud is {} cloud&&ShowCloud&&!ContourMode&&!OriginalOnly)
        {
            int stride=Math.Max(1,(int)Math.Ceiling(cloud.Points.Count/100_000.0));
            var dots=new List<(PointF Point,double Depth,Color Color)>();
            for(int i=0;i<cloud.Points.Count;i+=stride)
            {
                var p=cloud.Points[i];if(p.Withheld)continue;var q=Project(p.Position);
                if(q.Point.X<0||q.Point.Y<0||q.Point.X>Width||q.Point.Y>Height)continue;
                dots.Add((q.Point,q.Depth,HeightColors?ElevationColor(p.Position.Z):p.Argb is int rgb?Color.FromArgb(rgb):Color.FromArgb(107,173,156)));
            }
            foreach(var p in dots.OrderBy(p=>p.Depth)){using var brush=new SolidBrush(p.Color);g.FillRectangle(brush,p.Point.X,p.Point.Y,2.5f,2.5f);}
        }
        foreach(var f in Features.Where(f=>f.Visible&&f.Points.Count>0&&(!ShowSurface||OriginalOnly||!ContourMode||OverlayContours)).OrderBy(f=>Project(f.Points[f.Points.Count/2]).Depth))
        {
            var pts=f.Points.Select(Screen).ToArray();Color color=OverlayCad?Color.FromArgb(255,226,113):HeightColors?ElevationColor(f.Points[0].Z):Color.FromArgb(f.Argb);
            if(color.R+color.G+color.B<90)color=Color.LightGray;
            using var pen=new Pen(color,OverlayCad?1.6f:ContourMode?1.1f:1);using var brush=new SolidBrush(color);
            if(f.Text is not null){if(!ContourMode)g.DrawString(f.Text,Font,brush,pts[0]);}
            else if(pts.Length>1)g.DrawLines(pen,pts);else g.FillEllipse(brush,pts[0].X-2,pts[0].Y-2,4,4);
        }
        if(!OriginalOnly&&!DemOnly)
        {
            DrawRoads(g);
            DrawMarker(Start,"S",Color.Aquamarine);DrawMarker(End,"E",Color.SandyBrown);
        }
        if(!DemOnly&&ProfilePoint is {} track){var p=Screen(track);using var dot=new SolidBrush(Color.White);g.FillEllipse(dot,p.X-5,p.Y-5,10,10);}
        if(Pick is not null&&HoverPoint is {} preview)
        {
            var p=Screen(preview);using var glow=new SolidBrush(Color.FromArgb(80,255,245,130));using var ring=new Pen(Color.FromArgb(255,239,119),2);g.FillEllipse(glow,p.X-12,p.Y-12,24,24);g.DrawEllipse(ring,p.X-12,p.Y-12,24,24);g.DrawLine(ring,p.X-17,p.Y,p.X+17,p.Y);g.DrawLine(ring,p.X,p.Y-17,p.X,p.Y+17);
            using var box=new SolidBrush(Color.FromArgb(235,23,35,49));using var ink=new SolidBrush(Color.White);float x=Math.Clamp(p.X+20,8,Math.Max(8,Width-225)),y=Math.Clamp(p.Y-65,75,Math.Max(75,Height-110));g.FillRectangle(box,x,y,210,62);g.DrawString($"{(Pick=="start"?"시작점":"종점")} 미리보기\nX {preview.X:F2}  Y {preview.Y:F2}\nZ {preview.Z:F2}",Font,ink,x+8,y+5);
        }
        using var label=new SolidBrush(Color.FromArgb(213,225,238));
        TextRenderer.DrawText(g,$"{(Pick is null?"3D 회전 모드":"3D "+(Pick=="start"?"시작점":"종점")+" 선택 모드")} · 원본 Z 고도 {minZ:N2} ~ {maxZ:N2} | 높이 ×{HeightScale:g}",Font,new Rectangle(16,16,Math.Max(1,Width-32),Font.Height*3+6),Color.FromArgb(213,225,238),TextFormatFlags.WordBreak);
        TextRenderer.DrawText(g,Pick is null?"좌클릭 회전 · 우클릭 이동 · 휠 확대":"지형 클릭으로 시작·종점 지정 · Esc 취소 · 우클릭 이동",Font,new Rectangle(16,Math.Max(0,Height-viewToolbar.Height-Font.Height*2-18),Math.Max(1,Width-32),Font.Height*2+6),Color.FromArgb(213,225,238),TextFormatFlags.WordBreak);
        if(HeightColors){for(int i=0;i<120;i++){using var b=new SolidBrush(ElevationColor(minZ+(maxZ-minZ)*i/119));g.FillRectangle(b,Width-150+i,48,1,9);}g.DrawString($"{minZ:0.##}  →  {maxZ:0.##}",Font,label,Width-150,62);}
        var origin=new CadPoint(minX,minY,minZ);var a=Screen(origin);double length=Math.Max(maxX-minX,maxY-minY)*0.12;
        Axis(new(origin.X+length,origin.Y,origin.Z),"X",Color.Salmon);Axis(new(origin.X,origin.Y+length,origin.Z),"Y",Color.LightGreen);Axis(new(origin.X,origin.Y,origin.Z+length/HeightScale),"Z",Color.LightSkyBlue);
        void Axis(CadPoint p,string title,Color c){var b=Screen(p);using var pen=new Pen(c,2);using var fill=new SolidBrush(c);g.DrawLine(pen,a,b);g.DrawString(title,Font,fill,b);}
        void DrawMarker(CadPoint? p,string title,Color color)
        {
            if(p is null)return;var elevated=Terrain?.At(p.X,p.Y);if(elevated is null)return;
            var q=Screen(elevated);using var brush=new SolidBrush(color);using var outline=new Pen(Color.White,2);
            if(title=="S"){g.FillEllipse(brush,q.X-7,q.Y-7,14,14);g.DrawEllipse(outline,q.X-7,q.Y-7,14,14);}
            else{PointF[] diamond=[new(q.X,q.Y-9),new(q.X+9,q.Y),new(q.X,q.Y+9),new(q.X-9,q.Y)];g.FillPolygon(brush,diamond);g.DrawPolygon(outline,diamond);}
            g.DrawString(title,Font,brush,q.X+11,q.Y-9);
        }
    }
    record PickCell(int X,int Y,CadPoint[] Nodes,(PointF Point,double Depth)[] Projected,float MinX,float MaxX,float MinY,float MaxY);
    string? pickKey;List<PickCell> pickCells=[];
    public CadPoint? PickTerrain(PointF click)
    {
        if(Terrain is not {} grid)return null;
        CadPoint? best=null;double depth=double.NegativeInfinity;
        var key=$"{grid.GetHashCode()}:{Width}:{Height}:{yaw:R}:{pitch:R}:{zoom:R}:{panX:R}:{panY:R}:{HeightScale:R}:{minX:R}:{maxX:R}:{minY:R}:{maxY:R}:{minZ:R}:{maxZ:R}";
        if(pickKey!=key)
        {
            pickCells=[];
            for(int row=0;row<grid.Height-1;row++)for(int column=0;column<grid.Width-1;column++)
            {
                int id=row*grid.Width+column;int[] ids=[id,id+1,id+grid.Width+1,id+grid.Width];if(ids.Any(k=>!double.IsFinite(grid.Values[k])))continue;
                var ns=ids.Select(grid.Node).ToArray();var qs=ns.Select(Project).ToArray();pickCells.Add(new(column,row,ns,qs,qs.Min(p=>p.Point.X),qs.Max(p=>p.Point.X),qs.Min(p=>p.Point.Y),qs.Max(p=>p.Point.Y)));
            }
            pickKey=key;
        }
        foreach(var cell in pickCells)
        {
            if(click.X<cell.MinX-0.01||click.X>cell.MaxX+0.01||click.Y<cell.MinY-0.01||click.Y>cell.MaxY+0.01)continue;
            int x=cell.X,y=cell.Y;var nodes=cell.Nodes;var projected=cell.Projected;
            Hit(0,1,2);Hit(0,2,3);
            void Hit(int a,int b,int c)
            {
                var u=projected[a].Point;var v=projected[b].Point;var w=projected[c].Point;
                double den=(v.Y-w.Y)*(u.X-w.X)+(w.X-v.X)*(u.Y-w.Y);if(Math.Abs(den)<1e-10)return;
                double f=((v.Y-w.Y)*(click.X-w.X)+(w.X-v.X)*(click.Y-w.Y))/den;
                double h=((w.Y-u.Y)*(click.X-w.X)+(u.X-w.X)*(click.Y-w.Y))/den;double k=1-f-h;
                if(f< -1e-6||h< -1e-6||k< -1e-6)return;
                double px=f*nodes[a].X+h*nodes[b].X+k*nodes[c].X,py=f*nodes[a].Y+h*nodes[b].Y+k*nodes[c].Y;
                // Refine against the same bilinear elevations used by slope calculation.
                for(int n=0;n<8;n++)
                {
                    var p=grid.At(px,py);if(p is null)return;var q=Project(p).Point;
                    double ex=click.X-q.X,ey=click.Y-q.Y;if(Math.Abs(ex)+Math.Abs(ey)<0.01)break;
                    double d=grid.Step*0.001;var pu=grid.At(Math.Min(px+d,grid.X+(grid.Width-1)*grid.Step),py);var pv=grid.At(px,Math.Min(py+d,grid.Y+(grid.Height-1)*grid.Step));
                    if(pu is null||pv is null)return;double dx=pu.X-px,dy=pv.Y-py;if(dx<1e-9||dy<1e-9)break;
                    var qu=Project(pu).Point;var qv=Project(pv).Point;double ux=(qu.X-q.X)/dx,uy=(qu.Y-q.Y)/dx,vx=(qv.X-q.X)/dy,vy=(qv.Y-q.Y)/dy;
                    double determinant=ux*vy-vx*uy;if(Math.Abs(determinant)<1e-10)return;
                    px=Math.Clamp(px+(ex*vy-vx*ey)/determinant,grid.X+x*grid.Step,grid.X+(x+1)*grid.Step);
                    py=Math.Clamp(py+(ux*ey-ex*uy)/determinant,grid.Y+y*grid.Step,grid.Y+(y+1)*grid.Step);
                }
                var actual=grid.At(px,py);if(actual is null)return;var screen=Project(actual);
                if(Math.Abs(screen.Point.X-click.X)+Math.Abs(screen.Point.Y-click.Y)>1)return;
                if(screen.Depth>depth){depth=screen.Depth;best=actual;}
            }
        }
        return best;
    }
    public void FocusRoute()
    {
        if(Route is not {} route)return;var points=route.Vertices.Select(Screen).ToArray();
        double x0=points.Min(p=>p.X),x1=points.Max(p=>p.X),y0=points.Min(p=>p.Y),y1=points.Max(p=>p.Y);
        double factor=Math.Min(Math.Max(Width-180,1)/Math.Max(x1-x0,30),Math.Max(Height-180,1)/Math.Max(y1-y0,30));
        double next=Math.Clamp(zoom*factor,0.1,100);factor=next/zoom;zoom=next;
        panX=factor*(panX+Width/2.0-(x0+x1)/2);panY=factor*(panY+Height/2.0-(y0+y1)/2);Invalidate();
    }
    internal void CheckToolbar()
    {
        var center=new CadPoint((minX+maxX)/2,(minY+maxY)/2,(minZ+maxZ)/2);double d=10;
        foreach(var id in new[]{"TOP","BOTTOM","LEFT","RIGHT","FRONT","BACK"})
        {
            viewToolbar.ClickForCheck(id);if(!Is3D||CameraPreset!=id)throw new Exception("시점 버튼 연결 오류 "+id);
            var q=id is "TOP" or "BOTTOM"?new CadPoint(center.X,center.Y,center.Z+d):id is "LEFT" or "RIGHT"?new CadPoint(center.X+d,center.Y,center.Z):new CadPoint(center.X,center.Y+d,center.Z);
            var a=Screen(center);var b=Screen(q);if(Math.Abs(a.X-b.X)+Math.Abs(a.Y-b.Y)>0.01)throw new Exception("시점 투영 오류 "+id);
            var near=id switch{"LEFT"=>new CadPoint(center.X-d,center.Y,center.Z),"RIGHT"=>new CadPoint(center.X+d,center.Y,center.Z),"FRONT"=>new CadPoint(center.X,center.Y+d,center.Z),"BACK"=>new CadPoint(center.X,center.Y-d,center.Z),"BOTTOM"=>new CadPoint(center.X,center.Y,center.Z-d),_=>new CadPoint(center.X,center.Y,center.Z+d)};
            if(Project(near).Depth<=Project(center).Depth)throw new Exception("시점 앞뒤 방향 오류 "+id);
            if(id=="BOTTOM"&&Project(new(center.X,center.Y,center.Z-d)).Depth<=Project(new(center.X,center.Y,center.Z+d)).Depth)throw new Exception("Bottom 깊이 순서 오류");
        }
        viewToolbar.ClickForCheck("2D");if(Is3D)throw new Exception("2D 전환 오류");viewToolbar.ClickForCheck("ISO");
    }
    internal void CheckLeftClick(Point p)=>OnMouseDown(new MouseEventArgs(MouseButtons.Left,1,p.X,p.Y,0));
    void DrawRoads(Graphics g)
    {
        var routes=Candidates.Count>0?Candidates:Route is {} r?[r]:new List<RoadRoute>();
        foreach(int index in Enumerable.Range(0,routes.Count).OrderBy(i=>i==SelectedCandidate?1:0))
        {
            if(!ShowAllCandidates&&index!=SelectedCandidate)continue;var road=routes[index];bool selected=index==SelectedCandidate;
            Color color=RouteColors[index%RouteColors.Length];
            if(road.Vertices.Count>1)
            {
                // UI IMPROVEMENT: draw the same terrain-draped centreline in 2D and 3D.
                using var pen=new Pen(color,(float)(selected?RouteLineWidth:Math.Max(1,RouteLineWidth*.75)))
                {LineJoin=LineJoin.Round,StartCap=LineCap.Round,EndCap=LineCap.Round};
                g.DrawLines(pen,road.Vertices.Select(Screen).ToArray());
            }
            // Display the actual 20 m DEM stations on the selected bend-preserving polyline.
            if(selected)
            {
                using var dot=new SolidBrush(Color.White);using var rim=new Pen(color,1);
                foreach(var station in road.Stations){var p=Screen(new CadPoint(station.X,station.Y,station.Z));g.FillEllipse(dot,p.X-3,p.Y-3,6,6);g.DrawEllipse(rim,p.X-3,p.Y-3,6,6);}
            }
            var mid=Screen(road.Vertices[road.Vertices.Count/2]);using var badge=new SolidBrush(color);using var ink=new SolidBrush(Color.FromArgb(17,27,38));g.FillEllipse(badge,mid.X-10,mid.Y-10,20,20);g.DrawString((index+1).ToString(),Font,ink,mid.X-5,mid.Y-8);
        }
    }

}

