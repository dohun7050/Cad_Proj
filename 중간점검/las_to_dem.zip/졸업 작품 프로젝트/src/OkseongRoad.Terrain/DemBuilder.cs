using ForestRoad.Cad;
namespace OkseongRoad.Terrain;
public sealed record DemOptions(double MinX,double MinY,double MaxX,double MaxY,double Resolution,string Algorithm="IDW",double Power=2,int Neighbors=8,double Radius=15,string CoordinateReference="",bool GroundOnly=true,double NoData=-9999);
public static class DemBuilder
{

    public static TerrainGrid Build(IEnumerable<CadPoint> source,DemOptions o,CancellationToken ct=default)
    {
        if(!double.IsFinite(o.Resolution)||o.Resolution<=0||o.MaxX<=o.MinX||o.MaxY<=o.MinY||o.Radius<=0||o.Power<=0||o.Neighbors<3)throw new ArgumentException("DEM 범위와 보간 설정을 확인하세요.");
        double w=Math.Ceiling((o.MaxX-o.MinX)/o.Resolution-1e-8)+1,h=Math.Ceiling((o.MaxY-o.MinY)/o.Resolution-1e-8)+1;
        if(!double.IsFinite(w*h)||w*h>250000)throw new InvalidOperationException("격자가 25만 셀을 초과합니다. 해상도 또는 범위를 조정하세요.");
        int width=(int)w,height=(int)h;
        // Dense measurements are averaged per half-resolution bin before interpolation.
        double bin=o.Resolution/2;
        var sums=new Dictionary<(long,long),(double X,double Y,double Z,int N)>();
        foreach(var p in source){ct.ThrowIfCancellationRequested();if(!double.IsFinite(p.Z)||p.X<o.MinX||p.X>o.MaxX||p.Y<o.MinY||p.Y>o.MaxY)continue;var key=((long)Math.Floor((p.X-o.MinX)/bin),(long)Math.Floor((p.Y-o.MinY)/bin));var a=sums.GetValueOrDefault(key);sums[key]=(a.X+p.X,a.Y+p.Y,a.Z+p.Z,a.N+1);}
        var points=sums.Values.Select(a=>new CadPoint(a.X/a.N,a.Y/a.N,a.Z/a.N)).ToList();
        if(points.Count<3)throw new InvalidOperationException("선택 범위에 고도 표본이 3개 이상 필요합니다.");
        var values=Enumerable.Repeat(double.NaN,width*height).ToArray();
        if(o.Algorithm=="TIN")
        {
            var mesh=Task.Run(()=>GeoProcessing.Triangulate(points,ct),ct).GetAwaiter().GetResult();
            points=mesh.Points;var triangles=mesh.Faces;
            foreach(var t in triangles)
            {
                ct.ThrowIfCancellationRequested();var a=points[t.A];var b=points[t.B];var c=points[t.C];
                if(Distance(a,b)>o.Radius*o.Radius||Distance(b,c)>o.Radius*o.Radius||Distance(c,a)>o.Radius*o.Radius)continue;
                double den=(b.Y-c.Y)*(a.X-c.X)+(c.X-b.X)*(a.Y-c.Y);if(Math.Abs(den)<1e-15)continue;
                int left=Math.Max(0,(int)Math.Ceiling((Math.Min(a.X,Math.Min(b.X,c.X))-o.MinX)/o.Resolution)),right=Math.Min(width-1,(int)Math.Floor((Math.Max(a.X,Math.Max(b.X,c.X))-o.MinX)/o.Resolution));
                int bottom=Math.Max(0,(int)Math.Ceiling((Math.Min(a.Y,Math.Min(b.Y,c.Y))-o.MinY)/o.Resolution)),top=Math.Min(height-1,(int)Math.Floor((Math.Max(a.Y,Math.Max(b.Y,c.Y))-o.MinY)/o.Resolution));
                for(int j=bottom;j<=top;j++){ct.ThrowIfCancellationRequested();for(int i=left;i<=right;i++){double x=o.MinX+i*o.Resolution,y=o.MinY+j*o.Resolution;double u=((b.Y-c.Y)*(x-c.X)+(c.X-b.X)*(y-c.Y))/den,v=((c.Y-a.Y)*(x-c.X)+(a.X-c.X)*(y-c.Y))/den;if(u>=-1e-9&&v>=-1e-9&&u+v<=1+1e-9)values[j*width+i]=u*a.Z+v*b.Z+(1-u-v)*c.Z;}}
            }
        }
        else
        {
            double bucketSize=Math.Max(bin,o.Radius);var buckets=points.GroupBy(p=>((long)Math.Floor((p.X-o.MinX)/bucketSize),(long)Math.Floor((p.Y-o.MinY)/bucketSize))).ToDictionary(g=>g.Key,g=>g.ToList());
            for(int j=0;j<height;j++)for(int i=0;i<width;i++)
            {
                ct.ThrowIfCancellationRequested();double x=o.MinX+i*o.Resolution,y=o.MinY+j*o.Resolution;if(x>o.MaxX||y>o.MaxY)continue;
                var near=new List<(double D,double Z)>();long bx=(long)Math.Floor((x-o.MinX)/bucketSize),by=(long)Math.Floor((y-o.MinY)/bucketSize);
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)if(buckets.TryGetValue((bx+dx,by+dy),out var bucket))foreach(var p in bucket){double d=(p.X-x)*(p.X-x)+(p.Y-y)*(p.Y-y);if(d<=o.Radius*o.Radius)near.Add((d,p.Z));}
                var nearest=near.OrderBy(p=>p.D).Take(o.Neighbors).ToList();if(nearest.Count==0)continue;if(nearest[0].D<1e-12){values[j*width+i]=nearest[0].Z;continue;}if(nearest.Count<3)continue;
                double sum=0,weight=0;foreach(var p in nearest){double ww=1/Math.Pow(p.D,o.Power/2);sum+=ww*p.Z;weight+=ww;}values[j*width+i]=sum/weight;
            }
        }
        if(!values.Any(double.IsFinite))throw new InvalidOperationException("유효 DEM 셀이 없습니다. 범위, 검색 반경 또는 TIN 최대 변 길이를 늘리세요.");
        return new TerrainGrid(o.MinX,o.MinY,o.Resolution,width,height,values);
    }
    static double Distance(CadPoint a,CadPoint b)=>(a.X-b.X)*(a.X-b.X)+(a.Y-b.Y)*(a.Y-b.Y);
}

