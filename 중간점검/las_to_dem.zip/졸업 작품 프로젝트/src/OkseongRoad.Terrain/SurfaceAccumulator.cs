using ForestRoad.Cad;
namespace OkseongRoad.Terrain;
public sealed class SurfaceAccumulator
{
    record Cell(double X,double Y,double Z,long N,CadPoint Low);
    Dictionary<(long,long),Cell> cells=[];
    public double Step {get;private set;}=1;
    public void Add(double x,double y,double z)
    {
        var key=((long)Math.Floor(x/Step),(long)Math.Floor(y/Step));var p=new CadPoint(x,y,z);
        if(cells.TryGetValue(key,out var a))cells[key]=new(a.X+x,a.Y+y,a.Z+z,a.N+1,z<a.Low.Z?p:a.Low);else cells[key]=new(x,y,z,1,p);
        if(cells.Count<=500000)return;Step*=2;var next=new Dictionary<(long,long),Cell>();foreach(var entry in cells){var parent=((long)Math.Floor(entry.Key.Item1/2.0),(long)Math.Floor(entry.Key.Item2/2.0));var b=entry.Value;if(next.TryGetValue(parent,out a))next[parent]=new(a.X+b.X,a.Y+b.Y,a.Z+b.Z,a.N+b.N,a.Low.Z<b.Low.Z?a.Low:b.Low);else next[parent]=b;}cells=next;
    }
    public List<CadPoint> Means()=>cells.Values.Select(a=>new CadPoint(a.X/a.N,a.Y/a.N,a.Z/a.N)).ToList();
    public List<CadPoint> Lows()=>cells.Values.Select(a=>a.Low).ToList();
}
