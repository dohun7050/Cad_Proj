﻿using System.Drawing.Drawing2D;
namespace OkseongRoad.App;

/// <summary>Floating camera presets; pointer input is contained in this control.</summary>
public sealed class ViewToolbar:Control
{
    readonly (string Id,string Label,float Weight)[] items=[("ISO","ISO",42),("TOP","TOP",44),("BOTTOM","BOTTOM",62),("LEFT","좌 LEFT",58),("RIGHT","우 RIGHT",64),("FRONT","상 FRONT",68),("BACK","하 BACK",64),("2D","2D",38),("3D","3D",38)];
    readonly ToolTip tip=new();
    public string Camera { get; set; }="ISO";
    public bool Is3D { get; set; }
    public event Action<string>? Selected;
    int hovered=-1;
    public ViewToolbar()
    {
        DoubleBuffered=true;Height=42;BackColor=Color.FromArgb(23,31,43);Cursor=Cursors.Hand;
        AccessibleName="시점 선택";AccessibleDescription="ISO, TOP, BOTTOM, 좌, 우, 상, 하, 2D, 3D 시점 선택";
        Font=new Font("맑은 고딕",8,FontStyle.Bold);
    }
    RectangleF ButtonBounds(int index)
    {
        float start=38,space=4,available=Math.Max(1,Width-start-10-space*(items.Length-1));
        float total=items.Sum(p=>p.Weight),x=start;
        for(int i=0;i<index;i++)x+=available*items[i].Weight/total+space;
        return new(x,7,available*items[index].Weight/total,28);
    }
    static GraphicsPath Round(RectangleF rect,float radius)
    {
        var path=new GraphicsPath();float d=Math.Min(radius*2,Math.Min(rect.Width,rect.Height));
        path.AddArc(rect.X,rect.Y,d,d,180,90);path.AddArc(rect.Right-d,rect.Y,d,d,270,90);path.AddArc(rect.Right-d,rect.Bottom-d,d,d,0,90);path.AddArc(rect.X,rect.Bottom-d,d,d,90,90);path.CloseFigure();return path;
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
        using var outer=Round(new RectangleF(1,1,Width-2,Height-2),20);using var background=new SolidBrush(Color.FromArgb(30,44,61));using var border=new Pen(Color.FromArgb(63,83,106));g.FillPath(background,outer);g.DrawPath(border,outer);
        using var captionFont=new Font(Font.FontFamily,6.5f,FontStyle.Bold);TextRenderer.DrawText(g,"VIEW",captionFont,new Rectangle(7,8,30,26),Color.FromArgb(148,170,192),TextFormatFlags.VerticalCenter|TextFormatFlags.HorizontalCenter);
        for(int i=0;i<items.Length;i++)
        {
            var item=items[i];var rect=ButtonBounds(i);bool active=item.Id=="3D"?Is3D:item.Id=="2D"?!Is3D:Is3D&&Camera==item.Id;
            using var shape=Round(rect,14);using var fill=new SolidBrush(active?Color.FromArgb(34,130,222):i==hovered?Color.FromArgb(69,91,115):Color.FromArgb(45,62,81));g.FillPath(fill,shape);
            TextRenderer.DrawText(g,item.Label,Font,Rectangle.Round(rect),active?Color.White:Color.FromArgb(183,202,221),TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.NoPadding);
        }
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);int next=Enumerable.Range(0,items.Length).FirstOrDefault(i=>ButtonBounds(i).Contains(e.Location),-1);
        if(next==hovered)return;hovered=next;tip.SetToolTip(this,next<0?"시점 선택":items[next].Id switch{"ISO"=>"입체 시점","TOP"=>"위에서 아래로 (+Z)","BOTTOM"=>"아래에서 위로 (-Z)","LEFT"=>"왼쪽에서 보기 (-X)","RIGHT"=>"오른쪽에서 보기 (+X)","FRONT"=>"상 방향에서 보기 (+Y)","BACK"=>"하 방향에서 보기 (-Y)","2D"=>"XY 평면 보기",_=>"3D 입체 보기"});Invalidate();
    }
    protected override void OnMouseLeave(EventArgs e){base.OnMouseLeave(e);hovered=-1;Invalidate();}
    protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(e.Button!=MouseButtons.Left)return;for(int i=0;i<items.Length;i++)if(ButtonBounds(i).Contains(e.Location)){Selected?.Invoke(items[i].Id);return;}}
    internal void ClickForCheck(string id){int index=Array.FindIndex(items,p=>p.Id==id);var r=ButtonBounds(index);OnMouseDown(new MouseEventArgs(MouseButtons.Left,1,(int)(r.X+r.Width/2),(int)(r.Y+r.Height/2),0));}
    protected override void Dispose(bool disposing){if(disposing)tip.Dispose();base.Dispose(disposing);}
}
