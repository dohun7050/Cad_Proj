using System.Globalization;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;
public sealed class DemDialog:Form
{
    public DemOptions? Options {get;private set;}
    public DemDialog(DemOptions o,bool las)
    {
        Text="DEM 생성 설정";ClientSize=new Size(640,590);StartPosition=FormStartPosition.CenterParent;Font=new Font("맑은 고딕",9);FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;
        var panel=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,Padding=new Padding(16)};panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,260));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));Controls.Add(panel);
        void Row(string title,Control c){int r=panel.RowCount++;panel.RowStyles.Add(new RowStyle(SizeType.Absolute,36));panel.Controls.Add(new Label{Text=title,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,r);c.Dock=DockStyle.Fill;panel.Controls.Add(c,1,r);}
        NumericUpDown Numeric(decimal min,decimal max,decimal value,int decimals=0)=>new(){Minimum=min,Maximum=max,DecimalPlaces=decimals,Value=Math.Clamp(value,min,max),ThousandsSeparator=true};
        var columns=Numeric(2,125000,(decimal)Math.Ceiling((o.MaxX-o.MinX)/o.Resolution-1e-8)+1);
        var rows=Numeric(2,125000,(decimal)Math.Ceiling((o.MaxY-o.MinY)/o.Resolution-1e-8)+1);
        var resolution=Numeric(0.01m,10000,(decimal)o.Resolution,2);
        Row("입력 자료",new Label{Text=las?"LAS":"CAD 선택 등고선"});Row("그리드 크기 X (열 수)",columns);Row("그리드 크기 Y (행 수)",rows);Row("해상도 / 셀 간격 (m)",resolution);
        var extent=new Label();Row("그리드 전체 크기 / 셀 수",extent);
        void Estimate(){extent.Text=$"{(columns.Value-1)*resolution.Value:N2} × {(rows.Value-1)*resolution.Value:N2} m / {columns.Value*rows.Value:N0}셀";}
        columns.ValueChanged+=(_,_)=>Estimate();rows.ValueChanged+=(_,_)=>Estimate();resolution.ValueChanged+=(_,_)=>Estimate();Estimate();
        var algo=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList};algo.Items.AddRange(["IDW","TIN"]);algo.SelectedItem=o.Algorithm;Row("보간 알고리즘",algo);
        var radius=Numeric(0.01m,100000,(decimal)o.Radius,2);var power=Numeric(0.1m,10,(decimal)o.Power,1);var neighbors=Numeric(3,64,o.Neighbors);
        Row("검색 반경 / TIN 최대 변 길이 (m)",radius);Row("IDW 거리 가중 지수",power);Row("IDW 최대 이웃 표본 수",neighbors);
        var ground=new CheckBox{Text="지면 사용 (없으면 자동 추출)",Checked=o.GroundOnly,Enabled=las};Row("LAS 분류 / withheld 제외",ground);
        var crs=new TextBox{Text=o.CoordinateReference,ReadOnly=true};Row("현재 좌표계 (불러오기에서 설정)",crs);var units=new CheckBox{Text="XY·Z 미터 / 투영 좌표계 확인"};Row("단위 확인",units);
        Row("격자 배치",new Label{Text="입력 자료의 최소 X·Y에서 자동 시작"});
        Row("빈 셀 처리",new Label{Text="고도 계산 불가 영역은 비워 둡니다.\n저장 시 결측값 -9999 사용"});
        Row("처리 안내",new Label{Text="최대 25만 셀 / 반 셀 평균 표본 사용\n좌표계 자동 변환은 지원하지 않습니다."});
        var actions=new FlowLayoutPanel();var ok=new Button{Text="DEM 생성",Width=110};var cancel=new Button{Text="취소",DialogResult=DialogResult.Cancel};actions.Controls.AddRange([ok,cancel]);Row("",actions);AcceptButton=ok;CancelButton=cancel;
        void UpdateAlgorithm(){power.Enabled=neighbors.Enabled=algo.Text=="IDW";}algo.SelectedIndexChanged+=(_,_)=>UpdateAlgorithm();UpdateAlgorithm();
        ok.Click+=(_,_)=>{if(columns.Value*rows.Value>250000){MessageBox.Show(this,"그리드가 25만 셀을 초과합니다. 행 또는 열 수를 줄이세요.");return;}if(!units.Checked||string.IsNullOrWhiteSpace(crs.Text)){MessageBox.Show(this,"좌표계를 입력하고 미터 단위를 확인하세요.");return;}
            double step=(double)resolution.Value;Options=new(o.MinX,o.MinY,o.MinX+((int)columns.Value-1)*step,o.MinY+((int)rows.Value-1)*step,step,algo.Text,(double)power.Value,(int)neighbors.Value,(double)radius.Value,crs.Text.Trim(),ground.Checked,-9999);DialogResult=DialogResult.OK;};
    }
}


