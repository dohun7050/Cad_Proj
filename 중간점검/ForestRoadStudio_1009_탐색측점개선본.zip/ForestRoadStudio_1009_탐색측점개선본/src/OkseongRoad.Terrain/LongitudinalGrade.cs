namespace OkseongRoad.Terrain;

/// <summary>Grade uses absolute elevation change divided by horizontal road chainage.</summary>
public static class LongitudinalGrade
{
    public const double DefaultPercent=10;
    public const double DefaultAngle=5.710593137499643;
    public static double ToAngle(double percent)
    {
        if(!double.IsFinite(percent)||percent<=0)throw new ArgumentOutOfRangeException(nameof(percent),"최대 종단경사율은 유한한 양수여야 합니다.");
        return Math.Atan(percent/100)*180/Math.PI;
    }
    public static double ToPercent(double angle)=>Math.Tan(angle*Math.PI/180)*100;
    public static double Between(double elevationChange,double horizontalDistance)
        =>horizontalDistance>0?Math.Abs(elevationChange)/horizontalDistance*100:Math.Abs(elevationChange)<1e-9?0:double.PositiveInfinity;
}
