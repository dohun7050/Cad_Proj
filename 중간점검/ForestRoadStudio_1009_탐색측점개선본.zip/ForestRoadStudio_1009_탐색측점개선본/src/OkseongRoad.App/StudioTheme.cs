using System.Drawing.Drawing2D;
namespace OkseongRoad.App;

internal static class StudioTheme
{
    public static readonly Color Background=Color.FromArgb(244,246,245),Panel=Color.White,Raised=Color.FromArgb(236,244,239),Border=Color.FromArgb(218,227,222),Text=Color.FromArgb(38,51,42),Muted=Color.FromArgb(109,120,111),Accent=Color.FromArgb(39,119,80),Forest=Color.FromArgb(23,63,42),Highlight=Color.FromArgb(111,175,69);
    public static GraphicsPath Round(RectangleF r,float radius=10)
    {
        var p=new GraphicsPath();float d=radius*2;p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.Right-d,r.Y,d,d,270,90);p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);p.AddArc(r.X,r.Bottom-d,d,d,90,90);p.CloseFigure();return p;
    }
    public static void Apply(Control root)
    {
        foreach(Control c in root.Controls)Apply(c);
        if(root is MapCanvas or GpuCloudPanel)return;
        root.ForeColor=Text;
        switch(root)
        {
            case Form f: f.BackColor=Background;break;
            case TabPage p: p.BackColor=Panel;p.Font=UiFonts.Create(9.5f);break;
            case TabControl: root.BackColor=Background;break;
            case DataGridView grid:
                grid.EnableHeadersVisualStyles=false;grid.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.None;grid.BackgroundColor=Panel;grid.GridColor=Border;
                grid.ColumnHeadersHeight=32;grid.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
                grid.ColumnHeadersDefaultCellStyle=new(){BackColor=Raised,ForeColor=Muted,Font=UiFonts.Create(9,FontStyle.Bold),Padding=new Padding(4)};
                grid.DefaultCellStyle=new(){BackColor=Panel,ForeColor=Text,SelectionBackColor=Color.FromArgb(223,240,192),SelectionForeColor=Accent,Padding=new Padding(4)};
                grid.AlternatingRowsDefaultCellStyle.BackColor=Color.FromArgb(246,249,240);grid.RowTemplate.Height=22;grid.CellBorderStyle=DataGridViewCellBorderStyle.SingleHorizontal;break;
            case Button b:
                // UI IMPROVEMENT: information actions are neutral; retain every existing button.
                if(b is StudioButton studio){studio.Neutral|=b.Text.Contains("자료 정보");studio.SecondaryAccent=b.Text.Contains("좌표")||b.Text.Contains("교환")||b.Text=="선택 노선 저장";}
                b.FlatStyle=FlatStyle.Flat;b.FlatAppearance.BorderColor=Border;b.FlatAppearance.BorderSize=b is StudioButton?0:1;
                b.BackColor=Raised;b.ForeColor=Text;b.Cursor=Cursors.Hand;b.FlatAppearance.MouseOverBackColor=Color.FromArgb(223,235,208);break;
            case NumericUpDown n: n.BackColor=Panel;n.ForeColor=Text;n.BorderStyle=BorderStyle.FixedSingle;break;
            case TextBox t: t.BackColor=Panel;t.ForeColor=Text;t.BorderStyle=BorderStyle.FixedSingle;break;
            case ComboBox b:
                b.BackColor=Panel;b.ForeColor=Text;b.FlatStyle=FlatStyle.Flat;
                if(b.DrawMode!=DrawMode.OwnerDrawFixed)
                {
                    b.DrawMode=DrawMode.OwnerDrawFixed;b.ItemHeight=24;
                    b.DrawItem+=(_,e)=>{if(e.Bounds.Width<=0)return;using var fill=new SolidBrush((e.State&DrawItemState.Selected)!=0?Raised:Panel);e.Graphics.FillRectangle(fill,e.Bounds);string label=e.Index<0?b.Text:(b.GetItemText(b.Items[e.Index])??string.Empty);TextRenderer.DrawText(e.Graphics,label,b.Font,Rectangle.Inflate(e.Bounds,-5,0),Text,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);};
                }
                break;
            case CheckedListBox l: l.BackColor=Panel;l.ForeColor=Text;l.IntegralHeight=false;break;
            case ListBox l: l.BackColor=Panel;l.ForeColor=Text;break;
            case StatusStrip strip: strip.BackColor=Background;strip.ForeColor=Muted;foreach(ToolStripItem item in strip.Items)item.ForeColor=Muted;break;
            case Label l: l.BackColor=Color.Transparent;l.ForeColor=l.Font.Bold?Text:Muted;break;
            case CheckBox b: b.BackColor=Color.Transparent;b.ForeColor=Muted;break;
            case ProfileCanvas: root.BackColor=Panel;break;
            case System.Windows.Forms.Panel: root.BackColor=Panel;break;
        }
        if(root is not Form&&root is not StudioHeader&&root is not StudioButton)root.Invalidate();
    }
}

internal sealed class StudioButton:Button
{
    bool hover;public bool Primary {get;set;}public bool Neutral {get;set;}public bool SecondaryAccent {get;set;}
    public StudioButton(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;Margin=new Padding(4);Font=UiFonts.Create(9.5f,FontStyle.Bold);}
    protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
    protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
    protected override void OnPaint(PaintEventArgs e)
    {
        var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(Parent?.BackColor??StudioTheme.Panel);
        using var path=StudioTheme.Round(new RectangleF(1,1,Width-3,Height-3),8);
        Color fill=!Enabled?StudioTheme.Background:Primary?(hover?Color.FromArgb(65,130,53):StudioTheme.Accent):Neutral?(hover?Color.FromArgb(231,234,228):StudioTheme.Background):(hover?StudioTheme.Raised:StudioTheme.Panel);
        // UI IMPROVEMENT: consistent secondary borders and visible keyboard focus.
        using var brush=new SolidBrush(fill);g.FillPath(brush,path);using var pen=new Pen(Enabled&&(Primary||SecondaryAccent)?StudioTheme.Accent:StudioTheme.Border,Focused&&Enabled?2:1);g.DrawPath(pen,path);
        TextRenderer.DrawText(g,Text,Font,ClientRectangle,!Enabled?StudioTheme.Muted:Primary?Color.White:SecondaryAccent?StudioTheme.Forest:StudioTheme.Text,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
        if(Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(g,Rectangle.Inflate(ClientRectangle,-5,-5),StudioTheme.Accent,fill);
    }
}

internal sealed class StudioTabs:TabControl
{
    public bool Workflow {get;set;}
    public StudioTabs(){DrawMode=TabDrawMode.OwnerDrawFixed;ItemSize=new Size(150,36);SizeMode=TabSizeMode.Fixed;Padding=new Point(12,6);Font=UiFonts.Create(10,FontStyle.Bold);}
    protected override void OnLayout(LayoutEventArgs e)
    {
        base.OnLayout(e);if(TabCount==0)return;
        var size=new Size(Math.Max(1,(ClientSize.Width-6)/TabCount),36);if(ItemSize!=size)ItemSize=size;
    }
    protected override void OnDrawItem(DrawItemEventArgs e)
    {
        bool selected=e.Index==SelectedIndex;using var brush=new SolidBrush(selected?(Workflow?StudioTheme.Forest:StudioTheme.Raised):StudioTheme.Background);e.Graphics.FillRectangle(brush,e.Bounds);
        if(selected){using var accent=new SolidBrush(StudioTheme.Highlight);e.Graphics.FillRectangle(accent,e.Bounds.Left+12,e.Bounds.Bottom-3,e.Bounds.Width-24,3);}
        TextRenderer.DrawText(e.Graphics,TabPages[e.Index].Text,Font,e.Bounds,selected&&Workflow?Color.White:selected?StudioTheme.Text:StudioTheme.Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
    }
    protected override void WndProc(ref Message m)
    {
        base.WndProc(ref m);
        if(m.Msg==0xF&&IsHandleCreated){using var g=Graphics.FromHwnd(Handle);PaintFrame(g);}
        else if((m.Msg==0x317||m.Msg==0x318)&&m.WParam!=IntPtr.Zero){using var g=Graphics.FromHdc(m.WParam);PaintFrame(g);}
    }
    void PaintFrame(Graphics g)
    {
        if(TabCount==0)return;int bottom=GetTabRect(0).Bottom+2;using var background=new SolidBrush(StudioTheme.Background);g.FillRectangle(background,0,0,Width,bottom);
        for(int i=0;i<TabCount;i++)OnDrawItem(new DrawItemEventArgs(g,Font,GetTabRect(i),i,i==SelectedIndex?DrawItemState.Selected:DrawItemState.None));
        g.FillRectangle(background,0,bottom,3,Height-bottom);g.FillRectangle(background,Width-3,bottom,3,Height-bottom);g.FillRectangle(background,0,Height-3,Width,3);
        using var edge=new Pen(StudioTheme.Border);g.DrawRectangle(edge,2,bottom,Width-5,Math.Max(1,Height-bottom-3));
    }
}

internal sealed class StudioHeader:Panel
{
    public StudioHeader(){DoubleBuffered=true;Dock=DockStyle.Fill;Margin=Padding.Empty;}
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
        using var fill=new LinearGradientBrush(ClientRectangle,Color.FromArgb(24,62,40),Color.FromArgb(49,89,45),0f);g.FillRectangle(fill,ClientRectangle);
        using var contour=new Pen(Color.FromArgb(70,112,66));for(int i=0;i<8;i++)g.DrawBezier(contour,Width-420+i*22,-10,Width-300+i*18,10,Width-390+i*28,60,Width-140+i*20,Height+20);
        using var logoPen=new Pen(Color.FromArgb(193,226,131),2);g.DrawLines(logoPen,new PointF[]{new(22,47),new(38,23),new(49,38),new(57,29),new(70,47)});g.DrawLine(logoPen,23,51,70,51);
        // UI IMPROVEMENT: quieter subtitle; title and breadcrumb positions remain unchanged.
        using var title=UiFonts.Create(18,FontStyle.Bold);using var subtitle=UiFonts.Create(8.5f);using var ink=new SolidBrush(Color.White);using var muted=new SolidBrush(Color.FromArgb(180,202,175));
        g.DrawString("임도 노선 설계",title,ink,86,11);g.DrawString("FOREST ROAD STUDIO  ·  지형에서 후보 노선까지",subtitle,muted,88,44);
        if(Width>900){using var pill=StudioTheme.Round(new RectangleF(Width-210,22,180,32),16);using var tint=new SolidBrush(Color.FromArgb(66,105,52));g.FillPath(tint,pill);TextRenderer.DrawText(g,"자료  →  지형  →  노선",subtitle,new Rectangle(Width-210,22,180,32),Color.FromArgb(220,240,175),TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);}
    }
}

