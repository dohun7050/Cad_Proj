using ForestRoad.Cad;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;

public sealed partial class MainForm
{
    internal async Task VerifyUi(string output)
    {
        Directory.CreateDirectory(output);
        var sizes=new List<string>();
        Size=new Size(UiLayout.Pixels(this,1440),UiLayout.Pixels(this,900)); Refresh(); Application.DoEvents();
        SavePreview(Path.Combine(output,"01-empty.png"));
        ValidateUiLayout();sizes.Add($"Desktop: {Width}x{Height}");
        // Explicit synthetic data: never loaded during ordinary startup.
        meters.Checked=true;
        int w=41,h=61; double[] heights=new double[w*h];
        for(int y=0;y<h;y++)for(int x=0;x<w;x++)heights[y*w+x]=100+y*.18+3*Math.Exp(-((x-20)*(x-20)+(y-30)*(y-30))/220.0);
        grid=new TerrainGrid(200000,500000,5,w,h,heights); map.Terrain=grid;
        generated=grid.Contours(1);map.Features=generated;
        display.Items.Add("DEM만 보기");display.SelectedIndex=2;
        // Use the existing CAD contour display path and route planner.
        map.Features=generated;map.OriginalOnly=false;
        map.SetBounds(Enumerable.Range(0,w*h).Select(grid.Node));
        map.Start=grid.Node(5*w+5);map.End=grid.Node(55*w+35);MarkersChanged?.Invoke();
        terrainInfo.Text=$"시연용 합성 지형 · {w} × {h} / 5m\n실제 측량 자료가 아닙니다.";
        fileInfo.Text="시연용 합성 지형\n좌표·고도·후보 선택 UI 검증";
        await FindRoute();map.Features=generated;
        if(comparison.Rows.Count!=map.Candidates.Count||map.Candidates.Count<1)throw new Exception("후보 비교 연동 실패");
        view3D.Checked=true;surface.Checked=true;map.ResetCamera();
        ValidateUiLayout();
        if(candidates.Height<candidates.ItemHeight*5||layers.Height<50)throw new Exception("후보 / 레이어 패널 높이 오류");
        SavePreview(Path.Combine(output,"02-terrain-routes.png"));File.WriteAllText(Path.Combine(output,"layout.txt"),string.Join("\n",FindControls(this).Select(c=>$"{c.GetType().Name} | {c.Text.Replace("\n"," ")} | {c.Bounds} | visible={c.Visible}")));
        candidates.SelectedIndex=map.Candidates.Count-1;
        if(map.SelectedCandidate!=candidates.SelectedIndex||comparison.CurrentRow?.Index!=candidates.SelectedIndex)throw new Exception("후보 선택 동기화 실패");
        SavePreview(Path.Combine(output,"03-selected-route.png"));
        var toggle=FindControls(this).OfType<Button>().First(b=>b.Text=="세부 설정 펼치기");toggle.PerformClick();
        ValidateUiLayout();
        if(toggle.Text!="세부 설정 접기"||!radius.Visible)throw new Exception("세부 설정 펼치기 실패");toggle.PerformClick();
        Size=new Size(UiLayout.Pixels(this,1100),UiLayout.Pixels(this,750));SavePreview(Path.Combine(output,"04-compact.png"));
        ValidateUiLayout();sizes.Add($"Compact: {Width}x{Height}");
        Size=MinimumSize;SavePreview(Path.Combine(output,"05-small.png"));
        ValidateUiLayout();sizes.Add($"Minimum: {Width}x{Height}");
        Size=new Size(UiLayout.Pixels(this,1440),UiLayout.Pixels(this,900));Font=UiFonts.Create(12);SavePreview(Path.Combine(output,"06-large-text.png"));
        ValidateUiLayout();
        File.WriteAllText(Path.Combine(output,"verification.txt"),$"PASS: startup, synthetic terrain, {map.Candidates.Count} route candidates, selection synchronization, advanced toggle, non-overlapping vertical panels, enlarged inherited text; VIEW restored to original responsive layout. DPI={DeviceDpi}.\n{string.Join("\n",sizes)}\nSynthetic preview data only. Actual DWG/LAS import and multi-monitor DPI changes were not tested.");
    }
    void ValidateUiLayout()
    {
        Refresh();Application.DoEvents();
        foreach(var flow in FindControls(this).OfType<FlowLayoutPanel>().Where(p=>p.Visible&&p.FlowDirection==FlowDirection.TopDown&&!p.WrapContents))
        {
            var controls=flow.Controls.Cast<Control>().Where(c=>c.Visible).ToArray();
            for(int i=0;i<controls.Length;i++)for(int j=i+1;j<controls.Length;j++)
                if(controls[i].Bounds.IntersectsWith(controls[j].Bounds))throw new Exception($"UI 겹침: {controls[i].GetType().Name} {controls[i].Bounds} {controls[i].Text} / {controls[j].GetType().Name} {controls[j].Bounds} {controls[j].Text}");
        }
        if(map.Width<220||map.Height<80)throw new Exception("지도 영역 부족");
    }
    static IEnumerable<Control> FindControls(Control root)
    {foreach(Control c in root.Controls){yield return c;foreach(var child in FindControls(c))yield return child;}}
}




