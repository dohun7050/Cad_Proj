namespace OkseongRoad.App;

// UI IMPROVEMENT: presentation only; keep the imported controls and updated DEM features.
internal static class DesktopPresentation
{
    public static void Apply(Form form,FlowLayoutPanel header,TabControl ribbon,TabControl scenes,
        FlowLayoutPanel left,FlowLayoutPanel right,Label start,Label end,Label files,Label result,
        DataGridView comparison,ProfileCanvas profile)
    {
        if(form.Controls[0] is TableLayoutPanel root&&root.ColumnStyles.Count==0)
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
        ((TableLayoutPanel)form.Controls[0]).RowStyles[0]=new RowStyle(SizeType.Absolute,76);
        header.AutoSize=false;
        form.Font=UiFonts.Create(9.5f);form.Text="임도 노선 설계 · Forest Road Studio · UI 개선본";
        StudioTheme.Apply(form);header.BackColor=StudioTheme.Forest;header.Padding=new Padding(20,10,20,10);
        header.FlowDirection=FlowDirection.TopDown;header.WrapContents=false;
        var titles=header.Controls.OfType<Label>().ToArray();
        titles[0].Text="임도 노선 설계";titles[0].Font=UiFonts.Create(17,FontStyle.Bold);titles[0].ForeColor=Color.White;
        titles[1].Text="01 자료 불러오기    →    02 DEM 생성    →    03 시작·종점 지정    →    04 후보 경로 생성";titles[1].Font=UiFonts.Create(8.5f);titles[1].ForeColor=Color.FromArgb(187,210,183);titles[1].Padding=Padding.Empty;
        ribbon.TabPages[0].Text="자료 불러오기";ribbon.TabPages[1].Text="DEM · 노선";
        ribbon.TabPages[2].Text="지형 · 3D 보기";ribbon.TabPages[3].Text="전체 점군 보기";
        StyleTabs(ribbon,true);StyleTabs(scenes,false);
        foreach(TabPage tab in ribbon.TabPages)
            foreach(var flow in tab.Controls.OfType<FlowLayoutPanel>())StyleTools(flow);
        left.Padding=new Padding(12);right.Padding=new Padding(12);scenes.TabPages[0].Text="지형 · 노선";scenes.TabPages[1].Text="전체 점군";
        files.Padding=new Padding(10);files.BackColor=StudioTheme.Background;files.ForeColor=StudioTheme.Muted;
        foreach(var flow in new[]{left,right})foreach(Control c in flow.Controls)
        {
            c.Margin=new Padding(0,0,0,8);
            if(c is Label label&&label.Font.Bold)
            {
                label.Font=UiFonts.Create(10.5f,FontStyle.Bold);label.ForeColor=StudioTheme.Forest;label.Padding=new Padding(0,6,0,6);
                label.Margin=new Padding(0,8,0,8);
                label.Paint+=(_,e)=>{using var p=new Pen(StudioTheme.Border);e.Graphics.DrawLine(p,0,label.Height-1,label.Width,label.Height-1);};
            }
            if(c is TableLayoutPanel row&&row.ColumnCount==2)
            {
                row.ColumnStyles[0].Width=60;row.ColumnStyles[1].Width=40;row.Margin=new Padding(0,0,0,8);
                foreach(var rowLabel in row.Controls.OfType<Label>())rowLabel.ForeColor=StudioTheme.Text;
                if(row.Controls.OfType<NumericUpDown>().FirstOrDefault() is {} number){number.TextAlign=HorizontalAlignment.Right;number.Font=UiFonts.Create(10,FontStyle.Bold);}
            }
        }
        StylePoint(start);StylePoint(end);
        result.Font=UiFonts.Create(9.5f,FontStyle.Bold);result.BackColor=StudioTheme.Raised;result.ForeColor=StudioTheme.Forest;result.Padding=new Padding(10);
        foreach(var button in Descendants(form).OfType<Button>())StyleButton(button);
        ConfigurePanels(form,left,right,comparison);
        comparison.Columns[2].HeaderText="평균 %";comparison.Columns[3].HeaderText="최대 %";
        comparison.ColumnHeadersDefaultCellStyle.ForeColor=StudioTheme.Forest;comparison.ColumnHeadersDefaultCellStyle.Padding=new Padding(4,8,4,8);
        comparison.RowTemplate.MinimumHeight=28;comparison.DefaultCellStyle.SelectionBackColor=Color.FromArgb(226,239,218);
        comparison.DefaultCellStyle.Alignment=DataGridViewContentAlignment.MiddleRight;
        comparison.AlternatingRowsDefaultCellStyle.BackColor=Color.FromArgb(248,250,246);
        comparison.Columns[0].DefaultCellStyle.Alignment=DataGridViewContentAlignment.MiddleCenter;
        profile.BackColor=StudioTheme.Panel;
    }
    static void ConfigurePanels(Form form,FlowLayoutPanel left,FlowLayoutPanel right,DataGridView comparison)
    {
        var tips=new ToolTip{AutoPopDelay=12000,InitialDelay=450,ReshowDelay=150,ShowAlways=true};
        form.Disposed+=(_,_)=>tips.Dispose();
        foreach(var button in Descendants(form).OfType<Button>())tips.SetToolTip(button,button.Text);
        var actions=right.Controls.OfType<FlowLayoutPanel>().FirstOrDefault(p=>p.Controls.OfType<Button>().Any(b=>b.Text=="후보 생성"));
        if(actions is not null)
        {
            if(right.Parent is TableLayoutPanel shell)
            {
                var primary=actions.Controls.OfType<Button>().First(b=>b.Text=="후보 생성");
                var cancel=actions.Controls.OfType<Button>().First(b=>b.Text=="작업 취소");cancel.Text="취소";cancel.Padding=Padding.Empty;cancel.Font=UiFonts.Create(9);
                var footer=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=new Padding(10,4,10,8)};
                footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,75));footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,25));footer.RowStyles.Add(new RowStyle(SizeType.Percent,100));
                foreach(var button in new[]{primary,cancel}){button.AutoSize=false;button.MaximumSize=Size.Empty;button.MinimumSize=Size.Empty;button.Dock=DockStyle.Fill;button.Margin=new Padding(3);}
                footer.Controls.Add(primary,0,0);footer.Controls.Add(cancel,1,0);
                shell.RowCount=3;shell.RowStyles.Add(new RowStyle(SizeType.Absolute,52));shell.Controls.Add(footer,0,2);
            }
            actions.FlowDirection=FlowDirection.TopDown;actions.WrapContents=false;actions.Padding=Padding.Empty;
            UiLayout.FitFlow(actions);
        }
        comparison.CellFormatting+=(_,e)=>
        {
            if(e.RowIndex<0||e.ColumnIndex!=0)return;
            e.Value=$"{e.RowIndex+1:00}";
            e.CellStyle!.ForeColor=Color.FromArgb(23,63,42);
            e.FormattingApplied=true;
        };
        comparison.DefaultCellStyle.SelectionBackColor=Color.FromArgb(216,235,224);
        comparison.DefaultCellStyle.SelectionForeColor=StudioTheme.Forest;
    }
    static IEnumerable<Control> Descendants(Control parent)
    {foreach(Control c in parent.Controls){yield return c;foreach(var child in Descendants(c))yield return child;}}
    static void StyleButton(Button b)
    {
        b.Font=UiFonts.Create(9.5f,FontStyle.Bold);b.Padding=new Padding(8,4,8,4);b.FlatStyle=FlatStyle.Flat;
        bool primary=b.Text.Contains("후보")&&!b.Text.Contains("CSV"),neutral=b.Text.Contains("취소")||b.Text.Contains("정보")||b.Text.Contains("접기");
        bool secondary=b.Text.Contains("좌표")||b.Text.Contains("CSV")||b.Text.Contains("↔");
        if(b is ActionButton action)action.Primary=primary;b.MinimumSize=new Size(b.MinimumSize.Width,UiLayout.Pixels(b,38));
        b.BackColor=primary?StudioTheme.Accent:neutral?StudioTheme.Background:StudioTheme.Panel;
        b.ForeColor=primary?Color.White:StudioTheme.Forest;b.FlatAppearance.BorderSize=primary?0:1;
        b.FlatAppearance.BorderColor=primary||secondary?StudioTheme.Accent:StudioTheme.Border;
        b.FlatAppearance.MouseOverBackColor=primary?Color.FromArgb(65,130,53):StudioTheme.Raised;
        b.FlatAppearance.MouseDownBackColor=primary?StudioTheme.Forest:Color.FromArgb(220,235,210);
    }
    static void StylePoint(Label label)
    {
        label.Padding=new Padding(10);label.Font=UiFonts.Create(9.5f,FontStyle.Bold);
        void State(){bool chosen=label.Text.StartsWith("S  X ")||label.Text.StartsWith("E  X ");label.BackColor=chosen?StudioTheme.Raised:StudioTheme.Background;label.ForeColor=chosen?StudioTheme.Forest:StudioTheme.Muted;label.Invalidate();}
        label.TextChanged+=(_,_)=>State();State();
    }
    static void StyleTabs(TabControl tabs,bool workflow)
    {
        tabs.DrawMode=TabDrawMode.OwnerDrawFixed;tabs.Font=UiFonts.Create(10,FontStyle.Bold);
        tabs.SizeMode=TabSizeMode.Fixed;tabs.Padding=new Point(12,6);tabs.ItemSize=new Size(UiLayout.Pixels(tabs,workflow?175:145),UiLayout.Pixels(tabs,34));
        tabs.DrawItem+=(_,e)=>
        {
            bool selected=e.Index==tabs.SelectedIndex;
            using var fill=new SolidBrush(selected?(workflow?StudioTheme.Forest:StudioTheme.Raised):StudioTheme.Background);e.Graphics.FillRectangle(fill,e.Bounds);
            var textBounds=e.Bounds;int icon=UiLayout.Pixels(tabs,18);LineIcons.Draw(e.Graphics,LineIcons.For(tabs.TabPages[e.Index].Text),new RectangleF(e.Bounds.Left+8,e.Bounds.Top+(e.Bounds.Height-icon)/2f,icon,icon),selected&&workflow?Color.White:StudioTheme.Forest);textBounds.X+=icon+10;textBounds.Width-=icon+12;TextRenderer.DrawText(e.Graphics,tabs.TabPages[e.Index].Text,tabs.Font,textBounds,selected&&workflow?Color.White:StudioTheme.Text,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
            if(selected){using var line=new SolidBrush(StudioTheme.Highlight);e.Graphics.FillRectangle(line,e.Bounds.Left+8,e.Bounds.Bottom-3,e.Bounds.Width-16,3);}
        };
    }
    static void StyleTools(FlowLayoutPanel flow)
    {
        // Group the existing option controls; their event connections and references remain intact.
        var original=flow.Controls.Cast<Control>().ToArray();
        for(int i=0;i<original.Length;i++)
        {
            var c=original[i];if(c is Button)continue;
            int index=flow.Controls.GetChildIndex(c);var tile=new OptionTile();
            tile.Controls.Add(c);
            if(c is Label&&i+1<original.Length&&original[i+1] is NumericUpDown)tile.Controls.Add(original[++i]);
            flow.Controls.Add(tile);flow.Controls.SetChildIndex(tile,index);
        }
        flow.Padding=new Padding(10,8,10,8);bool arranging=false;
        void Fit()
        {
            if(arranging||flow.Width<100)return;arranging=true;
            try
            {
                int gap=UiLayout.Pixels(flow,8),width=flow.ClientSize.Width-flow.Padding.Horizontal;
                int n=flow.Controls.Count,maxColumns=Math.Max(1,(width+gap)/UiLayout.Pixels(flow,190)),rows=(n+maxColumns-1)/maxColumns,index=0;
                for(int row=0;row<rows;row++)
                {
                    int count=n/rows+(row<n%rows?1:0),usable=width-(count-1)*gap;
                    for(int col=0;col<count;col++)
                    {
                        var c=flow.Controls[index++];c.AutoSize=false;c.MinimumSize=Size.Empty;c.Margin=new Padding(0,0,col+1<count?gap:0,gap);
                        c.Size=new Size(usable/count+(col<usable%count?1:0),UiLayout.Pixels(flow,42));
                    }
                }
                flow.Tag=rows*UiLayout.Pixels(flow,50)+flow.Padding.Vertical;
            }
            finally{arranging=false;}
        }
        flow.SizeChanged+=(_,_)=>Fit();flow.HandleCreated+=(_,_)=>Fit();flow.DpiChangedAfterParent+=(_,_)=>Fit();flow.FontChanged+=(_,_)=>Fit();Fit();
    }
}

internal sealed class OptionTile:Panel
{
    public OptionTile(){DoubleBuffered=true;Padding=new Padding(8,4,8,4);BackColor=StudioTheme.Panel;}
    protected override void OnLayout(LayoutEventArgs e)
    {
        base.OnLayout(e);if(Controls.Count==0)return;
        int available=Math.Max(1,Width-Padding.Horizontal);
        if(Controls.Count==2)
        {
            var input=Controls[1];int inputWidth=Math.Min(70,available/2);
            input.SetBounds(Width-Padding.Right-inputWidth,(Height-input.Height)/2,inputWidth,input.Height);
            var label=Controls[0];label.AutoSize=false;label.Padding=Padding.Empty;label.SetBounds(Padding.Left,0,available-inputWidth-4,Height);
            if(label is Label l)l.TextAlign=ContentAlignment.MiddleLeft;
        }
        else
        {
            var c=Controls[0];c.AutoSize=false;c.Padding=Padding.Empty;
            int height=c is CheckBox?Height-Padding.Vertical:c.Height;
            c.SetBounds(Padding.Left,(Height-height)/2,available,height);
        }
    }
    protected override void OnPaint(PaintEventArgs e)
    {base.OnPaint(e);using var pen=new Pen(StudioTheme.Border);e.Graphics.DrawRectangle(pen,0,0,Math.Max(0,Width-1),Math.Max(0,Height-1));}
}











