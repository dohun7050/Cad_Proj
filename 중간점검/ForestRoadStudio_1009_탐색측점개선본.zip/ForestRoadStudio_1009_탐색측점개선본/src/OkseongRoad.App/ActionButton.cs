using System.Drawing.Drawing2D;
namespace OkseongRoad.App;

// Icons are vector strokes rendered at the control's current DPI.
internal sealed class ActionButton : Button
{
    public bool Primary { get; set; }
    public ActionButton()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
        FlatStyle = FlatStyle.Flat; FlatAppearance.BorderSize = 0;
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
        g.Clear(Parent?.BackColor ?? StudioTheme.Panel);
        bool hot = ClientRectangle.Contains(PointToClient(MousePosition));
        Color fill = !Enabled ? StudioTheme.Background : Primary ? (hot ? StudioTheme.Forest : StudioTheme.Accent) : hot ? StudioTheme.Raised : StudioTheme.Panel;
        Color ink = !Enabled ? StudioTheme.Muted : Primary ? Color.White : StudioTheme.Forest;
        float scale = DeviceDpi / 96f;
        using var path = StudioTheme.Round(new RectangleF(1, 1, Width - 3, Height - 3), 6 * scale);
        using var brush = new SolidBrush(fill); g.FillPath(brush, path);
        using var border = new Pen(Focused ? StudioTheme.Accent : Primary ? fill : StudioTheme.Border, Focused ? 2 : 1); g.DrawPath(border, path);
        int icon = (int)(20 * scale), gap = (int)(8 * scale), inset = (int)(10 * scale);
        LineIcons.Draw(g, LineIcons.For(Text), new RectangleF(inset, (Height - icon) / 2f, icon, icon), ink);
        TextRenderer.DrawText(g, Text, Font, new Rectangle(inset + icon + gap, 3, Math.Max(1, Width - inset * 2 - icon - gap), Height - 6), ink,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
        if (Focused && ShowFocusCues) ControlPaint.DrawFocusRectangle(g, Rectangle.Inflate(ClientRectangle, -5, -5));
    }
    protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); Invalidate(); }
    protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); Invalidate(); }
}

internal static class LineIcons
{
    public static string For(string text) => text.Contains("저장") || text.Contains("CSV") ? "save" : text.Contains("시작") && !text.Contains("종점") ? "pin" : text.Contains("종점") ? "flag" : text.Contains("DEM") || text.Contains("지형") || text.Contains("높이") ? "terrain" : text.Contains("후보") || text.Contains("경로") ? "route" : text.Contains("열기") || text.Contains("불러") ? "folder" : text.Contains("레이어") ? "layers" : text.Contains("확대") || text.Contains("전체 보기") ? "zoom" : text.Contains("3D") || text.Contains("입체") || text.Contains("포인트") ? "cube" : text.Contains("2D") || text.Contains("원본") || text.Contains("위에서") ? "map" : text.Contains("취소") ? "close" : text.Contains("정보") ? "info" : text.Contains("접기") || text.Contains("펼치기") ? "settings" : "target";
    public static void Draw(Graphics g, string kind, RectangleF bounds, Color color)
    {
        var state = g.Save(); g.TranslateTransform(bounds.X, bounds.Y); g.ScaleTransform(bounds.Width / 24, bounds.Height / 24);
        using var p = new Pen(color, 1.7f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
        void Line(float x,float y,float a,float b) => g.DrawLine(p,x,y,a,b);
        void Lines(params PointF[] points) => g.DrawLines(p,points);
        switch(kind)
        {
            case "folder": Lines(new(3,20),new(3,5),new(9,5),new(12,8),new(21,8),new(21,20),new(3,20)); Line(3,11,21,11); break;
            case "save": Lines(new(4,3),new(18,3),new(21,6),new(21,21),new(3,21),new(3,3),new(4,3)); g.DrawRectangle(p,7,3,9,6); g.DrawRectangle(p,7,14,10,7); break;
            case "terrain": Lines(new(2,20),new(9,5),new(14,14),new(17,9),new(22,20),new(2,20)); Lines(new(6,11),new(9,13),new(12,11)); break;
            case "pin": g.DrawEllipse(p,5,2,14,14); g.DrawEllipse(p,10,7,4,4); Lines(new(6,13),new(12,22),new(18,13)); break;
            case "flag": Line(5,22,5,3); Lines(new(5,3),new(20,3),new(16,8),new(20,13),new(5,13)); break;
            case "route": g.DrawEllipse(p,2,16,5,5); g.DrawEllipse(p,17,3,5,5); Lines(new(5,16),new(5,8),new(13,8),new(13,16),new(19,16),new(19,8)); break;
            case "layers": Lines(new(2,8),new(12,3),new(22,8),new(12,13),new(2,8)); Lines(new(2,13),new(12,18),new(22,13)); Lines(new(2,18),new(12,23),new(22,18)); break;
            case "zoom": g.DrawEllipse(p,3,3,13,13); Line(15,15,22,22); Line(6,9,13,9); Line(9.5f,6,9.5f,13); break;
            case "cube": Lines(new(12,2),new(22,7),new(22,17),new(12,22),new(2,17),new(2,7),new(12,2)); Lines(new(2,7),new(12,12),new(22,7)); Line(12,12,12,22); break;
            case "map": Lines(new(2,5),new(8,2),new(16,6),new(22,3),new(22,19),new(16,22),new(8,18),new(2,21),new(2,5)); Line(8,2,8,18); Line(16,6,16,22); break;
            case "close": Line(5,5,19,19); Line(19,5,5,19); break;
            case "info": g.DrawEllipse(p,3,3,18,18); Line(12,10,12,17); Line(12,7,12,7.1f); break;
            case "settings": Line(3,6,21,6); Line(3,12,21,12); Line(3,18,21,18); g.DrawEllipse(p,7,4,4,4); g.DrawEllipse(p,15,10,4,4); g.DrawEllipse(p,6,16,4,4); break;
            default: g.DrawEllipse(p,5,5,14,14); g.DrawEllipse(p,10,10,4,4); Line(12,1,12,5); Line(12,19,12,23); Line(1,12,5,12); Line(19,12,23,12); break;
        }
        g.Restore(state);
    }
}
