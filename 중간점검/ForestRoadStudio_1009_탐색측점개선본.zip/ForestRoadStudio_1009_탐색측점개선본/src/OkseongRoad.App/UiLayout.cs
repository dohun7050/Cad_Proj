namespace OkseongRoad.App;

// Measure using the current font, including Windows text scaling.
internal static class UiLayout
{
    public static Label Text(string text, Padding padding=default) => new()
    {Text=text,AutoSize=true,Padding=padding,Margin=new Padding(2,2,2,2)};

    public static int Pixels(Control c,int logical)=>Math.Max(1,(int)Math.Round(logical*c.DeviceDpi/96.0));

    public static void FitWindow(Form form,bool main=false)
    {
        void Fit(bool initial)
        {
            var area=Screen.FromControl(form.Owner??form).WorkingArea;
            form.MinimumSize=new Size(Math.Min(Pixels(form,main?800:420),(int)(area.Width*.85)),Math.Min(Pixels(form,main?520:280),(int)(area.Height*.85)));
            var size=main&&initial?new Size(Math.Min((int)(area.Width*.9),Pixels(form,1440)),Math.Min((int)(area.Height*.88),Pixels(form,900))):form.Size;
            form.Size=new Size(Math.Min(size.Width,(int)(area.Width*.96)),Math.Min(size.Height,(int)(area.Height*.96)));
            if(initial&&main)form.Location=new Point(area.Left+(area.Width-form.Width)/2,area.Top+(area.Height-form.Height)/2);
            else form.Location=new Point(Math.Clamp(form.Left,area.Left,Math.Max(area.Left,area.Right-form.Width)),Math.Clamp(form.Top,area.Top,Math.Max(area.Top,area.Bottom-form.Height)));
        }
        form.Shown+=(_,_)=>Fit(true);
        form.DpiChanged+=(_,_)=>{if(form.IsHandleCreated)form.BeginInvoke((Action)(()=>Fit(false)));};
    }

    public static void FitLabel(Label label,int width)
    {
        width=Math.Max(60,width);
        label.AutoSize=true;
        label.MaximumSize=new Size(width,0);
        label.MinimumSize=new Size(width,0);
    }

    public static void FitFlow(FlowLayoutPanel flow)
    {
        bool fitting=false;
        void Fit()
        {
            if(fitting)return;fitting=true;flow.SuspendLayout();
            try{
            int width=Math.Max(80,flow.ClientSize.Width-flow.Padding.Horizontal-6);
            foreach(Control c in flow.Controls)
            {
                if(c is Label label)FitLabel(label,width);
                else if(c is CheckBox check)FitCheck(check,width);
                else if(c is Button button){button.AutoSize=false;button.MaximumSize=new Size(width,32767);int height=Math.Max(Pixels(button,38),TextRenderer.MeasureText(button.Text,button.Font,new Size(Math.Max(1,width-button.Padding.Horizontal-Pixels(button,42)),int.MaxValue),TextFormatFlags.WordBreak).Height+button.Padding.Vertical+8);button.MinimumSize=new Size(Math.Min(width,button.MinimumSize.Width),height);button.Width=width;button.Height=height;}
                else if(c is ComboBox combo){combo.MaximumSize=Size.Empty;combo.MinimumSize=new Size(width,combo.PreferredHeight);combo.Width=width;}
                else {c.MaximumSize=new Size(width,32767);c.MinimumSize=new Size(Math.Min(c.MinimumSize.Width,width),c.MinimumSize.Height);c.Width=width;if(c is TableLayoutPanel row)row.MinimumSize=new Size(width,0);}
            }
            }finally{flow.ResumeLayout(true);fitting=false;}
        }
                bool queued=false;
        void Reflow()
        {
            Fit();
            if(queued||!flow.IsHandleCreated||flow.IsDisposed)return;
            queued=true;
            flow.BeginInvoke((Action)(()=>{try{if(!flow.IsDisposed)flow.PerformLayout();}finally{queued=false;}}));
        }
        flow.SizeChanged+=(_,_)=>Reflow();flow.ControlAdded+=(_,_)=>Reflow();flow.Layout+=(_,_)=>Reflow();flow.HandleCreated+=(_,_)=>Reflow();Fit();
    }

    public static void FitTopLabel(Label label)
    {
        label.AutoSize=false;
        void Fit(){int width=Math.Max(50,label.Width-label.Padding.Horizontal);label.Height=TextRenderer.MeasureText(label.Text,label.Font,new Size(width,0),TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl).Height+label.Padding.Vertical+8;}
        label.SizeChanged+=(_,_)=>Fit();label.TextChanged+=(_,_)=>Fit();label.FontChanged+=(_,_)=>Fit();Fit();
    }
    static void FitCheck(CheckBox check,int width)
    {
        check.AutoSize=false;check.MaximumSize=new Size(width,32767);check.MinimumSize=new Size(width,0);check.Width=width;
        check.Height=Math.Max(check.Font.Height+4,TextRenderer.MeasureText(check.Text,check.Font,new Size(Math.Max(1,width-Pixels(check,24)),int.MaxValue),TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl).Height+Pixels(check,4));
    }

    public static FlowLayoutPanel Actions(params Control[] controls)
    {
        var flow=new FlowLayoutPanel{Dock=DockStyle.Bottom,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Padding=new Padding(8,4,8,4),WrapContents=true};
        foreach(var c in controls){c.AutoSize=true;c.MinimumSize=new Size(75,28);flow.Controls.Add(c);}return flow;
    }
    public static void FitTable(TableLayoutPanel table)
    {
        bool fitting=false;
        void Fit()
        {
            if(fitting)return;fitting=true;
            try
            {
                var widths=table.GetColumnWidths();
                foreach(Control c in table.Controls)
                {
                    int col=table.GetColumn(c);if(col<0||col>=widths.Length)continue;
                    int span=table.GetColumnSpan(c);int width=Math.Max(60,widths.Skip(col).Take(span).Sum()-c.Margin.Horizontal-4);
                    if(c is Label label)FitLabel(label,width);
                    if(c is CheckBox check)FitCheck(check,width);
                }
            }
            finally{fitting=false;}
        }
        table.SizeChanged+=(_,_)=>Fit();table.Layout+=(_,_)=>Fit();
    }
}






