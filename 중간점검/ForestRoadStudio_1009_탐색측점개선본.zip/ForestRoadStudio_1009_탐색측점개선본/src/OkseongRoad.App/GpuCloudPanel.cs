using System.ComponentModel;
using System.Runtime.InteropServices;
using OpenTK.GLControl;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OkseongRoad.Terrain;
using ForestRoad.Cad;
namespace OkseongRoad.App;

public sealed class GpuCloudPanel : Panel
{
    private sealed record Batch(int Vao, int Vbo, int Count);
    private GLControl? gl;
    private readonly List<Batch> batches = new();
    private int program, matrixLocation;
    private bool ready, redraw;
    private string? error;
    private float radius = 1, zoom = 1, pitch=.65f, yaw=-.65f;
    LasCloud? cloud;
    public Action<string>? Diagnostic {get;set;}
    public long UploadedCount {get;private set;}
    public string? Error=>error;
    public bool PreferRgb {get;set;}=true;
    public double HeightScale {get;set;}=1;
    public event Action<long,long>? UploadProgress;
    readonly TaskCompletionSource<bool> initialized=new(TaskCreationOptions.RunContinuationsAsynchronously);
    readonly ViewToolbar toolbar=new(){Width=640};
    Batch? routeBatch;
    Batch? contourBatch;
    List<CadFeature> contours=[];
    readonly List<(int First,int Count,int Index)> routeRanges=[];
    public bool ShowAllRoutes {get;set;}=true;
    float maximumLineWidth=1;
    public List<RoadRoute> Routes {get;private set;}=[];
    public int SelectedRoute {get;private set;}
    public string ViewPreset {get;private set;}="ISO";
    private Vector2 pan;
    private Point last;
    private readonly System.Windows.Forms.Timer frames = new() { Interval = 16 };
    public GpuCloudPanel()
    {
        BackColor = Color.FromArgb(23,31,43);Controls.Add(toolbar);toolbar.Selected+=SetView;
        Resize+=(_,_)=>{toolbar.Width=Math.Min(680,Math.Max(280,Width-24));toolbar.Location=new Point((Width-toolbar.Width)/2,Math.Max(0,Height-toolbar.Height-12));toolbar.BringToFront();};
        frames.Tick += (_, _) => { if (redraw && ready) { redraw = false; gl?.Invalidate(); } };
    }
    protected override void OnCreateControl()
    {
        Diagnostic?.Invoke("GPU OnCreateControl");base.OnCreateControl();
        if (gl != null || DesignMode || LicenseManager.UsageMode == LicenseUsageMode.Designtime) return;
        try
        {
            Diagnostic?.Invoke("Create GLControl");gl = new GLControl(new GLControlSettings { API = ContextAPI.OpenGL, APIVersion = new Version(3, 3), Profile = ContextProfile.Core }) { Dock = DockStyle.Fill };
            gl.Load += (_, _) => InitializeGl();
            gl.Paint += (_, _) => Draw();
            gl.Resize += (_, _) => redraw = true;
            gl.MouseDown += (_, e) => { gl.Focus(); last = e.Location; gl.Capture = true; };
            gl.MouseUp += (_, _) => gl.Capture = false;
            gl.MouseMove += (_, e) =>
            {
                if (e.Button == MouseButtons.Left) { yaw += (e.X - last.X) * .008f; pitch=Math.Clamp(pitch+(e.Y-last.Y)*.008f,-MathF.PI/2,MathF.PI/2);ViewPreset="FREE";toolbar.Camera="FREE";toolbar.Invalidate(); }
                else if (e.Button is MouseButtons.Right or MouseButtons.Middle)
                {
                    float units = 2 * radius * 1.15f / zoom / Math.Max(1, gl.Height) / Math.Min(1f, gl.Width / (float)Math.Max(1, gl.Height));
                    pan += new Vector2((e.X - last.X) * units, -(e.Y - last.Y) * units);
                }
                last = e.Location;
                if (e.Button != MouseButtons.None) redraw = true;
            };
            gl.MouseWheel += (_, e) => { zoom = Math.Clamp(zoom * (e.Delta > 0 ? 1.15f : 1 / 1.15f), .02f, 10000); redraw = true; };
            gl.DoubleClick += (_, _) => FitAll();
            gl.KeyDown += (_,e)=>{if(e.KeyCode==Keys.D1)SetView("2D");if(e.KeyCode==Keys.D3)SetView("ISO");};
            Diagnostic?.Invoke("Add GLControl");Controls.Add(gl);Diagnostic?.Invoke("GLControl added");toolbar.BringToFront();toolbar.Is3D=true;frames.Start();
        }
        catch (Exception ex) { ShowError(ex); }
    }
    private void ShowError(Exception ex)
    {
        Diagnostic?.Invoke("GPU error: "+ex);error = "OpenGL 화면 오류: " + ex.Message; ready = false;
        if (gl != null) gl.Visible = false;
        initialized.TrySetResult(false);Invalidate();
    }
    private void InitializeGl()
    {
        if(ready)return;
        try
        {
            Diagnostic?.Invoke("Initialize GL");gl!.MakeCurrent();
            int vs = Compile(ShaderType.VertexShader, "#version 330 core\nlayout(location=0) in vec3 position; layout(location=1) in vec4 color; uniform mat4 mvp; out vec4 pointColor; uniform bool heightColor; uniform float zRange; void main(){ gl_Position=mvp*vec4(position,1.0); gl_PointSize=2.0; float t=clamp(position.z/max(zRange,0.001)+0.5,0.0,1.0); vec3 c=t<0.5?mix(vec3(0.15,0.35,0.8),vec3(0.45,0.8,0.55),t*2.0):mix(vec3(0.45,0.8,0.55),vec3(1.0,0.5,0.25),(t-0.5)*2.0); pointColor=heightColor?vec4(c,1.0):color; }");
            int fs = Compile(ShaderType.FragmentShader, "#version 330 core\nin vec4 pointColor; out vec4 outputColor; void main(){ outputColor=pointColor; }");
            program = GL.CreateProgram(); GL.AttachShader(program, vs); GL.AttachShader(program, fs); GL.LinkProgram(program);
            GL.DeleteShader(vs); GL.DeleteShader(fs);
            GL.GetProgram(program, GetProgramParameterName.LinkStatus, out int linked);
            if (linked == 0) throw new InvalidOperationException(GL.GetProgramInfoLog(program));
            matrixLocation = GL.GetUniformLocation(program, "mvp");
            GL.Enable(EnableCap.DepthTest); GL.Enable(EnableCap.ProgramPointSize); GL.ClearColor(20/255f,38/255f,29/255f,1); // UI IMPROVEMENT: match the forest canvas.
            var widthRange=new float[2];GL.GetFloat(GetPName.AliasedLineWidthRange,widthRange);maximumLineWidth=Math.Max(1,widthRange[1]);
            Diagnostic?.Invoke("GPU renderer: "+GL.GetString(StringName.Renderer)+" / "+GL.GetString(StringName.Version));
            ready = true; redraw = true;Diagnostic?.Invoke("GL initialized");initialized.TrySetResult(true);
        }
        catch (Exception ex) { ShowError(ex); }
    }
    private static int Compile(ShaderType type, string source)
    {
        int shader = GL.CreateShader(type); GL.ShaderSource(shader, source); GL.CompileShader(shader);
        GL.GetShader(shader, ShaderParameter.CompileStatus, out int ok);
        if (ok == 0) { string log = GL.GetShaderInfoLog(shader); GL.DeleteShader(shader); throw new InvalidOperationException(log); }
        return shader;
    }
    public async Task SetCloudAsync(LasCloud data,CancellationToken ct)
    {
        Diagnostic?.Invoke("Await GPU ready");if(!await initialized.Task.WaitAsync(TimeSpan.FromSeconds(15),ct))throw new InvalidOperationException(error??"OpenGL을 사용할 수 없습니다.");
        if(!ready)throw new InvalidOperationException(error??"OpenGL이 준비되지 않았습니다.");
        Diagnostic?.Invoke("Start GPU upload");FreeCloud();var pending=new List<Batch>();
        try
        {
            using var source=new LasGpuSource(data);
            while(true)
            {
                var vertices=await Task.Run(()=>source.Next(ct),ct);if(vertices is null)break;ct.ThrowIfCancellationRequested();if(IsDisposed)throw new OperationCanceledException();
                if(vertices.Length>0)
                {
                    gl!.MakeCurrent();int vao=GL.GenVertexArray(),vbo=GL.GenBuffer();pending.Add(new(vao,vbo,vertices.Length));GL.BindVertexArray(vao);GL.BindBuffer(BufferTarget.ArrayBuffer,vbo);
                    GL.BufferData(BufferTarget.ArrayBuffer,vertices.Length*16,vertices,BufferUsageHint.StaticDraw);
                    if(GL.GetError()!=ErrorCode.NoError)throw new InvalidOperationException("GPU 메모리에 전체 점을 올리지 못했습니다. GPU 해제를 누르고 기존 지형 탭의 표본 보기를 사용하세요.");
                    GL.VertexAttribPointer(0,3,VertexAttribPointerType.Float,false,16,0);GL.EnableVertexAttribArray(0);GL.VertexAttribPointer(1,4,VertexAttribPointerType.UnsignedByte,true,16,12);GL.EnableVertexAttribArray(1);
                }
                UploadProgress?.Invoke(source.ReadCount,source.TotalCount);
            }
            batches.AddRange(pending);pending.Clear();cloud=data;UploadedCount=batches.Sum(b=>(long)b.Count);
            var b=data.Bounds;radius=(float)Math.Max(1,Math.Sqrt(Math.Pow(b.MaxX-b.MinX,2)+Math.Pow(b.MaxY-b.MinY,2)+Math.Pow(b.MaxZ-b.MinZ,2))/2);FitAll();SetRoutes(Routes,SelectedRoute);SetContours(contours);
        }
        finally{Diagnostic?.Invoke("GPU upload done");if(!IsDisposed&&ready){gl!.MakeCurrent();DeleteBatches(pending);}}
    }
    public void FreeCloud()
    {
        if(ready&&gl is not null){gl.MakeCurrent();DeleteBatches(batches);if(routeBatch is {} old){DeleteBatches([old]);routeBatch=null;}}
        if(ready&&gl is not null&&contourBatch is {} contour){gl.MakeCurrent();DeleteBatches([contour]);contourBatch=null;}
        cloud=null;UploadedCount=0;redraw=true;
    }
    public void SetView(string view)
    {
        if(view=="3D")view="ISO";
        ViewPreset=view;toolbar.Camera=view;toolbar.Is3D=view!="2D";
        (yaw,pitch)=view switch{"TOP" or "2D"=>(0,MathF.PI/2),"BOTTOM"=>(0,-MathF.PI/2),"LEFT"=>(MathF.PI/2,0),"RIGHT"=>(-MathF.PI/2,0),"FRONT"=>(MathF.PI,0),"BACK"=>(0,0),_=>(-.65f,.65f)};
        toolbar.Invalidate();redraw=true;
    }
    public void FitAll(){zoom=1;pan=Vector2.Zero;SetView("ISO");}
    public void RefreshColors(){redraw=true;}
    public void SetContours(List<CadFeature> features)
    {
        contours=features;if(!ready||cloud is null)return;gl!.MakeCurrent();
        if(contourBatch is {} old){DeleteBatches([old]);contourBatch=null;}
        double cx=(cloud.Bounds.MinX+cloud.Bounds.MaxX)/2,cy=(cloud.Bounds.MinY+cloud.Bounds.MaxY)/2,cz=(cloud.Bounds.MinZ+cloud.Bounds.MaxZ)/2;
        var vertices=new List<GpuPoint>();
        foreach(var f in features.Where(f=>f.Visible&&f.Text is null&&f.Points.Count>1))
            for(int i=1;i<f.Points.Count;i++)foreach(var p in new[]{f.Points[i-1],f.Points[i]})
                vertices.Add(new(){X=(float)(p.X-cx),Y=(float)(p.Y-cy),Z=(float)(p.Z-cz),R=255,G=226,B=113,A=255});
        if(vertices.Count>0)
        {
            int vao=GL.GenVertexArray(),vbo=GL.GenBuffer();GL.BindVertexArray(vao);GL.BindBuffer(BufferTarget.ArrayBuffer,vbo);var array=vertices.ToArray();
            GL.BufferData(BufferTarget.ArrayBuffer,array.Length*16,array,BufferUsageHint.StaticDraw);GL.VertexAttribPointer(0,3,VertexAttribPointerType.Float,false,16,0);GL.EnableVertexAttribArray(0);GL.VertexAttribPointer(1,4,VertexAttribPointerType.UnsignedByte,true,16,12);GL.EnableVertexAttribArray(1);contourBatch=new(vao,vbo,array.Length);
        }
        redraw=true;
    }
    public void SetRoutes(List<RoadRoute> routes,int selected)
    {
        Routes=routes;SelectedRoute=selected;if(!ready||cloud is null)return;gl!.MakeCurrent();if(routeBatch is {} old){DeleteBatches([old]);routeBatch=null;}
        double cx=(cloud.Bounds.MinX+cloud.Bounds.MaxX)/2,cy=(cloud.Bounds.MinY+cloud.Bounds.MaxY)/2,cz=(cloud.Bounds.MinZ+cloud.Bounds.MaxZ)/2;
        routeRanges.Clear();var vertices=new List<GpuPoint>();
        for(int index=0;index<routes.Count;index++)
        {
            int first=vertices.Count;var color=MapCanvas.RouteColors[index%MapCanvas.RouteColors.Length];var route=routes[index];
            foreach(var (a,b) in route.Vertices.Zip(route.Vertices.Skip(1)))foreach(var p in new[]{a,b})vertices.Add(new(){X=(float)(p.X-cx),Y=(float)(p.Y-cy),Z=(float)(p.Z-cz),R=color.R,G=color.G,B=color.B,A=255});
            routeRanges.Add((first,vertices.Count-first,index));
        }
        if(vertices.Count>0){int vao=GL.GenVertexArray(),vbo=GL.GenBuffer();GL.BindVertexArray(vao);GL.BindBuffer(BufferTarget.ArrayBuffer,vbo);var array=vertices.ToArray();GL.BufferData(BufferTarget.ArrayBuffer,array.Length*16,array,BufferUsageHint.StaticDraw);GL.VertexAttribPointer(0,3,VertexAttribPointerType.Float,false,16,0);GL.EnableVertexAttribArray(0);GL.VertexAttribPointer(1,4,VertexAttribPointerType.UnsignedByte,true,16,12);GL.EnableVertexAttribArray(1);routeBatch=new(vao,vbo,array.Length);}
        redraw=true;
    }
    public Bitmap CaptureFrame()
    {
        if(!ready||gl is null)throw new InvalidOperationException(error??"GPU 미준비");Draw();gl.MakeCurrent();GL.ReadBuffer(ReadBufferMode.Front);var pixels=new byte[gl.Width*gl.Height*4];GL.ReadPixels(0,0,gl.Width,gl.Height,PixelFormat.Bgra,PixelType.UnsignedByte,pixels);
        var bitmap=new Bitmap(gl.Width,gl.Height,System.Drawing.Imaging.PixelFormat.Format32bppArgb);var locked=bitmap.LockBits(new Rectangle(0,0,bitmap.Width,bitmap.Height),System.Drawing.Imaging.ImageLockMode.WriteOnly,bitmap.PixelFormat);Marshal.Copy(pixels,0,locked.Scan0,pixels.Length);bitmap.UnlockBits(locked);bitmap.RotateFlip(RotateFlipType.RotateNoneFlipY);
        using(var graphics=Graphics.FromImage(bitmap)){using var bar=new Bitmap(toolbar.Width,toolbar.Height);toolbar.DrawToBitmap(bar,new Rectangle(Point.Empty,bar.Size));graphics.DrawImageUnscaled(bar,toolbar.Location);}return bitmap;
    }
    private void Draw()
    {
        if (!ready || gl == null || gl.Width < 1 || gl.Height < 1) return;
        gl.MakeCurrent(); GL.Viewport(0, 0, gl.Width, gl.Height); GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
        float effectiveRadius=cloud is null?radius:(float)Math.Max(1,Math.Sqrt(Math.Pow(cloud.Bounds.MaxX-cloud.Bounds.MinX,2)+Math.Pow(cloud.Bounds.MaxY-cloud.Bounds.MinY,2)+Math.Pow((cloud.Bounds.MaxZ-cloud.Bounds.MinZ)*HeightScale,2))/2);
        float aspect = gl.Width / (float)gl.Height, halfHeight = effectiveRadius * 1.15f / zoom / Math.Min(1, aspect);
        Matrix4 model = Matrix4.CreateScale(1,1,(float)HeightScale)*Matrix4.CreateRotationZ(yaw) * Matrix4.CreateRotationX(pitch-MathF.PI/2) * Matrix4.CreateTranslation(pan.X, pan.Y, 0);
        Matrix4 view = Matrix4.LookAt(new Vector3(0, 0, effectiveRadius * 3), Vector3.Zero, Vector3.UnitY);
        Matrix4 projection = Matrix4.CreateOrthographic(halfHeight * 2 * aspect, halfHeight * 2, effectiveRadius * .01f, effectiveRadius * 8);
        Matrix4 mvp = model * view * projection;
        GL.UseProgram(program); GL.UniformMatrix4(matrixLocation, false, ref mvp);
        GL.Uniform1(GL.GetUniformLocation(program,"heightColor"),!PreferRgb||cloud?.HasRgb!=true?1:0);GL.Uniform1(GL.GetUniformLocation(program,"zRange"),(float)(cloud is null?1:cloud.Bounds.MaxZ-cloud.Bounds.MinZ));
        foreach (var b in batches) { GL.BindVertexArray(b.Vao); GL.DrawArrays(PrimitiveType.Points, 0, b.Count); }
        if(contourBatch is {} contour){GL.Uniform1(GL.GetUniformLocation(program,"heightColor"),0);GL.Disable(EnableCap.DepthTest);GL.LineWidth(Math.Min(maximumLineWidth,1.8f));GL.BindVertexArray(contour.Vao);GL.DrawArrays(PrimitiveType.Lines,0,contour.Count);GL.Enable(EnableCap.DepthTest);}
        if(routeBatch is {} route){GL.Uniform1(GL.GetUniformLocation(program,"heightColor"),0);GL.Disable(EnableCap.DepthTest);GL.BindVertexArray(route.Vao);foreach(var range in routeRanges.OrderBy(r=>r.Index==SelectedRoute?1:0)){if(!ShowAllRoutes&&range.Index!=SelectedRoute)continue;GL.LineWidth(Math.Min(maximumLineWidth,range.Index==SelectedRoute?5:2));GL.DrawArrays(PrimitiveType.Lines,range.First,range.Count);}GL.Enable(EnableCap.DepthTest);}
        gl.SwapBuffers();
    }
    private static void DeleteBatches(List<Batch> items) { foreach (var b in items) { GL.DeleteBuffer(b.Vbo); GL.DeleteVertexArray(b.Vao); } items.Clear(); }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        if (gl == null || error != null) TextRenderer.DrawText(e.Graphics, error ?? "OpenGL 3D 점군 영역", Font, ClientRectangle, Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) { frames.Stop(); frames.Dispose(); if (ready && gl is { IsDisposed: false }) { gl.MakeCurrent(); FreeCloud(); GL.DeleteProgram(program); ready = false; } }
        base.Dispose(disposing);
    }
}
