using System.Drawing.Text;
using System.Runtime.InteropServices;
namespace OkseongRoad.App;

internal static class UiFonts
{
    static readonly PrivateFontCollection collection=new();
    static readonly FontFamily family=Load();
    [DllImport("gdi32.dll",CharSet=CharSet.Unicode)]static extern int AddFontResourceEx(string path,uint flags,IntPtr reserved);
    static FontFamily Load()
    {
        foreach(string name in new[]{"SUIT-Regular.ttf","SUIT-Bold.ttf"})
        {
            string path=Path.Combine(AppContext.BaseDirectory,"Assets","Fonts",name);
            if(!File.Exists(path))continue;
            AddFontResourceEx(path,0x10,IntPtr.Zero);collection.AddFontFile(path);
        }
        return collection.Families.FirstOrDefault(f=>f.Name=="SUIT")??new FontFamily("맑은 고딕");
    }
    public static Font Create(float size=9.5f,FontStyle style=FontStyle.Regular)=>new(family,size,style,GraphicsUnit.Point);
    public static Font Create(float size,GraphicsUnit unit)=>new(family,size,FontStyle.Regular,unit);
    public static string Name=>family.Name;
}
