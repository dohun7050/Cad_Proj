using OkseongRoad.Terrain;
namespace OkseongRoad.App;

public sealed class ProfileCanvas:Control
{
    public List<Station> Points { get; set; }=[];
    public double MaximumAngle { get; set; }=LongitudinalGrade.DefaultAngle;
    public event Action<Station?>? Hovered;
    int hover=-1;
    public ProfileCanvas(){DoubleBuffered=true;BackColor=Color.White;Dock=DockStyle.Fill;MouseLeave+=(_,_)=>{hover=-1;Hovered?.Invoke(null);Invalidate();};}
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);if(Points.Count==0)return;
        double distance=Math.Clamp((e.X-52.0)/Math.Max(Width-72,1),0,1)*Points[^1].Distance;
        hover=Enumerable.Range(0,Points.Count).MinBy(i=>Math.Abs(Points[i].Distance-distance));Hovered?.Invoke(Points[hover]);Invalidate();
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);var g=e.Graphics;using var ink=new SolidBrush(StudioTheme.Text);string title="선택 후보 종단면 · 가로 평면거리(m) / 세로 고도(m)";
        int titleHeight=TextRenderer.MeasureText(title,Font,new Size(Math.Max(1,Width-24),int.MaxValue),TextFormatFlags.WordBreak).Height;
        TextRenderer.DrawText(g,title,Font,new Rectangle(12,8,Math.Max(1,Width-24),titleHeight),StudioTheme.Text,TextFormatFlags.WordBreak);
        if(Points.Count<2){TextRenderer.DrawText(g,"후보를 생성하면 종단면이 표시됩니다.",Font,new Rectangle(15,titleHeight+24,Math.Max(1,Width-30),Math.Max(1,Height-titleHeight-30)),StudioTheme.Text,TextFormatFlags.WordBreak);return;}
        double min=Points.Min(p=>p.Z),max=Points.Max(p=>p.Z),padding=Math.Max(1,(max-min)*0.12);min-=padding;max+=padding;
        float left=52,top=titleHeight+18,right=Width-20,bottom=Height-Font.Height-12;
        if(bottom<=top||right<=left)return;
        PointF Screen(Station p)=>new((float)(left+p.Distance/Math.Max(Points[^1].Distance,1e-9)*(right-left)),(float)(bottom-(p.Z-min)/(max-min)*(bottom-top)));
        using var grid=new Pen(StudioTheme.Border);
        for(int i=0;i<=4;i++){float y=top+(bottom-top)*i/4;g.DrawLine(grid,left,y,right,y);g.DrawString((max-(max-min)*i/4).ToString("0.0"),Font,ink,2,y-7);float x=left+(right-left)*i/4;g.DrawString((Points[^1].Distance*i/4).ToString("0"),Font,ink,x-12,bottom+7);}
        var pts=Points.Select(Screen).ToArray();using var fill=new SolidBrush(Color.FromArgb(30,111,175,69));g.FillPolygon(fill,pts.Concat(new[]{new PointF(right,bottom),new PointF(left,bottom)}).ToArray());
        using var normal=new Pen(StudioTheme.Accent,2);using var steep=new Pen(Color.OrangeRed,2.5f);
        for(int i=1;i<Points.Count;i++){double d=Points[i].Distance-Points[i-1].Distance;double angle=Math.Atan(Math.Abs(Points[i].Z-Points[i-1].Z)/Math.Max(d,1e-9))*180/Math.PI;g.DrawLine(angle>MaximumAngle*0.9?steep:normal,pts[i-1],pts[i]);}
        if(hover>=0&&hover<Points.Count){var q=pts[hover];using var cross=new Pen(Color.FromArgb(85,104,121)){DashStyle=System.Drawing.Drawing2D.DashStyle.Dash};g.DrawLine(cross,q.X,top,q.X,bottom);g.FillEllipse(ink,q.X-4,q.Y-4,8,8);g.DrawString($"{Points[hover].Distance:0.0}m / Z {Points[hover].Z:0.00}",Font,ink,Math.Clamp(q.X+8,left,Math.Max(left,right-155)),top);}
    }
}
