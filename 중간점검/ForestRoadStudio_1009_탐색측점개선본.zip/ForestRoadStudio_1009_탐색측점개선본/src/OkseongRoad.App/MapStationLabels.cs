using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.CompilerServices;
using ForestRoad.Cad;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;

public sealed partial class MapCanvas
{
    readonly ConditionalWeakTable<RoadRoute,HashSet<int>> expandedStations=new();
    readonly ToolTip stationTip=new(){InitialDelay=400,AutoPopDelay=15000};
    readonly List<StationLabel> stationLabels=[];
    RoadRoute? labelRoute;int hoveredStation=-1;
    readonly record struct StationLabel(int Index,Rectangle Box,Rectangle Toggle,PointF Anchor,bool Expanded);
    RoadRoute? SelectedStationRoute=>Candidates.Count>0
        ?SelectedCandidate>=0&&SelectedCandidate<Candidates.Count?Candidates[SelectedCandidate]:null:Route;
    static string StationDistance(double distance)=>distance.ToString("0.###",CultureInfo.InvariantCulture)+" m";
    static string StationCoordinate(double value)=>value.ToString("F3",CultureInfo.InvariantCulture);

    void DrawStationLabels(Graphics g)
    {
        stationLabels.Clear();labelRoute=null;
        if(OriginalOnly||DemOnly||SelectedStationRoute is not {} road)return;
        labelRoute=road;var opened=expandedStations.GetOrCreateValue(road);
        int unit=UiLayout.Pixels(this,1),gap=UiLayout.Pixels(this,5),icon=UiLayout.Pixels(this,22);
        using var labelFont=UiFonts.Create(8.5f);int row=Math.Max(UiLayout.Pixels(this,20),labelFont.Height+gap);
        Color accent=RouteColors[Math.Max(0,SelectedCandidate)%RouteColors.Length];
        var occupied=new List<Rectangle>();
        // Expanded cards receive space first; compact station headers remain individually clickable.
        foreach(int i in Enumerable.Range(0,road.Stations.Count).OrderByDescending(opened.Contains))
        {
            var station=road.Stations[i];var anchor=Screen(new CadPoint(station.X,station.Y,station.Z));
            if(!float.IsFinite(anchor.X)||!float.IsFinite(anchor.Y)||anchor.X<0||anchor.Y<0||anchor.X>Width||anchor.Y>Height)continue;
            bool expanded=opened.Contains(i);string title=expanded?$"측점 {i+1:00} · {StationDistance(station.Distance)}":StationDistance(station.Distance);
            int textWidth=TextRenderer.MeasureText(title,labelFont).Width;
            if(expanded)foreach(double value in new[]{station.X,station.Y,station.Z})
                textWidth=Math.Max(textWidth,TextRenderer.MeasureText("X  "+StationCoordinate(value),labelFont).Width);
            int width=textWidth+icon+gap*3,height=row*(expanded?4:1)+gap*2;
            width=Math.Min(width,Math.Max(1,Width-gap*2));height=Math.Min(height,Math.Max(1,Height-gap*2));
            Rectangle box=PlaceStationLabel(anchor,width,height,gap,occupied);
            occupied.Add(box);
            var toggle=new Rectangle(box.Left+gap,box.Top+gap,icon,row);
            stationLabels.Add(new(i,box,toggle,anchor,expanded));
        }
        using var connector=new Pen(Color.FromArgb(160,accent),Math.Max(1,unit));
        using var border=new Pen(Color.FromArgb(92,122,109),Math.Max(1,unit));
        using var background=new SolidBrush(Color.FromArgb(250,248,252,249));
        using var iconFill=new SolidBrush(Color.FromArgb(225,237,230));
        using var chevron=new Pen(Color.FromArgb(28,99,65),Math.Max(1.5f,UiLayout.Pixels(this,2)))
        {StartCap=LineCap.Round,EndCap=LineCap.Round,LineJoin=LineJoin.Round};
        foreach(var label in stationLabels.OrderBy(p=>p.Expanded))
        {
            var station=road.Stations[label.Index];var box=label.Box;
            g.DrawLine(connector,label.Anchor,new PointF(Math.Clamp(label.Anchor.X,box.Left,box.Right),box.Bottom));
            using var shape=StationRound(box,UiLayout.Pixels(this,5));g.FillPath(background,shape);g.DrawPath(border,shape);
            g.FillRectangle(iconFill,label.Toggle);float cx=label.Toggle.Left+label.Toggle.Width/2f,cy=label.Toggle.Top+label.Toggle.Height/2f,d=UiLayout.Pixels(this,3);
            if(label.Expanded)g.DrawLines(chevron,new PointF[]{new(cx-d,cy-d/2),new(cx,cy+d/2),new(cx+d,cy-d/2)});
            else g.DrawLines(chevron,new PointF[]{new(cx-d/2,cy-d),new(cx+d/2,cy),new(cx-d/2,cy+d)});
            string title=label.Expanded?$"측점 {label.Index+1:00} · {StationDistance(station.Distance)}":StationDistance(station.Distance);
            var text=new Rectangle(label.Toggle.Right+gap,box.Top+gap,Math.Max(1,box.Right-label.Toggle.Right-gap*2),row);
            TextRenderer.DrawText(g,title,labelFont,text,Color.FromArgb(28,76,51),TextFormatFlags.VerticalCenter|TextFormatFlags.NoPadding);
            if(!label.Expanded)continue;
            foreach(var (axis,value) in new[]{("X",station.X),("Y",station.Y),("Z",station.Z)})
            {text.Y+=row;TextRenderer.DrawText(g,axis+"  "+StationCoordinate(value),labelFont,text,Color.FromArgb(40,55,47),TextFormatFlags.VerticalCenter|TextFormatFlags.NoPadding);}
        }
    }
    Rectangle PlaceStationLabel(PointF anchor,int width,int height,int gap,List<Rectangle> occupied)
    {
        int top=Height>=UiLayout.Pixels(this,200)?UiLayout.Pixels(this,Is3D?48:12):gap;
        int bottom=viewToolbar.Visible?Math.Max(top+height,viewToolbar.Top-gap):Height-gap;
        int maxY=Math.Max(top,bottom-height),maxX=Math.Max(gap,Width-width-gap);
        // Try nearby rows above the point across the full canvas width before using another row.
        int columns=Math.Max(3,2*Width/Math.Max(1,width+gap)+1);
        for(int lane=0;lane<columns*12;lane++)
        {
            int column=lane%columns,offset=column==0?0:(column+1)/2*(column%2==1?-1:1);
            int x=(int)anchor.X-width/2+offset*(width+gap*2);
            int y=(int)anchor.Y-height-gap*2-(lane/columns)*(height+gap*2);
            var candidate=new Rectangle(Math.Clamp(x,gap,maxX),Math.Clamp(y,top,maxY),width,height);
            if(occupied.All(r=>!Rectangle.Inflate(r,gap,gap).IntersectsWith(candidate)))return candidate;
        }
        // Find the closest remaining space, including lower rows, for a dense 3D projection.
        Rectangle? closest=null;double best=double.PositiveInfinity;
        for(int y=top;y<=maxY;y+=height+gap*2)for(int x=gap;x<=maxX;x+=width+gap*2)
        {
            var candidate=new Rectangle(x,y,width,height);
            if(occupied.Any(r=>Rectangle.Inflate(r,gap,gap).IntersectsWith(candidate)))continue;
            double dx=x+width/2-anchor.X,dy=y+height-anchor.Y,score=dx*dx+dy*dy;
            if(score<best){best=score;closest=candidate;}
        }
        if(closest is {} available)return available;
        // Dense projections can exceed the available screen space. Zoom/pan exposes each point;
        // never discard a station or truncate its coordinates to reduce the label count.
        return new(Math.Clamp((int)anchor.X-width/2,gap,maxX),Math.Clamp((int)anchor.Y-height-gap*2,top,maxY),width,height);
    }
    static GraphicsPath StationRound(Rectangle box,int radius)
    {
        float d=Math.Max(1,Math.Min(radius*2,Math.Min(box.Width,box.Height)));var path=new GraphicsPath();
        path.AddArc(box.Left,box.Top,d,d,180,90);path.AddArc(box.Right-d,box.Top,d,d,270,90);
        path.AddArc(box.Right-d,box.Bottom-d,d,d,0,90);path.AddArc(box.Left,box.Bottom-d,d,d,90,90);path.CloseFigure();return path;
    }
    StationLabel? HitStationToggle(Point location)
    {
        if(OriginalOnly||DemOnly||Pick is not null||!ReferenceEquals(labelRoute,SelectedStationRoute))return null;
        // Reverse the paint order so overlapping labels hit the visible topmost card.
        foreach(var label in stationLabels.OrderBy(p=>p.Expanded).Reverse())
        {if(label.Box.Contains(location))return label.Toggle.Contains(location)?label:null;}
        return null;
    }
    bool ToggleStation(Point location)
    {
        if(HitStationToggle(location) is not {} label||labelRoute is null)return false;
        var opened=expandedStations.GetOrCreateValue(labelRoute);
        if(!opened.Add(label.Index))opened.Remove(label.Index);
        stationTip.SetToolTip(this,null);hoveredStation=-1;Invalidate();return true;
    }
    void UpdateStationHover(Point location)
    {
        if(drag is not null||Pick is not null)return;
        var hit=HitStationToggle(location);int index=hit?.Index??-1;
        if(index>=0)Cursor=Cursors.Hand;else if(Cursor==Cursors.Hand)Cursor=Cursors.Default;
        if(index==hoveredStation)return;hoveredStation=index;
        stationTip.SetToolTip(this,hit is {} label?(label.Expanded?"측점 XYZ 좌표 접기":"이 측점의 XYZ 좌표 펼치기"):null);
    }
}
