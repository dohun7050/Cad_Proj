using System.Drawing.Drawing2D;
namespace OkseongRoad.App;

/// <summary>Floating camera presets; pointer input is contained in this control.</summary>
public sealed class ViewToolbar:Control
{
    readonly (string Id,string Label,float Weight)[] items=[("ISO","ISO",42),("TOP","TOP",44),("BOTTOM","BOTTOM",62),("LEFT","LEFT",58),("RIGHT","RIGHT",64),("FRONT","FRONT",68),("BACK","BACK",64),("2D","2D",38),("3D","3D",38)];
    readonly ToolTip tip=new();
    public string Camera { get; set; }="ISO";
    public bool Is3D { get; set; }
    public event Action<string>? Selected;
    int hovered=-1;
    public ViewToolbar()
    {
        DoubleBuffered=true;Height=42;BackColor=Color.FromArgb(23,31,43);Cursor=Cursors.Hand;
        AccessibleName="시점 선택";AccessibleDescription="ISO, TOP, BOTTOM, 좌, 우, 상, 하, 2D, 3D 시점 선택";
        Font=UiFonts.Create(8,FontStyle.Bold); // UI IMPROVEMENT
    }
    RectangleF ButtonBounds(int index)
    {
        float x=38,y=7;
        for(int i=0;i<=index;i++)
        {
            float width=Math.Max(items[i].Weight,TextRenderer.MeasureText(items[i].Label,Font).Width+14);
            if(x+width>Width-10&&x>38){x=38;y+=34;}
            if(i==index)return new(x,y,width,28);
            x+=width+4;
        }
        return RectangleF.Empty;
    }
    protected override void OnSizeChanged(EventArgs e){base.OnSizeChanged(e);int required=(int)ButtonBounds(items.Length-1).Bottom+7;if(Height!=required)Height=required;Invalidate();}
    // UI IMPROVEMENT: text scaling can wrap the last view button without changing the width.
    protected override void OnFontChanged(EventArgs e)
    {
        base.OnFontChanged(e);int required=(int)ButtonBounds(items.Length-1).Bottom+7;
        if(Height!=required)Height=required;Invalidate();
    }
    static GraphicsPath Round(RectangleF rect,float radius)
    {
        var path=new GraphicsPath();float d=Math.Min(radius*2,Math.Min(rect.Width,rect.Height));
        path.AddArc(rect.X,rect.Y,d,d,180,90);path.AddArc(rect.Right-d,rect.Y,d,d,270,90);path.AddArc(rect.Right-d,rect.Bottom-d,d,d,0,90);path.AddArc(rect.X,rect.Bottom-d,d,d,90,90);path.CloseFigure();return path;
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
        // UI IMPROVEMENT: preserve the existing responsive bounds and camera events.
        using var outer=Round(new RectangleF(1,1,Width-2,Height-2),9);using var background=new SolidBrush(Color.FromArgb(29,50,36));using var border=new Pen(Color.FromArgb(76,107,64));g.FillPath(background,outer);g.DrawPath(border,outer);
        using var captionFont=new Font(Font.FontFamily,6.5f,FontStyle.Bold);TextRenderer.DrawText(g,"VIEW",captionFont,new Rectangle(7,8,30,26),Color.FromArgb(148,170,192),TextFormatFlags.VerticalCenter|TextFormatFlags.HorizontalCenter);
        for(int i=0;i<items.Length;i++)
        {
            var item=items[i];var rect=ButtonBounds(i);bool active=item.Id=="3D"?Is3D:item.Id=="2D"?!Is3D:Is3D&&Camera==item.Id;
            using var shape=Round(rect,6);using var fill=new SolidBrush(active?Color.FromArgb(193,225,138):i==hovered?Color.FromArgb(66,91,54):Color.FromArgb(37,61,43));g.FillPath(fill,shape);
            TextRenderer.DrawText(g,item.Label,Font,Rectangle.Round(rect),active?StudioTheme.Text:Color.FromArgb(210,225,194),TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.NoPadding);
        }
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);int next=Enumerable.Range(0,items.Length).FirstOrDefault(i=>ButtonBounds(i).Contains(e.Location),-1);
        if(next==hovered)return;hovered=next;tip.SetToolTip(this,next<0?"시점 선택":items[next].Id switch{"ISO"=>"입체 시점","TOP"=>"위에서 아래로 (+Z)","BOTTOM"=>"아래에서 위로 (-Z)","LEFT"=>"왼쪽에서 보기 (-X)","RIGHT"=>"오른쪽에서 보기 (+X)","FRONT"=>"상 방향에서 보기 (+Y)","BACK"=>"하 방향에서 보기 (-Y)","2D"=>"XY 평면 보기",_=>"3D 입체 보기"});Invalidate();
    }
    protected override void OnMouseLeave(EventArgs e){base.OnMouseLeave(e);hovered=-1;Invalidate();}
    protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(e.Button!=MouseButtons.Left)return;for(int i=0;i<items.Length;i++)if(ButtonBounds(i).Contains(e.Location)){Selected?.Invoke(items[i].Id);return;}}
    internal void ClickForCheck(string id){int index=Array.FindIndex(items,p=>p.Id==id);var r=ButtonBounds(index);OnMouseDown(new MouseEventArgs(MouseButtons.Left,1,(int)(r.X+r.Width/2),(int)(r.Y+r.Height/2),0));}
    protected override void Dispose(bool disposing){if(disposing)tip.Dispose();base.Dispose(disposing);}
}

