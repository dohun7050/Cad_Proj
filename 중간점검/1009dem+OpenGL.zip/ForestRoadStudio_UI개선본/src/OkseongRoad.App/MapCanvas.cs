﻿using System.Drawing.Drawing2D;
using ForestRoad.Cad;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;
public sealed partial class MapCanvas:Control
{
    public List<CadFeature> Features {get;set;}=[];
    public LasCloud? Cloud {get;set;}
    public RoadRoute? Route {get;set;}
    public CadPoint? Start {get;set;}
    public CadPoint? End {get;set;}
    public bool ContourMode {get;set;}
    public bool OverlayCad {get;set;}
    public bool OriginalOnly {get;set;}=true;
    public bool DemOnly {get;set;}
    public bool ShowCloud {get;set;}=true;
    string? pick;
    public string? Pick {get=>pick;set{pick=value;HoverPoint=null;pendingHover=null;HoverChanged?.Invoke(null);Invalidate();}}
    public event Action<CadPoint?>? HoverChanged;
    readonly System.Windows.Forms.Timer hoverTimer=new(){Interval=100};
    Point? pendingHover;
    public event Action<string,CadPoint>? Picked;
    public event Action<CadPoint>? Pointer;
    double minX,minY,maxX=621.36,maxY=1175.20,zoom=1,panX,panY;
    Point? drag;
    public MapCanvas(){InitializeToolbar();InitializeSceneRenderer();Dock=DockStyle.Fill;DoubleBuffered=true;BackColor=Color.FromArgb(20,38,29);Resize+=(_,_)=>Invalidate();hoverTimer.Tick+=(_,_)=>{if(pendingHover is not Point p||Pick is null||!Is3D){hoverTimer.Stop();return;}pendingHover=null;HoverPoint=PickTerrain(p);Cursor=HoverPoint is null?Cursors.No:Cursors.Cross;HoverChanged?.Invoke(HoverPoint);Invalidate();};} // UI IMPROVEMENT: forest canvas palette.
    double ViewScale=>Math.Min(Math.Max(Width-90,1)/Math.Max(maxX-minX,1),Math.Max(Height-90,1)/Math.Max(maxY-minY,1))*zoom;
    public PointF Screen(CadPoint p)=>Is3D?Project(p).Point:new((float)(Width/2.0+panX+(p.X-(minX+maxX)/2)*ViewScale),(float)(Height/2.0+panY-(p.Y-(minY+maxY)/2)*ViewScale));
    public CadPoint World(Point p)=>new((p.X-Width/2.0-panX)/ViewScale+(minX+maxX)/2,(Height/2.0+panY-p.Y)/ViewScale+(minY+maxY)/2,0);
    public void SetBounds(IEnumerable<CadPoint> points)
    {
        var list=points.ToList();if(list.Count==0){minX=minY=minZ=maxZ=0;maxX=621.36;maxY=1175.20;}else{minX=list.Min(p=>p.X);minY=list.Min(p=>p.Y);maxX=list.Max(p=>p.X);maxY=list.Max(p=>p.Y);minZ=list.Min(p=>p.Z);maxZ=list.Max(p=>p.Z);}Fit();
    }
    public void Fit(){zoom=1;panX=panY=0;Invalidate();}
    public void Zoom(double factor){zoom=Math.Clamp(zoom*factor,0.1,100);Invalidate();}
    internal Action PreserveView()
    {
        var saved=(minX,minY,maxX,maxY,minZ,maxZ,zoom,panX,panY,yaw,pitch);
        return ()=>{(minX,minY,maxX,maxY,minZ,maxZ,zoom,panX,panY,yaw,pitch)=saved;Invalidate();};
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);sceneRenderer?.RequestFrame();
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);Focus();
        if(e.Button==MouseButtons.Left&&Pick is not null)
        {
            var point=Is3D?PickTerrain(e.Location):World(e.Location);
            if(point is null){PickMissed?.Invoke();return;}
            var mode=Pick;Pick=null;Cursor=Cursors.Default;Picked?.Invoke(mode,point);Invalidate();
        }
        else if(e.Button is MouseButtons.Right or MouseButtons.Middle||(Is3D&&e.Button==MouseButtons.Left)){drag=e.Location;orbit=Is3D&&e.Button==MouseButtons.Left;Capture=true;}
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if(drag is Point p){if(orbit){yaw+=(e.X-p.X)*0.008;pitch=Math.Clamp(pitch+(e.Y-p.Y)*0.006,-Math.PI/2,Math.PI/2);CameraPreset="FREE";UpdateToolbar();}else{panX+=e.X-p.X;panY+=e.Y-p.Y;}drag=e.Location;Invalidate();}
        if(Is3D&&Pick is not null){pendingHover=e.Location;hoverTimer.Start();}else if(!Is3D)Pointer?.Invoke(World(e.Location));
    }
    protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);drag=null;Capture=false;}
    protected override void OnMouseWheel(MouseEventArgs e)
    {
        if(Is3D)Zoom(e.Delta>0?1.2:1/1.2);
        else{var p=World(e.Location);Zoom(e.Delta>0?1.2:1/1.2);var q=Screen(p);panX+=e.X-q.X;panY+=e.Y-q.Y;Invalidate();}
        base.OnMouseWheel(e);
    }    protected override void OnMouseLeave(EventArgs e){base.OnMouseLeave(e);pendingHover=null;HoverPoint=null;HoverChanged?.Invoke(null);Invalidate();}
    protected override void Dispose(bool disposing){if(disposing)hoverTimer.Dispose();base.Dispose(disposing);}
    internal void CheckHover(Point p){OnMouseMove(new MouseEventArgs(MouseButtons.None,0,p.X,p.Y,0));HoverPoint=PickTerrain(p);HoverChanged?.Invoke(HoverPoint);Invalidate();}
    internal void CheckMiddleDrag(Point from,Point to)
    {
        OnMouseDown(new MouseEventArgs(MouseButtons.Middle,1,from.X,from.Y,0));
        OnMouseMove(new MouseEventArgs(MouseButtons.Middle,0,to.X,to.Y,0));
        OnMouseUp(new MouseEventArgs(MouseButtons.Middle,1,to.X,to.Y,0));
    }

}


