using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using ForestRoad.Cad;
using OkseongRoad.Terrain;
using OpenTK.GLControl;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Windowing.Common;

namespace OkseongRoad.App;

public sealed partial class MapCanvas
{
    SceneRenderer? sceneRenderer;
    void InitializeSceneRenderer()
    {
        sceneRenderer=new SceneRenderer(this){Dock=DockStyle.Fill};
        Controls.Add(sceneRenderer);viewToolbar.BringToFront();
        sceneRenderer.Load+=(_,_)=>{LayoutToolbar();viewToolbar.BringToFront();};
        Invalidated+=(_,_)=>sceneRenderer.RequestFrame();
        sceneRenderer.MouseDown+=(_,e)=>{OnMouseDown(e);sceneRenderer.Capture=Capture;};
        sceneRenderer.MouseMove+=(_,e)=>OnMouseMove(e);
        sceneRenderer.MouseUp+=(_,e)=>{OnMouseUp(e);sceneRenderer.Capture=false;};
        sceneRenderer.MouseWheel+=(_,e)=>OnMouseWheel(e);
        sceneRenderer.MouseLeave+=(_,e)=>OnMouseLeave(e);
    }
    internal bool GpuSceneReady=>sceneRenderer?.Ready==true;
    internal int SceneGeometryUploads=>sceneRenderer?.GeometryUploads??0;
    public Bitmap CaptureScene()=>sceneRenderer?.CaptureFrame()??throw new InvalidOperationException("OpenGL 화면이 준비되지 않았습니다.");

    // Text and selection decorations stay lightweight; terrain, CAD lines and LAS points
    // are drawn from persistent GPU buffers. This overlay never traverses the LAS cloud.
    void PaintSceneOverlay(Graphics g)
    {
        g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        foreach(var f in Features)
        {
            if(!f.Visible||f.Text is null||f.Points.Count==0||ContourMode)continue;
            var p=Screen(f.Points[0]);if(p.X< -100||p.X>Width+100||p.Y< -80||p.Y>Height+80)continue;
            Color color=OverlayCad?Color.FromArgb(255,226,113):Is3D&&HeightColors?ElevationColor(f.Points[0].Z):Color.FromArgb(f.Argb);
            if(color.R+color.G+color.B<90)color=Color.LightGray;
            using var brush=new SolidBrush(color);
            if(Is3D)g.DrawString(f.Text,Font,brush,p);
            else
            {
                using var font=new Font("맑은 고딕",(float)Math.Clamp(f.TextHeight*ViewScale,6,80),GraphicsUnit.Pixel);
                var saved=g.Save();g.TranslateTransform(p.X,p.Y);g.RotateTransform((float)(-f.Rotation*180/Math.PI));g.DrawString(f.Text,font,brush,0,-font.Size);g.Restore(saved);
            }
        }
        if(!OriginalOnly)
        {
            DrawRoads(g);
        }
        Marker(Start,"S",Color.Aquamarine);Marker(End,"E",Color.SandyBrown);
        if(ProfilePoint is {} track){var p=Screen(track);using var brush=new SolidBrush(Color.White);g.FillEllipse(brush,p.X-5,p.Y-5,10,10);}
        if(Pick is not null&&HoverPoint is {} preview)
        {
            var p=Screen(preview);using var pen=new Pen(Color.Gold,2);g.DrawEllipse(pen,p.X-12,p.Y-12,24,24);
            using var brush=new SolidBrush(Color.White);using var box=new SolidBrush(Color.FromArgb(225,23,35,49));
            float x=Math.Clamp(p.X+20,8,Math.Max(8,Width-225)),y=Math.Clamp(p.Y-65,8,Math.Max(8,Height-90));
            g.FillRectangle(box,x,y,210,65);g.DrawString($"선택 미리보기\nX {preview.X:F2} Y {preview.Y:F2}\nZ {preview.Z:F2}",Font,brush,x+6,y+4);
        }
        using var ink=new SolidBrush(Color.FromArgb(162,180,199));
        using var right=new StringFormat{Alignment=StringAlignment.Far};
        g.DrawString("↑ Y / 북",Font,ink,new RectangleF(12,18,Math.Max(1,Width-24),Font.Height+6),right);
        g.DrawString(Is3D?(Pick is null?"좌클릭 회전 · 우클릭 이동 · 휠 확대":"지형 클릭으로 시작·종점 지정 · Esc 취소 · 우클릭 이동"):$"X {maxX-minX:N2} × Y {maxY-minY:N2} | 휠 확대 · 우클릭 이동",Font,ink,new RectangleF(18,Math.Max(0,Height-viewToolbar.Height-Font.Height*2-18),Math.Max(1,Width-36),Font.Height*2+6));
        if(!DemOnly&&Features.Count==0&&(Cloud is null||OriginalOnly))
        {
            int center=Height/2;
            LineIcons.Draw(g,"terrain",new RectangleF(Width/2f-28,center-85,56,56),Color.FromArgb(151,190,164));
            using var title=UiFonts.Create(14,FontStyle.Bold);
            using var titleInk=new SolidBrush(Color.FromArgb(230,241,234));
            using var hintInk=new SolidBrush(Color.FromArgb(157,184,168));
            using var centered=new StringFormat{Alignment=StringAlignment.Center,LineAlignment=StringAlignment.Center};
            g.DrawString("지형 자료로 설계를 시작하세요",title,titleInk,new RectangleF(12,center-16,Width-24,45),centered);
            centered.LineAlignment=StringAlignment.Near;
            g.DrawString("상단 자료 불러오기에서 DWG · DXF · LAS 파일 열기",Font,hintInk,new RectangleF(12,center+38,Width-24,48),centered);
        }
        if(Is3D&&HeightColors)
        {
            for(int i=0;i<120;i++){using var brush=new SolidBrush(ElevationColor(minZ+(maxZ-minZ)*i/119));g.FillRectangle(brush,Width-150+i,45,1,9);}
            g.DrawString($"{minZ:0.##} → {maxZ:0.##}",Font,ink,Width-150,60);
        }
        void Marker(CadPoint? point,string label,Color color)
        {
            if(point is null)return;var actual=Is3D?Terrain?.At(point.X,point.Y)??point:point;var p=Screen(actual);
            using var fill=new SolidBrush(color);using var outline=new Pen(Color.White,2);
            g.FillEllipse(fill,p.X-7,p.Y-7,14,14);g.DrawEllipse(outline,p.X-7,p.Y-7,14,14);g.DrawString(label,Font,fill,p.X+10,p.Y-10);
        }
    }

    sealed class SceneRenderer:GLControl
    {
        protected override CreateParams CreateParams
        {
            get{var parameters=base.CreateParams;parameters.Style|=0x04000000|0x02000000;return parameters;}
        }
        readonly MapCanvas owner;
        readonly System.Windows.Forms.Timer frames=new(){Interval=16};
        bool dirty=true;
        int program,overlayProgram,overlayVao,overlayVbo,texture;
        object? geometryKey;
        readonly List<(int Vao,int Vbo,int Count,PrimitiveType Mode,float Width)> batches=[];
        Bitmap? overlay;
        public bool Ready{get;private set;}
        public int GeometryUploads{get;private set;}
        public string? Failure{get;private set;}
        public SceneRenderer(MapCanvas owner):base(new GLControlSettings{API=ContextAPI.OpenGL,APIVersion=new Version(3,3),Profile=ContextProfile.Core})
        {
            this.owner=owner;TabStop=true;
            Load+=(_,_)=>Initialize();Paint+=(_,_)=>Render();Resize+=(_,_)=>RequestFrame();
            frames.Tick+=(_,_)=>{if(dirty&&Visible&&Ready){dirty=false;Invalidate();}};
            frames.Start();
        }
        public void RequestFrame()=>dirty=true;
        static int Shader(ShaderType type,string text)
        {
            int s=GL.CreateShader(type);GL.ShaderSource(s,text);GL.CompileShader(s);GL.GetShader(s,ShaderParameter.CompileStatus,out int success);
            if(success==0){string log=GL.GetShaderInfoLog(s);GL.DeleteShader(s);throw new InvalidOperationException(log);}return s;
        }
        static int Program(string vertex,string fragment)
        {
            int vs=Shader(ShaderType.VertexShader,vertex),fs=Shader(ShaderType.FragmentShader,fragment),p=GL.CreateProgram();
            GL.AttachShader(p,vs);GL.AttachShader(p,fs);GL.LinkProgram(p);GL.DeleteShader(vs);GL.DeleteShader(fs);GL.GetProgram(p,GetProgramParameterName.LinkStatus,out int success);
            if(success==0){string log=GL.GetProgramInfoLog(p);GL.DeleteProgram(p);throw new InvalidOperationException(log);}return p;
        }
        void Initialize()
        {
            try
            {
                MakeCurrent();
                program=Program("""
                    #version 330 core
                    layout(location=0) in vec3 position;
                    layout(location=1) in vec4 color;
                    uniform vec2 viewportSize;
                    uniform vec2 pan;
                    uniform vec2 rotation;
                    uniform float scale;
                    uniform float heightScale;
                    uniform float depthExtent;
                    uniform float pointSize;
                    uniform bool threeD;
                    out vec4 vertexColor;
                    void main(){
                        vec3 p=position;float z=p.z*heightScale;
                        float u=p.x*cos(rotation.x)-p.y*sin(rotation.x);
                        float v=p.x*sin(rotation.x)+p.y*cos(rotation.x);
                        vec2 screen=threeD?vec2(u,v*sin(rotation.y)+z*cos(rotation.y)):p.xy;
                        float depth=threeD?(-v*cos(rotation.y)+z*sin(rotation.y)):0.0;
                        gl_Position=vec4(2.0*(pan.x+screen.x*scale)/viewportSize.x,2.0*(-pan.y+screen.y*scale)/viewportSize.y,-depth/depthExtent,1.0);
                        gl_PointSize=pointSize;vertexColor=color;
                    }
                    ""","#version 330 core\nin vec4 vertexColor;out vec4 outputColor;void main(){outputColor=vertexColor;}");
                overlayProgram=Program("#version 330 core\nlayout(location=0) in vec2 p;layout(location=1) in vec2 t;out vec2 uv;void main(){gl_Position=vec4(p,0,1);uv=t;}","#version 330 core\nin vec2 uv;uniform sampler2D image;out vec4 outputColor;void main(){outputColor=texture(image,uv);}");
                overlayVao=GL.GenVertexArray();overlayVbo=GL.GenBuffer();GL.BindVertexArray(overlayVao);GL.BindBuffer(BufferTarget.ArrayBuffer,overlayVbo);
                float[] quad=[-1,1,0,0,-1,-1,0,1,1,-1,1,1,-1,1,0,0,1,-1,1,1,1,1,1,0];
                GL.BufferData(BufferTarget.ArrayBuffer,quad.Length*sizeof(float),quad,BufferUsageHint.StaticDraw);
                GL.VertexAttribPointer(0,2,VertexAttribPointerType.Float,false,16,0);GL.EnableVertexAttribArray(0);GL.VertexAttribPointer(1,2,VertexAttribPointerType.Float,false,16,8);GL.EnableVertexAttribArray(1);
                texture=GL.GenTexture();GL.BindTexture(TextureTarget.Texture2D,texture);GL.TexParameter(TextureTarget.Texture2D,TextureParameterName.TextureMinFilter,(int)TextureMinFilter.Linear);GL.TexParameter(TextureTarget.Texture2D,TextureParameterName.TextureMagFilter,(int)TextureMagFilter.Linear);
                GL.Enable(EnableCap.ProgramPointSize);GL.ClearColor(20/255f,38/255f,29/255f,1);Ready=true;
            }
            catch(Exception e){Failure=e.Message;Ready=false;Visible=false;owner.Controls.Add(new Label{Dock=DockStyle.Fill,Text="OpenGL 초기화 실패: "+e.Message,ForeColor=Color.White,TextAlign=ContentAlignment.MiddleCenter});}
        }
        void ReleaseGeometry()
        {
            foreach(var b in batches){GL.DeleteBuffer(b.Vbo);GL.DeleteVertexArray(b.Vao);}batches.Clear();
        }
        void Upload(List<GpuPoint> vertices,PrimitiveType mode,float width=1)
        {
            if(vertices.Count==0)return;
            int vao=GL.GenVertexArray(),vbo=GL.GenBuffer();batches.Add((vao,vbo,vertices.Count,mode,width));
            GL.BindVertexArray(vao);GL.BindBuffer(BufferTarget.ArrayBuffer,vbo);var data=vertices.ToArray();
            GL.BufferData(BufferTarget.ArrayBuffer,data.Length*16,data,BufferUsageHint.StaticDraw);
            GL.VertexAttribPointer(0,3,VertexAttribPointerType.Float,false,16,0);GL.EnableVertexAttribArray(0);GL.VertexAttribPointer(1,4,VertexAttribPointerType.UnsignedByte,true,16,12);GL.EnableVertexAttribArray(1);
            if(GL.GetError()!=ErrorCode.NoError)throw new InvalidOperationException("GPU 도형 버퍼 업로드에 실패했습니다.");
        }
        void PrepareGeometry()
        {
            var o=owner;
            object key=(o.Features,o.Cloud,o.Terrain,o.OriginalOnly,o.DemOnly,o.ShowCloud,o.ContourMode,o.OverlayCad,o.Is3D,o.ShowSurface,o.OverlayContours,o.HeightColors,o.HeightScale,o.minX,o.maxX,o.minY,o.maxY,o.minZ,o.maxZ);
            if(key.Equals(geometryKey))return;
            ReleaseGeometry();geometryKey=null;
            double cx=(o.minX+o.maxX)/2,cy=(o.minY+o.maxY)/2,cz=(o.minZ+o.maxZ)/2;
            GpuPoint Vertex(CadPoint p,Color c)=>new(){X=(float)(p.X-cx),Y=(float)(p.Y-cy),Z=(float)(p.Z-cz),R=c.R,G=c.G,B=c.B,A=c.A};
            if(o.Terrain is {} terrain&&!o.OriginalOnly&&(o.DemOnly||o.Is3D&&o.ShowSurface))
            {
                var vertices=new List<GpuPoint>();
                for(int y=0;y<terrain.Height-1;y++)for(int x=0;x<terrain.Width-1;x++)
                {
                    int i=y*terrain.Width+x;int[] ids=[i,i+1,i+terrain.Width+1,i+terrain.Width];if(ids.Any(k=>!double.IsFinite(terrain.Values[k])))continue;
                    var c=o.ElevationColor(ids.Average(k=>terrain.Values[k]));
                    if(o.Is3D)
                    {
                        double nx=-((terrain.Values[ids[1]]+terrain.Values[ids[2]])-(terrain.Values[ids[0]]+terrain.Values[ids[3]]))/(2*terrain.Step)*o.HeightScale;
                        double ny=-((terrain.Values[ids[2]]+terrain.Values[ids[3]])-(terrain.Values[ids[0]]+terrain.Values[ids[1]]))/(2*terrain.Step)*o.HeightScale;
                        double shade=.64+.36*Math.Clamp((.4*nx-.5*ny+.8)/Math.Sqrt(nx*nx+ny*ny+1),0,1);c=Color.FromArgb((int)(c.R*shade),(int)(c.G*shade),(int)(c.B*shade));
                    }
                    foreach(int index in new[]{0,1,2,0,2,3})vertices.Add(Vertex(terrain.Node(ids[index]),c));
                }
                Upload(vertices,PrimitiveType.Triangles);
            }
            if(o.Cloud is {} cloud&&o.ShowCloud&&!o.ContourMode&&!o.OriginalOnly&&!o.DemOnly)
            {
                var vertices=new List<GpuPoint>();int stride=Math.Max(1,(int)Math.Ceiling(cloud.Points.Count/100000.0));
                for(int i=0;i<cloud.Points.Count;i+=stride)
                {
                    var p=cloud.Points[i];if(p.Withheld)continue;
                    var color=o.Is3D&&o.HeightColors?o.ElevationColor(p.Position.Z):p.Argb is int rgb?Color.FromArgb(rgb):p.Classification==2?Color.FromArgb(107,173,156):Color.FromArgb(133,149,181);
                    vertices.Add(Vertex(p.Position,color));
                }
                Upload(vertices,PrimitiveType.Points,2.5f);
            }
            var lines=new List<GpuPoint>();var dots=new List<GpuPoint>();
            foreach(var f in o.Features)
            {
                if(!f.Visible||f.Points.Count==0||f.Text is not null||o.DemOnly)continue;
                if(o.Is3D&&o.ShowSurface&&!o.OriginalOnly&&o.ContourMode&&!o.OverlayContours)continue;
                double z=f.Points[0].Z;bool major=Math.Abs(z/5-Math.Round(z/5))<1e-5,basic=Math.Abs(z-Math.Round(z))<1e-5;
                Color color=o.OverlayCad?Color.FromArgb(255,226,113):o.Is3D&&o.HeightColors?o.ElevationColor(z):o.ContourMode?major?Color.FromArgb(245,196,112):basic?Color.FromArgb(132,190,152):Color.FromArgb(69,113,95):Color.FromArgb(f.Argb);
                if(color.R+color.G+color.B<90)color=Color.LightGray;
                if(f.Points.Count==1)dots.Add(Vertex(f.Points[0],color));
                else for(int j=1;j<f.Points.Count;j++){lines.Add(Vertex(f.Points[j-1],color));lines.Add(Vertex(f.Points[j],color));}
            }
            Upload(lines,PrimitiveType.Lines);Upload(dots,PrimitiveType.Points,4);
            geometryKey=key;GeometryUploads++;
        }
        void Render()
        {
            if(!Ready||Width<1||Height<1)return;
            try
            {
                MakeCurrent();PrepareGeometry();var o=owner;GL.Viewport(0,0,Width,Height);GL.Clear(ClearBufferMask.ColorBufferBit|ClearBufferMask.DepthBufferBit);
                if(o.Is3D)GL.Enable(EnableCap.DepthTest);else GL.Disable(EnableCap.DepthTest);
                GL.UseProgram(program);
                double extent=Math.Sqrt(Math.Pow(o.maxX-o.minX,2)+Math.Pow(o.maxY-o.minY,2)+Math.Pow((o.maxZ-o.minZ)*o.HeightScale,2));
                double scale=o.Is3D?Math.Max(1,Math.Min(o.Width-80,o.Height-(o.viewToolbar.Visible?110:45)))/Math.Max(1,extent)*o.zoom:o.ViewScale;
                GL.Uniform2(GL.GetUniformLocation(program,"viewportSize"),(float)o.Width,(float)o.Height);
                GL.Uniform2(GL.GetUniformLocation(program,"pan"),(float)o.panX,(float)o.panY);GL.Uniform2(GL.GetUniformLocation(program,"rotation"),(float)o.yaw,(float)o.pitch);
                GL.Uniform1(GL.GetUniformLocation(program,"scale"),(float)scale);GL.Uniform1(GL.GetUniformLocation(program,"heightScale"),(float)o.HeightScale);GL.Uniform1(GL.GetUniformLocation(program,"depthExtent"),(float)Math.Max(1,extent));GL.Uniform1(GL.GetUniformLocation(program,"threeD"),o.Is3D?1:0);
                foreach(var b in batches)
                {
                    // Explicit CAD/contour overlays stay visible above the LAS/DEM surface.
                    if(o.Is3D&&!(b.Mode==PrimitiveType.Lines&&(o.OverlayCad||o.OverlayContours)))GL.Enable(EnableCap.DepthTest);else GL.Disable(EnableCap.DepthTest);
                    GL.BindVertexArray(b.Vao);GL.Uniform1(GL.GetUniformLocation(program,"pointSize"),b.Width);GL.DrawArrays(b.Mode,0,b.Count);
                }
                DrawOverlay();SwapBuffers();
            }
            catch(Exception e){Failure=e.Message;Ready=false;owner.Controls.Add(new Label{Dock=DockStyle.Top,Height=55,Text="OpenGL 표시 오류: "+e.Message,ForeColor=Color.OrangeRed});}
        }
        void DrawOverlay()
        {
            if(overlay is null||overlay.Width!=Width||overlay.Height!=Height)
            {
                overlay?.Dispose();overlay=new Bitmap(Width,Height,System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                GL.BindTexture(TextureTarget.Texture2D,texture);GL.TexImage2D(TextureTarget.Texture2D,0,PixelInternalFormat.Rgba,Width,Height,0,OpenTK.Graphics.OpenGL4.PixelFormat.Bgra,PixelType.UnsignedByte,IntPtr.Zero);
            }
            using(var graphics=Graphics.FromImage(overlay)){graphics.Clear(Color.Transparent);owner.PaintSceneOverlay(graphics);}
            var locked=overlay.LockBits(new Rectangle(0,0,Width,Height),ImageLockMode.ReadOnly,overlay.PixelFormat);
            try{GL.ActiveTexture(TextureUnit.Texture0);GL.BindTexture(TextureTarget.Texture2D,texture);GL.TexSubImage2D(TextureTarget.Texture2D,0,0,0,Width,Height,OpenTK.Graphics.OpenGL4.PixelFormat.Bgra,PixelType.UnsignedByte,locked.Scan0);}finally{overlay.UnlockBits(locked);}
            GL.Disable(EnableCap.DepthTest);GL.Enable(EnableCap.Blend);GL.BlendFunc(BlendingFactor.SrcAlpha,BlendingFactor.OneMinusSrcAlpha);
            GL.UseProgram(overlayProgram);GL.Uniform1(GL.GetUniformLocation(overlayProgram,"image"),0);GL.BindVertexArray(overlayVao);GL.DrawArrays(PrimitiveType.Triangles,0,6);GL.Disable(EnableCap.Blend);
        }
        public Bitmap CaptureFrame()
        {
            if(!Ready)throw new InvalidOperationException(Failure??"OpenGL 미준비");Render();MakeCurrent();GL.ReadBuffer(ReadBufferMode.Front);
            var bitmap=new Bitmap(Width,Height,System.Drawing.Imaging.PixelFormat.Format32bppArgb);var locked=bitmap.LockBits(new Rectangle(0,0,Width,Height),ImageLockMode.WriteOnly,bitmap.PixelFormat);
            try{GL.ReadPixels(0,0,Width,Height,OpenTK.Graphics.OpenGL4.PixelFormat.Bgra,PixelType.UnsignedByte,locked.Scan0);}finally{bitmap.UnlockBits(locked);}bitmap.RotateFlip(RotateFlipType.RotateNoneFlipY);
            if(owner.viewToolbar.Visible){using var graphics=Graphics.FromImage(bitmap);using var bar=new Bitmap(owner.viewToolbar.Width,owner.viewToolbar.Height);owner.viewToolbar.DrawToBitmap(bar,new Rectangle(Point.Empty,bar.Size));graphics.DrawImageUnscaled(bar,owner.viewToolbar.Location);}return bitmap;
        }
        protected override void Dispose(bool disposing)
        {
            if(disposing)
            {
                frames.Dispose();overlay?.Dispose();
                if(Ready){MakeCurrent();ReleaseGeometry();GL.DeleteBuffer(overlayVbo);GL.DeleteVertexArray(overlayVao);GL.DeleteTexture(texture);GL.DeleteProgram(program);GL.DeleteProgram(overlayProgram);Ready=false;}
            }
            base.Dispose(disposing);
        }
    }
}
