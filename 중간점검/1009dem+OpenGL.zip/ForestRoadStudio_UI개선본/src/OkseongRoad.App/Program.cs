namespace OkseongRoad.App;
internal static class Program
{
    [STAThread]static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();using var form=new MainForm();
        if(args.Length==2&&(args[0]=="--ui-check"||args[0]=="--render-check"))
        {
            form.Shown+=async(_,_)=>
            {
                try{if(args[0]=="--render-check")await form.VerifyRenderer(Path.GetFullPath(args[1]));else await form.VerifyUi(Path.GetFullPath(args[1]));}
                catch(Exception error){Directory.CreateDirectory(args[1]);File.WriteAllText(Path.Combine(args[1],"verification-error.txt"),error.ToString());Environment.ExitCode=1;}
                finally{form.Close();}
            };
        }
        Application.Run(form);
    }
}
