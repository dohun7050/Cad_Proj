﻿using System.Globalization;
using System.Text;
using System.Text.Json;
using ForestRoad.Cad;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;
public sealed partial class MainForm:Form
{
    readonly MapCanvas map=new();
    readonly GpuCloudPanel gpu=new(){Dock=DockStyle.Fill};
    readonly TabControl sceneTabs=new(){Dock=DockStyle.Fill,Multiline=true};
    readonly Label gpuInfo=new(){Dock=DockStyle.Top,Height=62,Padding=new Padding(6),Text="LAS / GPU 탭의 전체 포인트 보기를 누르면 원본 전체 점군을 표시합니다.",BackColor=Color.FromArgb(232,240,248)};
    readonly CheckedListBox layers=new(){Dock=DockStyle.Fill,CheckOnClick=true,BorderStyle=BorderStyle.None};
    readonly Label fileInfo=new(){Dock=DockStyle.Top,Height=100,Padding=new Padding(6),Text="파일을 열면 원본 XY 좌표로 표시합니다.\n\nCAD와 LAS를 함께 열 경우 좌표계가 같아야 합니다."};
    readonly Label result=new(){AutoSize=false,Height=140,Width=292,ForeColor=Color.FromArgb(40,75,100),Text="시작점과 종점을 지정한 후\n후보 경로를 생성하세요."};
    readonly Label terrainInfo=new(){AutoSize=false,Width=292,Height=72,Text="고도 격자: 준비 전"};
    readonly ComboBox display=new(){DropDownStyle=ComboBoxStyle.DropDownList,Width=260};
    readonly CheckBox view3D=new(){Text="3D 보기",AutoSize=true,Padding=new Padding(3,3,0,0)};
    readonly CheckBox surface=new(){Text="지형 면 표시",AutoSize=true,Padding=new Padding(3,3,0,0)};
    readonly ListBox candidates=new(){Dock=DockStyle.Fill,Height=155,BorderStyle=BorderStyle.FixedSingle,DrawMode=DrawMode.OwnerDrawFixed,ItemHeight=27};
    readonly CheckBox showAll=new(){Text="후보 경로 모두 표시",Checked=true,AutoSize=true};
    readonly NumericUpDown roadWidth=new(){Minimum=1,Maximum=8,Value=4,DecimalPlaces=1,Increment=0.5m,Width=85};
    readonly NumericUpDown radius=new(){Minimum=0,Maximum=100,Value=0,DecimalPlaces=1,Width=85};
    readonly NumericUpDown turnWeight=new(){Minimum=0,Maximum=100,Value=0,Width=85};
    readonly DataGridView comparison=new(){Dock=DockStyle.Fill,ReadOnly=true,AllowUserToAddRows=false,AllowUserToDeleteRows=false,AllowUserToResizeRows=false,RowHeadersVisible=false,MultiSelect=false,SelectionMode=DataGridViewSelectionMode.FullRowSelect,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,BackgroundColor=Color.White,BorderStyle=BorderStyle.None};
    readonly ProfileCanvas profile=new();
    bool syncing;
    int demSource; // Set only when loading data or committing DEM settings.
    readonly NumericUpDown step=new(){Minimum=1,Maximum=50,Value=5,Width=85};
    readonly NumericUpDown angle=new(){Minimum=0.1m,Maximum=100,DecimalPlaces=1,Value=10,Width=85}; // Grade percent; keep the existing control reference.
    readonly CheckBox meters=new(){Text="입력 XY·Z가 미터이며 같은 좌표계임",AutoSize=true};
    readonly ToolStripStatusLabel status=new("파일을 열어 시작하세요.");
    readonly ToolStripStatusLabel pointer=new(){Spring=true,TextAlign=ContentAlignment.MiddleRight};
    readonly List<Control> locked=[];
    string cadCrs="미확인"; string demMethod="";
    List<CadPoint>? autoGround;
    LasCloud? uploadedCloud;
    DemOptions? demOptions;
    CadDrawing? cad;LasCloud? cloud;TerrainGrid? grid;List<CadFeature> generated=[];
    CancellationTokenSource? operation;bool changing;int appliedDisplay=-1,appliedSource=-1;
    static readonly Color Blue=Color.FromArgb(41,83,128);
    public MainForm()
    {
        Text="옥성임도 통합 · 경로 탐색 + DEM";Size=new Size(1440,920);MinimumSize=new Size(800,520);AutoScaleDimensions=new SizeF(96,96);AutoScaleMode=AutoScaleMode.Dpi;UiLayout.FitWindow(this,true);Font=new Font("맑은 고딕",9);StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(240,244,249);KeyPreview=true;
        var root=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=4};root.RowStyles.Add(new RowStyle(SizeType.AutoSize));root.RowStyles.Add(new RowStyle(SizeType.Absolute,100));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.AutoSize));Controls.Add(root);
        var header=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoSize=true,WrapContents=true,BackColor=Blue,Margin=Padding.Empty,Padding=new Padding(6)};
        header.Controls.Add(new Label{Text="옥성임도 / 지형과 후보 경로",ForeColor=Color.White,AutoSize=true,Font=new Font(Font.FontFamily,12,FontStyle.Bold)});
        header.Controls.Add(new Label{Text="중간 점검 10.12 (월) · 제출 10.19 (월)",ForeColor=Color.FromArgb(212,226,244),AutoSize=true,Padding=new Padding(8,4,0,0)});root.Controls.Add(header,0,0);
        var ribbon=new TabControl{Dock=DockStyle.Fill,Multiline=true};root.Controls.Add(ribbon,0,1);
        void FitRibbon(){int available=Math.Max(200,ribbon.ClientSize.Width-UiLayout.Pixels(this,16));foreach(var combo in ribbon.TabPages.Cast<TabPage>().SelectMany(t=>t.Controls.Cast<Control>()).OfType<FlowLayoutPanel>().SelectMany(p=>p.Controls.Cast<Control>()).OfType<ComboBox>())combo.Width=Math.Min(available,combo.Items.Cast<object>().Select(i=>TextRenderer.MeasureText(i.ToString(),combo.Font).Width+UiLayout.Pixels(this,28)).DefaultIfEmpty(150).Max());var tools=ribbon.SelectedTab?.Controls.OfType<FlowLayoutPanel>().FirstOrDefault();int columns=Math.Max(1,((tools?.ClientSize.Width??available)-(tools?.Padding.Horizontal??0)+UiLayout.Pixels(this,8))/UiLayout.Pixels(this,190));int needed=tools is null?40:((tools.Controls.Count+columns-1)/columns)*UiLayout.Pixels(this,50)+tools.Padding.Vertical;int tabs=ribbon.ItemSize.Height*ribbon.RowCount+UiLayout.Pixels(this,8);int cap=Math.Max(tabs+UiLayout.Pixels(this,42),(int)(ClientSize.Height*.23));int target=Math.Min(needed+tabs,cap);if(tools is not null)tools.AutoScroll=needed+tabs>cap;if(Math.Abs(root.RowStyles[1].Height-target)>1)root.RowStyles[1].Height=target;}
        ribbon.SizeChanged+=(_,_)=>FitRibbon();ribbon.FontChanged+=(_,_)=>FitRibbon();ribbon.SelectedIndexChanged+=(_,_)=>FitRibbon();Shown+=(_,_)=>FitRibbon();DpiChanged+=(_,_)=>BeginInvoke((Action)FitRibbon);
        var file=Tab("파일 / 보기"); var route=Tab("경로 탐색");ribbon.TabPages.Add(file);ribbon.TabPages.Add(route);
        file.Controls.Add(Tools(
            B("DWG / DXF 열기",async()=>await Open(false)),B("LAS 열기",async()=>await Open(true),100),
            display,B("전체 보기",()=>{map.Fit();return Task.CompletedTask;},90),B("자료 정보",()=>{Info();return Task.CompletedTask;},90),B("자료 JSON 저장",()=>{ExportData();return Task.CompletedTask;},125)));
        var space=Tab("3D / 높낮이");ribbon.TabPages.Add(space);
        var height=new NumericUpDown{Minimum=1,Maximum=10,Value=1,DecimalPlaces=1,Increment=0.5m,Width=65};
        var contourOverlay=new CheckBox{Text="면 위 등고선",AutoSize=true,Padding=new Padding(3,3,0,0)};
        var colors=new CheckBox{Text="높이 색상",Checked=true,AutoSize=true,Padding=new Padding(3,3,0,0)};
        space.Controls.Add(Tools(view3D,B("2D 평면 보기",()=>{view3D.Checked=false;return Task.CompletedTask;},115),
            B("입체 시점 초기화",()=>{view3D.Checked=true;map.ResetCamera();return Task.CompletedTask;},140),
            B("위에서 보기",()=>{view3D.Checked=true;map.TopCamera();return Task.CompletedTask;},110),
            new Label{Text="높이 배율",AutoSize=true,Padding=new Padding(0,5,0,0)},height,colors,surface,contourOverlay, B("선택 도로 확대",()=>{map.FocusRoute();return Task.CompletedTask;},125)));
        view3D.CheckedChanged+=(_,_)=>{map.Set3D(view3D.Checked);if(view3D.Checked)ribbon.SelectedTab=space;pointer.Text="";status.Text=view3D.Checked?"3D · 좌클릭 회전 / 우클릭 이동 / 휠 확대 · 원본 좌표단위의 Z 고도":"2D 평면 보기 · 시작점과 종점 선택 가능";};
        map.ViewModeChanged+=enabled=>{if(view3D.Checked!=enabled)view3D.Checked=enabled;gpu.SetView(enabled?map.CameraPreset:"2D");};
        height.ValueChanged+=(_,_)=>{map.HeightScale=(double)height.Value;map.Fit();gpu.HeightScale=(double)height.Value;gpu.RefreshColors();};
        colors.CheckedChanged+=(_,_)=>{map.HeightColors=colors.Checked;map.Invalidate();};
        surface.CheckedChanged+=(_,_)=>{map.ShowSurface=map.DemOnly||surface.Checked;map.Invalidate();if(surface.Checked&&grid is null)status.Text="지형 면은 경로 탐색 → 고도 격자 생성 후 표시됩니다. 원본 보기에서는 숨김";};
        contourOverlay.CheckedChanged+=(_,_)=>{map.OverlayContours=contourOverlay.Checked;map.Invalidate();};
        locked.AddRange([view3D,height,colors,surface,contourOverlay]);
        var gpuTools=Tab("LAS / GPU");ribbon.TabPages.Add(gpuTools);
        var rgb=new CheckBox{Text="원본 RGB",Checked=true,AutoSize=true,Padding=new Padding(3,3,0,0)};
        gpuTools.Controls.Add(Tools(B("전체 포인트 보기",async()=>await LoadGpu(),160),B("전체 보기",()=>{gpu.FitAll();return Task.CompletedTask;},110),rgb,B("LAS 자료 정보",()=>{Info();return Task.CompletedTask;},140)));
        rgb.CheckedChanged+=(_,_)=>{gpu.PreferRgb=rgb.Checked;gpu.RefreshColors();};locked.Add(rgb);
        gpu.UploadProgress+=(read,total)=>{if(operation is not null)status.Text=$"전체 점군 GPU 업로드 {read:N0}/{total:N0}점 · {(total==0?0:100.0*read/total):F0}%";};
        display.Items.AddRange(["DWG 원본만 보기","전체 자료 / 경로 보기","등고선만 보기","LAS 점군 보기","LAS + DWG 등고선"]);display.SelectedIndex=0;display.SelectedIndexChanged+=(_,_)=>{ApplyDisplay();};locked.Add(display);
        route.Controls.Add(Tools(B("DEM 생성 설정",async()=>await ConfigureDem()),B("시작점 선택",async()=>await Pick("start")),B("종점 선택",async()=>await Pick("end")),B("후보 경로 생성",async()=>await FindRoute()),B("좌표 입력",()=>{Coordinates();return Task.CompletedTask;}),B("DEM 저장",()=>{ExportDem();return Task.CompletedTask;},100),B("경로 CSV 저장",()=>{ExportRoute();return Task.CompletedTask;})));
        var body=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3,Padding=new Padding(5)};body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,18));body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,60));body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,22));root.Controls.Add(body,0,2);
        var left=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoScroll=true,FlowDirection=FlowDirection.TopDown,WrapContents=false,BackColor=Color.White,Padding=new Padding(5),Margin=new Padding(0,0,8,0)};body.Controls.Add(left,0,0);UiLayout.FitFlow(left);
        var layerHeading=UiLayout.Text("자료 · 레이어",new Padding(7));layerHeading.Font=new Font(Font,FontStyle.Bold);left.Controls.Add(layerHeading);
        fileInfo.Dock=DockStyle.None;left.Controls.Add(fileInfo);
        layers.Dock=DockStyle.None;layers.Height=92;layers.MinimumSize=new Size(0,92);layers.HorizontalScrollbar=true;layers.IntegralHeight=false;left.Controls.Add(layers);
        var hint=UiLayout.Text("레이어를 체크하여 등고선을 표시하세요.\n\n좌표계와 단위는 자료 정보에서 확인하세요.",new Padding(6));left.Controls.Add(hint);
        var candidatePanel=new Panel{Height=182,MinimumSize=new Size(0,182),Visible=false};candidatePanel.Controls.Add(candidates);var candidateTitle=new Label{Dock=DockStyle.Top,Text="후보 선택 · 지도와 비교표에 동시 반영",Padding=new Padding(4)};UiLayout.FitTopLabel(candidateTitle);candidatePanel.Controls.Add(candidateTitle);locked.Add(candidates);
        candidates.HorizontalScrollbar=true;candidates.FontChanged+=(_,_)=>{candidates.ItemHeight=Math.Max(27,candidates.Font.Height+12);candidates.HorizontalExtent=candidates.Items.Cast<object>().Select(i=>TextRenderer.MeasureText(i.ToString(),candidates.Font).Width+36).DefaultIfEmpty(0).Max();};comparison.AutoSizeRowsMode=DataGridViewAutoSizeRowsMode.AllCells;
        candidates.DrawItem+=(_,e)=>
        {
            if(e.Index<0)return;bool selected=(e.State&DrawItemState.Selected)!=0;using var background=new SolidBrush(selected?StudioTheme.Raised:Color.White);e.Graphics.FillRectangle(background,e.Bounds);if(selected){using var bar=new SolidBrush(StudioTheme.Accent);e.Graphics.FillRectangle(bar,e.Bounds.X,e.Bounds.Y,3,e.Bounds.Height);}
            using var swatch=new SolidBrush(MapCanvas.RouteColors[e.Index%MapCanvas.RouteColors.Length]);e.Graphics.FillRectangle(swatch,e.Bounds.X+6,e.Bounds.Y+8,12,12);
            using var ink=new SolidBrush(StudioTheme.Forest);e.Graphics.DrawString(candidates.Items[e.Index].ToString(),Font,ink,e.Bounds.X+25,e.Bounds.Y+5);e.DrawFocusRectangle();
        };
        candidates.SelectedIndexChanged+=(_,_)=>{if(candidates.SelectedIndex<0)return;map.SelectedCandidate=candidates.SelectedIndex;map.Route=map.Candidates[map.SelectedCandidate];UpdateRouteResult();map.Invalidate();};
        layers.ItemCheck+=(_,_)=>{if(!changing)BeginInvoke((Action)(()=>{ClearTerrain();ApplyDisplay();}));};locked.Add(layers);
        var planningTab=new TabPage("지형 / 경로 탐색 (분석 자료)");planningTab.Controls.Add(map);sceneTabs.TabPages.Add(planningTab);
        var gpuTab=new TabPage("LAS GPU 전체 점군");gpuTab.Controls.Add(gpu);gpuTab.Controls.Add(gpuInfo);sceneTabs.TabPages.Add(gpuTab);body.Controls.Add(sceneTabs,1,0);
        body.RowCount=2;body.RowStyles.Add(new RowStyle(SizeType.Percent,100));body.RowStyles.Add(new RowStyle(SizeType.Absolute,210));
        bool fittingBody=false;
        body.SizeChanged+=(_,_)=>
        {
            if(fittingBody || body.ClientSize.Width<=0)return;
            fittingBody=true;
            body.SuspendLayout();
            try
            {
                body.RowStyles[1].Height=UiLayout.Pixels(this,body.ClientSize.Height>=UiLayout.Pixels(this,420)?178:body.ClientSize.Height>=UiLayout.Pixels(this,250)?88:64);
                double logical=body.ClientSize.Width*96.0/DeviceDpi;
                double left=Math.Clamp(logical*.16,175,225);
                double right=Math.Clamp(logical*.22,245,300);
                // Reserve at least 30 percent for the map, even during transient tiny layouts.
                double scale=Math.Min(1,logical*.70/(left+right));
                float leftRatio=(float)(left*scale/logical*100);
                float rightRatio=(float)(right*scale/logical*100);
                body.ColumnStyles[0].Width=leftRatio;
                body.ColumnStyles[1].Width=Math.Max(0,100-leftRatio-rightRatio);
                body.ColumnStyles[2].Width=rightRatio;
            }
            finally
            {
                body.ResumeLayout(true);
                fittingBody=false;
            }
        };
        var dashboard=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,BackColor=Color.White,Margin=new Padding(0,8,0,0)};dashboard.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));dashboard.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));
        dashboard.Controls.Add(comparison,0,0);dashboard.Controls.Add(profile,1,0);body.Controls.Add(dashboard,0,1);body.SetColumnSpan(dashboard,3);
        foreach(var (name,title) in new[]{("id","후보"),("length","길이 m"),("average","평균 °"),("peak","최대 °"),("bends","굴곡 수"),("radius","최소 R m"),("overlap","선택과 겹침 %")})comparison.Columns.Add(name,title);
        comparison.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.AutoSize;comparison.ColumnHeadersDefaultCellStyle.WrapMode=DataGridViewTriState.True;foreach(DataGridViewColumn column in comparison.Columns)column.MinimumWidth=90;comparison.Columns[0].MinimumWidth=55;comparison.FontChanged+=(_,_)=>{foreach(DataGridViewColumn column in comparison.Columns)column.MinimumWidth=Math.Max(column.Index==0?55:90,TextRenderer.MeasureText(column.HeaderText,comparison.Font).Width+16);};comparison.Columns[0].FillWeight=45;comparison.Columns[6].FillWeight=125;comparison.SelectionChanged+=(_,_)=>{if(!syncing&&comparison.CurrentRow is {} row&&row.Index<map.Candidates.Count)candidates.SelectedIndex=row.Index;};locked.Add(comparison);
        profile.Hovered+=station=>{map.ProfilePoint=station is null?null:new CadPoint(station.X,station.Y,station.Z);map.Invalidate();};

        var right=new FlowLayoutPanel{Dock=DockStyle.Fill,BackColor=Color.White,FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoScroll=true,Padding=new Padding(6),Margin=Padding.Empty};var rightShell=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=2,BackColor=Color.White,Margin=new Padding(8,0,0,0)};
        rightShell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));rightShell.RowStyles.Add(new RowStyle(SizeType.AutoSize));rightShell.RowStyles.Add(new RowStyle(SizeType.Percent,100));body.Controls.Add(rightShell,2,0);rightShell.Controls.Add(right,0,1);
        var collapse=new Button{Dock=DockStyle.Fill,AutoSize=true,MinimumSize=new Size(0,26),Text="설정 접기 ▴",FlatStyle=FlatStyle.Flat};collapse.Click+=(_,_)=>{right.Visible=!right.Visible;collapse.Text=right.Visible?"설정 접기 ▴":"설정 펼치기 ▾";};rightShell.Controls.Add(collapse,0,0);
        UiLayout.FitFlow(right);UiLayout.FitTopLabel(gpuInfo);
        right.Controls.Add(Heading("탐색 설정"));
        right.Controls.Add(Row("고도 격자 간격 (m)",step));right.Controls.Add(Row("최대 종단경사율 (%)",angle));step.ValueChanged+=(_,_)=>{demOptions=null;ClearTerrain();};angle.ValueChanged+=(_,_)=>ClearRoute();locked.Add(step);locked.Add(angle);
        var equivalent=Note("기준 10% = 약 5.71°\n절대 고도차 ÷ 수평거리 × 100\n최소 반경 0m: 경사 조건만 적용");right.Controls.Add(equivalent);angle.ValueChanged+=(_,_)=>equivalent.Text=$"최대 {angle.Value:0.0}% = {LongitudinalGrade.ToAngle((double)angle.Value):0.00}°\n절대 고도차 ÷ 수평거리 × 100\n최소 반경 0m: 경사 조건만 적용";
        var advanced=new FlowLayoutPanel{AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,FlowDirection=FlowDirection.TopDown,WrapContents=false,Padding=new Padding(0,4,0,4),Visible=false};var advancedToggle=B("세부 설정 펼치기",()=>{advanced.Visible=!advanced.Visible;return Task.CompletedTask;},260);advancedToggle.Click+=(_,_)=>advancedToggle.Text=advanced.Visible?"세부 설정 접기":"세부 설정 펼치기";right.Controls.Add(advancedToggle);right.Controls.Add(advanced);UiLayout.FitFlow(advanced);advanced.Controls.Add(equivalent);advanced.Controls.Add(Row("최소 회전반경 (m)",radius));advanced.Controls.Add(Row("굴곡 억제 강도",turnWeight));locked.AddRange([radius,turnWeight]);radius.ValueChanged+=(_,_)=>ClearRoute();turnWeight.ValueChanged+=(_,_)=>ClearRoute();
        advanced.Controls.Add(Row("노선 선 두께 (px)",roadWidth));locked.Add(roadWidth);roadWidth.ValueChanged+=(_,_)=>{map.RouteLineWidth=(double)roadWidth.Value;map.Invalidate();};
        right.Controls.Add(showAll);locked.Add(showAll);showAll.CheckedChanged+=(_,_)=>{map.ShowAllCandidates=showAll.Checked;gpu.ShowAllRoutes=showAll.Checked;gpu.RefreshColors();map.Invalidate();};
        right.Controls.Add(meters);locked.Add(meters);meters.CheckedChanged+=(_,_)=>ClearRoute();
        right.Controls.Add(Heading("시작점과 종점"));
        var startLabel=Note("S  시작점 미지정"); var endLabel=Note("E  종점 미지정");startLabel.Height=endLabel.Height=44;right.Controls.Add(startLabel);right.Controls.Add(endLabel);
        void UpdateLabels(){startLabel.Text=map.Start is {} s?$"S  X {s.X:F3}\n    Y {s.Y:F3}":"S  시작점 미지정";endLabel.Text=map.End is {} e?$"E  X {e.X:F3}\n    Y {e.Y:F3}":"E  종점 미지정";}
        MarkersChanged+=UpdateLabels;
        right.Controls.Add(B("좌표 입력",()=>{Coordinates();return Task.CompletedTask;},286));
        advanced.Controls.Add(B("시작 ↔ 종점",()=>{(map.Start,map.End)=(map.End,map.Start);ClearRoute();MarkersChanged?.Invoke();return Task.CompletedTask;},286));
        right.Controls.Add(Heading("후보 경로와 결과"));right.Controls.Add(candidatePanel);candidatePanel.Visible=true;right.Controls.Add(terrainInfo);result.AutoSize=true;result.Padding=new Padding(6);right.Controls.Add(result);
        var fixedActions=new FlowLayoutPanel{AutoSize=true,Padding=new Padding(4),WrapContents=true};right.Controls.Add(fixedActions);
        fixedActions.Controls.Add(B("후보 생성",async()=>await FindRoute(),130));fixedActions.Controls.Add(B("선택 후보 CSV",()=>{ExportRoute();return Task.CompletedTask;},130));
        var cancel=new Button{Text="작업 취소",AutoSize=true,MinimumSize=new Size(85,28),Width=85,Height=28,FlatStyle=FlatStyle.Flat};cancel.Click+=(_,_)=>operation?.Cancel();fixedActions.Controls.Add(cancel);
        var conditions=Note("등고선 0.5m / 기본 1m / 주요 5m\n도면 예상 범위 621.36 × 1,175.20m\n측점 간격 20m · 굴곡점은 별도 보존");conditions.Height=70;advanced.Controls.Add(conditions);
        var strip=new StatusStrip{Dock=DockStyle.Fill,SizingGrip=false};strip.Items.Add(status);strip.Items.Add(pointer);root.Controls.Add(strip,0,3);
        map.HoverChanged+=p=>pointer.Text=p is null?(map.Pick is null?"":"고도가 있는 지형에 마우스를 올리세요"):$"선택 미리보기 X {p.X:F2}  Y {p.Y:F2}  Z {p.Z:F2}";
        map.PickMissed+=()=>status.Text="고도 자료가 있는 지형을 클릭하세요. 빈 공간과 고도 결측 영역은 선택할 수 없습니다.";
        map.Picked+=(mode,p)=>{if(mode=="start")map.Start=p;else map.End=p;ClearRoute();MarkersChanged?.Invoke();status.Text="좌표 선택 완료 · 고도는 지형 격자에서 조회합니다.";};
        map.Pointer+=p=>{var elevation=grid?.At(p.X,p.Y);pointer.Text=$"X {p.X:F2}  Y {p.Y:F2}  Z {(elevation is null?"—":elevation.Z.ToString("F2"))}";};
        // UI IMPROVEMENT: style the existing controls while preserving the updated DEM workflows.
        DesktopPresentation.Apply(this,header,ribbon,sceneTabs,left,right,startLabel,endLabel,fileInfo,result,comparison,profile);
        KeyDown+=(_,e)=>{if(e.KeyCode==Keys.Escape){map.Pick=null;map.Cursor=Cursors.Default;}};FormClosing+=(_,_)=>operation?.Cancel();
    }
    event Action? MarkersChanged;
    static TabPage Tab(string text)=>new(text){BackColor=Color.FromArgb(242,246,251)};
    static FlowLayoutPanel Tools(params Control[] items){var p=new FlowLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(4),WrapContents=true,AutoScroll=false};p.Controls.AddRange(items);return p;}
    Button B(string text,Func<Task> action,int width=140)
    {
        var b=new ActionButton{Text=text,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,MinimumSize=new Size(Math.Clamp((int)(width*.7),64,110),28),Padding=new Padding(5,2,5,2),Width=width,Height=28,BackColor=Color.FromArgb(226,235,247),ForeColor=Blue,FlatStyle=FlatStyle.Flat,Cursor=Cursors.Hand};b.FlatAppearance.BorderSize=0;b.Click+=async(_,_)=>{try{await action();}catch(Exception e){Error(e);}};locked.Add(b);return b;
    }
    static Label Heading(string text)=>new(){Text=text,AutoSize=true,Width=290,Font=new Font("맑은 고딕",9,FontStyle.Bold),Padding=new Padding(0,3,0,0)};
    static Label Note(string text)=>new(){Text=text,AutoSize=true,Width=290,ForeColor=Color.FromArgb(94,110,128)};
    static Control Row(string title,Control input)
    {
        var p=new TableLayoutPanel{Width=260,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,ColumnCount=2,RowCount=1,Margin=new Padding(2,2,2,2)};
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,64));p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,36));p.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        var label=UiLayout.Text(title);label.Dock=DockStyle.Fill;label.TextAlign=ContentAlignment.MiddleLeft;
        input.Dock=DockStyle.Fill;input.Margin=new Padding(2);input.MinimumSize=new Size(48,input.PreferredSize.Height);
        p.Controls.Add(label,0,0);p.Controls.Add(input,1,0);UiLayout.FitTable(p);return p;
    }
    void Error(Exception e){if(IsDisposed)return;status.Text=e is OperationCanceledException?"작업을 취소했습니다.":e.Message;if(e is not OperationCanceledException)MessageBox.Show(this,e.Message,"작업 확인",MessageBoxButtons.OK,MessageBoxIcon.Information);}
    async Task Run(string message,Func<CancellationToken,Task> task)
    {
        if(operation is not null)return;using var cts=new CancellationTokenSource();operation=cts;status.Text=message;map.Pick=null;map.Cursor=Cursors.Default;
        foreach(var c in locked)c.Enabled=false;
        try{await task(cts.Token);}finally{operation=null;if(!IsDisposed){foreach(var c in locked)c.Enabled=true;surface.Enabled=!map.DemOnly;}}
    }
    async Task Open(bool las)
    {
        using var dialog=new OpenFileDialog{Filter=las?"LAS 점군 (*.las)|*.las":"CAD (*.dwg;*.dxf)|*.dwg;*.dxf",Title=las?"LAS 점군 열기":"CAD 도면 열기"};if(dialog.ShowDialog(this)==DialogResult.OK)await LoadFile(dialog.FileName);
    }
    public async Task LoadFile(string path,bool showOriginalLas=true)
    {
        ImportSettings? import=null; CadDrawing? pendingCad=null;
        if(showOriginalLas)
        {
            string detected="",units="좌표계에 따른 실제 단위 확인";
            if(Path.GetExtension(path).Equals(".las",StringComparison.OrdinalIgnoreCase))detected=LasMetadata.Read(path).CoordinateReference;
            else{await Run("CAD 정보 확인 중…",async ct=>pendingCad=await Task.Run(()=>DrawingReader.Read(path),ct));if(pendingCad is null)return;units=pendingCad.Units;if(cloud is not null&&cloud.CoordinateReference.StartsWith("EPSG:")&&pendingCad.Bounds.MinX<cloud.Bounds.MaxX&&pendingCad.Bounds.MaxX>cloud.Bounds.MinX&&pendingCad.Bounds.MinY<cloud.Bounds.MaxY&&pendingCad.Bounds.MaxY>cloud.Bounds.MinY){detected=cloud.CoordinateReference;units+=" · LAS와 범위 겹침, 실제 단위 확인";}}
            using var settings=new ImportDialog(path,detected,units);if(settings.ShowDialog(this)!=DialogResult.OK)return;import=settings.Settings;
        }
        bool loadedLas=false;
        await Run("자료 읽는 중…",async ct=>
        {
            if(Path.GetExtension(path).Equals(".las",StringComparison.OrdinalIgnoreCase))
            {
                var progress=new Progress<LasReadProgress>(p=>{if(!IsDisposed&&operation?.Token==ct&&!ct.IsCancellationRequested)status.Text=$"LAS 읽는 중 {p.Read:N0} / {p.Total:N0}점 · {(p.Total==0?0:100.0*p.Read/p.Total):F0}%";});
                var actual=import is null?path:await GeoProcessing.PrepareLas(path,import,ct);var data=await Task.Run(()=>LasReader.Read(actual,ct,progress),ct);if(import is not null)data=data with{CoordinateReference=import.Known?ImportSettings.Target:"미확인 / 원본 위치 유지"};autoGround=null;ct.ThrowIfCancellationRequested();if(IsDisposed)return;gpu.FreeCloud();uploadedCloud=null;sceneTabs.SelectedIndex=0;cloud=data;map.Cloud=cloud;loadedLas=true;gpuInfo.Text=$"{Path.GetFileName(path)} · 원본 {data.TotalPointCount:N0}점 · {data.CoordinateReference}\nLAS / GPU → 전체 포인트 보기를 누르면 원본 전체 점군을 표시합니다.";demSource=1;
            }
            else
            {
                var data=pendingCad??await Task.Run(()=>DrawingReader.Read(path),ct);if(import is not null)data=await GeoProcessing.PrepareCad(data,import,ct);cadCrs=import?.Known==true?ImportSettings.Target:"미확인";ct.ThrowIfCancellationRequested();if(IsDisposed)return;cad=data;changing=true;layers.Items.Clear();
                foreach(var l in cad.Layers.Where(l=>l.DrawableCount>0)){bool candidate=l.Name.Contains("등고")||l.Name.Contains("contour",StringComparison.OrdinalIgnoreCase)||l.Name.StartsWith("F001");layers.Items.Add(l.Name,candidate);}changing=false;demSource=cloud is null?0:1;
            }
            demOptions=null;meters.Checked=import is not null;map.Start=map.End=null;MarkersChanged?.Invoke();ClearTerrain();display.SelectedIndex=cloud is not null&&cad is not null?4:Path.GetExtension(path).Equals(".las",StringComparison.OrdinalIgnoreCase)?3:0;ApplyDisplay();FitData();
            fileInfo.Text=$"CAD: {(cad is null?"없음":Path.GetFileName(cad.Source))}\nLAS: {(cloud is null?"없음":Path.GetFileName(cloud.Source))}\nCAD 좌표계: {cadCrs} / LAS: {cloud?.CoordinateReference??"없음"}\n원본 보기 → 등고선만 보기 전환";
            status.Text=map.OriginalOnly?"DWG 원본 보기 · 원본 좌표와 색상 표시 · 자료 정보에서 지원 범위 확인":"읽기 완료 · 자료 정보에서 단위와 읽기 알림을 확인하세요.";
        });
        if(cloud is not null&&cad is not null&&!IsDisposed)status.Text="LAS 위에 DWG 등고선 표시 · 좌측 레이어 체크로 표시 선택";else if(loadedLas&&!IsDisposed)status.Text=cloud!.IsReduced?"LAS 읽기 완료 · 대용량 표시 표본 / 지면 집계 사용":"LAS 읽기 완료 · DEM 생성에서 설정을 지정하세요.";
    }
    void FitData()
    {
        if((display.SelectedIndex==5||(display.SelectedIndex==2&&demSource==2))&&grid is not null){map.SetBounds(Enumerable.Range(0,grid.Values.Length).Where(i=>double.IsFinite(grid.Values[i])).Select(grid.Node));return;}
        bool onlyLas=display.SelectedIndex==3||(display.SelectedIndex==2&&demSource==1);
        bool includeCloud=display.SelectedIndex==1||display.SelectedIndex==4||onlyLas;
        IEnumerable<CadPoint> cloudBounds=cloud is not null&&includeCloud?
            new[]{new CadPoint(cloud.Bounds.MinX,cloud.Bounds.MinY,cloud.Bounds.MinZ),new CadPoint(cloud.Bounds.MaxX,cloud.Bounds.MaxY,cloud.Bounds.MaxZ)}:[];
        map.SetBounds((onlyLas?Enumerable.Empty<CadPoint>():display.SelectedIndex==4?SelectedContours().SelectMany(f=>f.Points):cad?.Features.SelectMany(f=>f.Points)??[]).Concat(cloudBounds));
    }
    void ShowOriginal()
    {
        if(cad is null)throw new InvalidOperationException("DWG / DXF 파일을 먼저 여세요.");
        map.Pick=null;map.Cursor=Cursors.Default;display.SelectedIndex=0;ApplyDisplay();FitData();
        status.Text="DWG 원본만 표시 · 원본 색상 · 휠 확대 / 우클릭 이동";
    }
    List<CadFeature> SelectedContours(){var names=layers.CheckedItems.Cast<string>().ToHashSet();return cad?.Features.Where(f=>names.Contains(f.Layer)&&f.Text is null&&f.Points.Count>1).ToList()??[];}
    void ApplyDisplay()
    {
        if(display.SelectedIndex==5&&grid is null){display.SelectedIndex=cloud is not null&&cad is not null?4:cloud is not null?3:0;return;}
        map.DemOnly=display.SelectedIndex==5;map.ShowCloud=!map.DemOnly;map.ShowSurface=map.DemOnly||surface.Checked;surface.Enabled=operation is null&&!map.DemOnly;
        if(map.DemOnly){sceneTabs.SelectedIndex=0;status.Text="DEM만 보기 · DWG와 LAS 숨김";}
        bool wasOriginal=map.OriginalOnly;
        map.OriginalOnly=display.SelectedIndex==0;
        map.ContourMode=display.SelectedIndex==2;map.OverlayCad=display.SelectedIndex==4;
        map.Features=map.DemOnly?[]:display.SelectedIndex==4?SelectedContours():display.SelectedIndex==3?[]:map.ContourMode?(demSource!=0?generated:SelectedContours()):cad?.Features.ToList()??[];
        if(wasOriginal!=map.OriginalOnly||appliedDisplay!=display.SelectedIndex||appliedSource!=demSource)FitData();
        appliedDisplay=display.SelectedIndex;appliedSource=demSource;
        if(map.OriginalOnly){map.Pick=null;map.Cursor=Cursors.Default;}
        gpu.SetContours(SelectedContours());map.Invalidate();if(map.ContourMode && map.Features.Count==0)status.Text="등고선 레이어를 체크하거나 LAS 고도 격자를 생성하세요.";
    }
    void ClearRoute(){gpu.SetRoutes([],0);syncing=true;comparison.Rows.Clear();profile.Points=[];profile.Invalidate();map.ProfilePoint=null;map.Route=null;map.Candidates=[];candidates.Items.Clear();syncing=false;result.Text="좌표 또는 지형 변경 · 경로 생성 대기";map.Invalidate();}
    void ClearTerrain(){if(display.SelectedIndex==5)display.SelectedIndex=cloud is not null&&cad is not null?4:cloud is not null?3:0;if(display.Items.Count>5)display.Items.RemoveAt(5);grid=null;map.Terrain=null;generated=[];terrainInfo.Text="고도 격자: 준비 전";ClearRoute();ApplyDisplay();}
    List<CadFeature> DemContours()
    {
        var contours=SelectedContours();if(contours.Count==0)throw new InvalidOperationException("좌측에서 고도가 있는 CAD 등고선 레이어를 체크하세요.");return contours;
    }
    DemOptions FusionBounds()
    {
        if(cloud is null||cad is null)throw new InvalidOperationException("통합 DEM은 LAS와 DWG/DXF를 모두 불러와야 합니다.");
        if(cadCrs!=ImportSettings.Target||cloud.CoordinateReference!=ImportSettings.Target)throw new InvalidOperationException("통합 DEM은 두 자료의 원본 좌표계 확인이 필요합니다. 불러오기에서 올바른 원본 좌표계와 실제 단위를 설정해 EPSG:5186으로 맞추세요. 미확인 자료는 통합할 수 없습니다.");
        var pts=DemContours().SelectMany(f=>f.Points);double x=pts.Min(p=>p.X),y=pts.Min(p=>p.Y),xx=pts.Max(p=>p.X),yy=pts.Max(p=>p.Y);
        if(Math.Min(xx,cloud.Bounds.MaxX)<=Math.Max(x,cloud.Bounds.MinX)||Math.Min(yy,cloud.Bounds.MaxY)<=Math.Max(y,cloud.Bounds.MinY))throw new InvalidOperationException("LAS와 선택한 CAD 등고선 범위가 겹치지 않습니다. 같은 현장 자료인지와 좌표계를 확인하세요. 떨어진 두 지역 사이를 연결한 DEM은 생성하지 않습니다.");
        return new(Math.Min(x,cloud.Bounds.MinX),Math.Min(y,cloud.Bounds.MinY),Math.Max(xx,cloud.Bounds.MaxX),Math.Max(yy,cloud.Bounds.MaxY),(double)step.Value,Radius:(double)step.Value*3,CoordinateReference:ImportSettings.Target);
    }
    async Task<IEnumerable<CadPoint>> LasDemPoints(CancellationToken ct,bool groundOnly)
    {
        if(cloud is null)throw new InvalidOperationException("LAS 파일을 먼저 여세요.");
        if(!groundOnly){demMethod="전체 표면 평균 · 수목/건물 포함";return cloud.SurfaceSamples;}
        if(cloud.GroundCount>=3){demMethod="기존 Class 2 지면";return cloud.Ground;}
        status.Text="Class 2 없음 · 공간 표본에서 자동 지면 추출 중…";autoGround??=await GeoProcessing.AutoGround(cloud,ct);demMethod=$"SMRF 자동 추정 지면 · {cloud.SurfaceStep:g}m 표본";return autoGround;
    }
    async Task<TerrainGrid> MakeGrid(CancellationToken ct)
    {
        if(!meters.Checked)throw new InvalidOperationException("입력 XY·Z의 미터 단위와 좌표계를 확인하세요.");
        double spacing=(double)step.Value;IEnumerable<CadPoint> points;
        if(demSource==2)
        {
            var defaultOptions=FusionBounds();var options=demOptions??defaultOptions;
            var las=await LasDemPoints(ct,true);var contours=DemContours();
            points=await Task.Run(()=>DemFusion.Combine(las,TerrainGrid.ContourSamples(contours,options.Resolution/2,options,ct),options,ct),ct);
            demMethod="LAS + CAD 통합 · "+demMethod;return await Task.Run(()=>DemBuilder.Build(points,options,ct),ct);
        }
        if(demSource==1)points=await LasDemPoints(ct,demOptions?.GroundOnly!=false);
        else{demMethod="CAD 등고선";var contours=DemContours();var heights=contours.SelectMany(f=>f.Points).Select(p=>p.Z);if(heights.Max()-heights.Min()<0.01)throw new InvalidOperationException("선택한 등고선 Z가 모두 같습니다.");points=TerrainGrid.ContourSamples(contours,(demOptions?.Resolution??spacing)/2,demOptions,ct);}
        return await Task.Run(()=>demOptions is {} options?DemBuilder.Build(points,options,ct):TerrainGrid.Build(points,spacing,ct),ct);
    }
    async Task Prepare(CancellationToken ct)
    {
        var next=await MakeGrid(ct);var contours=demSource!=0?await Task.Run(()=>next.Contours(5),ct):new List<CadFeature>();ct.ThrowIfCancellationRequested();if(IsDisposed)return;
        grid=next;map.Terrain=grid;if(display.Items.Count==5)display.Items.Add("DEM만 보기");generated=contours;terrainInfo.Text=$"고도 격자 {grid.Width} × {grid.Height} / {grid.Step}m\n유효 셀 {grid.Values.Count(double.IsFinite):N0}\n{demOptions?.Algorithm??"IDW"} · {demMethod}";ApplyDisplay();
    }
    DemOptions SourceDemOptions(int index)
    {
        if(index==2)return FusionBounds();
        IEnumerable<CadPoint> points;
        if(index==1){if(cloud is null)throw new InvalidOperationException("LAS 파일을 먼저 불러오세요.");points=new[]{new CadPoint(cloud.Bounds.MinX,cloud.Bounds.MinY,0),new CadPoint(cloud.Bounds.MaxX,cloud.Bounds.MaxY,0)};}
        else points=DemContours().SelectMany(f=>f.Points);
        return new(points.Min(p=>p.X),points.Min(p=>p.Y),points.Max(p=>p.X),points.Max(p=>p.Y),(double)step.Value,Radius:(double)step.Value*3,CoordinateReference:index==1?cloud!.CoordinateReference:cadCrs);
    }
    async Task ConfigureDem()
    {
        int initial=demSource;DemOptions? options=null;Exception? error=null;
        foreach(int index in new[]{initial,0,1,2}.Distinct())try{options=SourceDemOptions(index);initial=index;break;}catch(InvalidOperationException e){error=e;}
        if(options is null)throw error??new InvalidOperationException("자료를 먼저 불러오세요.");
        using var dialog=new DemDialog(initial==demSource?demOptions??options:options,initial!=0,initial==2,SourceDemOptions);
        if(dialog.ShowDialog(this)!=DialogResult.OK)return;
        demSource=dialog.SelectedSource;ClearTerrain();demOptions=dialog.Options;meters.Checked=true;await BuildTerrain();surface.Checked=true;
    }    async Task BuildTerrain()=>await Run("고도 격자 생성 중…",async ct=>{await Prepare(ct);if(!IsDisposed){display.SelectedIndex=5;status.Text="고도 격자 준비 완료 · 종단경사 계산 가능";}});
    async Task FindRoute()
    {
        sceneTabs.SelectedIndex=0;
        if(map.Start is null||map.End is null)throw new InvalidOperationException("시작점과 종점을 먼저 지정하세요.");
        if(grid is null){await ConfigureDem();if(grid is null)return;}
        await Run("경사 제한 후보 경로 탐색 중…",async ct=>
        {
            if(!meters.Checked)throw new InvalidOperationException("미터 단위 및 동일 좌표계를 확인하고 체크하세요.");
            if(grid is null)await Prepare(ct);if(IsDisposed)return;
            var start=map.Start!;var end=map.End!;double max=(double)angle.Value;
            var progress=new Progress<int>(attempt=>{if(operation?.Token==ct&&!ct.IsCancellationRequested)status.Text=attempt<0?$"격자 세분화 재탐색 · 원본 간격의 1/{-attempt} · 176개 방향 · 최대 {max:0.0}% 유지":$"후보 경로 탐색 중 · 탐색 {attempt}/12 · 176개 방향 · 최대 5개";});
            var quality=new RouteQualityOptions((double)radius.Value,(double)turnWeight.Value);
            var roads=await Task.Run(()=>RoutePlanner.FindCandidatesByGrade(grid!,start,end,max,5,ct,progress,quality),ct);ct.ThrowIfCancellationRequested();if(IsDisposed)return;
            map.Start=roads[0].Vertices[0];map.End=roads[0].Vertices[^1];MarkersChanged?.Invoke();
            map.Candidates=roads;map.SelectedCandidate=0;map.Route=roads[0];candidates.Items.Clear();
            for(int i=0;i<roads.Count;i++)candidates.Items.Add($"{i+1}  {roads[i].Length:N0}m / {roads[i].MaximumGrade:F2}%");
            candidates.HorizontalExtent=candidates.Items.Cast<object>().Select(i=>TextRenderer.MeasureText(i.ToString(),candidates.Font).Width+36).DefaultIfEmpty(0).Max();candidates.SelectedIndex=0;if(map.OriginalOnly||map.DemOnly)display.SelectedIndex=cloud is not null&&cad is not null?4:cloud is not null?3:2;
            if(map.Is3D){surface.Checked=true;map.FocusRoute();}UpdateRouteResult();map.Invalidate();
            if(candidates.Parent?.Parent is ScrollableControl resultsPane)resultsPane.AutoScrollPosition=new Point(0,candidates.Parent.Top-resultsPane.AutoScrollPosition.Y);
            status.Text=$"최대 {angle.Value:0.0}% 이하 후보 {roads.Count}개 · 20m 측점 / 종점 포함 · 노선 선 표시 · 중심선 경사 검증";
        });
    }
    void UpdateRouteResult()
    {
        if(map.Route is not {} road)return;
        var metrics=RoadGeometry.Metrics(road);var points=RoadGeometry.Profile(grid!,road);
        double average=points.Zip(points.Skip(1)).Sum(pair=>Math.Abs(pair.Second.Z-pair.First.Z))*100/road.Length;
        result.Text=$"후보 {map.Candidates.Count}개 · 선택 {map.SelectedCandidate+1} / {road.Length:N1}m\n평균 {average:F2}% · 최대 {road.MaximumGrade:F2}%\n20m 측점 {road.Stations.Count}개 · 종점 포함\n굴곡 {metrics.BendCount}개 · 최소 반경 {(double.IsInfinity(metrics.MinimumRadius)?"직선":metrics.MinimumRadius.ToString("F1")+"m")}\n노선 선 표시 · 중심선 경사 검증";
        gpu.SetRoutes(map.Candidates,map.SelectedCandidate);
        profile.Points=points;profile.MaximumAngle=LongitudinalGrade.ToAngle((double)angle.Value);profile.Invalidate();
        syncing=true;comparison.Rows.Clear();
        for(int i=0;i<map.Candidates.Count;i++)
        {
            var candidate=map.Candidates[i];var m=RoadGeometry.Metrics(candidate);var samples=RoadGeometry.Profile(grid!,candidate);
            double mean=samples.Zip(samples.Skip(1)).Sum(p=>Math.Abs(p.Second.Z-p.First.Z))*100/candidate.Length;
            comparison.Rows.Add(i+1,candidate.Length.ToString("N1"),mean.ToString("F2"),candidate.MaximumGrade.ToString("F2"),m.BendCount,double.IsInfinity(m.MinimumRadius)?"직선":m.MinimumRadius.ToString("F1"),i==map.SelectedCandidate?"—":RoadGeometry.Overlap(candidate,road,grid!.Step*2).ToString("F0"));
            comparison.Rows[i].DefaultCellStyle.ForeColor=Color.FromArgb(35,65,85);comparison.Rows[i].Cells[0].Style.BackColor=MapCanvas.RouteColors[i];
        }
        comparison.ClearSelection();comparison.Rows[map.SelectedCandidate].Selected=true;comparison.CurrentCell=comparison.Rows[map.SelectedCandidate].Cells[0];syncing=false;
    }
    async Task Pick(string mode)
    {
        sceneTabs.SelectedIndex=0;
        if(map.Is3D&&grid is null)
        {
            int selectedDisplay=display.SelectedIndex;bool showSurface=surface.Checked;var restoreView=map.PreserveView();
            try{await ConfigureDem();}
            finally{display.SelectedIndex=selectedDisplay;surface.Checked=showSurface;restoreView();}
            if(grid is null)return;
        }
        map.Pick=mode;map.Cursor=Cursors.Cross;map.Invalidate();
        status.Text=$"{(mode=="start"?"시작점":"종점")}을 {(map.Is3D?"3D 지형":"지도")}에서 클릭하세요. Esc 취소";
    }
    void Coordinates()
    {
        using var d=new CoordinateDialog(map.Start,map.End);if(d.ShowDialog(this)!=DialogResult.OK)return;map.Start=d.Start;map.End=d.End;ClearRoute();MarkersChanged?.Invoke();
    }
    async Task LoadGpu()
    {
        if(cloud is null)throw new InvalidOperationException("먼저 LAS 파일을 여세요.");
        if(ReferenceEquals(uploadedCloud,cloud)&&gpu.UploadedCount==cloud.TotalPointCount)
        {sceneTabs.SelectedIndex=1;status.Text="GPU 전체 점군 표시 · 기존 버퍼 사용";return;}
        await Run("전체 LAS GPU 업로드 준비 중…",async ct=>
        {
            sceneTabs.SelectedIndex=1;gpuInfo.Text="LAS 원본 전체 점 업로드 중 · 압축 / 점 생략 없음 · 취소 가능";
            try{await gpu.SetCloudAsync(cloud,ct);if(gpu.UploadedCount!=cloud.TotalPointCount){gpu.FreeCloud();throw new InvalidDataException("LAS 원본 전체 점 수와 GPU 표시 점 수가 다릅니다.");}uploadedCloud=cloud;gpu.SetRoutes(map.Candidates,map.SelectedCandidate);gpu.SetContours(SelectedContours());gpuInfo.Text=$"{Path.GetFileName(cloud.Source)} · GPU {gpu.UploadedCount:N0}/{cloud.TotalPointCount:N0}점 · 점 버퍼 약 {gpu.UploadedCount*16/1024.0/1024:N0}MB\n좌클릭 회전 · 우클릭/가운데 이동 · 휠 확대 · 1 평면 / 3 입체 · 더블클릭 전체 보기";status.Text="GPU 전체 점군 준비 완료 · 지점 선택과 도로 면은 지형 / 경로 탐색 탭에서 사용";}
            catch{gpuInfo.Text="원본 전체 점 표시 미완료 · 점 수를 줄여 표시하지 않습니다. 분석 탭은 별도의 표본 / DEM 자료입니다.";throw;}
        });
    }
    public async Task GpuPreview(string input,string png)
    {
        gpu.Diagnostic=message=>File.AppendAllText(png+".trace.txt",message+"\n");File.AppendAllText(png+".trace.txt","GPU test start\n");await LoadFile(input,showOriginalLas:false);await LoadGpu();File.AppendAllText(png+".trace.txt","LAS explicit GPU upload ready\n");if(sceneTabs.SelectedIndex!=1)throw new Exception("LAS 원본 탭 자동 전환 실패");
        if(gpu.UploadedCount!=cloud!.TotalPointCount)throw new Exception("GPU 원본 전체 점 업로드 수 불일치");
        if(cloud.TotalPointCount<100000)
        {
            meters.Checked=true;await Prepare(CancellationToken.None);var nodes=Enumerable.Range(0,grid!.Values.Length).Where(i=>double.IsFinite(grid.Values[i])).Select(grid.Node).ToList();map.Start=nodes[nodes.Count/5];map.End=nodes[nodes.Count*4/5];await FindRoute();
            if(gpu.Routes.Count!=map.Candidates.Count)throw new Exception("GPU 후보 동기화 오류");sceneTabs.SelectedIndex=1;gpu.SetView("ISO");
        }
        using var frame=gpu.CaptureFrame();frame.Save(Path.Combine(Path.GetDirectoryName(png)!,Path.GetFileNameWithoutExtension(png)+"-viewport.png"));
        using var whole=new Bitmap(Width,Height);DrawToBitmap(whole,new Rectangle(Point.Empty,Size));using(var graphics=Graphics.FromImage(whole)){var location=gpu.PointToScreen(Point.Empty);graphics.DrawImageUnscaled(frame,location.X-Left,location.Y-Top);}whole.Save(png);
        File.WriteAllText(png+".json",JsonSerializer.Serialize(new{gpu.UploadedCount,cloud.TotalPointCount,cloud.CoordinateReference,cloud.HasRgb,cloud.RgbIs8Bit,CandidateCount=gpu.Routes.Count}));
        if(cloud.TotalPointCount<100000)
        {
            using var cancel=new CancellationTokenSource();void CancelUpload(long read,long total){if(read>0)cancel.Cancel();}
            gpu.UploadProgress+=CancelUpload;bool cancelled=false;
            try{await gpu.SetCloudAsync(cloud,cancel.Token);}catch(OperationCanceledException){cancelled=true;}finally{gpu.UploadProgress-=CancelUpload;}
            if(!cancelled||gpu.UploadedCount!=0)throw new Exception("GPU 취소/임시 버퍼 정리 오류");
            await gpu.SetCloudAsync(cloud,CancellationToken.None);if(gpu.UploadedCount!=cloud.TotalPointCount)throw new Exception("GPU 재업로드 수 불일치");
            File.AppendAllText(png+".trace.txt","PASS GPU cancellation cleanup and re-upload\n");
        }
    }
    void Info()
    {
        var text=new StringBuilder();if(cad is not null){var b=cad.Bounds;text.AppendLine($"CAD {cad.Source}\n버전 {cad.Version} / 단위 {cad.Units}\nX {b.MinX:F3}~{b.MaxX:F3}\nY {b.MinY:F3}~{b.MaxY:F3}\nZ {b.MinZ:F3}~{b.MaxZ:F3}\n");foreach(var w in cad.Warnings)text.AppendLine(w);}
        if(cloud is not null)text.AppendLine($"\nLAS {cloud.Source}\n버전 {cloud.Version} / 포맷 {cloud.Format}\nRGB {cloud.HasRgb} / 8비트 범위 {cloud.RgbIs8Bit}\nGPU 업로드 {gpu.UploadedCount:N0}점\n전체 {cloud.TotalPointCount:N0}점 / 지면 {cloud.GroundCount:N0}점\n메모리 보관 {cloud.Points.Count:N0}점 / 대용량 모드 {cloud.IsReduced}\n지면 집계 간격 {cloud.GroundAggregationStep:g} / 집계 {cloud.GroundSamples.Count:N0}개\n자동 추출용 표본 {cloud.LowSamples.Count:N0}개 / 간격 {cloud.SurfaceStep:g}m\n원본 전체 점군: 점 생략 없음 (withheld 포함) / LAS 파일 압축·변환·수정 없음\nDEM 분석 자료: 별도 표본·지면 집계 사용\n좌표계 {cloud.CoordinateReference}");
        text.AppendLine("\nCAD 원본 보기는 지원 선·점·문자의 XY 배치와 색상을 표시합니다. 해치·치수·외부 참조·Civil 3D 객체·선종류·문자 배치는 AutoCAD와 완전히 동일하지 않습니다.\n확인된 원본 좌표계는 EPSG:5186으로 변환합니다. 미확인 자료는 원본 위치를 유지합니다.\n기본 최대 종단경사율은 10% (약 5.71°)이며 입력은 % 기준입니다. 노선 중간의 DEM 경사를 검사하고, 20m 측점과 굴곡점을 보존합니다.");
        using var d=new Form{Text="자료 정보 / 지원 범위",Size=new Size(780,580),StartPosition=FormStartPosition.CenterParent};d.Controls.Add(new TextBox{Text=text.ToString().Replace("\n","\r\n"),Multiline=true,ReadOnly=true,Dock=DockStyle.Fill,ScrollBars=ScrollBars.Both,WordWrap=false,Font=Font});d.ShowDialog(this);
    }
    void ExportData()
    {
        if(cad is null&&cloud is null)throw new InvalidOperationException("자료를 먼저 여세요.");using var d=new SaveFileDialog{Filter="JSON (*.json)|*.json",Title=cloud?.IsReduced==true?"LAS 화면 표본·지면 집계 JSON 저장":"자료 JSON 저장",FileName=cloud?.IsReduced==true?"terrain-summary.json":"terrain-data.json"};if(d.ShowDialog(this)!=DialogResult.OK)return;
        using(var output=File.Create(d.FileName))JsonSerializer.Serialize(output,new{cad,las=cloud},new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase});status.Text=cloud?.IsReduced==true?"화면 표본·지면 집계 JSON 저장 완료 · 전체 원본 점은 LAS 파일에 보존":"자료구조 JSON 저장 완료";
    }
    void ExportDem()
    {
        if(grid is null)throw new InvalidOperationException("DEM을 먼저 생성하세요.");
        using var d=new SaveFileDialog{Filter="ESRI ASCII Grid (*.asc)|*.asc",FileName="terrain-dem.asc"};if(d.ShowDialog(this)!=DialogResult.OK)return;
        double noData=demOptions?.NoData??-9999;
        using(var writer=new StreamWriter(d.FileName,false,new UTF8Encoding(false)))
        {
            writer.WriteLine(FormattableString.Invariant($"ncols {grid.Width}\nnrows {grid.Height}\nxllcenter {grid.X}\nyllcenter {grid.Y}\ncellsize {grid.Step}\nNODATA_value {noData}"));
            for(int j=grid.Height-1;j>=0;j--)writer.WriteLine(string.Join(" ",Enumerable.Range(0,grid.Width).Select(i=>(double.IsFinite(grid.Values[j*grid.Width+i])?grid.Values[j*grid.Width+i]:noData).ToString("G17",CultureInfo.InvariantCulture))));
        }
        File.WriteAllText(d.FileName+".json",JsonSerializer.Serialize(new{Settings=demOptions,Source=demMethod,CoordinateReference=demSource!=0?cloud?.CoordinateReference:cadCrs},new JsonSerializerOptions{WriteIndented=true}));status.Text="DEM ASC 및 좌표계·보간 설정 JSON 저장 완료";
    }
    void ExportRoute()
    {
        if(map.Route is not {} road)throw new InvalidOperationException("경로를 먼저 생성하세요.");using var d=new SaveFileDialog{Filter="CSV (*.csv)|*.csv",FileName="road-route.csv"};if(d.ShowDialog(this)!=DialogResult.OK)return;
        var text=new StringBuilder("type,index,distance_m,x,y,z\r\n");double distance=0;
        for(int i=0;i<road.Vertices.Count;i++){if(i>0)distance+=RoutePlanner.Distance(road.Vertices[i-1],road.Vertices[i]);var p=road.Vertices[i];text.AppendLine(FormattableString.Invariant($"vertex,{i},{distance:G17},{p.X:G17},{p.Y:G17},{p.Z:G17}"));}
        for(int i=0;i<road.Stations.Count;i++){var p=road.Stations[i];text.AppendLine(FormattableString.Invariant($"station,{i},{p.Distance:G17},{p.X:G17},{p.Y:G17},{p.Z:G17}"));}
        File.WriteAllText(d.FileName,text.ToString(),new UTF8Encoding(true));status.Text="굴곡점 및 20m 측점 CSV 저장 완료";
    }
    public async Task Preview(string input,string png,bool viewOnly=false,bool threeD=false)
    {
        await LoadFile(input,showOriginalLas:false);
        if(viewOnly)
        {
            if(Path.GetExtension(input).Equals(".las",StringComparison.OrdinalIgnoreCase))
            {if(cloud is null||cloud.Points.Count==0||map.OriginalOnly)throw new Exception("LAS 점군 보기 확인 실패");}
            else if(cad is null || map.Features.Count!=cad.Features.Count || !map.OriginalOnly)throw new Exception("CAD 원본 보기 확인 실패");
            if(threeD){view3D.Checked=true;Check3D();}SavePreview(png);return;
        }
        meters.Checked=true;await BuildTerrain();if(grid is null)throw new Exception("격자 생성 확인 실패");
        var nodes=Enumerable.Range(0,grid.Values.Length).Where(i=>double.IsFinite(grid.Values[i])).Select(grid.Node).ToList();
        map.Start=nodes[nodes.Count/5];map.End=nodes[nodes.Count*4/5];
        if(threeD)
        {
            view3D.Checked=true;await Pick("start");var expected=map.Start!;var hit=map.PickTerrain(map.Screen(expected));
            if(!map.Is3D||map.Pick!="start"||hit is null||RoutePlanner.Distance(hit,expected)>grid.Step*0.01)throw new Exception("3D 지형 선택 확인 실패");
            if(map.PickTerrain(new PointF(-10000,-10000)) is not null)throw new Exception("빈 공간 3D 선택 오류");
            map.CheckHover(Point.Round(map.Screen(expected)));
            if(map.HoverPoint is null)throw new Exception("3D 선택 미리보기 오류");
            SavePreview(Path.Combine(Path.GetDirectoryName(png)!,Path.GetFileNameWithoutExtension(png)+"-pick.png"));
            map.CheckLeftClick(Point.Round(map.Screen(expected)));
            if(map.Pick is not null||map.Start is null||!map.Is3D)throw new Exception("3D 클릭 이벤트 선택 실패");
            await Pick("end");map.CheckLeftClick(Point.Round(map.Screen(map.End!)));
            if(map.Pick is not null||map.End is null||!map.Is3D)throw new Exception("3D 종점 클릭 이벤트 실패");
        }
        MarkersChanged?.Invoke();await FindRoute();
        if(map.Route is null)throw new Exception("경로 생성 확인 실패");display.SelectedIndex=2;map.Fit();Refresh();Application.DoEvents();
        if(threeD){view3D.Checked=true;surface.Checked=true;Check3D();map.FocusRoute();}SavePreview(png);
        if(threeD)
        {
            candidates.SelectedIndex=map.Candidates.Count-1;
            if(map.Route!=map.Candidates[candidates.SelectedIndex])throw new Exception("후보 선택 / CSV 대상 연결 오류");
            showAll.Checked=false;map.FocusRoute();
            if(profile.Points.Count<2||comparison.Rows.Count!=map.Candidates.Count||!result.Visible)throw new Exception("고정 결과 영역 / 비교표 / 종단면 오류");
            SavePreview(Path.Combine(Path.GetDirectoryName(png)!,Path.GetFileNameWithoutExtension(png)+"-selected.png"));
            Size=MinimumSize;map.Fit();Refresh();Application.DoEvents();
            if(candidates.Parent?.Parent is ScrollableControl resultsPane)resultsPane.AutoScrollPosition=new Point(0,candidates.Parent.Top-resultsPane.AutoScrollPosition.Y);
            if(!Bounds.Contains(result.RectangleToScreen(result.ClientRectangle)))throw new Exception("최소 창 크기에서 결과가 잘림");
            SavePreview(Path.Combine(Path.GetDirectoryName(png)!,Path.GetFileNameWithoutExtension(png)+"-small.png"));
        }
    }
    void Check3D()
    {
        var p=new CadPoint(0,0,0);var q=new CadPoint(0,0,100);
        var a=map.Screen(p);var b=map.Screen(q);
        if(!map.Is3D||Math.Abs(a.Y-b.Y)<1)throw new Exception("3D 투영에서 Z 고도가 반영되지 않음");
        double difference=Math.Abs(a.Y-b.Y);map.HeightScale=2;a=map.Screen(p);b=map.Screen(q);
        if(Math.Abs(a.Y-b.Y)<=difference||Math.Abs(a.Y-b.Y)>2*difference+0.01)throw new Exception("높이 배율 투영 오류");
        map.HeightScale=1;map.TopCamera();a=map.Screen(p);b=map.Screen(q);
        if(Math.Abs(a.Y-b.Y)>0.01||Math.Abs(a.X-b.X)>0.01)throw new Exception("위에서 보기 투영 오류");
        map.CheckToolbar();map.ResetCamera();
    }
    void SavePreview(string png)
    {
        Refresh();Application.DoEvents();
        if(map.Width<220||map.Height<80)throw new Exception($"화면 배치 오류: 지형 캔버스 {map.Width} × {map.Height} / 창 {Width} × {Height}");
        using var bitmap=new Bitmap(Width,Height);DrawToBitmap(bitmap,new Rectangle(Point.Empty,Size));
        if(map.GpuSceneReady){using var frame=map.CaptureScene();using var graphics=Graphics.FromImage(bitmap);var position=map.PointToScreen(Point.Empty);graphics.DrawImageUnscaled(frame,position.X-Left,position.Y-Top);}
        bitmap.Save(png);
    }
}






















