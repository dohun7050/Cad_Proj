using ForestRoad.Cad;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;

public sealed partial class MainForm
{
    internal async Task VerifyRenderer(string output)
    {
        Directory.CreateDirectory(output);await Task.Delay(150);
        if(!map.GpuSceneReady)throw new Exception("OpenGL initialization failed");
        if(FindControls(this).Any(c=>c is Button&&(c.Text=="DWG 원본만 보기"||c.Text=="DEM만 보기"))||FindControls(this).Contains(step.Parent!)&&FindControls(this).Any(c=>c.Text=="고도 자료 선택"))throw new Exception("Duplicate controls remain");
        await LoadFile(@"C:\Users\user\Downloads\옥성임도_2024.dwg",false);
        SavePreview(Path.Combine(output,"01-dwg-opengl.png"));
        using(var frame=map.CaptureScene())CheckImage(frame);
        int uploads=map.SceneGeometryUploads;
        var times=new List<double>();
        for(int i=0;i<20;i++)
        {
            map.Zoom(i%2==0?1.03:1/1.03);var clock=System.Diagnostics.Stopwatch.StartNew();using var frame=map.CaptureScene();times.Add(clock.Elapsed.TotalMilliseconds);
        }
        if(map.SceneGeometryUploads!=uploads)throw new Exception("Camera movement rebuilt GPU geometry");
        await LoadFile(@"C:\Users\user\Downloads\옥성임도_2024.las",false);
        display.SelectedIndex=4;SavePreview(Path.Combine(output,"02-las-dwg-opengl.png"));
        using(var frame=map.CaptureScene())CheckImage(frame);
        view3D.Checked=true;map.ResetCamera();SavePreview(Path.Combine(output,"03-las-dwg-3d.png"));
        using(var frame=map.CaptureScene())CheckImage(frame);
        map.CheckToolbar();map.ResetCamera();
        // Synthetic DEM specifically tests picking and NoData display; it is not measured terrain.
        double[] heights=Enumerable.Range(0,31*31).Select(i=>100+(i/31)*.2).ToArray();heights[15*31+15]=double.NaN;
        grid=new TerrainGrid(200000,500000,5,31,31,heights);map.Terrain=grid;
        if(display.Items.Count==5)display.Items.Add("DEM만 보기");display.SelectedIndex=5;
        map.SetBounds(Enumerable.Range(0,heights.Length).Where(i=>double.IsFinite(heights[i])).Select(grid.Node));map.Set3D(true);
        var expected=grid.Node(10*31+10);var hit=map.PickTerrain(map.Screen(expected));
        if(hit is null||RoutePlanner.Distance(hit,expected)>.01)throw new Exception("GPU camera/DEM picking mismatch");
        map.Pick="start";map.CheckLeftClick(Point.Round(map.Screen(expected)));if(map.Start is null)throw new Exception("Start selection failed");
        SavePreview(Path.Combine(output,"04-synthetic-dem-pick.png"));
        foreach(int selectedDisplay in new[]{0,3,4,5})foreach(bool in3D in new[]{false,true})
        {
            display.SelectedIndex=selectedDisplay;map.Set3D(in3D);map.Zoom(1.17);surface.Checked=false;
            var features=map.Features;var before=map.Screen(expected);bool original=map.OriginalOnly,demOnly=map.DemOnly;
            foreach(string mode in new[]{"start","end"})
            {
                await Pick(mode);
                if(display.SelectedIndex!=selectedDisplay||map.OriginalOnly!=original||map.DemOnly!=demOnly||!ReferenceEquals(features,map.Features)||map.Screen(expected)!=before||surface.Checked)
                    throw new Exception($"Point selection changed display: {selectedDisplay}, 3D={in3D}, {mode}");
                map.CheckLeftClick(Point.Round(map.Screen(expected)));
                if(map.Pick is not null||(mode=="start"?map.Start:map.End) is null)throw new Exception("Point selection failed");
            }
        }
        File.WriteAllText(Path.Combine(output,"point-selection-verification.txt"),"PASS: start/end selection preserves DWG, LAS, combined and DEM display, zoom and surface settings in both 2D and 3D; clicks accepted.");
        foreach(bool in3D in new[]{false,true})
        {
            map.Set3D(in3D);map.Pick="start";var before=map.Screen(expected);int uploadsBefore=map.SceneGeometryUploads;
            using(var initial=map.CaptureScene())uploadsBefore=map.SceneGeometryUploads;
            map.CheckMiddleDrag(new Point(100,100),new Point(145,130));var after=map.Screen(expected);
            using var moved=map.CaptureScene();
            if(Math.Abs(after.X-before.X-45)>.01||Math.Abs(after.Y-before.Y-30)>.01||map.Pick!="start"||map.Capture||map.SceneGeometryUploads!=uploadsBefore)
                throw new Exception($"Middle-button pan failed: 3D={in3D}");
            map.Pick=null;
        }
        File.WriteAllText(Path.Combine(output,"middle-pan-verification.txt"),"PASS: middle-button drag pans 2D and 3D without selecting points or re-uploading geometry; mouse capture released.");
        var savedGrid=grid;var savedSource=demSource;
        // Changing inputs in a cancelled dialog must leave the existing DEM untouched.
        using(var dialog=new DemDialog(new(0,0,100,100,5),true,false,i=>new(0,0,i==2?200:100,100,5,CoordinateReference:"EPSG:5186")))
        {
            var input=FindControls(dialog).OfType<ComboBox>().Single(c=>c.Name=="DemSource");input.SelectedIndex=2;
            if(dialog.SelectedSource!=2)throw new Exception("Combined DEM source switch failed");input.SelectedIndex=0;
            if(dialog.SelectedSource!=0||!ReferenceEquals(grid,savedGrid)||demSource!=savedSource)throw new Exception("Dialog preview changed active DEM");
        }
        File.WriteAllText(Path.Combine(output,"render-verification.txt"),$"PASS: real DWG, real LAS preview + DWG, OpenGL 2D/3D, original data buffers reused during zoom, camera presets, synthetic DEM picking, removed duplicate controls, DEM dialog source changes preserve current DEM until commit.\nDWG capture+draw (20 zoom frames, includes framebuffer readback): median {times.Order().ElementAt(times.Count/2):F1}ms; max {times.Max():F1}ms. Not an interactive FPS benchmark.\nLAS preview {cloud!.Points.Count:N0}; full source {cloud.TotalPointCount:N0}. Full source GPU tab remains separate.");
    }
    static void CheckImage(Bitmap frame)
    {
        var colors=new HashSet<int>();for(int y=50;y<frame.Height-60;y+=5)for(int x=30;x<frame.Width-30;x+=5)colors.Add(frame.GetPixel(x,y).ToArgb());
        if(colors.Count<2)throw new Exception("OpenGL frame is empty or missing geometry");
    }
}
