using ForestRoad.Cad;
namespace OkseongRoad.Terrain;
public record Station(double Distance, double X, double Y, double Z);
public record RoadRoute(List<CadPoint> Vertices, List<Station> Stations, double Length, double MaximumAngle)
{
    public double MaximumGrade=>LongitudinalGrade.ToPercent(MaximumAngle);
}
public static class RoutePlanner
{
    // Primitive integer offsets provide 176 headings, including shallow contour-following
    // directions unavailable on an eight-neighbor grid. Each entire edge is validated.
    public static readonly IReadOnlyList<(int X,int Y)> Directions =
        (from y in Enumerable.Range(-8,17)
         from x in Enumerable.Range(-8,17)
         where (x!=0||y!=0) && Gcd(Math.Abs(x),Math.Abs(y))==1
         orderby x*x+y*y
         select (x,y)).ToArray();
    static int Gcd(int a,int b){while(b!=0){(a,b)=(b,a%b);}return a;}
    public static double Distance(CadPoint a,CadPoint b)=>Math.Sqrt((a.X-b.X)*(a.X-b.X)+(a.Y-b.Y)*(a.Y-b.Y));
    public static bool Allowed(TerrainGrid grid,CadPoint a,CadPoint b,double angle,out double peak)
    {
        peak=0; double length=Distance(a,b);
        if(!double.IsFinite(angle)||angle<=0||angle>=90||!double.IsFinite(length))return false;
        if(length<1e-9) return Math.Abs(a.Z-b.Z)<1e-7;
        // Bilinear terrain is quadratic along a straight segment. Check analytic derivatives
        // within each crossed grid cell, including both sides of grid boundaries.
        var cuts=new List<double>{0,1};
        if(Math.Abs(b.X-a.X)>1e-9)
            for(int i=(int)Math.Ceiling((Math.Min(a.X,b.X)-grid.X)/grid.Step);i<=(int)Math.Floor((Math.Max(a.X,b.X)-grid.X)/grid.Step);i++)
            {double t=(grid.X+i*grid.Step-a.X)/(b.X-a.X);if(t>1e-9 && t<1-1e-9)cuts.Add(t);}
        if(Math.Abs(b.Y-a.Y)>1e-9)
            for(int j=(int)Math.Ceiling((Math.Min(a.Y,b.Y)-grid.Y)/grid.Step);j<=(int)Math.Floor((Math.Max(a.Y,b.Y)-grid.Y)/grid.Step);j++)
            {double t=(grid.Y+j*grid.Step-a.Y)/(b.Y-a.Y);if(t>1e-9 && t<1-1e-9)cuts.Add(t);}
        cuts=cuts.Distinct().Order().ToList();
        for(int k=1;k<cuts.Count;k++)
        {
            double t0=cuts[k-1],t1=cuts[k],dt=t1-t0;if(dt<1e-10)continue;
            CadPoint? P(double t)=>grid.At(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t);
            var p0=P(t0);var pm=P((t0+t1)/2);var p1=P(t1);
            if(p0 is null || pm is null || p1 is null) return false;
            double dz=p1.Z-p0.Z, curvature=p1.Z+p0.Z-2*pm.Z;
            double slope=Math.Max(Math.Abs(dz-2*curvature),Math.Abs(dz+2*curvature))/(length*dt);
            peak=Math.Max(peak,Math.Atan(slope)*180/Math.PI);
            if(peak>angle+1e-7)return false;
        }
        return true;
    }
    public static RoadRoute FindByGrade(TerrainGrid grid,CadPoint start,CadPoint end,double maximumGrade=10,CancellationToken ct=default)
        =>Find(grid,start,end,LongitudinalGrade.ToAngle(maximumGrade),20,ct);
    public static List<RoadRoute> FindCandidatesByGrade(TerrainGrid grid,CadPoint start,CadPoint end,double maximumGrade=10,int count=5,CancellationToken ct=default,IProgress<int>? progress=null,RouteQualityOptions? quality=null)
        =>FindCandidates(grid,start,end,LongitudinalGrade.ToAngle(maximumGrade),count,ct,progress,quality);
    // Angular entry points remain for smoothing and existing callers; defaults also represent 10%.
    public static RoadRoute Find(TerrainGrid grid,CadPoint start,CadPoint end,double angle=LongitudinalGrade.DefaultAngle,double stationSpacing=20,CancellationToken ct=default)
        =>FindCore(grid,start,end,angle,stationSpacing,ct,null,null);
    static RoadRoute FindCore(TerrainGrid grid,CadPoint start,CadPoint end,double angle,double stationSpacing,CancellationToken ct,double[]? penalties,Dictionary<long,bool>? edges,double turnWeight=0)
    {
        ct.ThrowIfCancellationRequested();
        if(!double.IsFinite(angle)||angle<=0||angle>=90||!double.IsFinite(stationSpacing)||stationSpacing<=0)throw new ArgumentException("경사 기준과 측점 간격을 확인하세요.");
        if(!double.IsFinite(start.X)||!double.IsFinite(start.Y)||!double.IsFinite(end.X)||!double.IsFinite(end.Y))throw new ArgumentException("시작점·종점 좌표가 유효하지 않습니다.");
        start=grid.At(start.X,start.Y)??throw new InvalidOperationException("시작점에 유효한 지형 고도가 없습니다.");
        end=grid.At(end.X,end.Y)??throw new InvalidOperationException("종점에 유효한 지형 고도가 없습니다.");
        if(Distance(start,end)<0.001)throw new InvalidOperationException("시작점과 종점을 다르게 지정하세요.");
        string limit=$"{LongitudinalGrade.ToPercent(angle):0.###}%";
        // A feasible straight edge is globally shortest in horizontal distance.
        if((penalties is null||!penalties.Any(p=>p>0))&&Allowed(grid,start,end,angle,out _))
            return RoadGeometry.Create(grid,[start,end],angle,ct,stationSpacing)!;

        // Integrate corridor penalties along the entire edge. Endpoint-only costs let long
        // grid edges jump across penalized cells, rewarding repeated zigzags at their borders.
        double TravelCost(CadPoint a,CadPoint b)
        {
            double distance=Distance(a,b);
            if(penalties is null)return distance;
            int samples=Math.Max(1,(int)Math.Ceiling(distance/(grid.Step/2)));
            double sum=0;
            for(int i=0;i<samples;i++)
            {
                ct.ThrowIfCancellationRequested();double t=(i+.5)/samples;
                int x=Math.Clamp((int)Math.Round((a.X+(b.X-a.X)*t-grid.X)/grid.Step),0,grid.Width-1);
                int y=Math.Clamp((int)Math.Round((a.Y+(b.Y-a.Y)*t-grid.Y)/grid.Step),0,grid.Height-1);
                sum+=penalties[y*grid.Width+x];
            }
            return distance*(1+sum/samples);
        }
        var travelCosts=new Dictionary<long,double>();

        // A turn cost depends on arrival direction. Never merge different headings into one node.
        int stride=turnWeight>0?Directions.Count+1:1,initialHeading=stride-1;
        var states=new Dictionary<long,(double Cost,long Parent)>();
        var queue=new PriorityQueue<(long Key,double Cost),double>();
        void Enqueue(int id,int heading,double cost,long parent)
        {
            long key=(long)id*stride+heading;
            if(states.TryGetValue(key,out var old)&&cost>=old.Cost-1e-9)return;
            states[key]=(cost,parent);queue.Enqueue((key,cost),cost+Distance(grid.Node(id),end));
        }
        CadPoint Previous(int id,int heading)
        {
            if(stride==1||heading==initialHeading)return start;
            var d=Directions[heading];var p=grid.Node(id);return new(p.X-d.X*grid.Step,p.Y-d.Y*grid.Step,0);
        }
        int sx=(int)Math.Round((start.X-grid.X)/grid.Step),sy=(int)Math.Round((start.Y-grid.Y)/grid.Step);
        for(int dy=-6;dy<=6;dy++)for(int dx=-6;dx<=6;dx++)
        {
            ct.ThrowIfCancellationRequested();int x=sx+dx,y=sy+dy;
            if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;
            int id=y*grid.Width+x;var p=grid.Node(id);
            if(double.IsFinite(p.Z)&&Distance(start,p)<=grid.Step*6&&Allowed(grid,start,p,angle,out _))
                Enqueue(id,initialHeading,TravelCost(start,p),-1);
        }
        if(queue.Count==0)throw new SearchUnavailableException($"시작점에서 {limit} 이하로 지형 격자에 진입할 수 없습니다. 위치·고도 결측·좌표 단위를 확인하세요.");
        var goals=new Dictionary<int,double>();
        int ex=(int)Math.Round((end.X-grid.X)/grid.Step),ey=(int)Math.Round((end.Y-grid.Y)/grid.Step);
        for(int dy=-6;dy<=6;dy++)for(int dx=-6;dx<=6;dx++)
        {
            ct.ThrowIfCancellationRequested();int x=ex+dx,y=ey+dy;
            if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;
            int id=y*grid.Width+x;var p=grid.Node(id);double distance=Distance(p,end);
            if(double.IsFinite(p.Z)&&distance<=grid.Step*6&&Allowed(grid,p,end,angle,out _))
                goals[id]=TravelCost(p,end);
        }
        if(goals.Count==0)throw new SearchUnavailableException($"종점에 {limit} 이하로 연결할 수 없습니다. 위치·고도 결측·좌표 단위를 확인하세요.");
        long last=-1;double best=double.PositiveInfinity;
        while(queue.TryDequeue(out var item,out double priority))
        {
            ct.ThrowIfCancellationRequested();if(priority>=best-1e-9)break;
            if(item.Cost>states[item.Key].Cost+1e-9)continue;
            int id=(int)(item.Key/stride),heading=(int)(item.Key%stride);var a=grid.Node(id);
            var previous=Previous(id,heading);
            if(goals.TryGetValue(id,out double final))
            {
                double turn=turnWeight>0?RoadGeometry.Turn(previous,a,end):0;
                double candidate=item.Cost+final+turnWeight*turn*turn;
                if(candidate<best){best=candidate;last=item.Key;}
            }
            for(int direction=0;direction<Directions.Count;direction++)
            {
                ct.ThrowIfCancellationRequested();
                var (dx,dy)=Directions[direction];int x=id%grid.Width+dx,y=id/grid.Width+dy;
                if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;
                int next=y*grid.Width+x;var b=grid.Node(next);if(!double.IsFinite(b.Z))continue;
                double turn=turnWeight>0?RoadGeometry.Turn(previous,a,b):0;
                long edge=((long)Math.Min(id,next)<<32)|(uint)Math.Max(id,next);
                if(!travelCosts.TryGetValue(edge,out double travel))
                {travel=TravelCost(a,b);if(travelCosts.Count<1_000_000)travelCosts[edge]=travel;}
                double candidate=item.Cost+travel+turnWeight*turn*turn;
                long nextKey=(long)next*stride+(stride==1?0:direction);
                if(states.TryGetValue(nextKey,out var old)&&candidate>=old.Cost-1e-9)continue;
                bool permitted;
                if(edges is null)permitted=Allowed(grid,a,b,angle,out _);
                else if(!edges.TryGetValue(edge,out permitted)){permitted=Allowed(grid,a,b,angle,out _);if(edges.Count<1_000_000)edges[edge]=permitted;}
                if(permitted)Enqueue(next,stride==1?0:direction,candidate,item.Key);
            }
        }
        if(last<0)throw new SearchUnavailableException($"최대 종단경사율 {limit} 이하인 연결 노선을 찾지 못했습니다. 도달 상태 {states.Count:N0}개. 경사 기준을 자동 완화하지 않습니다. 고도 결측 및 시작·종점 위치를 확인하세요. 이는 현재 DEM과 탐색 방향에서의 결과입니다.");
        var route=new List<CadPoint>{end};
        for(long key=last;key>=0;key=states[key].Parent)route.Add(grid.Node((int)(key/stride)));
        route.Add(start);route.Reverse();
        return RoadGeometry.Create(grid,route,angle,ct,stationSpacing)??throw new InvalidOperationException("최종 노선의 지형 고도·경사 검증에 실패했습니다.");
    }
    /// <summary>Search alternative corridors by penalizing previously searched routes.
    /// All candidates retain the same endpoints and full-edge slope/NoData validation.</summary>
    public static List<RoadRoute> FindCandidates(TerrainGrid grid,CadPoint start,CadPoint end,double angle=LongitudinalGrade.DefaultAngle,int count=5,CancellationToken ct=default,IProgress<int>? progress=null,RouteQualityOptions? quality=null)
    {
        ct.ThrowIfCancellationRequested();
        if(!double.IsFinite(angle)||angle<=0||angle>=90)throw new ArgumentException("경사 기준을 확인하세요.");
        if(!double.IsFinite(start.X)||!double.IsFinite(start.Y)||!double.IsFinite(end.X)||!double.IsFinite(end.Y))throw new ArgumentException("시작점·종점 좌표가 유효하지 않습니다.");
        // Bad inputs/NoData endpoints cannot be repaired by subdividing the search lattice.
        start=grid.At(start.X,start.Y)??throw new InvalidOperationException("시작점에 유효한 지형 고도가 없습니다.");
        end=grid.At(end.X,end.Y)??throw new InvalidOperationException("종점에 유효한 지형 고도가 없습니다.");
        if(Distance(start,end)<0.001)throw new InvalidOperationException("시작점과 종점을 다르게 지정하세요.");
        if(quality is not null&&(!double.IsFinite(quality.MinimumRadius)||quality.MinimumRadius<0||!double.IsFinite(quality.TurnWeight)||quality.TurnWeight<0))throw new ArgumentException("회전반경과 굴곡 비용은 유한한 0 이상의 값이어야 합니다.");
        if(count<1||count>5)throw new ArgumentOutOfRangeException(nameof(count));
        SearchUnavailableException? failure=null;int lastFactor=1;
        foreach(int factor in new[]{1,2,4,8})
        {
            ct.ThrowIfCancellationRequested();
            long width=(long)(grid.Width-1)*factor+1,height=(long)(grid.Height-1)*factor+1;
            if(factor>1&&(width*height>1_000_000||grid.Step/factor<0.25))break;
            lastFactor=factor;var search=grid;
            if(factor>1)
            {
                progress?.Report(-factor);
                var values=new double[(int)(width*height)];
                for(int y=0;y<(int)height;y++)for(int x=0;x<(int)width;x++)
                {
                    ct.ThrowIfCancellationRequested();
                    values[y*(int)width+x]=grid.At(grid.X+x*grid.Step/factor,grid.Y+y*grid.Step/factor)?.Z??double.NaN;
                }
                // Subdivide the same bilinear DEM without smoothing or changing source elevations.
                search=new TerrainGrid(grid.X,grid.Y,grid.Step/factor,(int)width,(int)height,values);
            }
            try
            {
                var candidates=FindCandidatesCore(search,start,end,angle,count,ct,progress,quality);
                var verified=new List<RoadRoute>();
                foreach(var candidate in candidates)
                {
                    ct.ThrowIfCancellationRequested();
                    // Rebuild 20m stations and validate every segment against the ORIGINAL DEM.
                    var road=RoadGeometry.Create(grid,candidate.Vertices,angle,ct,20);
                    if(road is null)continue;
                    if(quality is {MinimumRadius:>0}&&RoadGeometry.Metrics(road).MinimumRadius<quality.MinimumRadius*(1-1e-4))continue;
                    // Candidate separation uses physical distance on the original grid at every level.
                    if(verified.All(old=>DistinctCorridor(road,old,grid.Step*2,ct)))verified.Add(road);
                }
                if(verified.Count>0)return verified.OrderBy(r=>r.Length).ToList();
                throw new SearchUnavailableException("원본 DEM에서 경사·회전반경을 만족하는 후보가 없습니다.");
            }
            catch(SearchUnavailableException e){failure=e;}
        }
        throw new InvalidOperationException($"176개 방향 및 최대 {lastFactor}배 격자 탐색으로 조건을 만족하는 노선을 찾지 못했습니다. 최대 종단경사율 {LongitudinalGrade.ToPercent(angle):0.###}%와 회전반경 조건을 자동 완화하지 않습니다.\n"+(failure?.Message??"DEM 범위를 확인하세요."),failure);
    }
    // Only a genuine search failure triggers refinement; cancellation and invalid input propagate.
    sealed class SearchUnavailableException(string message):InvalidOperationException(message);
    static List<RoadRoute> FindCandidatesCore(TerrainGrid grid,CadPoint start,CadPoint end,double angle,int count,CancellationToken ct,IProgress<int>? progress,RouteQualityOptions? quality)
    {
        var accepted=new List<RoadRoute>();var explored=new List<RoadRoute>();var edges=new Dictionary<long,bool>();
        for(int attempt=0;attempt<12&&accepted.Count<count;attempt++)
        {
            ct.ThrowIfCancellationRequested();progress?.Report(attempt+1);
            double[] penalties=new double[grid.Values.Length];
            foreach(var old in explored)
            {
                var marked=new HashSet<int>();
                foreach(var (a,b) in old.Vertices.Zip(old.Vertices.Skip(1)))
                {
                    int steps=Math.Max(1,(int)Math.Ceiling(Distance(a,b)/grid.Step));
                    for(int k=0;k<=steps;k++)
                    {
                        ct.ThrowIfCancellationRequested();double t=(double)k/steps;
                        var p=new CadPoint(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t,0);
                        if(Distance(p,start)<grid.Step*5||Distance(p,end)<grid.Step*5)continue;
                        int x=(int)Math.Round((p.X-grid.X)/grid.Step),y=(int)Math.Round((p.Y-grid.Y)/grid.Step);
                        for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++)
                        {int u=x+dx,v=y+dy;if(u>=0&&v>=0&&u<grid.Width&&v<grid.Height&&dx*dx+dy*dy<=9)marked.Add(v*grid.Width+u);}
                    }
                }
                foreach(int id in marked)penalties[id]+=2;
            }
            var candidate=FindCore(grid,start,end,angle,20,ct,penalties,edges,quality?.TurnWeight??0);explored.Add(candidate);
            // Apply terrain-validated zigzag cleanup even when no optional radius was supplied.
            var smooth=RoadGeometry.Smooth(grid,candidate,angle,quality?.MinimumRadius??0,ct);
            if(smooth is null)continue;candidate=smooth;
            // Do not fill the candidate list with excessive penalty-driven detours.
            // Compare with a feasible baseline, rather than the straight endpoint distance:
            // terrain may legitimately require a long switchback route.
            if(accepted.Count>0&&candidate.Length>accepted.Min(r=>r.Length)*1.5+grid.Step*2)continue;
            if(accepted.All(r=>DistinctCorridor(candidate,r,grid.Step*2,ct)))accepted.Add(candidate);
        }
        if(accepted.Count==0)throw new SearchUnavailableException("경사와 최소 회전반경을 동시에 만족하는 후보를 찾지 못했습니다. 반경·격자 간격·시작/종점을 조정하세요. 조건을 자동으로 완화하지 않습니다.");
        double shortest=accepted.Min(r=>r.Length);
        return accepted.Where(r=>r.Length<=shortest*1.5+grid.Step*2).OrderBy(r=>r.Length).ToList();
    }
    public static bool DistinctCorridor(RoadRoute a,RoadRoute b,double tolerance,CancellationToken ct=default)
    {
        double different=0,total=0;
        foreach(var (p,q) in a.Vertices.Zip(a.Vertices.Skip(1)))
        {
            ct.ThrowIfCancellationRequested();double length=Distance(p,q);int pieces=Math.Max(1,(int)Math.Ceiling(length/Math.Max(1,tolerance)));
            for(int i=0;i<pieces;i++)
            {
                double t=(i+0.5)/pieces;var point=new CadPoint(p.X+(q.X-p.X)*t,p.Y+(q.Y-p.Y)*t,0);
                double nearest=double.PositiveInfinity;
                foreach(var (u,v) in b.Vertices.Zip(b.Vertices.Skip(1)))
                {
                    double dx=v.X-u.X,dy=v.Y-u.Y,den=dx*dx+dy*dy;
                    double f=den==0?0:Math.Clamp(((point.X-u.X)*dx+(point.Y-u.Y)*dy)/den,0,1);
                    nearest=Math.Min(nearest,Distance(point,new CadPoint(u.X+f*dx,u.Y+f*dy,0)));
                }
                total+=length/pieces;if(nearest>tolerance)different+=length/pieces;
            }
        }
        return total>0&&different/total>=0.15;
    }

}
