# 임도 노선 설계 · 최신 UI 개선본

## Visual Studio에서 실행

1. 이 폴더의 OkseongRoad.sln을 엽니다.
2. .NET 데스크톱 개발 워크로드와 .NET 8 SDK를 준비합니다.
3. OkseongRoad.App을 시작 프로젝트로 설정합니다.
4. Debug / x64를 선택하고 F5로 실행합니다.

명령줄 빌드:
```powershell
dotnet build OkseongRoad.sln -c Release -m:1 -p:UseSharedCompilation=false
```

빌드 후 실행: src/OkseongRoad.App/bin/Release/net8.0-windows/OkseongRoad.exe
실행에는 .NET 8 Windows Desktop Runtime x64가 필요합니다.

## 남긴 파일

- src: WinForms UI, 지도·3D·점군, CAD 읽기, LAS·DEM·노선 계산, 폰트 자산
- lib: 참조 DLL과 네이티브 라이브러리
- OkseongRoad.sln, 각 csproj, Directory.Build.props: 솔루션과 빌드 설정
- THIRD_PARTY_NOTICES.md 및 폰트 라이선스: 외부 라이브러리·폰트 고지
- .gitignore: Visual Studio 캐시와 빌드 결과 제외 설정

bin, obj, .vs는 Visual Studio가 필요할 때 다시 생성합니다.
lib와 src 아래 폰트·라이선스는 유지하세요. 실제 DWG/DXF/LAS는 파일 열기로 외부 원본을 선택합니다.

## 최신 개선 사항

밝은 회색·흰색과 초록색 강조, 라인 아이콘, 자료·레이어 및 설계 조건·결과 배치,
주요 후보 생성 버튼, 지도·목록·표의 후보 선택 연동, 세부 설정 접기를 적용했습니다.
후보 탐색 비용과 굴곡 정리, 과도한 우회 후보 제외 개선을 유지합니다.
VIEW는 원래 배치이며 LEFT / RIGHT / FRONT / BACK의 한글 접두어를 제거했습니다.

정리 전 Release 빌드: 오류 0, 경고 0. 노선 회귀 검사 17개는 복구 검증에서 통과했습니다.
현재 100% 배율의 최소 창 크기에서 지형 캔버스 공간 부족 검사가 실패한 제한은 남아 있습니다.
실제 사용자 DWG/LAS 자료와 여러 모니터 간 배율 변경은 별도 검증이 필요합니다.

이전 프로젝트·ZIP·중복 실행본·검증 자료는 삭제하지 않고 작업 폴더 밖의 정리전_보관 폴더에 보관했습니다.
