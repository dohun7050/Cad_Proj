using ForestRoad.Cad;
namespace OkseongRoad.App;

public sealed partial class MainForm
{
    sealed record DisplayLayer(string Key,string Label,string Kind,string? CadName=null,int RouteIndex=-1,bool Available=true)
    { public override string ToString()=>Label; }
    readonly HashSet<string> demInputLayers=[];
    readonly HashSet<string> removedDisplayLayers=[];
    void InitializeLayerMenu()
    {
        layers.DrawMode=DrawMode.OwnerDrawFixed;layers.ItemHeight=Math.Max(24,layers.Font.Height+8);
        layers.FontChanged+=(_,_)=>layers.ItemHeight=Math.Max(24,layers.Font.Height+8);
        layers.DrawItem+=(_,e)=>
        {
            if(e.Index<0)return;
            var item=(DisplayLayer)layers.Items[e.Index];e.DrawBackground();
            var check=new Rectangle(e.Bounds.X+3,e.Bounds.Y+(e.Bounds.Height-14)/2,14,14);
            ButtonState state=item.Available?ButtonState.Normal:ButtonState.Inactive;
            if(layers.GetItemChecked(e.Index))state|=ButtonState.Checked;
            ControlPaint.DrawCheckBox(e.Graphics,check,state);
            TextRenderer.DrawText(e.Graphics,item.Label,e.Font,new Rectangle(e.Bounds.X+23,e.Bounds.Y,e.Bounds.Width-23,e.Bounds.Height),item.Available?e.ForeColor:SystemColors.GrayText,TextFormatFlags.VerticalCenter|TextFormatFlags.NoPrefix);
            e.DrawFocusRectangle();
        };
        var menu=new ContextMenuStrip();
        var remove=menu.Items.Add("목록에서 제거");
        var restore=menu.Items.Add("제거한 항목 복원");
        var demInput=new ToolStripMenuItem("DEM 생성 입력으로 사용"){CheckOnClick=true};menu.Items.Add(demInput);
        menu.Opening+=(_,_)=>
        {
            remove.Enabled=layers.SelectedItem is DisplayLayer{Available:true}&&operation is null;restore.Enabled=removedDisplayLayers.Count>0&&operation is null;
            demInput.Visible=layers.SelectedItem is DisplayLayer{Kind:"cad",Available:true};demInput.Enabled=operation is null;
            demInput.Checked=layers.SelectedItem is DisplayLayer item&&demInputLayers.Contains(item.CadName??"");
        };
        demInput.Click+=(_,_)=>
        {
            if(layers.SelectedItem is not DisplayLayer{Kind:"cad"} layer)return;
            if(demInput.Checked)demInputLayers.Add(layer.CadName!);else demInputLayers.Remove(layer.CadName!);
            demOptions=null;ClearTerrain();status.Text="DEM 입력 레이어 변경 · DEM과 후보 경로를 다시 생성하세요.";
        };
        layers.MouseDown+=(_,e)=>{if(e.Button==MouseButtons.Right)layers.SelectedIndex=layers.IndexFromPoint(e.Location);};
        remove.Click+=(_,_)=>
        {
            if(layers.SelectedItem is not DisplayLayer{Available:true} layer)return;
            removedDisplayLayers.Add(layer.Key);RefreshLayers();DisplayLayerChanged();
        };
        restore.Click+=(_,_)=>{removedDisplayLayers.Clear();RefreshLayers();DisplayLayerChanged();};
        layers.ContextMenuStrip=menu;
    }
    bool LayerVisible(string key)=>layers.CheckedItems.OfType<DisplayLayer>().Any(l=>l.Key==key&&l.Available);
    void SetAllRouteLayers(bool visible)
    {
        if(changing)return;
        changing=true;
        try{for(int i=0;i<layers.Items.Count;i++)if(((DisplayLayer)layers.Items[i]).Kind=="route")layers.SetItemChecked(i,visible);}
        finally{changing=false;}
        DisplayLayerChanged();
    }
    void SyncRouteToggle()
    {
        bool saved=changing;changing=true;
        try{showAll.Checked=map.Candidates.Count==0||map.HiddenCandidates.Count==0;}
        finally{changing=saved;}
    }
    void RefreshLayers(bool resetCad=false,bool resetRoutes=false)
    {
        var previous=Enumerable.Range(0,layers.Items.Count).ToDictionary(i=>((DisplayLayer)layers.Items[i]).Key,i=>layers.GetItemChecked(i));
        bool saved=changing;changing=true;layers.BeginUpdate();
        try
        {
            layers.Items.Clear();
            void Add(DisplayLayer layer,bool reset=false)
            {
                if(reset)removedDisplayLayers.Remove(layer.Key);
                if(!removedDisplayLayers.Contains(layer.Key))layers.Items.Add(layer,layer.Available&&(!reset&&previous.TryGetValue(layer.Key,out var visible)?visible:true));
            }
            if(cad is not null)foreach(var layer in cad.Layers.Where(l=>l.DrawableCount>0))Add(new("cad:"+layer.Name,"CAD · "+layer.Name,"cad",layer.Name),resetCad);
            if(cad is null||!cad.Layers.Any(l=>l.DrawableCount>0))Add(new("missing:cad","CAD · 자료 없음","cad",Available:false));
            if(cloud is not null)Add(new("las","LAS · 점군","las"));
            else Add(new("missing:las","LAS · 자료 없음","las",Available:false));
            if(grid is not null)Add(new("dem","DEM · 지형 면","dem"));
            else Add(new("missing:dem","DEM · 생성 전","dem",Available:false));
            for(int i=0;i<map.Candidates.Count;i++)Add(new("route:"+i,$"후보 경로 {i+1}","route",RouteIndex:i),resetRoutes);
            if(map.Candidates.Count==0)Add(new("missing:route","후보 경로 · 생성 전","route",Available:false));
            layers.Height=Math.Clamp(layers.Items.Count*layers.ItemHeight+12,180,420);
        }
        finally{layers.EndUpdate();changing=saved;}
    }
    void ApplyLayerPreset()
    {
        bool saved=changing;changing=true;
        try
        {
            for(int i=0;i<layers.Items.Count;i++)
            {
                var layer=(DisplayLayer)layers.Items[i];
                bool visible=display.SelectedIndex switch
                {
                    0=>layer.Kind=="cad",
                    1=>true,
                    2=>demSource==0?layer.Kind=="cad"&&demInputLayers.Contains(layer.CadName!):layer.Kind=="dem",
                    3=>layer.Kind=="las",
                    4=>layer.Kind=="las"||layer.Kind=="cad"&&demInputLayers.Contains(layer.CadName!),
                    5=>layer.Kind=="dem",
                    _=>false
                };
                layers.SetItemChecked(i,visible&&layer.Available);
            }
            surface.Checked=LayerVisible("dem");
        }
        finally{changing=saved;}
    }
    void DisplayLayerChanged()
    {
        if(IsDisposed)return;
        // Layer checks only affect rendering. Analysis inputs and results remain intact.
        var restoreView=map.PreserveView();
        changing=true;
        try{display.SelectedIndex=1;surface.Checked=LayerVisible("dem");}
        finally{changing=false;}
        try{ApplyDisplay();}finally{restoreView();}
    }
    void SetDemLayerVisible(bool visible)
    {
        if(changing)return;
        for(int i=0;i<layers.Items.Count;i++)if(((DisplayLayer)layers.Items[i]).Key=="dem")
        {
            changing=true;try{layers.SetItemChecked(i,visible);}finally{changing=false;}
            DisplayLayerChanged();return;
        }
    }
    List<CadFeature> VisibleCadFeatures()=>cad?.Features.Where(f=>LayerVisible("cad:"+f.Layer)).ToList()??[];
}
