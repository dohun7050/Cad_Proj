using System.Drawing.Drawing2D;
namespace OkseongRoad.App;

internal static class StudioTheme
{
    public static readonly Color Background=Color.FromArgb(244,246,245),Panel=Color.White,Raised=Color.FromArgb(236,244,239),Border=Color.FromArgb(218,227,222),Text=Color.FromArgb(38,51,42),Muted=Color.FromArgb(109,120,111),Accent=Color.FromArgb(39,119,80),Forest=Color.FromArgb(23,63,42),Highlight=Color.FromArgb(111,175,69);
    public static GraphicsPath Round(RectangleF r,float radius=10)
    {
        var p=new GraphicsPath();float d=radius*2;p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.Right-d,r.Y,d,d,270,90);p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);p.AddArc(r.X,r.Bottom-d,d,d,90,90);p.CloseFigure();return p;
    }
    public static void Apply(Control root)
    {
        foreach(Control c in root.Controls)Apply(c);
        if(root is MapCanvas or GpuCloudPanel)return;
        root.ForeColor=Text;
        switch(root)
        {
            case Form f: f.BackColor=Background;break;
            case TabPage p: p.BackColor=Panel;p.Font=UiFonts.Create(9.5f);break;
            case TabControl: root.BackColor=Background;break;
            case DataGridView grid:
                grid.EnableHeadersVisualStyles=false;grid.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.None;grid.BackgroundColor=Panel;grid.GridColor=Border;
                grid.ColumnHeadersHeight=32;grid.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
                grid.ColumnHeadersDefaultCellStyle=new(){BackColor=Raised,ForeColor=Muted,Font=UiFonts.Create(9,FontStyle.Bold),Padding=new Padding(4)};
                grid.DefaultCellStyle=new(){BackColor=Panel,ForeColor=Text,SelectionBackColor=Color.FromArgb(223,240,192),SelectionForeColor=Accent,Padding=new Padding(4)};
                grid.AlternatingRowsDefaultCellStyle.BackColor=Color.FromArgb(246,249,240);grid.RowTemplate.Height=22;grid.CellBorderStyle=DataGridViewCellBorderStyle.SingleHorizontal;break;
            case Button b:
                // UI IMPROVEMENT: information actions are neutral; retain every existing button.
                b.FlatStyle=FlatStyle.Flat;b.FlatAppearance.BorderColor=Border;b.FlatAppearance.BorderSize=1;
                b.BackColor=Raised;b.ForeColor=Text;b.Cursor=Cursors.Hand;b.FlatAppearance.MouseOverBackColor=Color.FromArgb(223,235,208);break;
            case NumericUpDown n: n.BackColor=Panel;n.ForeColor=Text;n.BorderStyle=BorderStyle.FixedSingle;break;
            case TextBox t: t.BackColor=Panel;t.ForeColor=Text;t.BorderStyle=BorderStyle.FixedSingle;break;
            case ComboBox b:
                b.BackColor=Panel;b.ForeColor=Text;b.FlatStyle=FlatStyle.Flat;
                if(b.DrawMode!=DrawMode.OwnerDrawFixed)
                {
                    b.DrawMode=DrawMode.OwnerDrawFixed;b.ItemHeight=24;
                    b.DrawItem+=(_,e)=>{if(e.Bounds.Width<=0)return;using var fill=new SolidBrush((e.State&DrawItemState.Selected)!=0?Raised:Panel);e.Graphics.FillRectangle(fill,e.Bounds);string label=e.Index<0?b.Text:(b.GetItemText(b.Items[e.Index])??string.Empty);TextRenderer.DrawText(e.Graphics,label,b.Font,Rectangle.Inflate(e.Bounds,-5,0),Text,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);};
                }
                break;
            case CheckedListBox l: l.BackColor=Panel;l.ForeColor=Text;l.IntegralHeight=false;break;
            case ListBox l: l.BackColor=Panel;l.ForeColor=Text;break;
            case StatusStrip strip: strip.BackColor=Background;strip.ForeColor=Muted;foreach(ToolStripItem item in strip.Items)item.ForeColor=Muted;break;
            case Label l: l.BackColor=Color.Transparent;l.ForeColor=l.Font.Bold?Text:Muted;break;
            case CheckBox b: b.BackColor=Color.Transparent;b.ForeColor=Muted;break;
            case ProfileCanvas: root.BackColor=Panel;break;
            case System.Windows.Forms.Panel: root.BackColor=Panel;break;
        }
        if(root is not Form)root.Invalidate();
    }
}


