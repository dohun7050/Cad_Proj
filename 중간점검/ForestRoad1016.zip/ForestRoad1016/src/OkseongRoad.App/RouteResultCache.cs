using System.Diagnostics;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;

public sealed partial class MainForm
{
    sealed record RouteSummary(RouteMetrics Metrics,List<Station> Profile,double Average);
    sealed record RouteResults(TerrainGrid Grid,RoadRoute[] Roads,RouteSummary[] Summaries,double[,] Overlap);
    RouteResults? routeResults;
    readonly Dictionary<string,double> phaseMilliseconds=[];
    static RouteResults CalculateRouteResults(TerrainGrid terrain,List<RoadRoute> roads,CancellationToken ct)
    {
        var summaries=new RouteSummary[roads.Count];var overlap=new double[roads.Count,roads.Count];
        for(int i=0;i<roads.Count;i++)
        {
            ct.ThrowIfCancellationRequested();var road=roads[i];var points=RoadGeometry.Profile(terrain,road,ct);
            double average=points.Zip(points.Skip(1)).Sum(p=>Math.Abs(p.Second.Z-p.First.Z))*100/road.Length;
            summaries[i]=new(RoadGeometry.Metrics(road),points,average);
            for(int j=0;j<roads.Count;j++)if(i!=j)
            {ct.ThrowIfCancellationRequested();overlap[i,j]=RoadGeometry.Overlap(road,roads[j],terrain.Step*2,ct);}
        }
        return new(terrain,roads.ToArray(),summaries,overlap);
    }
    RouteResults EnsureRouteResults()
    {
        if(routeResults is {} cached&&ReferenceEquals(cached.Grid,grid)&&cached.Roads.Length==map.Candidates.Count&&cached.Roads.Where((r,i)=>!ReferenceEquals(r,map.Candidates[i])).Any()==false)return cached;
        return routeResults=CalculateRouteResults(grid!,map.Candidates,CancellationToken.None);
    }
}
