using System.Diagnostics;
using System.Drawing.Drawing2D;
using ForestRoad.Cad;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;

public sealed partial class MainForm
{
    readonly ToolStripProgressBar searchActivity=new(){Visible=false,Style=ProgressBarStyle.Marquee,MarqueeAnimationSpeed=30,Width=90};
    readonly System.Windows.Forms.Timer searchAnimation=new(){Interval=150};
    LiveSearch? liveSearch;
    sealed class LiveSearch(int target):IProgress<SearchVisualFrame>
    {
        readonly object gate=new();readonly Queue<CadPoint> points=[];
        SearchVisualFrame? latest;public readonly Stopwatch Clock=Stopwatch.StartNew();public int Target=>target;
        public void Report(SearchVisualFrame frame)
        {
            lock(gate)
            {
                latest=frame with{Visited=[]};
                foreach(var point in frame.Visited){if(points.Count>=2048)points.Dequeue();points.Enqueue(point);}
            }
        }
        public SearchVisualFrame? Take()
        {
            lock(gate)
            {
                if(latest is null)return null;
                var frame=latest with{Visited=points.ToArray()};latest=null;points.Clear();return frame;
            }
        }
    }
    void InitializeSearchVisualization()
    {
        searchAnimation.Tick+=(_,_)=>
        {
            if(liveSearch is not {} current||IsDisposed)return;
            if(current.Take() is {} frame)map.UpdateSearchVisualization(frame);
            map.SearchSeconds=current.Clock.Elapsed.TotalSeconds;
            if(map.SearchFrame is {} shown)status.Text=$"10% 고정 · {shown.Phase} · {map.SearchSeconds:F1}초 · 검토 {shown.Expanded:N0} · 후보 {map.Candidates.Count}/{current.Target}";
            map.Invalidate();
        };
        FormClosed+=(_,_)=>searchAnimation.Dispose();
    }
    IProgress<SearchVisualFrame> BeginSearchVisualization(int target)
    {
        liveSearch=new(target);map.ClearSearchVisualization();map.SearchActive=true;
        map.UpdateSearchVisualization(new("탐색 준비",0,target,map.Candidates.Count,grid?.Step??0,0,0,0,0,0,null,[]));
        searchActivity.Visible=true;searchAnimation.Start();map.Invalidate();return liveSearch;
    }
    void SearchPhase(string phase)
    {
        if(liveSearch is null)return;
        if(liveSearch.Take() is {} frame)map.UpdateSearchVisualization(frame);
        if(map.SearchFrame is {} current)map.UpdateSearchVisualization(current with{Phase=phase,Visited=[]});
    }
    void EndSearchVisualization()
    {
        liveSearch=null;if(IsDisposed)return;
        searchAnimation.Stop();searchActivity.Visible=false;map.ClearSearchVisualization();map.Invalidate();
    }
}

public sealed partial class MapCanvas
{
    readonly Queue<CadPoint> searchPoints=[];
    public SearchVisualFrame? SearchFrame {get;private set;}
    public bool SearchActive {get;set;}
    public double SearchSeconds {get;set;}
    public void UpdateSearchVisualization(SearchVisualFrame frame)
    {
        SearchFrame=frame;
        foreach(var p in frame.Visited){if(searchPoints.Count>=2500)searchPoints.Dequeue();searchPoints.Enqueue(p);}
        Invalidate();
    }
    public void ClearSearchVisualization(){SearchFrame=null;SearchActive=false;SearchSeconds=0;searchPoints.Clear();}
    void PaintSearchVisualization(Graphics g)
    {
        if(!SearchActive||SearchFrame is not {} frame)return;
        using var visited=new SolidBrush(Color.FromArgb(120,105,245,230));
        foreach(var point in searchPoints)
        {var p=Screen(point);if(p.X>=0&&p.Y>=0&&p.X<Width&&p.Y<Height)g.FillRectangle(visited,p.X-1.5f,p.Y-1.5f,3,3);}
        if(frame.Current is {} current)
        {
            var p=Screen(current);float radius=(float)(9+3*Math.Sin(SearchSeconds*4));
            using var halo=new Pen(Color.Gold,2);g.DrawEllipse(halo,p.X-radius,p.Y-radius,2*radius,2*radius);
            using var fill=new SolidBrush(Color.Gold);g.FillEllipse(fill,p.X-3,p.Y-3,6,6);
        }
        float width=Math.Max(120,Math.Min(490,Width-28));bool compact=Height<160;
        float height=compact?52:Font.Height*5+24;float top=compact?8:48;
        using var background=new SolidBrush(Color.FromArgb(235,17,35,27));using var border=new Pen(Color.FromArgb(100,170,140));
        g.FillRectangle(background,14,top,width,height);g.DrawRectangle(border,14,top,width,height);
        using var ink=new SolidBrush(Color.FromArgb(225,244,232));using var title=UiFonts.Create(10,FontStyle.Bold);
        g.DrawString("노선 찾는 중 · 경사율 10% 고정",title,ink,new RectangleF(23,top+7,width-18,title.Height+5));
        string body=compact?$"{SearchSeconds:F1}초 · 검토 {frame.Expanded:N0}":
            $"{frame.Phase}\n격자 {frame.GridStep:0.###}m · 시도 {frame.Attempt}/12 · 확보 {Candidates.Count}/{frame.Target}\n경과 {SearchSeconds:F1}초 · 검토 {frame.Expanded:N0} · 대기 {frame.Frontier:N0}\n청록: 최근 탐색 표본 · 노란 원: 현재 위치 (노선 아님)";
        g.DrawString(body,Font,ink,new RectangleF(23,top+title.Height+12,width-18,height-title.Height-20));
        using var track=new SolidBrush(Color.FromArgb(50,90,70));using var moving=new SolidBrush(Color.FromArgb(130,215,165));
        g.FillRectangle(track,23,top+height-6,width-18,3);
        float span=width-18,segment=span*.2f,offset=(float)((SearchSeconds*.5)%1)*(span-segment);
        g.FillRectangle(moving,23+offset,top+height-6,segment,3);
    }
}
