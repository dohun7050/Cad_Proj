using System.Diagnostics;
using ForestRoad.Cad;
namespace OkseongRoad.Terrain;

public sealed record SearchVisualFrame(string Phase,int Attempt,int Target,int Candidates,double GridStep,
    double Seconds,long Expanded,long EdgeChecks,long CacheHits,int Frontier,CadPoint? Current,CadPoint[] Visited);

internal sealed class SearchTrace(IProgress<SearchVisualFrame>? progress,int target)
{
    readonly Stopwatch clock=Stopwatch.StartNew();
    readonly List<CadPoint> pending=[];
    double lastReport;string phase="탐색 준비";int attempt,candidates,frontier;double step;
    long expanded,edges,hits;CadPoint? current;
    public void Phase(string value,double gridStep=0,int searchAttempt=0,int accepted=0)
    {phase=value;if(gridStep>0)step=gridStep;if(searchAttempt>0)attempt=searchAttempt;candidates=accepted;Publish(true);}
    public void Expand(CadPoint point,int queue)
    {
        expanded++;frontier=queue;current=point;
        if(progress is not null&&expanded%4==0&&pending.Count<384)pending.Add(point);
        Publish(false);
    }
    public void Edge(bool cached){if(cached)hits++;else edges++;}
    public void Publish(bool force)
    {
        if(progress is null)return;double seconds=clock.Elapsed.TotalSeconds;
        if(!force&&seconds-lastReport<.25)return;
        progress.Report(new(phase,attempt,target,candidates,step,seconds,expanded,edges,hits,frontier,current,pending.ToArray()));
        pending.Clear();lastReport=seconds;
    }
}
