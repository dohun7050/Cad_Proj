using ForestRoad.Cad;
namespace OkseongRoad.Terrain;

public static partial class RoutePlanner
{
    // Crop on original grid lines: elevations and bilinear interpolation stay identical.
    // This bounds graph search, penalty arrays and refinement, not the displayed DEM.
    public static TerrainGrid LimitSearchArea(TerrainGrid source,CadPoint start,CadPoint end,CancellationToken ct=default)
    {
        ct.ThrowIfCancellationRequested();
        if(!double.IsFinite(start.X)||!double.IsFinite(start.Y)||!double.IsFinite(end.X)||!double.IsFinite(end.Y))throw new ArgumentException("시작점·종점 좌표가 유효하지 않습니다.");
        if(source.At(start.X,start.Y) is null||source.At(end.X,end.Y) is null)throw new InvalidOperationException("시작점·종점이 유효한 지형 범위 안에 있어야 합니다.");
        double margin=Math.Max(source.Step*8,Math.Clamp(Distance(start,end)*.25,50,500));
        int left=Math.Clamp((int)Math.Floor((Math.Min(start.X,end.X)-margin-source.X)/source.Step),0,source.Width-2);
        int bottom=Math.Clamp((int)Math.Floor((Math.Min(start.Y,end.Y)-margin-source.Y)/source.Step),0,source.Height-2);
        int right=Math.Clamp((int)Math.Ceiling((Math.Max(start.X,end.X)+margin-source.X)/source.Step),left+1,source.Width-1);
        int top=Math.Clamp((int)Math.Ceiling((Math.Max(start.Y,end.Y)+margin-source.Y)/source.Step),bottom+1,source.Height-1);
        if(left==0&&bottom==0&&right==source.Width-1&&top==source.Height-1)return source;
        int width=right-left+1,height=top-bottom+1;
        var values=new double[width*height];
        for(int row=0;row<height;row++){ct.ThrowIfCancellationRequested();Array.Copy(source.Values,(bottom+row)*source.Width+left,values,row*width,width);}
        return new(source.X+left*source.Step,source.Y+bottom*source.Step,source.Step,width,height,values);
    }
}
