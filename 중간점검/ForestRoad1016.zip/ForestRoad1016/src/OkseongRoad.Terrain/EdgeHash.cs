namespace OkseongRoad.Terrain;

// Packed nearby node pairs collide under Int64's default low-word XOR high-word hash.
internal sealed class EdgeHash:IEqualityComparer<long>
{
    public static readonly EdgeHash Instance=new();
    public bool Equals(long a,long b)=>a==b;
    public int GetHashCode(long key)=>HashCode.Combine((int)(key>>32),(int)key);
}
