using ForestRoad.Cad;
namespace OkseongRoad.Terrain;

// Exact segment-distance test with a spatial broad phase; no route simplification.
internal sealed class CorridorIndex
{
    readonly Dictionary<(long X,long Y),List<(CadPoint A,CadPoint B)>> buckets=[];
    readonly List<(CadPoint A,CadPoint B)> wide=[];
    readonly double tolerance,cell;
    readonly bool subtractionFirst;
    public CorridorIndex(List<CadPoint> points,double tolerance,CancellationToken ct=default,bool subtractionFirst=false)
    {
        this.tolerance=tolerance;cell=Math.Max(1,tolerance);this.subtractionFirst=subtractionFirst;
        for(int i=1;i<points.Count;i++)
        {
            ct.ThrowIfCancellationRequested();var a=points[i-1];var b=points[i];
            double padding=tolerance+Math.Max(1e-9,Math.Max(Math.Max(Math.Abs(a.X),Math.Abs(b.X)),Math.Max(Math.Abs(a.Y),Math.Abs(b.Y)))*1e-12);
            long x0=Key(Math.Min(a.X,b.X)-padding),x1=Key(Math.Max(a.X,b.X)+padding);
            long y0=Key(Math.Min(a.Y,b.Y)-padding),y1=Key(Math.Max(a.Y,b.Y)+padding);
            if((double)(x1-x0+1)*(y1-y0+1)>4096){wide.Add((a,b));continue;}
            for(long y=y0;y<=y1;y++)for(long x=x0;x<=x1;x++)
            {var key=(x,y);if(!buckets.TryGetValue(key,out var list))buckets[key]=list=[];list.Add((a,b));}
        }
    }
    long Key(double v)=>(long)Math.Floor(v/cell);
    public bool Near(double x,double y)
    {
        if(buckets.TryGetValue((Key(x),Key(y)),out var list))foreach(var segment in list)if(Near(segment,x,y))return true;
        foreach(var segment in wide)if(Near(segment,x,y))return true;
        return false;
    }
    bool Near((CadPoint A,CadPoint B) s,double x,double y)
    {
        double dx=s.B.X-s.A.X,dy=s.B.Y-s.A.Y,den=dx*dx+dy*dy;
        double f=den==0?0:Math.Clamp(((x-s.A.X)*dx+(y-s.A.Y)*dy)/den,0,1);
        double px=subtractionFirst?x-s.A.X-f*dx:x-(s.A.X+f*dx);
        double py=subtractionFirst?y-s.A.Y-f*dy:y-(s.A.Y+f*dy);
        return (subtractionFirst?Math.Sqrt(Math.Pow(px,2)+Math.Pow(py,2)):Math.Sqrt(px*px+py*py))<=tolerance;
    }
}
