using ForestRoad.Cad;
namespace OkseongRoad.Terrain;
public static partial class RoadGeometry
{
    // Bounded coordinate descent changes the actual centerline, not its display.
    // Every move must improve length/turn costs and keep both terrain edges valid.
    static void RelaxBends(TerrainGrid grid,List<CadPoint> points,double angle,CancellationToken ct)
    {
        double weight=Math.Max(30,grid.Step*4);
        double Cost(int i,CadPoint candidate)
        {
            var a=points[i-1];var c=points[i+1];
            double cost=RoutePlanner.Distance(a,candidate)+RoutePlanner.Distance(candidate,c);
            double Penalty(CadPoint u,CadPoint v,CadPoint w){double t=Turn(u,v,w);return weight*t*t*(1+8*Math.Pow(t/Math.PI,4));}
            cost+=Penalty(a,candidate,c);
            if(i>1)cost+=Penalty(points[i-2],a,candidate);
            if(i+2<points.Count)cost+=Penalty(candidate,c,points[i+2]);
            return cost;
        }
        for(int pass=0;pass<4;pass++)
        {
            bool changed=false;
            for(int j=1;j<points.Count-1;j++)
            {
                ct.ThrowIfCancellationRequested();int i=pass%2==0?j:points.Count-1-j;
                var a=points[i-1];var b=points[i];var c=points[i+1];var best=b;double score=Cost(i,b);
                void Try(double x,double y)
                {
                    ct.ThrowIfCancellationRequested();
                    var p=grid.At(x,y);if(p is null||RoutePlanner.Distance(a,p)<.1||RoutePlanner.Distance(p,c)<.1)return;
                    double next=Cost(i,p);if(next>=score-1e-6)return;
                    if(!RoutePlanner.Allowed(grid,a,p,angle,out _)||!RoutePlanner.Allowed(grid,p,c,angle,out _))return;
                    score=next;best=p;
                }
                foreach(double fraction in new[]{.5,.25,.125})Try(b.X+((a.X+c.X)/2-b.X)*fraction,b.Y+((a.Y+c.Y)/2-b.Y)*fraction);
                foreach(double scale in new[]{2.0,1.0,.5})for(int d=0;d<8;d++)
                {double theta=d*Math.PI/4;Try(b.X+Math.Cos(theta)*grid.Step*scale,b.Y+Math.Sin(theta)*grid.Step*scale);}
                if(!ReferenceEquals(best,b)){points[i]=best;changed=true;}
            }
            if(!changed)break;
        }
    }
}
