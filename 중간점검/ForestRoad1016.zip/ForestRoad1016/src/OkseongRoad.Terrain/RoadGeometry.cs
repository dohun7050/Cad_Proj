using ForestRoad.Cad;
namespace OkseongRoad.Terrain;

public record RouteQualityOptions(double MinimumRadius=0,double TurnWeight=0);
public record RouteMetrics(double AverageAngle,int BendCount,double MinimumRadius);
public static partial class RoadGeometry
{
    public static double Turn(CadPoint a,CadPoint b,CadPoint c)
    {
        double u=RoutePlanner.Distance(a,b),v=RoutePlanner.Distance(b,c);
        if(u*v<1e-10)return 0;
        return Math.Acos(Math.Clamp(((b.X-a.X)*(c.X-b.X)+(b.Y-a.Y)*(c.Y-b.Y))/(u*v),-1,1));
    }
    // Automatic mode (0) treats radius as a preference rather than rejecting a whole
    // feasible corridor. A positive UI value is still a hard minimum radius.
    public static RoadRoute? SmoothForestRoad(TerrainGrid grid,RoadRoute raw,double angle,double minimumRadius=0,CancellationToken ct=default,double stationSpacing=20)
    {
        RoutePlanner.RequireTenPercent(angle);
        if(!double.IsFinite(minimumRadius)||minimumRadius<0)throw new ArgumentOutOfRangeException(nameof(minimumRadius));
        ct.ThrowIfCancellationRequested();
        var simplified=Smooth(grid,raw,angle,0,ct)??raw;
        var bends=new List<CadPoint>();
        foreach(var p in simplified.Vertices)
        {
            ct.ThrowIfCancellationRequested();
            while(bends.Count>=2)
            {
                var a=bends[^2];var b=bends[^1];
                double ux=b.X-a.X,uy=b.Y-a.Y,vx=p.X-b.X,vy=p.Y-b.Y;
                if(ux*vx+uy*vy<0||Math.Abs(ux*vy-uy*vx)>1e-8*Math.Max(1,RoutePlanner.Distance(a,b)*RoutePlanner.Distance(b,p)))break;
                bends.RemoveAt(bends.Count-1);
            }
            bends.Add(p);
        }
        if(bends.Count<2)return null;
        if(minimumRadius==0)RelaxBends(grid,bends,angle,ct);
        var points=new List<CadPoint>{bends[0]};
        for(int i=1;i<bends.Count-1;i++)
        {
            ct.ThrowIfCancellationRequested();
            var a=bends[i-1];var b=bends[i];var c=bends[i+1];
            double turn=Turn(a,b,c),l=RoutePlanner.Distance(a,b),m=RoutePlanner.Distance(b,c);
            if(turn<1e-6){points.Add(b);continue;}
            double ux=(b.X-a.X)/l,uy=(b.Y-a.Y)/l,vx=(c.X-b.X)/m,vy=(c.Y-b.Y)/m;
            double sign=Math.Sign(ux*vy-uy*vx);
            // Reserve half of every edge for its neighboring corner, avoiding
            // overlapping fillets when the route contains short grid edges.
            double capacity=.45*Math.Min(l,m)/Math.Tan(turn/2);
            double lower=minimumRadius>0?minimumRadius:Math.Min(1,capacity);
            List<CadPoint>? curve=null;
            if(sign!=0&&turn<Math.PI-.001&&capacity>=lower&&lower>1e-6)
            {
                double preferred=Math.Min(Math.Max(30,minimumRadius),capacity);
                for(int attempt=0;attempt<12;attempt++)
                {
                    ct.ThrowIfCancellationRequested();
                    double radius=Math.Max(lower,preferred*Math.Pow(.5,attempt));
                    double tangent=radius*Math.Tan(turn/2),x=b.X-ux*tangent,y=b.Y-uy*tangent;
                    double cx=x-sign*uy*radius,cy=y+sign*ux*radius,theta=Math.Atan2(y-cy,x-cx);
                    int samples=Math.Max(2,(int)Math.Ceiling(radius*turn/Math.Min(.5,grid.Step/4)));
                    var trial=new List<CadPoint>();var previous=a;bool valid=true;
                    for(int k=0;k<=samples;k++)
                    {
                        ct.ThrowIfCancellationRequested();double t=theta+sign*turn*k/samples;
                        var p=grid.At(cx+radius*Math.Cos(t),cy+radius*Math.Sin(t));
                        if(p is null||!RoutePlanner.Allowed(grid,previous,p,angle,out _)){valid=false;break;}
                        trial.Add(p);previous=p;
                    }
                    if(valid&&RoutePlanner.Allowed(grid,previous,c,angle,out _)){curve=trial;break;}
                    if(radius<=lower+1e-9)break;
                }
            }
            if(curve is null)
            {
                if(minimumRadius>0)return null;
                // In automatic mode preserve only this terrain-constrained corner;
                // other corners can still be rounded. Never cross a void or relax grade.
                points.Add(b);
            }
            else points.AddRange(curve);
        }
        points.Add(bends[^1]);
        var result=Create(grid,points,angle,ct,stationSpacing);
        if(result is not null&&minimumRadius>0&&Metrics(result).MinimumRadius<minimumRadius*(1-1e-4))return null;
        return result;
    }
    public static RoadRoute? Smooth(TerrainGrid grid,RoadRoute raw,double angle,double radius,CancellationToken ct=default)
    {
        RoutePlanner.RequireTenPercent(angle);
        if(!double.IsFinite(radius)||radius<0)throw new ArgumentOutOfRangeException(nameof(radius));
        // Ignore collinear display subdivisions during corridor simplification; Create restores stations.
        var bends=new List<CadPoint>{raw.Vertices[0]};
        for(int i=1;i<raw.Vertices.Count-1;i++)
        {
            ct.ThrowIfCancellationRequested();var a=bends[^1];var b=raw.Vertices[i];var c=raw.Vertices[i+1];
            double cross=(b.X-a.X)*(c.Y-b.Y)-(b.Y-a.Y)*(c.X-b.X);
            double dot=(b.X-a.X)*(c.X-b.X)+(b.Y-a.Y)*(c.Y-b.Y);
            if(Math.Abs(cross)>1e-8*Math.Max(1,RoutePlanner.Distance(a,b)*RoutePlanner.Distance(b,c))||dot<0)bends.Add(b);
        }
        bends.Add(raw.Vertices[^1]);raw=raw with{Vertices=bends};
        // Remove unnecessary grid zigzags only when the complete shortcut is valid.
        var reduced=new List<CadPoint>{raw.Vertices[0]};int at=0;
        while(at<raw.Vertices.Count-1)
        {
            ct.ThrowIfCancellationRequested();int next=at+1;
            for(int j=Math.Min(raw.Vertices.Count-1,at+64);j>at+1;j--)
            {
                // Permit local corridor cleanup across several cells. Large necessary hillside
                // switchbacks remain protected by the full-segment grade and NoData checks.
                if(RoutePlanner.Allowed(grid,raw.Vertices[at],raw.Vertices[j],angle,out _)){next=j;break;}
            }
            reduced.Add(raw.Vertices[next]);at=next;
        }
        var tangent=new double[reduced.Count];
        for(int i=1;i<reduced.Count-1;i++)
        {
            double turn=Turn(reduced[i-1],reduced[i],reduced[i+1]);if(turn>Math.PI-0.001)return null;
            tangent[i]=radius*Math.Tan(turn/2);
        }
        for(int i=1;i<reduced.Count;i++)if(tangent[i-1]+tangent[i]>RoutePlanner.Distance(reduced[i-1],reduced[i])-1e-6)return null;
        var points=new List<CadPoint>{reduced[0]};
        for(int i=1;i<reduced.Count-1;i++)
        {
            ct.ThrowIfCancellationRequested();var a=reduced[i-1];var b=reduced[i];var c=reduced[i+1];double turn=Turn(a,b,c);
            if(radius==0||turn<1e-6){points.Add(b);continue;}
            double l=RoutePlanner.Distance(a,b),m=RoutePlanner.Distance(b,c),ux=(b.X-a.X)/l,uy=(b.Y-a.Y)/l,vx=(c.X-b.X)/m,vy=(c.Y-b.Y)/m;
            double sign=Math.Sign(ux*vy-uy*vx);if(sign==0){points.Add(b);continue;}
            double x=b.X-ux*tangent[i],y=b.Y-uy*tangent[i];
            double cx=x-sign*uy*radius,cy=y+sign*ux*radius,theta=Math.Atan2(y-cy,x-cx);
            int samples=Math.Max(2,(int)Math.Ceiling(radius*turn/Math.Min(0.5,grid.Step/4)));
            for(int k=0;k<=samples;k++)
            {
                double t=theta+sign*turn*k/samples;var p=grid.At(cx+radius*Math.Cos(t),cy+radius*Math.Sin(t));if(p is null)return null;points.Add(p);
            }
        }
        points.Add(reduced[^1]);
        var result=Create(grid,points,angle,ct);if(result is null)return null;
        // Circumcircle checks also catch unintended tight corners between neighboring fillets.
        if(radius>0&&Metrics(result).MinimumRadius<radius*(1-1e-4))return null;
        return result;
    }
    public static List<Station> Profile(TerrainGrid grid,RoadRoute route,CancellationToken ct=default)
    {
        var result=new List<Station>();double chainage=0;
        foreach(var (a,b) in route.Vertices.Zip(route.Vertices.Skip(1)))
        {
            ct.ThrowIfCancellationRequested();
            double length=RoutePlanner.Distance(a,b);int count=Math.Max(1,(int)Math.Ceiling(length/Math.Max(0.5,Math.Min(1,grid.Step/4))));
            for(int i=0;i<count;i++){double t=(double)i/count;var p=grid.At(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t)!;result.Add(new(chainage+length*t,p.X,p.Y,p.Z));}chainage+=length;
        }
        var end=route.Vertices[^1];result.Add(new(chainage,end.X,end.Y,end.Z));return result;
    }
    public static RoadRoute? Create(TerrainGrid grid,List<CadPoint> input,double angle,CancellationToken ct=default,double stationSpacing=20)
    {
        RoutePlanner.RequireTenPercent(angle);
        if(!double.IsFinite(stationSpacing)||stationSpacing<=0)throw new ArgumentOutOfRangeException(nameof(stationSpacing));
        var raw=new List<CadPoint>();
        foreach(var point in input){ct.ThrowIfCancellationRequested();var p=grid.At(point.X,point.Y);if(p is null)return null;if(raw.Count==0||RoutePlanner.Distance(raw[^1],p)>1e-7)raw.Add(p);}
        if(raw.Count<2)return null;
        double length=0,peak=0,nextStation=0;
        var points=new List<CadPoint>();var stations=new List<Station>();
        foreach(var (a,b) in raw.Zip(raw.Skip(1)))
        {
            ct.ThrowIfCancellationRequested();if(!RoutePlanner.Allowed(grid,a,b,angle,out double local))return null;
            peak=Math.Max(peak,local);double distance=RoutePlanner.Distance(a,b);
            var fractions=new SortedSet<double>{0,1};
            // Drape geometry on the DEM and retain both original bends and 20 m station points.
            int pieces=Math.Max(1,(int)Math.Ceiling(distance/Math.Min(5,grid.Step/2)));
            for(int i=1;i<pieces;i++)fractions.Add((double)i/pieces);
            while(nextStation<length+distance-1e-8)
            {
                ct.ThrowIfCancellationRequested();double t=Math.Clamp((nextStation-length)/distance,0,1);
                var p=grid.At(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t);if(p is null)return null;
                stations.Add(new(nextStation,p.X,p.Y,p.Z));fractions.Add(t);nextStation+=stationSpacing;
            }
            foreach(double t in fractions)
            {
                ct.ThrowIfCancellationRequested();var p=grid.At(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t);if(p is null)return null;
                if(points.Count==0||RoutePlanner.Distance(points[^1],p)>1e-7)points.Add(p);
            }
            length+=distance;
        }
        var end=raw[^1];stations.Add(new(length,end.X,end.Y,end.Z));return new(points,stations,length,peak);
    }
    public static RouteMetrics Metrics(RoadRoute route)
    {
        double average=0,radius=double.PositiveInfinity;int bends=0;double accumulated=0;int priorSign=0;
        foreach(var (a,b) in route.Vertices.Zip(route.Vertices.Skip(1)))
        {double d=RoutePlanner.Distance(a,b);if(d>1e-8)average+=Math.Atan(Math.Abs(b.Z-a.Z)/d)*180/Math.PI*d;}
        // Station insertion subdivides arc chords. Those collinear subdivisions are
        // not new alignment vertices and would falsely shrink the measured radius.
        var alignment=new List<CadPoint>();
        foreach(var p in route.Vertices)
        {
            while(alignment.Count>=2)
            {
                var a=alignment[^2];var b=alignment[^1];
                double ux=b.X-a.X,uy=b.Y-a.Y,vx=p.X-b.X,vy=p.Y-b.Y;
                if(ux*vx+uy*vy<0||Math.Abs(ux*vy-uy*vx)>1e-8*Math.Max(1,RoutePlanner.Distance(a,b)*RoutePlanner.Distance(b,p)))break;
                alignment.RemoveAt(alignment.Count-1);
            }
            alignment.Add(p);
        }
        for(int i=1;i<alignment.Count-1;i++)
        {
            var a=alignment[i-1];var b=alignment[i];var c=alignment[i+1];double cross=(b.X-a.X)*(c.Y-b.Y)-(b.Y-a.Y)*(c.X-b.X),turn=Turn(a,b,c);int sign=Math.Abs(cross)<1e-8?0:Math.Sign(cross);
            if(sign==0||sign!=priorSign){if(accumulated>Math.PI/36)bends++;accumulated=0;}accumulated+=turn;priorSign=sign;
            if(Math.Abs(cross)>1e-8)radius=Math.Min(radius,RoutePlanner.Distance(a,b)*RoutePlanner.Distance(b,c)*RoutePlanner.Distance(a,c)/(2*Math.Abs(cross)));
        }
        if(accumulated>Math.PI/36)bends++;
        return new(average/Math.Max(route.Length,1e-8),bends,radius);
    }
    public static double Overlap(RoadRoute a,RoadRoute b,double tolerance,CancellationToken ct=default)
    {
        double shared=0,total=0;var index=new CorridorIndex(b.Vertices,tolerance,ct,subtractionFirst:true);
        foreach(var (p,q) in a.Vertices.Zip(a.Vertices.Skip(1)))
        {
            ct.ThrowIfCancellationRequested();
            double length=RoutePlanner.Distance(p,q);int pieces=Math.Max(1,(int)Math.Ceiling(length/Math.Max(1,tolerance/2)));
            for(int i=0;i<pieces;i++)
            {
                double t=(i+0.5)/pieces,x=p.X+(q.X-p.X)*t,y=p.Y+(q.Y-p.Y)*t;bool near=false;
                near=index.Near(x,y);
                total+=length/pieces;if(near)shared+=length/pieces;
            }
        }
        return 100*shared/Math.Max(total,1e-9);
    }
}
