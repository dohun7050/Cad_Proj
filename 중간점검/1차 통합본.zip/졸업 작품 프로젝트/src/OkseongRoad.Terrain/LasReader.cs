﻿using System.Text;
using System.Buffers.Binary;
using System.Text.Json.Serialization;
using ForestRoad.Cad;
namespace OkseongRoad.Terrain;

public readonly record struct LasPoint
{
    readonly double x,y,z;
    readonly int color;
    public CadPoint Position => new(x,y,z);
    public byte Classification {get;}
    public bool Withheld {get;}
    public int? Argb => color==0?null:color;
    public LasPoint(double x,double y,double z,byte classification,bool withheld,int? argb)
    {this.x=x;this.y=y;this.z=z;Classification=classification;Withheld=withheld;color=argb??0;}
}
public record LasReadProgress(long Read,long Total);
public record LasReadOptions(int InMemoryPointLimit=20_000_000,int PreviewPointLimit=100_000,int GroundCellLimit=1_000_000);
public record LasCloud(string Source, string Version, int Format, List<LasPoint> Points, string CoordinateReference)
{
    [JsonIgnore] public IEnumerable<CadPoint> Ground => IsReduced?GroundSamples:Points.Where(p => p.Classification == 2 && !p.Withheld).Select(p => p.Position);
    public bool HasRgb {get;init;}
    public bool RgbIs8Bit {get;init;}
    public long GroundCount {get;init;}
    public long VisiblePointCount {get;init;}
    public long TotalPointCount {get;init;}
    public bool IsReduced {get;init;}
    public double GroundAggregationStep {get;init;}
    public List<CadPoint> GroundSamples {get;init;}=[];
    public CadBounds Bounds {get;init;} = new(0,0,0,0,0,0);
}

public static class LasReader
{
    public const int MaximumInMemoryPointCount=20_000_000;
    // LAS 1.0-1.4, uncompressed formats 0-10. Extra bytes are skipped by record length.
    public static LasCloud Read(string path, CancellationToken ct=default,IProgress<LasReadProgress>? progress=null,LasReadOptions? options=null)
    {
        options??=new LasReadOptions();
        if(options.InMemoryPointLimit<0||options.PreviewPointLimit<1||options.GroundCellLimit<4)throw new ArgumentException("LAS 메모리 설정을 확인하세요.");
        ct.ThrowIfCancellationRequested();
        using var stream = new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read,1024*1024,FileOptions.SequentialScan);
        using var r = new BinaryReader(stream);
        if (stream.Length < 227 || Encoding.ASCII.GetString(r.ReadBytes(4)) != "LASF") throw new InvalidDataException("LAS 헤더가 올바르지 않습니다.");
        stream.Position = 24; int major = r.ReadByte(), minor = r.ReadByte();
        if (major != 1 || minor > 4) throw new InvalidDataException("LAS 1.0~1.4만 지원합니다.");
        stream.Position = 94; int header = r.ReadUInt16(); long offset = r.ReadUInt32(); uint vlrs = r.ReadUInt32();
        byte rawFormat = r.ReadByte(); int format = rawFormat & 63; int length = r.ReadUInt16(); ulong count = r.ReadUInt32();
        if ((rawFormat & 192) != 0) throw new InvalidDataException("압축 LAZ는 지원하지 않습니다. 비압축 LAS로 변환해 주세요.");
        int[] minimum = [20, 28, 26, 34, 57, 63, 30, 36, 38, 59, 67];
        if (format > 10 || length < minimum[format] || (format >= 6 && minor < 4)) throw new InvalidDataException("LAS 점 형식 또는 레코드 길이가 올바르지 않습니다.");
        stream.Position = 131;
        var scale = new[] { r.ReadDouble(), r.ReadDouble(), r.ReadDouble() };
        var origin = new[] { r.ReadDouble(), r.ReadDouble(), r.ReadDouble() };
        if (scale.Any(v => !double.IsFinite(v) || v <= 0) || origin.Any(v => !double.IsFinite(v))) throw new InvalidDataException("LAS 좌표 배율/오프셋이 잘못되었습니다.");
        if (minor == 4)
        {
            if (header < 375 || stream.Length < 375) throw new InvalidDataException("LAS 1.4 헤더가 잘렸습니다.");
            stream.Position = 247; ulong extended = r.ReadUInt64(); if (extended > 0) count = extended;
        }
        if (header < 227 || offset < header || offset > stream.Length || count > (ulong)((stream.Length-offset)/length)) throw new InvalidDataException("LAS 점 데이터가 잘렸거나 헤더가 잘못되었습니다.");
        if (count == 0) throw new InvalidDataException("LAS에 점이 없습니다.");
        bool reduced=count>(ulong)options.InMemoryPointLimit;
        string crs=LasMetadata.Read(path,ct).CoordinateReference;
        ushort maximumColor=0;
        ulong stride=reduced?Math.Max(1,(count+(ulong)options.PreviewPointLimit-1)/(ulong)options.PreviewPointLimit):1;
        var points = new List<LasPoint>(reduced?options.PreviewPointLimit:(int)count);
        var groundCells=new Dictionary<(long X,long Y),(double X,double Y,double Z,long Count)>();
        double cellSize=1;long groundCount=0,visibleCount=0;
        int recordsPerBatch=Math.Max(1,4*1024*1024/length);
        var buffer=new byte[recordsPerBatch*length];
        double minX=double.PositiveInfinity,minY=minX,minZ=minX,maxX=double.NegativeInfinity,maxY=maxX,maxZ=maxX;
        int rgbOffset = format switch { 2 => 20, 3 or 5 => 28, 7 or 8 or 10 => 30, _ => -1 };
        stream.Position=offset;progress?.Report(new LasReadProgress(0,(long)count));
        for (ulong first = 0; first < count;)
        {
            ct.ThrowIfCancellationRequested();
            int batch=(int)Math.Min((ulong)recordsPerBatch,count-first);
            stream.ReadExactly(buffer.AsSpan(0,batch*length));
            for(int i=0;i<batch;i++)
            {
                var record=buffer.AsSpan(i*length,length);
                double x=BinaryPrimitives.ReadInt32LittleEndian(record)*scale[0]+origin[0],
                    y=BinaryPrimitives.ReadInt32LittleEndian(record[4..])*scale[1]+origin[1],
                    z=BinaryPrimitives.ReadInt32LittleEndian(record[8..])*scale[2]+origin[2];
                if(!double.IsFinite(x)||!double.IsFinite(y)||!double.IsFinite(z))throw new InvalidDataException("LAS에 유한하지 않은 좌표가 있습니다.");
                byte classification=record[format<6?15:16];
                bool withheld=format<6?(classification&128)!=0:(record[15]&4)!=0;
                if(format<6)classification&=31;
                if(!withheld)visibleCount++;
                int? argb=null;
                if(rgbOffset>=0)
                {
                    int red=BinaryPrimitives.ReadUInt16LittleEndian(record[rgbOffset..]),green=BinaryPrimitives.ReadUInt16LittleEndian(record[(rgbOffset+2)..]),blue=BinaryPrimitives.ReadUInt16LittleEndian(record[(rgbOffset+4)..]);
                    maximumColor=(ushort)Math.Max(maximumColor,Math.Max(red,Math.Max(green,blue)));
                    argb=red<=255&&green<=255&&blue<=255?unchecked((int)0xfe000000)|red<<16|green<<8|blue:unchecked((int)0xff000000)|(red/257)<<16|(green/257)<<8|blue/257;
                }
                if(!reduced||(first+(ulong)i)%stride==0)points.Add(new LasPoint(x,y,z,classification,withheld,argb));
                if(classification==2&&!withheld)
                {
                    groundCount++;
                    if(reduced)
                    {
                        var key=((long)Math.Floor(x/cellSize),(long)Math.Floor(y/cellSize));
                        var a=groundCells.GetValueOrDefault(key);groundCells[key]=(a.X+x,a.Y+y,a.Z+z,a.Count+1);
                        while(groundCells.Count>options.GroundCellLimit)
                        {
                            ct.ThrowIfCancellationRequested();cellSize*=2;
                            var compact=new Dictionary<(long,long),(double X,double Y,double Z,long Count)>();
                            foreach(var item in groundCells)
                            {
                                var parent=((long)Math.Floor(item.Key.X/2.0),(long)Math.Floor(item.Key.Y/2.0));
                                var b=compact.GetValueOrDefault(parent);var v=item.Value;compact[parent]=(b.X+v.X,b.Y+v.Y,b.Z+v.Z,b.Count+v.Count);
                            }
                            groundCells=compact;
                        }
                    }
                }
                minX=Math.Min(minX,x);minY=Math.Min(minY,y);minZ=Math.Min(minZ,z);maxX=Math.Max(maxX,x);maxY=Math.Max(maxY,y);maxZ=Math.Max(maxZ,z);
            }
            first+=(ulong)batch;progress?.Report(new LasReadProgress((long)first,(long)count));
        }
        ct.ThrowIfCancellationRequested();
        bool rgb8=rgbOffset>=0&&maximumColor<=255;
        for(int i=0;i<points.Count;i++)
        {
            if(i%65536==0)ct.ThrowIfCancellationRequested();var point=points[i];if(point.Argb is int color&&(uint)color>>24==254){var p=point.Position;points[i]=new LasPoint(p.X,p.Y,p.Z,point.Classification,point.Withheld,rgb8?unchecked((int)0xff000000)|(color&0xffffff):unchecked((int)0xff000000));}
        }
        var groundSamples=reduced?groundCells.Values.Select(a=>new CadPoint(a.X/a.Count,a.Y/a.Count,a.Z/a.Count)).ToList():[];
        return new LasCloud(Path.GetFullPath(path), $"{major}.{minor}", format, points, crs)
        {HasRgb=rgbOffset>=0,RgbIs8Bit=rgb8,Bounds=new CadBounds(minX,minY,maxX,maxY,minZ,maxZ),TotalPointCount=(long)count,VisiblePointCount=visibleCount,GroundCount=groundCount,
         IsReduced=reduced,GroundAggregationStep=reduced?cellSize:0,GroundSamples=groundSamples};
    }
}
