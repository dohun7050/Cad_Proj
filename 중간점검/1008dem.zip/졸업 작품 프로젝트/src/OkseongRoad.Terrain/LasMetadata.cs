using System.Text;
namespace OkseongRoad.Terrain;

public record LasMetadata(string Version,int Format,long Count,long DataOffset,int RecordLength,
    double[] Scale,double[] Origin,string CoordinateReference,int RgbOffset)
{
    public static LasMetadata Read(string path,CancellationToken ct=default)
    {
        using var stream=File.OpenRead(path);using var r=new BinaryReader(stream);
        if(stream.Length<227||Encoding.ASCII.GetString(r.ReadBytes(4))!="LASF")throw new InvalidDataException("LAS 헤더가 올바르지 않습니다.");
        stream.Position=24;int major=r.ReadByte(),minor=r.ReadByte();if(major!=1||minor>4)throw new InvalidDataException("비압축 LAS 1.0~1.4를 사용하세요.");
        stream.Position=94;int header=r.ReadUInt16();long offset=r.ReadUInt32();uint vlrs=r.ReadUInt32();int format=r.ReadByte(),record=r.ReadUInt16();ulong count=r.ReadUInt32();
        int[] minimum=[20,28,26,34,57,63,30,36,38,59,67];
        if(format>10||record<minimum[format]||header<227||offset<header||offset>stream.Length||(format>=6&&minor<4))throw new InvalidDataException("압축 LAZ 또는 손상된 LAS 헤더입니다.");
        stream.Position=131;double[] scale=[r.ReadDouble(),r.ReadDouble(),r.ReadDouble()],origin=[r.ReadDouble(),r.ReadDouble(),r.ReadDouble()];
        if(scale.Any(v=>!double.IsFinite(v)||v<=0)||origin.Any(v=>!double.IsFinite(v)))throw new InvalidDataException("LAS 좌표 배율을 확인하세요.");
        ulong evlrOffset=0;uint evlrCount=0;
        if(minor==4){if(header<375||stream.Length<375)throw new InvalidDataException("LAS 1.4 헤더가 잘렸습니다.");stream.Position=235;evlrOffset=r.ReadUInt64();evlrCount=r.ReadUInt32();ulong extended=r.ReadUInt64();if(extended>0)count=extended;}
        if(count==0||count>(ulong)((stream.Length-offset)/record)||count>long.MaxValue)throw new InvalidDataException("LAS 점 데이터가 부족합니다.");
        string? wkt=null;int? projected=null,geographic=null;
        void Parse(string user,int id,byte[] bytes)
        {
            if(user!="LASF_Projection")return;
            if(id==2112)wkt=Encoding.UTF8.GetString(bytes).TrimEnd('\0');
            if(id!=34735||bytes.Length<8)return;int keys=BitConverter.ToUInt16(bytes,6);
            if(8+keys*8>bytes.Length)throw new InvalidDataException("GeoTIFF 좌표계 키가 잘렸습니다.");
            for(int i=0;i<keys;i++){int p=8+i*8;int key=BitConverter.ToUInt16(bytes,p),location=BitConverter.ToUInt16(bytes,p+2),n=BitConverter.ToUInt16(bytes,p+4),value=BitConverter.ToUInt16(bytes,p+6);if(location!=0||n!=1||value==0||value==32767)continue;if(key==3072)projected=value;else if(key==2048)geographic=value;}
        }
        stream.Position=header;
        for(uint i=0;i<vlrs;i++){ct.ThrowIfCancellationRequested();if(stream.Position+54>offset)throw new InvalidDataException("VLR 헤더 손상");r.ReadUInt16();string user=Encoding.ASCII.GetString(r.ReadBytes(16)).TrimEnd('\0',' ');int id=r.ReadUInt16(),size=r.ReadUInt16();r.ReadBytes(32);if(stream.Position+size>offset)throw new InvalidDataException("VLR 길이 손상");Parse(user,id,r.ReadBytes(size));}
        if(evlrCount>0)
        {
            if(evlrOffset>long.MaxValue||(long)evlrOffset<offset+(long)count*record||evlrOffset>(ulong)stream.Length)throw new InvalidDataException("EVLR 위치 손상");stream.Position=(long)evlrOffset;
            for(uint i=0;i<evlrCount;i++){ct.ThrowIfCancellationRequested();if(stream.Position+60>stream.Length)throw new InvalidDataException("EVLR 헤더 손상");r.ReadUInt16();string user=Encoding.ASCII.GetString(r.ReadBytes(16)).TrimEnd('\0',' ');int id=r.ReadUInt16();ulong size=r.ReadUInt64();r.ReadBytes(32);if(size>(ulong)(stream.Length-stream.Position))throw new InvalidDataException("EVLR 길이 손상");if(user=="LASF_Projection"&&size<=1_048_576)Parse(user,id,r.ReadBytes((int)size));else stream.Seek((long)size,SeekOrigin.Current);}
        }
        string crs=!string.IsNullOrWhiteSpace(wkt)?"WKT 정의:\n"+wkt:projected is not null||geographic is not null?$"EPSG:{projected??geographic}":"좌표계 정보 없음 · 원본 단위/좌표계 확인 필요";
        return new($"{major}.{minor}",format,(long)count,offset,record,scale,origin,crs,format switch{2=>20,3 or 5=>28,7 or 8 or 10=>30,_=>-1});
    }
}
