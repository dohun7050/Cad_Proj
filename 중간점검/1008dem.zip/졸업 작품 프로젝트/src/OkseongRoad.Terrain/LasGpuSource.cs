using System.Buffers.Binary;
using System.Runtime.InteropServices;
namespace OkseongRoad.Terrain;

[StructLayout(LayoutKind.Sequential,Pack=1)]
public struct GpuPoint
{
    public float X,Y,Z;
    public byte R,G,B,A;
}
public sealed class LasGpuSource:IDisposable
{
    readonly FileStream stream;readonly LasMetadata metadata;readonly LasCloud cloud;readonly double cx,cy,cz;
    public long ReadCount {get;private set;}
    public long TotalCount=>metadata.Count;
    public LasGpuSource(LasCloud data)
    {
        cloud=data;metadata=LasMetadata.Read(data.Source);
        if(metadata.Count!=data.TotalPointCount)throw new InvalidDataException("LAS 원본이 변경되었습니다. 다시 여세요.");
        stream=new FileStream(data.Source,FileMode.Open,FileAccess.Read,FileShare.Read,4*1024*1024,FileOptions.SequentialScan);stream.Position=metadata.DataOffset;
        cx=(data.Bounds.MinX+data.Bounds.MaxX)/2;cy=(data.Bounds.MinY+data.Bounds.MaxY)/2;cz=(data.Bounds.MinZ+data.Bounds.MaxZ)/2;
    }
    public GpuPoint[]? Next(CancellationToken ct=default)
    {
        ct.ThrowIfCancellationRequested();if(ReadCount>=TotalCount)return null;
        int count=(int)Math.Min(262144,TotalCount-ReadCount),length=metadata.RecordLength;byte[] bytes=new byte[count*length];stream.ReadExactly(bytes);var vertices=new GpuPoint[count];int valid=0;
        for(int i=0;i<count;i++)
        {
            // Original view includes every record, including withheld points. Ground filtering belongs to DEM analysis.
            if(i%8192==0)ct.ThrowIfCancellationRequested();var r=bytes.AsSpan(i*length,length);
            double x=BinaryPrimitives.ReadInt32LittleEndian(r)*metadata.Scale[0]+metadata.Origin[0],y=BinaryPrimitives.ReadInt32LittleEndian(r[4..])*metadata.Scale[1]+metadata.Origin[1],z=BinaryPrimitives.ReadInt32LittleEndian(r[8..])*metadata.Scale[2]+metadata.Origin[2];
            if(!double.IsFinite(x)||!double.IsFinite(y)||!double.IsFinite(z))throw new InvalidDataException("유한하지 않은 점 좌표입니다.");
            byte red=160,green=195,blue=211;int divisor=cloud.RgbIs8Bit?1:257,offset=metadata.RgbOffset;
            if(offset>=0){red=(byte)(BinaryPrimitives.ReadUInt16LittleEndian(r[offset..])/divisor);green=(byte)(BinaryPrimitives.ReadUInt16LittleEndian(r[(offset+2)..])/divisor);blue=(byte)(BinaryPrimitives.ReadUInt16LittleEndian(r[(offset+4)..])/divisor);}
            vertices[valid++]=new(){X=(float)(x-cx),Y=(float)(y-cy),Z=(float)(z-cz),R=red,G=green,B=blue,A=255};
        }
        ReadCount+=count;if(valid!=count)Array.Resize(ref vertices,valid);return vertices;
    }
    public void Dispose()=>stream.Dispose();
}
