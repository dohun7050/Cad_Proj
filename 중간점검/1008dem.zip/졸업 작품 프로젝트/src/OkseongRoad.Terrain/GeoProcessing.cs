using System.Diagnostics;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ForestRoad.Cad;
namespace OkseongRoad.Terrain;
public record ImportSettings(string SourceCrs,double XYScale=1,double ZScale=1)
{
    public const string Target="EPSG:5186";
    public bool Known=>!string.IsNullOrWhiteSpace(SourceCrs);
}
public static class GeoProcessing
{
    public static string CacheDirectory {get;set;}=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"OkseongRoad","Cache");
    static string Engine=>Environment.GetEnvironmentVariable("OKSEONG_PDAL")??(File.Exists(@"C:\Program Files\ALS TLS Forest Analysis\pdal.exe")?@"C:\Program Files\ALS TLS Forest Analysis\pdal.exe":"pdal.exe");
    static string Key(string path,string settings){var f=new FileInfo(path);return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes($"v3|{f.FullName}|{f.Length}|{f.LastWriteTimeUtc.Ticks}|{settings}")));}
    public static async Task Pipeline(List<object> stages,CancellationToken ct,bool stream=false)
    {
        Directory.CreateDirectory(CacheDirectory);string json=Path.Combine(CacheDirectory,Guid.NewGuid()+".json");await File.WriteAllTextAsync(json,JsonSerializer.Serialize(new{pipeline=stages}),ct);
        try{var psi=new ProcessStartInfo(Engine){UseShellExecute=false,CreateNoWindow=true,RedirectStandardError=true,RedirectStandardOutput=true};string? engineFolder=Path.GetDirectoryName(Engine);if(!string.IsNullOrEmpty(engineFolder)){string proj=Path.Combine(engineFolder,"share","proj");if(File.Exists(Path.Combine(proj,"proj.db"))){psi.Environment["PROJ_DATA"]=proj;psi.Environment["PROJ_LIB"]=proj;}}psi.ArgumentList.Add("pipeline");psi.ArgumentList.Add(json);if(stream)psi.ArgumentList.Add("--stream");
            using var p=Process.Start(psi)??throw new InvalidOperationException("PDAL을 실행할 수 없습니다.");var error=p.StandardError.ReadToEndAsync();var output=p.StandardOutput.ReadToEndAsync();try{await p.WaitForExitAsync(ct);}catch{try{p.Kill(true);}catch{}await p.WaitForExitAsync();throw;}string message=await error;await output;if(p.ExitCode!=0)throw new InvalidOperationException("좌표/지면 처리 실패: "+message);
        }finally{File.Delete(json);}
    }
    static void Transform(List<object> stages,ImportSettings s)
    {
        if(s.XYScale!=1||s.ZScale!=1)stages.Add(new{type="filters.transformation",matrix=FormattableString.Invariant($"{s.XYScale} 0 0 0 0 {s.XYScale} 0 0 0 0 {s.ZScale} 0 0 0 0 1")});
        if(s.Known&&!s.SourceCrs.Equals(ImportSettings.Target,StringComparison.OrdinalIgnoreCase))stages.Add(new{type="filters.reprojection",in_srs=s.SourceCrs,out_srs=ImportSettings.Target});
    }
    public static async Task<string> PrepareLas(string path,ImportSettings s,CancellationToken ct)
    {
        if(s.XYScale==1&&s.ZScale==1&&(!s.Known||s.SourceCrs.Equals(ImportSettings.Target,StringComparison.OrdinalIgnoreCase)))return path;
        Directory.CreateDirectory(CacheDirectory);string output=Path.Combine(CacheDirectory,Key(path,JsonSerializer.Serialize(s))+".las");if(File.Exists(output))return output;string pending=output+".pending.las";
        try{var stages=new List<object>{new{type="readers.las",filename=path}};Transform(stages,s);stages.Add(new{type="writers.las",filename=pending,forward="all",a_srs=s.Known?ImportSettings.Target:"",scale_x=0.001,scale_y=0.001,scale_z=0.001,offset_x="auto",offset_y="auto",offset_z="auto"});await Pipeline(stages,ct,true);ct.ThrowIfCancellationRequested();File.Move(pending,output,true);return output;}finally{if(File.Exists(pending))File.Delete(pending);}
    }
    static async Task WritePoints(string path,IEnumerable<CadPoint> points,CancellationToken ct)
    {
        using var w=new StreamWriter(path,false,new UTF8Encoding(false));await w.WriteLineAsync("X,Y,Z");foreach(var p in points){ct.ThrowIfCancellationRequested();await w.WriteLineAsync(FormattableString.Invariant($"{p.X:G17},{p.Y:G17},{p.Z:G17}"));}
    }
    static List<CadPoint> ReadPoints(string path,CancellationToken ct)=>File.ReadLines(path).Skip(1).Select(line=>{ct.ThrowIfCancellationRequested();var v=line.Split(',');return new CadPoint(double.Parse(v[0],CultureInfo.InvariantCulture),double.Parse(v[1],CultureInfo.InvariantCulture),double.Parse(v[2],CultureInfo.InvariantCulture));}).ToList();
    static object Writer(string path)=>new{type="writers.text",filename=path,order="X,Y,Z",keep_unspecified=false,precision=10};
    public static async Task<CadDrawing> PrepareCad(CadDrawing drawing,ImportSettings s,CancellationToken ct)
    {
        var points=drawing.Features.SelectMany(f=>f.Points).Select(p=>new CadPoint(p.X*s.XYScale,p.Y*s.XYScale,p.Z*s.ZScale)).ToList();
        if(s.Known&&!s.SourceCrs.Equals(ImportSettings.Target,StringComparison.OrdinalIgnoreCase))
        {
            Directory.CreateDirectory(CacheDirectory);string input=Path.Combine(CacheDirectory,Guid.NewGuid()+".csv"),output=input+".out.csv";
            try{await WritePoints(input,points,ct);await Pipeline([new{type="readers.text",filename=input},new{type="filters.reprojection",in_srs=s.SourceCrs,out_srs=ImportSettings.Target},Writer(output)],ct);points=ReadPoints(output,ct);}finally{File.Delete(input);File.Delete(output);}
        }
        int index=0;var features=drawing.Features.Select(f=>f with{Points=f.Points.Select(_=>points[index++]).ToList(),TextHeight=f.TextHeight*s.XYScale}).ToList();
        if(points.Count==0)throw new InvalidOperationException("도면에 처리할 좌표가 없습니다.");
        return drawing with{Features=features,Units="Meters",Bounds=new(points.Min(p=>p.X),points.Min(p=>p.Y),points.Max(p=>p.X),points.Max(p=>p.Y),points.Min(p=>p.Z),points.Max(p=>p.Z)),Warnings=drawing.Warnings.Concat(new[]{s.Known?$"프로젝트 좌표계 {ImportSettings.Target}, XY/Z 미터 적용":"좌표계 미확인 · 원본 위치 유지 / 선택한 실제 단위로 환산"}).ToList()};
    }
    public static async Task<List<CadPoint>> AutoGround(LasCloud cloud,CancellationToken ct)
    {
        Directory.CreateDirectory(CacheDirectory);string output=Path.Combine(CacheDirectory,Key(cloud.Source,$"ground-smrf-{cloud.SurfaceStep}")+".ground.csv");if(File.Exists(output))return ReadPoints(output,ct);
        string input=output+".input.csv",pending=output+".pending.csv";
        try{await WritePoints(input,cloud.LowSamples,ct);await Pipeline([new{type="readers.text",filename=input},new{type="filters.smrf",cell=Math.Max(1,cloud.SurfaceStep),slope=0.3,threshold=0.5,scalar=1.25,window=18.0,returns="first,last,intermediate,only"},new{type="filters.expression",expression="Classification == 2"},Writer(pending)],ct);var points=ReadPoints(pending,ct);if(points.Count<3)throw new InvalidOperationException("자동 추출 지면이 부족합니다. 입력 자료와 지형을 확인하세요.");ct.ThrowIfCancellationRequested();File.Move(pending,output,true);return points;}finally{File.Delete(input);File.Delete(pending);}
    }
    public sealed record TinMesh(List<CadPoint> Points,List<(int A,int B,int C)> Faces);
    public static async Task<TinMesh> Triangulate(List<CadPoint> points,CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();Directory.CreateDirectory(CacheDirectory);
        string input=Path.Combine(CacheDirectory,Guid.NewGuid()+".tin.csv"),output=input+".ply";
        try
        {
            await WritePoints(input,points,ct);
            await Pipeline([new{type="readers.text",filename=input},new{type="filters.delaunay"},new{type="writers.ply",filename=output,faces=true,storage_mode="ascii",dims="X,Y,Z",precision=12}],ct);
            using var reader=new StreamReader(output);if(reader.ReadLine()!="ply")throw new InvalidDataException("TIN 출력 형식 오류");
            int vertexCount=0,faceCount=0;bool headerDone=false;string? line;
            while((line=reader.ReadLine()) is not null)
            {
                ct.ThrowIfCancellationRequested();var tokens=line.Split(' ',StringSplitOptions.RemoveEmptyEntries);
                if(line.StartsWith("element vertex "))vertexCount=int.Parse(tokens[2],CultureInfo.InvariantCulture);
                if(line.StartsWith("element face "))faceCount=int.Parse(tokens[2],CultureInfo.InvariantCulture);
                if(line=="end_header"){headerDone=true;break;}
            }
            if(!headerDone||vertexCount!=points.Count||faceCount<=0)throw new InvalidOperationException("TIN 삼각망을 만들 수 없습니다. 점들이 한 직선에 있는지 확인하세요.");
            var vertices=new List<CadPoint>(vertexCount);var faces=new List<(int,int,int)>(faceCount);
            for(int i=0;i<vertexCount;i++){ct.ThrowIfCancellationRequested();var t=(reader.ReadLine()??throw new InvalidDataException("TIN 꼭짓점 누락")).Split(' ',StringSplitOptions.RemoveEmptyEntries);vertices.Add(new(double.Parse(t[0],CultureInfo.InvariantCulture),double.Parse(t[1],CultureInfo.InvariantCulture),double.Parse(t[2],CultureInfo.InvariantCulture)));}
            for(int i=0;i<faceCount;i++){ct.ThrowIfCancellationRequested();var t=(reader.ReadLine()??throw new InvalidDataException("TIN 삼각형 누락")).Split(' ',StringSplitOptions.RemoveEmptyEntries);if(t.Length!=4||t[0]!="3")throw new InvalidDataException("TIN 삼각형 형식 오류");int a=int.Parse(t[1],CultureInfo.InvariantCulture),b=int.Parse(t[2],CultureInfo.InvariantCulture),c=int.Parse(t[3],CultureInfo.InvariantCulture);if(a<0||b<0||c<0||a>=vertexCount||b>=vertexCount||c>=vertexCount)throw new InvalidDataException("TIN 꼭짓점 참조 오류");faces.Add((a,b,c));}
            return new(vertices,faces);
        }
        finally{File.Delete(input);File.Delete(output);}
    }}




