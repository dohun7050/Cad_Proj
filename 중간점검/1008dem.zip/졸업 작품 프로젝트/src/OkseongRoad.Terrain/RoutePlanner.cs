﻿using ForestRoad.Cad;
namespace OkseongRoad.Terrain;
public record Station(double Distance, double X, double Y, double Z);
public record RoadRoute(List<CadPoint> Vertices, List<Station> Stations, double Length, double MaximumAngle);
public static class RoutePlanner
{
    // Primitive integer offsets provide 48 headings, including shallow contour-following
    // directions unavailable on an eight-neighbor grid. Each entire edge is validated.
    public static readonly IReadOnlyList<(int X,int Y)> Directions =
        (from y in Enumerable.Range(-4,9)
         from x in Enumerable.Range(-4,9)
         where (x!=0||y!=0) && Gcd(Math.Abs(x),Math.Abs(y))==1
         orderby x*x+y*y
         select (x,y)).ToArray();
    static int Gcd(int a,int b){while(b!=0){(a,b)=(b,a%b);}return a;}
    public static double Distance(CadPoint a,CadPoint b)=>Math.Sqrt((a.X-b.X)*(a.X-b.X)+(a.Y-b.Y)*(a.Y-b.Y));
    public static bool Allowed(TerrainGrid grid,CadPoint a,CadPoint b,double angle,out double peak)
    {
        peak=0; double length=Distance(a,b);
        if(length<1e-9) return Math.Abs(a.Z-b.Z)<1e-7;
        // Bilinear terrain is quadratic along a straight segment. Check analytic derivatives
        // within each crossed grid cell, including both sides of grid boundaries.
        var cuts=new List<double>{0,1};
        if(Math.Abs(b.X-a.X)>1e-9)
            for(int i=(int)Math.Ceiling((Math.Min(a.X,b.X)-grid.X)/grid.Step);i<=(int)Math.Floor((Math.Max(a.X,b.X)-grid.X)/grid.Step);i++)
            {double t=(grid.X+i*grid.Step-a.X)/(b.X-a.X);if(t>1e-9 && t<1-1e-9)cuts.Add(t);}
        if(Math.Abs(b.Y-a.Y)>1e-9)
            for(int j=(int)Math.Ceiling((Math.Min(a.Y,b.Y)-grid.Y)/grid.Step);j<=(int)Math.Floor((Math.Max(a.Y,b.Y)-grid.Y)/grid.Step);j++)
            {double t=(grid.Y+j*grid.Step-a.Y)/(b.Y-a.Y);if(t>1e-9 && t<1-1e-9)cuts.Add(t);}
        cuts=cuts.Distinct().Order().ToList();
        for(int k=1;k<cuts.Count;k++)
        {
            double t0=cuts[k-1],t1=cuts[k],dt=t1-t0;if(dt<1e-10)continue;
            CadPoint? P(double t)=>grid.At(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t);
            var p0=P(t0);var pm=P((t0+t1)/2);var p1=P(t1);
            if(p0 is null || pm is null || p1 is null) return false;
            double dz=p1.Z-p0.Z, curvature=p1.Z+p0.Z-2*pm.Z;
            double slope=Math.Max(Math.Abs(dz-2*curvature),Math.Abs(dz+2*curvature))/(length*dt);
            peak=Math.Max(peak,Math.Atan(slope)*180/Math.PI);
            if(peak>angle+1e-7)return false;
        }
        return true;
    }
    public static RoadRoute Find(TerrainGrid grid,CadPoint start,CadPoint end,double angle=10,double stationSpacing=20,CancellationToken ct=default)
        =>FindCore(grid,start,end,angle,stationSpacing,ct,null,null);
    static RoadRoute FindCore(TerrainGrid grid,CadPoint start,CadPoint end,double angle,double stationSpacing,CancellationToken ct,double[]? penalties,Dictionary<long,bool>? edges,double turnWeight=0)
    {
        if(!double.IsFinite(angle)||angle<=0||angle>=90||!double.IsFinite(stationSpacing)||stationSpacing<=0)throw new ArgumentException("경사각과 점 간격을 확인하세요.");
        start=grid.At(start.X,start.Y)??throw new InvalidOperationException("시작점이 고도 자료 범위 밖이거나 고도 자료가 없습니다.");
        end=grid.At(end.X,end.Y)??throw new InvalidOperationException("종점이 고도 자료 범위 밖이거나 고도 자료가 없습니다.");
        if(Distance(start,end)<0.001)throw new InvalidOperationException("시작점과 종점을 다르게 지정하세요.");
        int n=grid.Values.Length;var cost=Enumerable.Repeat(double.PositiveInfinity,n).ToArray();var parent=Enumerable.Repeat(-2,n).ToArray();
        var queue=new PriorityQueue<(int Id,double Cost),double>();
        // Connect exact user coordinates to nearby nodes, preserving exact endpoints.
        int sx=(int)Math.Round((start.X-grid.X)/grid.Step),sy=(int)Math.Round((start.Y-grid.Y)/grid.Step);
        for(int dy=-4;dy<=4;dy++)for(int dx=-4;dx<=4;dx++)
        {
            int x=sx+dx,y=sy+dy;if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;
            int id=y*grid.Width+x;var p=grid.Node(id);
            if(!double.IsFinite(p.Z)||!Allowed(grid,start,p,angle,out _))continue;
            double c=Distance(start,p)*(1+(penalties?[id]??0));cost[id]=c;parent[id]=-1;queue.Enqueue((id,c),c+Distance(p,end));
        }
        if(queue.Count==0)throw new InvalidOperationException($"시작점 부근에서 {angle:F1}° 이하로 격자에 진입할 수 없습니다. 시작점을 완만한 위치로 옮겨 보세요. 고도 보간과 XY·Z 단위도 확인해야 합니다.");
        var goalCosts=new Dictionary<int,double>();
        int ex=(int)Math.Round((end.X-grid.X)/grid.Step),ey=(int)Math.Round((end.Y-grid.Y)/grid.Step);
        for(int dy=-6;dy<=6;dy++)for(int dx=-6;dx<=6;dx++)
        {
            ct.ThrowIfCancellationRequested();
            int x=ex+dx,y=ey+dy;if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;
            int id=y*grid.Width+x;var p=grid.Node(id);double distance=Distance(p,end);
            if(double.IsFinite(p.Z)&&distance<=grid.Step*6&&Allowed(grid,p,end,angle,out _))goalCosts[id]=distance*(1+(penalties?[id]??0));
        }
        if(goalCosts.Count==0)throw new InvalidOperationException($"종점 부근에서 {angle:F1}° 이하로 종점에 연결할 수 없습니다. 종점을 완만한 위치로 옮겨 보세요. 고도 보간과 XY·Z 단위도 확인해야 합니다.");
        int last=-1;double best=double.PositiveInfinity;
        while(queue.TryDequeue(out var item,out double priority))
        {
            ct.ThrowIfCancellationRequested();if(priority>=best)break;
            int id=item.Id;if(item.Cost>cost[id]+1e-9)continue;var a=grid.Node(id);
            if(goalCosts.TryGetValue(id,out double final))
            {double candidate=cost[id]+final;if(candidate<best){best=candidate;last=id;}}
            foreach(var (dx,dy) in Directions)
            {
                if(dx==0&&dy==0)continue;int x=id%grid.Width+dx,y=id/grid.Width+dy;
                if(x<0||y<0||x>=grid.Width||y>=grid.Height)continue;int next=y*grid.Width+x;var b=grid.Node(next);
                if(!double.IsFinite(b.Z))continue;
                var previous=parent[id]>=0?grid.Node(parent[id]):start;
                double turn=RoadGeometry.Turn(previous,a,b);
                double candidate=cost[id]+Distance(a,b)*(1+((penalties?[id]??0)+(penalties?[next]??0))/2)+turnWeight*turn*turn;if(candidate>=cost[next])continue;
                long key=((long)Math.Min(id,next)<<32)|(uint)Math.Max(id,next);
                bool permitted;if(edges is null)permitted=Allowed(grid,a,b,angle,out _);
                else if(!edges.TryGetValue(key,out permitted)){permitted=Allowed(grid,a,b,angle,out _);if(edges.Count<1_000_000)edges[key]=permitted;}
                if(!permitted)continue;
                cost[next]=candidate;parent[next]=id;queue.Enqueue((next,candidate),candidate+Distance(b,end));
            }
        }
        if(last<0)throw new InvalidOperationException($"{angle:F1}° 이하 조건으로 두 지점을 연결하지 못했습니다.\n시작점에서 도달한 격자 노드 {cost.Count(double.IsFinite):N0}개 / 전체 유효 노드 {grid.Values.Count(double.IsFinite):N0}개\n경사 제한과 고도 결측 구간 때문에 연결 영역이 나뉠 수 있습니다. 완만한 위치의 시작·종점, XY·Z 단위, 고도 자료를 확인하세요. 이 결과는 현재 보간 격자와 탐색 방향에서의 판단입니다.");
        var route=new List<CadPoint>{end};for(int id=last;id>=0;id=parent[id])route.Add(grid.Node(id));route.Add(start);route.Reverse();
        for(int i=route.Count-1;i>0;i--)if(Distance(route[i-1],route[i])<1e-8)route.RemoveAt(i);
        double peak=0,length=0;foreach(var (a,b) in route.Zip(route.Skip(1)))
        {if(!Allowed(grid,a,b,angle,out double local))throw new InvalidOperationException("최종 경사 검증 실패");peak=Math.Max(peak,local);length+=Distance(a,b);}
        // Stations mark chainage along the full bend-preserving polyline; they are not shortcuts.
        var stations=new List<Station>();int segment=1;double before=0;
        void AddStation(double d)
        {
            while(segment<route.Count-1&&before+Distance(route[segment-1],route[segment])<d-1e-8){before+=Distance(route[segment-1],route[segment]);segment++;}
            var a=route[segment-1];var b=route[segment];double t=Math.Clamp((d-before)/Distance(a,b),0,1);
            var p=grid.At(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t)??throw new InvalidOperationException("측점 고도 조회 실패");stations.Add(new Station(d,p.X,p.Y,p.Z));
        }
        for(double d=0;d<length-1e-8;d+=stationSpacing)AddStation(d);AddStation(length);
        return new RoadRoute(route,stations,length,peak);
    }
    /// <summary>Search alternative corridors by penalizing previously searched routes.
    /// All candidates retain the same endpoints and full-edge slope/NoData validation.</summary>
    public static List<RoadRoute> FindCandidates(TerrainGrid grid,CadPoint start,CadPoint end,double angle=10,int count=5,CancellationToken ct=default,IProgress<int>? progress=null,RouteQualityOptions? quality=null)
    {
        if(quality is not null&&(!double.IsFinite(quality.MinimumRadius)||quality.MinimumRadius<0||!double.IsFinite(quality.TurnWeight)||quality.TurnWeight<0))throw new ArgumentException("회전반경과 굴곡 비용은 유한한 0 이상의 값이어야 합니다.");
        if(count<1||count>5)throw new ArgumentOutOfRangeException(nameof(count));
        var accepted=new List<RoadRoute>();var explored=new List<RoadRoute>();var edges=new Dictionary<long,bool>();
        for(int attempt=0;attempt<12&&accepted.Count<count;attempt++)
        {
            ct.ThrowIfCancellationRequested();progress?.Report(attempt+1);
            double[] penalties=new double[grid.Values.Length];
            foreach(var old in explored)
            {
                var marked=new HashSet<int>();
                foreach(var (a,b) in old.Vertices.Zip(old.Vertices.Skip(1)))
                {
                    int steps=Math.Max(1,(int)Math.Ceiling(Distance(a,b)/grid.Step));
                    for(int k=0;k<=steps;k++)
                    {
                        ct.ThrowIfCancellationRequested();double t=(double)k/steps;
                        var p=new CadPoint(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t,0);
                        if(Distance(p,start)<grid.Step*5||Distance(p,end)<grid.Step*5)continue;
                        int x=(int)Math.Round((p.X-grid.X)/grid.Step),y=(int)Math.Round((p.Y-grid.Y)/grid.Step);
                        for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++)
                        {int u=x+dx,v=y+dy;if(u>=0&&v>=0&&u<grid.Width&&v<grid.Height&&dx*dx+dy*dy<=9)marked.Add(v*grid.Width+u);}
                    }
                }
                foreach(int id in marked)penalties[id]+=4;
            }
            var candidate=FindCore(grid,start,end,angle,20,ct,penalties,edges,quality?.TurnWeight??0);explored.Add(candidate);
            if(quality is not null){var smooth=RoadGeometry.Smooth(grid,candidate,angle,quality.MinimumRadius,ct);if(smooth is null)continue;candidate=smooth;}
            if(accepted.All(r=>DistinctCorridor(candidate,r,grid.Step*2,ct)))accepted.Add(candidate);
        }
        if(accepted.Count==0)throw new InvalidOperationException("경사와 최소 회전반경을 동시에 만족하는 후보를 찾지 못했습니다. 반경·격자 간격·시작/종점을 조정하세요. 조건을 자동으로 완화하지 않습니다.");
        return accepted.OrderBy(r=>r.Length).ToList();
    }
    public static bool DistinctCorridor(RoadRoute a,RoadRoute b,double tolerance,CancellationToken ct=default)
    {
        double different=0,total=0;
        foreach(var (p,q) in a.Vertices.Zip(a.Vertices.Skip(1)))
        {
            ct.ThrowIfCancellationRequested();double length=Distance(p,q);int pieces=Math.Max(1,(int)Math.Ceiling(length/Math.Max(1,tolerance)));
            for(int i=0;i<pieces;i++)
            {
                double t=(i+0.5)/pieces;var point=new CadPoint(p.X+(q.X-p.X)*t,p.Y+(q.Y-p.Y)*t,0);
                double nearest=double.PositiveInfinity;
                foreach(var (u,v) in b.Vertices.Zip(b.Vertices.Skip(1)))
                {
                    double dx=v.X-u.X,dy=v.Y-u.Y,den=dx*dx+dy*dy;
                    double f=den==0?0:Math.Clamp(((point.X-u.X)*dx+(point.Y-u.Y)*dy)/den,0,1);
                    nearest=Math.Min(nearest,Distance(point,new CadPoint(u.X+f*dx,u.Y+f*dy,0)));
                }
                total+=length/pieces;if(nearest>tolerance)different+=length/pieces;
            }
        }
        return total>0&&different/total>=0.15;
    }

}
