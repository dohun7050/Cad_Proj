using ForestRoad.Cad;
namespace OkseongRoad.Terrain;

public sealed class TerrainGrid
{
    public double X { get; }
    public double Y { get; }
    public double Step { get; }
    public int Width { get; }
    public int Height { get; }
    public double[] Values { get; }
    public TerrainGrid(double x, double y, double step, int width, int height, double[] values)
    {
        if (!double.IsFinite(step) || step <= 0 || width < 2 || height < 2 || values.Length != width*height) throw new ArgumentException("지형 격자가 잘못되었습니다.");
        X=x; Y=y; Step=step; Width=width; Height=height; Values=values;
    }
    public CadPoint Node(int index) => new(X+index%Width*Step, Y+index/Width*Step, Values[index]);
    public CadPoint? At(double x, double y)
    {
        double u=(x-X)/Step, v=(y-Y)/Step;
        if (u < -1e-8 || v < -1e-8 || u > Width-1+1e-8 || v > Height-1+1e-8) return null;
        u=Math.Clamp(u,0,Width-1); v=Math.Clamp(v,0,Height-1);
        int a=Math.Min((int)u,Width-2), b=Math.Min((int)v,Height-2); double fx=u-a, fy=v-b;
        double z=0;
        foreach(var (id,w) in new[] { (b*Width+a,(1-fx)*(1-fy)), (b*Width+a+1,fx*(1-fy)), ((b+1)*Width+a,(1-fx)*fy), ((b+1)*Width+a+1,fx*fy) })
        {
            if(w < 1e-12) continue;
            if(!double.IsFinite(Values[id])) return null;
            z+=Values[id]*w;
        }
        return new CadPoint(x,y,z);
    }
    public static TerrainGrid Build(IEnumerable<CadPoint> source, double step, CancellationToken ct=default)
    {
        // Two passes over a repeatable source avoid retaining another full LAS point list.
        double x=double.PositiveInfinity,y=x,maxX=double.NegativeInfinity,maxY=maxX;long count=0;
        foreach(var p in source)
        {
            ct.ThrowIfCancellationRequested();count++;
            x=Math.Min(x,p.X);y=Math.Min(y,p.Y);maxX=Math.Max(maxX,p.X);maxY=Math.Max(maxY,p.Y);
        }
        if(count<3) throw new InvalidOperationException("고도 자료가 부족합니다. LAS 지면점 또는 Z가 있는 등고선 레이어를 선택하세요.");
        double spanX=maxX-x, spanY=maxY-y;
        if(spanX<step || spanY<step) throw new InvalidOperationException("지형 범위가 격자 간격보다 작습니다.");
        double w=Math.Ceiling(spanX/step)+1,h=Math.Ceiling(spanY/step)+1;
        if(w*h>250_000) throw new InvalidOperationException("격자가 25만 셀을 초과합니다. 격자 간격을 늘리거나 입력 범위를 줄이세요.");
        int width=(int)w,height=(int)h;
        // Aggregate samples into small bins before IDW; limits dense LAS bucket scans.
        double bin=step/2;
        var aggregates=new Dictionary<(int,int),(double X,double Y,double Z,int N)>();
        foreach(var p in source)
        {
            ct.ThrowIfCancellationRequested();
            var key=((int)Math.Floor((p.X-x)/bin),(int)Math.Floor((p.Y-y)/bin));
            var a=aggregates.GetValueOrDefault(key); aggregates[key]=(a.X+p.X,a.Y+p.Y,a.Z+p.Z,a.N+1);
        }
        var buckets=aggregates.ToDictionary(a=>a.Key,a=>new CadPoint(a.Value.X/a.Value.N,a.Value.Y/a.Value.N,a.Value.Z/a.Value.N));
        var z=Enumerable.Repeat(double.NaN,width*height).ToArray();
        double radius=step*3;
        for(int j=0;j<height;j++) for(int i=0;i<width;i++)
        {
            ct.ThrowIfCancellationRequested();
            double px=x+i*step,py=y+j*step;
            if(px>x+spanX+1e-8 || py>y+spanY+1e-8) continue; // no extrapolation past data rectangle
            var nearest=new List<(double D,double Z)>();
            int bx=(int)Math.Floor((px-x)/bin),by=(int)Math.Floor((py-y)/bin);
            for(int dy=-6;dy<=6;dy++) for(int dx=-6;dx<=6;dx++)
                if(buckets.TryGetValue((bx+dx,by+dy),out var p))
                {
                    double d=(p.X-px)*(p.X-px)+(p.Y-py)*(p.Y-py);
                    if(d<=radius*radius) nearest.Add((d,p.Z));
                }
            var list=nearest.OrderBy(p=>p.D).Take(8).ToList();
            if(list.Count==0) continue;
            if(list[0].D<1e-12) { z[j*width+i]=list[0].Z; continue; }
            // Require support around query; leave unsupported edges/holes as NoData.
            if(list.Count<3) continue;
            double weight=0,sum=0;
            foreach(var p in list) { double ww=1/p.D; weight+=ww; sum+=p.Z*ww; }
            z[j*width+i]=sum/weight;
        }
        return new TerrainGrid(x,y,step,width,height,z);
    }
    public static IEnumerable<CadPoint> ContourSamples(IEnumerable<CadFeature> lines,double spacing=2,DemOptions? bounds=null,CancellationToken ct=default)
    {
        if(!double.IsFinite(spacing)||spacing<=0)throw new ArgumentException("등고선 표본 간격이 잘못되었습니다.");
        foreach(var f in lines.Where(f=>f.Text is null&&f.Points.Count>1))
        {
            ct.ThrowIfCancellationRequested();double height=f.Points[0].Z;
            foreach(var p in f.Points){ct.ThrowIfCancellationRequested();if(!double.IsFinite(p.X)||!double.IsFinite(p.Y)||!double.IsFinite(p.Z)||Math.Abs(p.Z-height)>0.01)throw new InvalidOperationException($"{f.Layer}에 유효하지 않거나 고도가 일정하지 않은 선이 있습니다. 등고선 레이어만 선택하세요.");}
            for(int i=1;i<f.Points.Count;i++)
            {
                ct.ThrowIfCancellationRequested();var a=f.Points[i-1];var b=f.Points[i];double dx=b.X-a.X,dy=b.Y-a.Y,t0=0,t1=1;
                // Clip before sampling so outside geometry never expands into unnecessary points.
                bool Clip(double p,double q){if(p==0)return q>=0;double t=q/p;if(p<0){if(t>t1)return false;t0=Math.Max(t0,t);}else{if(t<t0)return false;t1=Math.Min(t1,t);}return true;}
                if(bounds is {} r&&(!Clip(-dx,a.X-r.MinX)||!Clip(dx,r.MaxX-a.X)||!Clip(-dy,a.Y-r.MinY)||!Clip(dy,r.MaxY-a.Y)))continue;
                double ax=a.X+dx*t0,ay=a.Y+dy*t0,bx=a.X+dx*t1,by=a.Y+dy*t1;
                if(bounds is {} region){ax=Math.Clamp(ax,region.MinX,region.MaxX);bx=Math.Clamp(bx,region.MinX,region.MaxX);ay=Math.Clamp(ay,region.MinY,region.MaxY);by=Math.Clamp(by,region.MinY,region.MaxY);}
                double count=Math.Max(1,Math.Ceiling(Math.Sqrt((bx-ax)*(bx-ax)+(by-ay)*(by-ay))/spacing-1e-8));
                if(!double.IsFinite(count)||count>int.MaxValue-1)throw new InvalidOperationException("등고선 범위와 실제 단위를 확인하세요.");
                int n=(int)count;
                for(int k=0;k<=n;k++){ct.ThrowIfCancellationRequested();double t=(double)k/n;yield return new CadPoint(ax+(bx-ax)*t,ay+(by-ay)*t,height);}
            }
        }
    }
    public List<CadFeature> Contours(double interval=0.5)
    {
        var result=new List<CadFeature>();
        for(int j=0;j<Height-1;j++) for(int i=0;i<Width-1;i++)
        {
            var a=Node(j*Width+i);var b=Node(j*Width+i+1);var c=Node((j+1)*Width+i+1);var d=Node((j+1)*Width+i);
            Triangle(a,b,c);Triangle(a,c,d);
        }
        return result;
        void Triangle(CadPoint a,CadPoint b,CadPoint c)
        {
            if(new[]{a,b,c}.Any(p=>!double.IsFinite(p.Z))) return;
            double lo=Math.Min(a.Z,Math.Min(b.Z,c.Z)),hi=Math.Max(a.Z,Math.Max(b.Z,c.Z));
            if((hi-lo)/interval>2000) throw new InvalidOperationException("셀 고도차가 너무 큽니다. LAS 단위를 확인하세요.");
            for(double z=Math.Ceiling(lo/interval)*interval;z<hi;z+=interval)
            {
                var hits=new List<CadPoint>();
                foreach(var (p,q) in new[]{(a,b),(b,c),(c,a)})
                    if((p.Z<=z && q.Z>z)||(q.Z<=z && p.Z>z))
                    { double t=(z-p.Z)/(q.Z-p.Z);hits.Add(new CadPoint(p.X+(q.X-p.X)*t,p.Y+(q.Y-p.Y)*t,z)); }
                if(hits.Count==2) result.Add(new CadFeature("LAS 등고선","Contour",hits));
                if(result.Count>500_000) throw new InvalidOperationException("등고선이 50만 구간을 초과합니다. 입력 범위를 줄이세요.");
            }
        }
    }
}


