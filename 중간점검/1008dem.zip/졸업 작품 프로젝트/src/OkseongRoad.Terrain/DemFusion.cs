using ForestRoad.Cad;
namespace OkseongRoad.Terrain;
public static class DemFusion
{
    // Each source contributes one mean per half-resolution cell so LAS point density
    // cannot overwhelm the contour measurements merely by containing more records.
    public static List<CadPoint> Combine(IEnumerable<CadPoint> las,IEnumerable<CadPoint> cad,DemOptions options,CancellationToken ct=default)
    {
        Dictionary<(long,long),(double X,double Y,double Z,long N)> Aggregate(IEnumerable<CadPoint> source)
        {
            var cells=new Dictionary<(long,long),(double X,double Y,double Z,long N)>();double bin=options.Resolution/2;
            foreach(var p in source){ct.ThrowIfCancellationRequested();if(!double.IsFinite(p.X)||!double.IsFinite(p.Y)||!double.IsFinite(p.Z)||p.X<options.MinX||p.X>options.MaxX||p.Y<options.MinY||p.Y>options.MaxY)continue;var key=((long)Math.Floor((p.X-options.MinX)/bin),(long)Math.Floor((p.Y-options.MinY)/bin));var a=cells.GetValueOrDefault(key);cells[key]=(a.X+p.X,a.Y+p.Y,a.Z+p.Z,a.N+1);}return cells;
        }
        var a=Aggregate(las);var b=Aggregate(cad);if(a.Count<3||b.Count<3)throw new InvalidOperationException("통합 DEM 범위 안에 LAS 지면점과 CAD 등고선 표본이 각각 3개 이상 필요합니다.");
        var result=new List<CadPoint>(a.Count+b.Count);
        foreach(var pair in a){ct.ThrowIfCancellationRequested();var p=pair.Value;if(b.Remove(pair.Key,out var q))result.Add(new((p.X/p.N+q.X/q.N)/2,(p.Y/p.N+q.Y/q.N)/2,(p.Z/p.N+q.Z/q.N)/2));else result.Add(new(p.X/p.N,p.Y/p.N,p.Z/p.N));}
        foreach(var p in b.Values){ct.ThrowIfCancellationRequested();result.Add(new(p.X/p.N,p.Y/p.N,p.Z/p.N));}return result;
    }
}
