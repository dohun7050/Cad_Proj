using OkseongRoad.Terrain;
namespace OkseongRoad.App;
public sealed class ImportDialog:Form
{
    public ImportSettings? Settings {get;private set;}
    public ImportDialog(string file,string detected,string units)
    {
        Text="불러오기 · 좌표계와 실제 단위";ClientSize=new Size(580,350);StartPosition=FormStartPosition.CenterParent;Font=new Font("맑은 고딕",9);AutoScaleDimensions=new SizeF(96,96);AutoScaleMode=AutoScaleMode.Dpi;UiLayout.FitWindow(this);MinimumSize=new Size(420,300);FormBorderStyle=FormBorderStyle.Sizable;MaximizeBox=false;MinimizeBox=false;
        var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(10),AutoScroll=true,ColumnCount=2};layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,32));layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,68));Controls.Add(layout);UiLayout.FitTable(layout);
        void Row(string title,Control c,int height=28){int r=layout.RowCount++;layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));layout.Controls.Add(new Label{Text=title,AutoSize=true,Dock=DockStyle.Fill},0,r);if(c is Label label){label.AutoSize=true;}c.MinimumSize=new Size(0,c is Label?0:28);c.Dock=DockStyle.Fill;layout.Controls.Add(c,1,r);}
        Row("파일",new Label{Text=Path.GetFileName(file)});Row("파일의 단위 표기",new Label{Text=units});
        var crs=new ComboBox{DropDownStyle=ComboBoxStyle.DropDown};crs.Items.AddRange(["미확인 / 원본 위치 유지","EPSG:5186","EPSG:5179","EPSG:5185","EPSG:5187","EPSG:5181","EPSG:5174","EPSG:4326"]);crs.Text=detected.StartsWith("EPSG:")?detected:detected.StartsWith("WKT 정의:")?detected[7..].Trim():"미확인 / 원본 위치 유지";Row("원본 좌표계",crs);
        ComboBox Unit(bool xy){var c=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList};c.Items.AddRange(xy?new object[]{"미터 (m)","밀리미터 (mm)","피트 (ft)","경위도 (도)"}:new object[]{"미터 (m)","밀리미터 (mm)","피트 (ft)"});c.SelectedIndex=0;return c;}
        var horizontal=Unit(true);var vertical=Unit(false);Row("실제 XY 단위",horizontal);Row("실제 Z 단위",vertical);
        Row("프로젝트 기준",new Label{Text="EPSG:5186 / 미터 · 원본 파일은 보존"});
        Row("확인 안내",new Label{Text="DWG의 mm 표기만으로 축척을 바꾸지 않습니다.\n실제 길이를 기준으로 단위를 선택하세요.\n좌표계 미확인은 위치를 유지하며 다른 자료와 정합을 보장하지 않습니다."},66);
        var confirm=new CheckBox{Text="선택한 실제 단위를 확인했습니다."};Row("",confirm);
        layout.RowCount++;layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        var buttons=new FlowLayoutPanel{AutoSize=true,WrapContents=false};var ok=new Button{Text="불러오기",AutoSize=true,MinimumSize=new Size(90,28)};var cancel=new Button{Text="취소",AutoSize=true,MinimumSize=new Size(75,28),DialogResult=DialogResult.Cancel};buttons.Controls.AddRange([ok,cancel]);buttons.Dock=DockStyle.Bottom;buttons.Padding=new Padding(10,5,10,5);Controls.Add(buttons);AcceptButton=ok;CancelButton=cancel;
        ok.Click+=(_,_)=>{if(!confirm.Checked){MessageBox.Show(this,"실제 단위를 확인해 주세요.");return;}string source=crs.Text.StartsWith("미확인")?"":crs.Text.Trim();if(horizontal.SelectedIndex==3&&source!="EPSG:4326"){MessageBox.Show(this,"경위도 입력은 원본 EPSG:4326을 선택하세요.");return;}if(source=="EPSG:4326"&&horizontal.SelectedIndex!=3){MessageBox.Show(this,"EPSG:4326은 XY 단위를 경위도(도)로 선택하세요.");return;}double Scale(int i)=>i==1?0.001:i==2?0.3048:1;Settings=new(source,Scale(horizontal.SelectedIndex),Scale(vertical.SelectedIndex));DialogResult=DialogResult.OK;};
    }
}
