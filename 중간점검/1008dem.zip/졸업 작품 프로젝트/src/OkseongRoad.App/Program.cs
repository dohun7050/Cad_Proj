﻿namespace OkseongRoad.App;
internal static class Program
{
    [STAThread]static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();using var form=new MainForm();
        if(args.Length==3&&(args[0]=="--smoke-test"||args[0]=="--view-test"||args[0]=="--3d-test"||args[0]=="--3d-route-test"||args[0]=="--gpu-test"))
        {
            form.StartPosition=FormStartPosition.Manual;form.Location=new Point(10000,10000);
            form.Shown+=async(_,_)=>{try{if(args[0]=="--gpu-test")await form.GpuPreview(args[1],args[2]);else await form.Preview(args[1],args[2],args[0]=="--view-test"||args[0]=="--3d-test",args[0].StartsWith("--3d"));}catch(Exception e){File.WriteAllText(args[2]+".error.txt",e.ToString());Environment.ExitCode=1;}finally{form.Close();}};
        }
        Application.Run(form);
    }
}
