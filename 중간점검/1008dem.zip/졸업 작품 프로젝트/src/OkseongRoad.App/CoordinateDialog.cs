using System.Globalization;
using ForestRoad.Cad;
namespace OkseongRoad.App;

public sealed class CoordinateDialog:Form
{
    public CadPoint? Start {get;private set;}
    public CadPoint? End {get;private set;}
    public CoordinateDialog(CadPoint? start,CadPoint? end)
    {
        Text="시작점 · 종점 좌표 입력";Font=new Font("맑은 고딕",9);AutoScaleDimensions=new SizeF(96,96);AutoScaleMode=AutoScaleMode.Dpi;UiLayout.FitWindow(this);ClientSize=new Size(480,280);MinimumSize=new Size(440,300);StartPosition=FormStartPosition.CenterParent;MaximizeBox=false;MinimizeBox=false;
        var table=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,AutoScroll=true,Padding=new Padding(10)};table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,35));table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,65));Controls.Add(table);UiLayout.FitTable(table);
        string[] titles=["시작점 X","시작점 Y","종점 X","종점 Y"];double?[] values=[start?.X,start?.Y,end?.X,end?.Y];var inputs=new TextBox[4];
        for(int i=0;i<4;i++){table.RowCount++;table.RowStyles.Add(new RowStyle(SizeType.AutoSize));table.Controls.Add(UiLayout.Text(titles[i]),0,i);inputs[i]=new TextBox{Dock=DockStyle.Fill,Text=values[i]?.ToString("F3",CultureInfo.InvariantCulture)??"",Margin=new Padding(3,6,3,6)};table.Controls.Add(inputs[i],1,i);}
        table.RowCount++;table.RowStyles.Add(new RowStyle(SizeType.AutoSize));var note=UiLayout.Text("원본 XY 좌표 입력 · 고도는 지형 격자에서 자동 조회");table.Controls.Add(note,0,4);table.SetColumnSpan(note,2);
        table.RowCount++;table.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        var ok=new Button{Text="적용"};var cancel=new Button{Text="취소",DialogResult=DialogResult.Cancel};Controls.Add(UiLayout.Actions(ok,cancel));AcceptButton=ok;CancelButton=cancel;
        ok.Click+=(_,_)=>{var nums=new double[4];for(int i=0;i<4;i++)if(!double.TryParse(inputs[i].Text,NumberStyles.Float,CultureInfo.InvariantCulture,out nums[i])||!double.IsFinite(nums[i])){MessageBox.Show(this,"유한한 숫자를 입력하세요.");inputs[i].Focus();return;}
            if(Math.Abs(nums[0]-nums[2])+Math.Abs(nums[1]-nums[3])<0.001){MessageBox.Show(this,"시작점과 종점이 같습니다.");return;}Start=new(nums[0],nums[1],0);End=new(nums[2],nums[3],0);DialogResult=DialogResult.OK;};
    }
}
