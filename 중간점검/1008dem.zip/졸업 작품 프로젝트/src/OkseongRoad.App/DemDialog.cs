using System.Globalization;
using OkseongRoad.Terrain;
namespace OkseongRoad.App;
public sealed class DemDialog:Form
{
    public int SelectedSource {get;private set;}
    public DemOptions? Options {get;private set;}
    public DemDialog(DemOptions o,bool las,bool combined=false,Func<int,DemOptions>? getSourceOptions=null)
    {
        Text="DEM 생성 설정";ClientSize=new Size(560,470);StartPosition=FormStartPosition.CenterParent;Font=new Font("맑은 고딕",9);AutoScaleDimensions=new SizeF(96,96);AutoScaleMode=AutoScaleMode.Dpi;UiLayout.FitWindow(this);MinimumSize=new Size(420,300);FormBorderStyle=FormBorderStyle.Sizable;MaximizeBox=false;MinimizeBox=false;
        var root=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=2,Margin=Padding.Empty};root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.AutoSize));Controls.Add(root);
        var scroll=new Panel{Dock=DockStyle.Fill,AutoScroll=true,Margin=Padding.Empty};root.Controls.Add(scroll,0,0);
        var panel=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,ColumnCount=2,Padding=new Padding(10)};panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,45));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,55));scroll.Controls.Add(panel);UiLayout.FitTable(panel);
        void Row(string title,Control c){int r=panel.RowCount++;panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));panel.Controls.Add(new Label{Text=title,AutoSize=true,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,r);if(c is Label label){label.AutoSize=true;}c.MinimumSize=new Size(0,26);c.Dock=DockStyle.Fill;panel.Controls.Add(c,1,r);}
        NumericUpDown Numeric(decimal min,decimal max,decimal value,int decimals=0)=>new(){Minimum=min,Maximum=max,DecimalPlaces=decimals,Value=Math.Clamp(value,min,max),ThousandsSeparator=true};
        var columns=Numeric(2,125000,(decimal)Math.Ceiling((o.MaxX-o.MinX)/o.Resolution-1e-8)+1);
        var rows=Numeric(2,125000,(decimal)Math.Ceiling((o.MaxY-o.MinY)/o.Resolution-1e-8)+1);
        var resolution=Numeric(0.01m,10000,(decimal)o.Resolution,2);
        SelectedSource=combined?2:las?1:0;var input=new ComboBox{Name="DemSource",DropDownStyle=ComboBoxStyle.DropDownList,Enabled=getSourceOptions is not null};input.Items.AddRange(["DWG","LAS","LAS + DWG"]);input.SelectedIndex=SelectedSource;Row("입력 자료",input);Row("그리드 크기 X (열 수)",columns);Row("그리드 크기 Y (행 수)",rows);Row("해상도 / 셀 간격 (m)",resolution);
        var extent=new Label();Row("그리드 전체 크기 / 셀 수",extent);
        void Estimate(){extent.Text=$"{(columns.Value-1)*resolution.Value:N2} × {(rows.Value-1)*resolution.Value:N2} m / {columns.Value*rows.Value:N0}셀";}
        columns.ValueChanged+=(_,_)=>Estimate();rows.ValueChanged+=(_,_)=>Estimate();resolution.ValueChanged+=(_,_)=>Estimate();Estimate();
        var algo=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList};algo.Items.AddRange(["IDW","TIN"]);algo.SelectedItem=o.Algorithm;Row("보간 알고리즘",algo);
        var radius=Numeric(0.01m,100000,(decimal)o.Radius,2);var power=Numeric(0.1m,10,(decimal)o.Power,1);var neighbors=Numeric(3,64,o.Neighbors);
        Row("검색 반경 / TIN 최대 변 길이 (m)",radius);Row("IDW 거리 가중 지수",power);Row("IDW 최대 이웃 표본 수",neighbors);
        var ground=new CheckBox{Text="지면 사용 (없으면 자동 추출)",Checked=combined||o.GroundOnly,Enabled=las&&!combined};Row("LAS 분류 / withheld 제외",ground);
        var crs=new TextBox{Text=o.CoordinateReference,ReadOnly=true};Row("현재 좌표계 (불러오기에서 설정)",crs);var units=new CheckBox{Text="XY·Z 미터 / 투영 좌표계 확인"};Row("단위 확인",units);
        var note=new Label{Text=combined?"LAS·DWG 동일 비중 결합 / 빈 영역은 결측 처리":"빈 영역은 결측 처리"};Row("안내",note);
        var aligned=new CheckBox{Text="두 자료의 위치와 고도 기준이 일치함을 확인했습니다.",AutoSize=true};
        var footer=new TableLayoutPanel{Dock=DockStyle.Fill,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,ColumnCount=1,Padding=new Padding(10,6,10,6),Margin=Padding.Empty};footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));root.Controls.Add(footer,0,1);
        aligned.Name="AlignmentConfirmation";aligned.Dock=DockStyle.Fill;aligned.Visible=combined;footer.Controls.Add(aligned,0,0);UiLayout.FitTable(footer);
        var actions=new FlowLayoutPanel{AutoSize=true,WrapContents=false};var ok=new Button{Text="DEM 생성",AutoSize=true,MinimumSize=new Size(90,28)};var cancel=new Button{Text="취소",AutoSize=true,MinimumSize=new Size(75,28),DialogResult=DialogResult.Cancel};actions.Controls.AddRange([ok,cancel]);actions.Dock=DockStyle.Fill;actions.Padding=new Padding(0,5,0,0);footer.Controls.Add(actions,0,1);AcceptButton=ok;CancelButton=cancel;
        input.SelectedIndexChanged+=(_,_)=>
        {
            if(input.SelectedIndex==SelectedSource||getSourceOptions is null)return;
            try
            {
                var next=getSourceOptions(input.SelectedIndex);o=next;SelectedSource=input.SelectedIndex;las=SelectedSource!=0;combined=SelectedSource==2;
                columns.Value=Math.Clamp((decimal)Math.Ceiling((o.MaxX-o.MinX)/(double)resolution.Value-1e-8)+1,columns.Minimum,columns.Maximum);
                rows.Value=Math.Clamp((decimal)Math.Ceiling((o.MaxY-o.MinY)/(double)resolution.Value-1e-8)+1,rows.Minimum,rows.Maximum);
                crs.Text=o.CoordinateReference;ground.Enabled=las&&!combined;ground.Checked=true;aligned.Visible=combined;aligned.Checked=false;units.Checked=false;
                note.Text=combined?"LAS·DWG 동일 비중 결합 / 빈 영역은 결측 처리":"빈 영역은 결측 처리";
            }
            catch(Exception e){input.SelectedIndex=SelectedSource;MessageBox.Show(this,e.Message,"입력 자료 확인");}
        };        void UpdateAlgorithm(){power.Enabled=neighbors.Enabled=algo.Text=="IDW";}algo.SelectedIndexChanged+=(_,_)=>UpdateAlgorithm();UpdateAlgorithm();
        ok.Click+=(_,_)=>{if(combined&&!aligned.Checked){MessageBox.Show(this,"통합 전에 두 자료의 위치와 고도 기준을 확인하세요.");return;}if(columns.Value*rows.Value>250000){MessageBox.Show(this,"그리드가 25만 셀을 초과합니다. 행 또는 열 수를 줄이세요.");return;}if(!units.Checked||string.IsNullOrWhiteSpace(crs.Text)){MessageBox.Show(this,"좌표계를 입력하고 미터 단위를 확인하세요.");return;}
            double step=(double)resolution.Value;Options=new(o.MinX,o.MinY,o.MinX+((int)columns.Value-1)*step,o.MinY+((int)rows.Value-1)*step,step,algo.Text,(double)power.Value,(int)neighbors.Value,(double)radius.Value,crs.Text.Trim(),ground.Checked,-9999);DialogResult=DialogResult.OK;};
    }
}






