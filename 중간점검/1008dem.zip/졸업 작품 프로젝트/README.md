# 옥성임도 C# Windows Forms

Visual Studio에서 `OkseongRoad.sln`을 열고 `OkseongRoad.App`을 시작 프로젝트로 설정하세요. Debug / x64를 선택하고 F5로 실행합니다.

.NET 8 이상 SDK와 Visual Studio의 .NET 데스크톱 개발 워크로드가 필요합니다.

- `src/OkseongRoad.App`: Windows Forms 화면, 2D/3D, GPU 전체 점군 표시
- `src/OkseongRoad.Terrain`: LAS 읽기, DEM, 후보 경로와 경사·반경 검사
- `src/OkseongRoad.Cad`: DWG/DXF 읽기
- `lib`: 빌드와 실행에 필요한 ACadSharp, OpenTK, Windows x64 GLFW DLL

파일 / 보기에서 DWG/DXF 또는 LAS를 직접 여세요. LAS는 원본을 압축·변환·수정하지 않고 전체 점군을 자동 표시합니다. DEM·경로 계산용 지면 자료는 별도로 사용합니다. GPU 메모리가 부족하면 오류를 표시하며 원본 화면의 점을 자동 생략하지 않습니다.

BAT/CMD, 이전 프로젝트·백업·ZIP·테스트·임시 자료와 빌드 결과를 삭제하고 최종 C# 프로젝트만 정리했습니다. `bin`과 `obj`는 Visual Studio 빌드 시 다시 생성됩니다. 외부 데이터 원본은 Downloads 폴더에서 직접 선택합니다.
