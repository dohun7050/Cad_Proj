using ForestRoad.Cad;
namespace OkseongRoad.Terrain;

public record RouteQualityOptions(double MinimumRadius=10,double TurnWeight=15);
public record RouteMetrics(double AverageAngle,int BendCount,double MinimumRadius);
public static class RoadGeometry
{
    public static double Turn(CadPoint a,CadPoint b,CadPoint c)
    {
        double u=RoutePlanner.Distance(a,b),v=RoutePlanner.Distance(b,c);
        if(u*v<1e-10)return 0;
        return Math.Acos(Math.Clamp(((b.X-a.X)*(c.X-b.X)+(b.Y-a.Y)*(c.Y-b.Y))/(u*v),-1,1));
    }
    public static RoadRoute? Smooth(TerrainGrid grid,RoadRoute raw,double angle,double radius,CancellationToken ct=default)
    {
        if(!double.IsFinite(radius)||radius<0)throw new ArgumentOutOfRangeException(nameof(radius));
        // Remove unnecessary grid zigzags only when the complete shortcut is valid.
        var reduced=new List<CadPoint>{raw.Vertices[0]};int at=0;
        while(at<raw.Vertices.Count-1)
        {
            ct.ThrowIfCancellationRequested();int next=at+1;
            for(int j=raw.Vertices.Count-1;j>at+1;j--)
                if(InCorridor(raw.Vertices,at,j,grid.Step*0.75)&&RoutePlanner.Allowed(grid,raw.Vertices[at],raw.Vertices[j],angle,out _)){next=j;break;}
            reduced.Add(raw.Vertices[next]);at=next;
        }
        var tangent=new double[reduced.Count];
        for(int i=1;i<reduced.Count-1;i++)
        {
            double turn=Turn(reduced[i-1],reduced[i],reduced[i+1]);if(turn>Math.PI-0.001)return null;
            tangent[i]=radius*Math.Tan(turn/2);
        }
        for(int i=1;i<reduced.Count;i++)if(tangent[i-1]+tangent[i]>RoutePlanner.Distance(reduced[i-1],reduced[i])-1e-6)return null;
        var points=new List<CadPoint>{reduced[0]};
        for(int i=1;i<reduced.Count-1;i++)
        {
            ct.ThrowIfCancellationRequested();var a=reduced[i-1];var b=reduced[i];var c=reduced[i+1];double turn=Turn(a,b,c);
            if(radius==0||turn<1e-6){points.Add(b);continue;}
            double l=RoutePlanner.Distance(a,b),m=RoutePlanner.Distance(b,c),ux=(b.X-a.X)/l,uy=(b.Y-a.Y)/l,vx=(c.X-b.X)/m,vy=(c.Y-b.Y)/m;
            double sign=Math.Sign(ux*vy-uy*vx);if(sign==0){points.Add(b);continue;}
            double x=b.X-ux*tangent[i],y=b.Y-uy*tangent[i];
            double cx=x-sign*uy*radius,cy=y+sign*ux*radius,theta=Math.Atan2(y-cy,x-cx);
            int samples=Math.Max(2,(int)Math.Ceiling(radius*turn/Math.Min(0.5,grid.Step/4)));
            for(int k=0;k<=samples;k++)
            {
                double t=theta+sign*turn*k/samples;var p=grid.At(cx+radius*Math.Cos(t),cy+radius*Math.Sin(t));if(p is null)return null;points.Add(p);
            }
        }
        points.Add(reduced[^1]);
        var result=Create(grid,points,angle,ct);if(result is null)return null;
        // Circumcircle checks also catch unintended tight corners between neighboring fillets.
        if(radius>0&&Metrics(result).MinimumRadius<radius*(1-1e-4))return null;
        return result;
    }
    static bool InCorridor(List<CadPoint> points,int a,int b,double tolerance)
    {
        var u=points[a];var v=points[b];double dx=v.X-u.X,dy=v.Y-u.Y,den=dx*dx+dy*dy;
        for(int i=a+1;i<b;i++){var p=points[i];double t=den==0?0:Math.Clamp(((p.X-u.X)*dx+(p.Y-u.Y)*dy)/den,0,1);if(Math.Sqrt(Math.Pow(p.X-u.X-t*dx,2)+Math.Pow(p.Y-u.Y-t*dy,2))>tolerance)return false;}
        return true;
    }
    public static List<Station> Profile(TerrainGrid grid,RoadRoute route)
    {
        var result=new List<Station>();double chainage=0;
        foreach(var (a,b) in route.Vertices.Zip(route.Vertices.Skip(1)))
        {
            double length=RoutePlanner.Distance(a,b);int count=Math.Max(1,(int)Math.Ceiling(length/Math.Max(0.5,Math.Min(1,grid.Step/4))));
            for(int i=0;i<count;i++){double t=(double)i/count;var p=grid.At(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t)!;result.Add(new(chainage+length*t,p.X,p.Y,p.Z));}chainage+=length;
        }
        var end=route.Vertices[^1];result.Add(new(chainage,end.X,end.Y,end.Z));return result;
    }
    public static RoadRoute? Create(TerrainGrid grid,List<CadPoint> input,double angle,CancellationToken ct=default)
    {
        var points=new List<CadPoint>();foreach(var point in input){var p=grid.At(point.X,point.Y);if(p is null)return null;if(points.Count==0||RoutePlanner.Distance(points[^1],p)>1e-7)points.Add(p);}
        if(points.Count<2)return null;double length=0,peak=0;
        foreach(var (a,b) in points.Zip(points.Skip(1)))
        {
            ct.ThrowIfCancellationRequested();
            if(!RoutePlanner.Allowed(grid,a,b,angle,out double local))return null;
            peak=Math.Max(peak,local);length+=RoutePlanner.Distance(a,b);
        }
        return new(points,Stations(grid,points,10,ct),length,peak);
    }
    public static List<Station> Stations(TerrainGrid grid,List<CadPoint> points,double spacing=10,CancellationToken ct=default)
    {
        if(!double.IsFinite(spacing)||spacing<=0)throw new ArgumentOutOfRangeException(nameof(spacing));
        double length=points.Zip(points.Skip(1)).Sum(p=>RoutePlanner.Distance(p.First,p.Second));
        if(length<=0)throw new ArgumentException("측점 경로 길이가 0입니다.");
        // Equal chainage intervals, including both endpoints, strictly below 10 metres.
        int intervals=Math.Max(1,(int)Math.Floor(length/Math.Min(10,spacing))+1);
        double step=length/intervals,before=0;int segment=1;var result=new List<Station>();
        for(int i=0;i<=intervals;i++)
        {
            ct.ThrowIfCancellationRequested();double d=i==intervals?length:i*step;
            while(segment<points.Count-1&&before+RoutePlanner.Distance(points[segment-1],points[segment])<d)
            {before+=RoutePlanner.Distance(points[segment-1],points[segment]);segment++;}
            var a=points[segment-1];var b=points[segment];double span=RoutePlanner.Distance(a,b);
            double t=span>0?Math.Clamp((d-before)/span,0,1):0;
            var p=grid.At(a.X+(b.X-a.X)*t,a.Y+(b.Y-a.Y)*t)??throw new InvalidOperationException("측점 고도 조회 실패");
            result.Add(new(d,p.X,p.Y,p.Z));
        }
        return result;
    }
    public static RouteMetrics Metrics(RoadRoute route)
    {
        double average=0,radius=double.PositiveInfinity;int bends=0;double accumulated=0;int priorSign=0;
        foreach(var (a,b) in route.Vertices.Zip(route.Vertices.Skip(1)))
        {double d=RoutePlanner.Distance(a,b);if(d>1e-8)average+=Math.Atan(Math.Abs(b.Z-a.Z)/d)*180/Math.PI*d;}
        for(int i=1;i<route.Vertices.Count-1;i++)
        {
            var a=route.Vertices[i-1];var b=route.Vertices[i];var c=route.Vertices[i+1];double cross=(b.X-a.X)*(c.Y-b.Y)-(b.Y-a.Y)*(c.X-b.X),turn=Turn(a,b,c);int sign=Math.Abs(cross)<1e-8?0:Math.Sign(cross);
            if(sign==0||sign!=priorSign){if(accumulated>Math.PI/36)bends++;accumulated=0;}accumulated+=turn;priorSign=sign;
            if(Math.Abs(cross)>1e-8)radius=Math.Min(radius,RoutePlanner.Distance(a,b)*RoutePlanner.Distance(b,c)*RoutePlanner.Distance(a,c)/(2*Math.Abs(cross)));
        }
        if(accumulated>Math.PI/36)bends++;
        return new(average/Math.Max(route.Length,1e-8),bends,radius);
    }
    public static double Overlap(RoadRoute a,RoadRoute b,double tolerance)
    {
        double shared=0,total=0;
        foreach(var (p,q) in a.Vertices.Zip(a.Vertices.Skip(1)))
        {
            double length=RoutePlanner.Distance(p,q);int pieces=Math.Max(1,(int)Math.Ceiling(length/Math.Max(1,tolerance/2)));
            for(int i=0;i<pieces;i++)
            {
                double t=(i+0.5)/pieces,x=p.X+(q.X-p.X)*t,y=p.Y+(q.Y-p.Y)*t;bool near=false;
                foreach(var (u,v) in b.Vertices.Zip(b.Vertices.Skip(1)))
                {
                    double dx=v.X-u.X,dy=v.Y-u.Y,d=dx*dx+dy*dy;double f=d==0?0:Math.Clamp(((x-u.X)*dx+(y-u.Y)*dy)/d,0,1);
                    if(Math.Sqrt(Math.Pow(x-u.X-f*dx,2)+Math.Pow(y-u.Y-f*dy,2))<=tolerance){near=true;break;}
                }
                total+=length/pieces;if(near)shared+=length/pieces;
            }
        }
        return 100*shared/Math.Max(total,1e-9);
    }
}
